#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Qurilish muhitini yangi (bo'sh) sandbox'da qayta tiklash skripti.
#
# Nima uchun kerak: JDK, Android SDK va Gradle /opt papkasida saqlanadi va
# sessiyalar orasida snapshot'ga tushmaydi. Shuning uchun har yangi sessiyada
# (yoki yangi konteynerda) shu skriptni bir marta ishga tushirish kifoya:
#
#     bash tools/setup-build-env.sh
#
# Skript idempotent: allaqachon o'rnatilgan bo'lsa, qayta yuklamaydi.
# ---------------------------------------------------------------------------
set -euo pipefail

JDK_VERSION="17"
JDK_DIR="/opt/tools/jdk-17.0.20.1+1"
GRADLE_VERSION="9.7.1"
GRADLE_DIR="/opt/tools/gradle-${GRADLE_VERSION}"
SDK_DIR="/opt/android-sdk"
CMDLINE_TOOLS_ZIP_URL="https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip"

sudo mkdir -p /opt/tools "$SDK_DIR" /opt/gradle-home
sudo chown -R "$(id -u):$(id -g)" /opt/tools "$SDK_DIR" /opt/gradle-home

# 0) Swap — 2 GB RAM li muhitda Gradle OOM bo'lmasligi uchun MAJBURIY.
#    (Faza 0 da kuzatilgan: java 1.5 GB RSS da oom-kill bilan o'ldirilgan.)
if ! grep -q "^/swapfile" /proc/swaps; then
  echo ">> Swap yoqilmoqda (4 GB)..."
  if [ ! -f /swapfile ]; then
    sudo fallocate -l 4G /swapfile || sudo dd if=/dev/zero of=/swapfile bs=1M count=4096
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile > /dev/null
  fi
  sudo /sbin/swapon /swapfile && echo ">> Swap yoqildi" || echo ">> Swap yoqib bo'lmadi (build sekin/OOM bo'lishi mumkin)"
fi

# 1) JDK 17 (Temurin)
if [ ! -x "$JDK_DIR/bin/java" ]; then
  echo ">> JDK $JDK_VERSION yuklanmoqda..."
  curl -sSL -o /opt/tools/jdk17.tar.gz \
    "https://api.adoptium.net/v3/binary/latest/${JDK_VERSION}/ga/linux/x64/jdk/hotspot/normal/eclipse"
  tar xzf /opt/tools/jdk17.tar.gz -C /opt/tools
  JDK_DIR="$(ls -d /opt/tools/jdk-17* | head -1)"
else
  echo ">> JDK allaqachon mavjud: $JDK_DIR"
fi

# 2) Gradle
if [ ! -x "$GRADLE_DIR/bin/gradle" ]; then
  echo ">> Gradle $GRADLE_VERSION yuklanmoqda..."
  curl -sSL -o /opt/tools/gradle.zip \
    "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
  unzip -q -o /opt/tools/gradle.zip -d /opt/tools
else
  echo ">> Gradle allaqachon mavjud: $GRADLE_DIR"
fi

# 3) Android SDK (platform 36 = Android 16, build-tools 36.0.0)
if [ ! -x "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo ">> Android cmdline-tools yuklanmoqda..."
  curl -sSL -o /opt/tools/cmdline-tools.zip "$CMDLINE_TOOLS_ZIP_URL"
  unzip -q -o /opt/tools/cmdline-tools.zip -d /opt/tools
  mkdir -p "$SDK_DIR/cmdline-tools"
  rm -rf "$SDK_DIR/cmdline-tools/latest"
  mv /opt/tools/cmdline-tools "$SDK_DIR/cmdline-tools/latest"
fi

export JAVA_HOME="$JDK_DIR"
export ANDROID_HOME="$SDK_DIR"

# Litsenziyalarni qabul qilish. Diqqat: sdkmanager --licenses ba'zan nol bo'lmagan
# kod qaytaradi, `set -e` tufayli skript to'xtab qolmasligi uchun `|| true`.
yes | "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK_DIR" --licenses > /dev/null 2>&1 || true
"$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK_DIR" \
  "platform-tools" "platforms;android-36" "platforms;android-37.0" "build-tools;36.0.0"

# O'rnatish haqiqatan amalga oshganini tekshirish (jim muvaffaqiyatsizlikning oldini oladi)
for p in platform-tools platforms/android-36 platforms/android-37.0 build-tools/36.0.0; do
  [ -d "$SDK_DIR/$p" ] || { echo "XATO: $SDK_DIR/$p o'rnatilmadi"; exit 1; }
done

cat <<EOF

Tayyor. Qurilish uchun:
  export JAVA_HOME=$JDK_DIR
  export ANDROID_HOME=$SDK_DIR
  export GRADLE_USER_HOME=/opt/gradle-home
  ./gradlew assembleDebug
EOF
