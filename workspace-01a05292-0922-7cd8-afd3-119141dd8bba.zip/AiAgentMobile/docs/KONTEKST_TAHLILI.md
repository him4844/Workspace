# KONTEKST TAHLILI — Android AI Coding Agent

> Bu hujjat `uploads/android-ai-agent-phased-spec.md` spetsifikatsiyasining chuqur tahlili.
> Maqsad: har bir fazaga kirishdan oldin "umuman nima qurilyapti, nima uchun shunday,
> qayerda portlashi mumkin" degan savollarga javob beradigan yagona kontekst manbai.
> Ishchi holat va qarorlar uchun `PROGRESS_LOG.md` ga qarang (bu hujjat — tahlil, log emas).

---

## 1. Nima qurilmoqda (bir gapda)

Telefonda ishlaydigan, **o'zi fayl o'qiydigan, o'zgartiradigan, build/test qilib xatosini
o'zi tuzatadigan** AI kodlash agenti — ya'ni Cursor/Aider sinfidagi vositaning Android versiyasi.

Oddiy chatbot emas: LLM "tool calling" orqali haqiqiy amallarni bajaradi
(`read_file`, `write_file`, `apply_patch`, `run_command`, `search_text`...), agent loop
bir necha qadam yuradi, foydalanuvchi esa diff orqali nazorat qiladi.

## 2. Spetsifikatsiyaning markaziy arxitektura garovi

Spetsifikatsiyaning eng muhim g'oyasi — **ikki bajarish tekisligi (execution plane)**:

| Tekislik | Nima qila oladi | Cheklovi |
|---|---|---|
| `PHONE` | SAF orqali fayl o'qish/yozish, qidiruv, Termux orqali buyruq | Haqiqiy shell yo'q, build og'ir, root yo'q |
| `COLAB` | Drive'dagi loyiha ustida haqiqiy `./gradlew build`, test, og'ir hisoblash | Ulanish vaqtinchalik (ngrok), sessiya o'ladi, fayl tizimi alohida |

Va bu ikkisining orasida **LLM asosidagi router** (Faza 6): "bu ishni qayerda bajarish
arzonroq/mumkin?" degan savolga har qadamda javob beradi. Standart javob — `COLAB`,
chunki telefon og'ir ishni ko'tarolmaydi.

Bu qaror Faza 1 da **interfeys darajasida** qo'yilgan (`ExecutionRouter`,
`RemoteExecutionEngine`, `ExecutionTarget`, `RemoteTask/Result`) — implementatsiya Faza 5-6 da.
Sabab: agar boshida arxitekturaga kiritilmasa, keyin "yopishtirib qo'yish" kerak bo'ladi va
butun agent loop qayta yoziladi.

**"Faqat natija qaytarish" printsipi** (Faza 5): Colab'dan Android'ga faqat
`success / output / errorMessage` qaytadi. Build artifaktlari, oraliq fayllar yuborilmaydi;
kerak bo'lsa Drive havolasi beriladi. Bu mobil trafik va xotira cheklovidan kelib chiqqan
to'g'ri qaror — lekin UI'da "fayl qayerda?" savoliga javob beradigan aniq holat kerak bo'ladi.

## 3. Agent uchun "kontrakt" (doimiy qoidalar xulosasi)

1. Har faza boshida `PROGRESS_LOG.md` ni **to'liq o'qish**, oxirida **qo'shib yozish**.
   Bu — agentning tashqi xotirasi; kontekst yo'qolishining yagona himoyasi.
2. **Soxta bajarish taqiqlanadi**: `// TODO` yoki `return "success"` bilan "tayyor" deb yozish mumkin emas.
3. Har faza oxirida: compile + har ekran uchun qo'lda tekshiruv ro'yxati + `TEKSHIRUV NATIJASI:` bo'limi.
4. **Faza chegarasidan chiqmaslik** — keyingi fazaning kodini oldindan yozmaslik.
5. Fayl ≤ 400 qator; Material 3 dan chetga chiqmaslik; har ekranda
   bo'sh/yuklanish/xato holatlari, 48dp touch target, tasdiqlash dialoglari,
   xavfsiz default qiymatlar (`ALWAYS_CONFIRM`).
6. Noaniqlik bo'lsa — eng oddiy ishonchli variantni tanla va `QARORLAR` ga yoz.

## 4. Qatlamlar va ma'lumot oqimi

```
UI (Compose)  ui/workspace, ui/files, ui/chat, ui/agent, ui/diff, ui/terminal, ui/settings, ui/history
   |  holat oqimi (StateFlow)
ViewModel / UseCase (domain/usecase)
   |
domain/agent  -> AgentController (AgentState, AgentLimits, Stop/Pause/Resume)
   |              |
   |              +-> ExecutionRouter.decide()  -> PHONE yoki COLAB
   |
domain/tools  -> Tool interfeyslari (ToolResult: Success / Error / PermissionRequired)
   |
   +-- PHONE yo'li: data/filesystem (SAF), data/terminal (Termux), data/git, data/index (Room)
   +-- COLAB yo'li: data/colab (ColabExecutionEngine -> Retrofit -> FastAPI + ngrok)

domain/context -> ContextManager (token budget, summary)
data/ai        -> provider chaqiruvi (OpenAI-compatible /chat/completions)
data/security  -> SecretScanner, checkpoint/backup
```

Muhim: `domain/*` — sof Kotlin (Android'ga bog'liq emas), `data/*` — Android/SDK bilan bog'liq.
Bu chegara saqlansa, agent mantiqini **JVM unit test** bilan tekshirish mumkin bo'ladi
(qurilma bo'lmagan muhitda ham). Bu bizning asosiy tekshiruv vositamiz.

## 5. Fazalar xaritasi va har birining asosiy riski

| Faza | Nima | Asosiy risk / portlash nuqtasi |
|---|---|---|
| 0 | Skelet + PROGRESS_LOG | toolchain mosligi (AGP/Kotlin/KSP/Hilt), xotira |
| 1 | Domain modellari + Colab interfeyslari | Modellar keyin o'zgarsa, eski kod buziladi (qoida 4.b) |
| 2 | Workspace + SAF fayl daraxti | `takePersistableUriPermission`, ruxsat qayta tiklangandan keyin yo'qolishi, chuqur daraxt performansi |
| 3 | Provider sozlamalari + oddiy chat | API kalit xavfsizligi; 401/429/timeout UX; kalit ro'yxatda ko'rinmasligi |
| 4 | Tool system + lokal agent loop | **Eng katta faza.** SAF "path" emas — path-like xaritalash, checksum conflict, diff, undo buffer |
| 5 | Colab server (FastAPI+ngrok) + ulanish | ngrok URL vaqtinchalik, autentifikatsiya yo'q, sessiya o'ladi |
| 6 | LLM routing | har qadamda qo'shimcha LLM chaqiruvi = kechikish+narx; parse ishonchliligi; fallback |
| 7 | Termux + git + xavfsizlik | Termux'ni oddiy ilova chaqira olmaydi (RUN_COMMAND, foydalanuvchi o'rnatishi kerak) |
| 8 | Build/test feedback loop, max 5 urinish | cheksiz sikl xavfi; xato tahlilining sifati |
| 9 | Room index + smart context | token budget; 50+ fayl indekslash performansi telefonda |
| 10 | UX yakunlash + end-to-end sinov | butun zanjirning uzilishsiz ishlashi |

## 6. Spetsifikatsiyada ochiq qolgan / men oldindan ko'rgan muammolar

1. **Uzoq agent sikli va Android fon cheklovlari.** `maxExecutionTimeMs = 10 daqiqa`.
   Activity fonga o'tsa, Android jarayonni o'ldirishi mumkin. Faza 4 da agent loop'ni
   **foreground service + bildirishnoma** ichida yuritish kerak, aks holda "Stop Agent"
   ham, 10 daqiqalik sikl ham ishonchsiz bo'ladi. (Spetsifikatsiyada yozilmagan — Faza 4 da hal qilinadi.)
2. **Termux integratsiyasi (Faza 7)** eng mo'rt qism: `com.termux.RUN_COMMAND` ruxsati
   manifest'da e'lon qilinishi, Termux'ning o'rnatilgan va sozlangan bo'lishi,
   `allow-external-apps=true` kerak. Buning o'rniga **fallback kolbasini** (Colab yo'q →
   foydalanuvchiga aniq xabar) birinchi darajali stsenariy sifatida qurish to'g'riroq.
3. **`EncryptedSharedPreferences` (Faza 3)** — `androidx.security:security-crypto` Google
   tomonidan deprecated deb belgilangan. Faza 3 da qaror kerak: shu kutubxona (oddiy) yoki
   Android Keystore + DataStore (zamonaviy). Hozircha spetsifikatsiya bo'yicha yuramiz,
   lekin bu `QARORLAR` ga yozilishi shart.
4. **Router narxi.** Har tool chaqiruvida LLM'ga murojaat qilish — sekin va qimmat.
   Faza 6 da qaror **task darajasida** keshlanishi kerak (bir xil task ichida takror so'ramaslik).
5. **Colab xavfsizligi.** Ochiq ngrok URL + autentifikatsiyasiz `/execute` = ixtiyoriy buyruq
   bajarish imkoni. Faza 5 da kamida **shared secret token** qo'shish kerak (spetsifikatsiyada yo'q).
6. **SAF va "path" tushunchasi.** AI modellari `src/main/App.kt` deb so'raydi; SAF esa URI bilan
   ishlaydi. Faza 4 da `workspace-root`ga nisbatan path <-> URI xaritasi (kesh bilan) zarur.

## 7. Tekshiruv imkoniyatlari — real muhit (2026-08-30 holati)

Bu sandbox'da **tekshirib BO'LADI**:
- `./gradlew assembleDebug`, `./gradlew build` (compile, KSP/Hilt, lint, unit testlar)
- `domain/*` va sof-JVM mantiq uchun unit testlar (router parse, checksum, token budget...)
- Resurs/manifest to'g'riligi, APK ichidagi Dex/AndroidManifest tahlili (`apkanalyzer`)

Bu sandbox'da **tekshirib BO'LMAYDI** (va buni har doim ochiq yozamiz):
- Emulyator/real qurilma: `/dev/kvm` yo'q, `adb devices` bo'sh → UI'ni bosib sinab bo'lmaydi.
  Shuning uchun "qo'lda tekshirish ro'yxati" bandlari **foydalanuvchi qurilmasida** bajariladi,
  men esa ularni "BU MUHITDA TEKSHIRILMADI" deb belgilayman (soxta "HA" yozmayman).
- Haqiqiy AI provider kaliti va haqiqiy Colab sessiyasi.
  O'rniga: lokal mock HTTP server (JVM test ichida) orqali `401/429/timeout` stsenariylari sinlanadi.

## 8. Faza 0 da qabul qilingan qarorlar (qisqa)

- **minSdk 30 (Android 11), targetSdk/compileSdk 36 (Android 16)** — foydalanuvchi talabi.
  Spetsifikatsiyadagi "Min SDK 26" shu bilan almashtirildi. Natija: SAF/scoped storage xatti-harakati
  butun diapazonda bir xil, legacy storage ruxsatlari umuman kerak emas.
- **AGP 9.3.2 + Gradle 9.7.1 + JDK 17 + built-in Kotlin (KGP 2.2.10) + KSP 2.3.11 + Hilt 2.60.1 +
  Compose BOM 2026.08.00.** `org.jetbrains.kotlin.android` plagini AGP 9 new DSL bilan mos emas
  (real xato bilan tekshirildi) → AGP'ning built-in Kotlin yo'li tanlandi.
- Qurilish muhiti `/opt` da (snapshot'ga tushmaydi) → `tools/setup-build-env.sh` bilan qayta tiklanadi.
- 2 GB RAM li muhitda Gradle OOM bo'ldi → 4 GB swap qo'shildi va heap 1536 MB ga cheklandi.

Batafsil va sana bilan — `PROGRESS_LOG.md` da.
