# PROGRESS LOG — Android AI Coding Agent

Bu fayl loyihaning barcha fazalardagi tarixini saqlaydi. HAR FAZADAN OLDIN BUNI TO'LIQ O'QI.

## Umumiy arxitektura qarorlari

Bu bo'lim butun loyihaga tegishli, o'zgarmas qarorlar uchun. Fazalar o'tishi bilan to'ldiriladi.

1. **Paket va modul:** bitta `app` moduli, `namespace = com.aiagent.mobile`.
   Qatlamlar: `domain/*` (sof Kotlin), `data/*` (Android/SDK), `ui/*` (Compose).
   Chegara qat'iy: `domain` hech qachon `android.*` import qilmaydi — bu agent mantiqini
   qurilmasiz (JVM unit test) tekshirish imkonini beradi.
2. **Ikkita bajarish tekisligi:** `PHONE` (SAF + Termux) va `COLAB` (FastAPI + ngrok).
   Tanlovni `ExecutionRouter` (LLM) qiladi, standart — `COLAB`. Interfeys Faza 1 da,
   implementatsiya Faza 5-6 da.
3. **Colab'dan faqat natija qaytadi** (`success/output/errorMessage`), fayl/artifakt emas.
4. **Fayl tizimiga kirish faqat SAF orqali** — hech qanday `MANAGE_EXTERNAL_STORAGE` yo'q.
5. **Agent xotirasi = shu fayl.** Har faza: o'qish → ishlash → yozish.

## Ishchi muhit (har sessiyada tekshiriladi)

- JDK 17 → `/opt/tools/jdk-17.0.20.1+1` (nom o'zgarishi mumkin: `ls -d /opt/tools/jdk-17*`)
- Android SDK → `/opt/android-sdk` (platform-36, platform-37.0, build-tools 36.0.0, platform-tools)
- Gradle → wrapper 9.7.1, `GRADLE_USER_HOME=/opt/gradle-home`
- **Har yangi sessiyada `/opt` BO'SH bo'ladi** (snapshot'ga tushmaydi) → avval
  `bash tools/setup-build-env.sh` (≈2-4 daqiqa). 2026-08-30 da shu tariqa qayta tiklandi.
- **`gradlew` ijra ruxsati snapshot'dan keyin yo'qoladi** → `chmod +x gradlew` (kuzatilgan:
  "Permission denied", exit 126).
- RAM 2 GB → **4 GB swap majburiy** (`/swapfile`), aks holda Gradle OOM bo'ladi (kuzatilgan).
  Skript swap'ni o'zi yoqadi.
- Qurilma/emulyator YO'Q (`/dev/kvm` mavjud emas, `adb devices` bo'sh) → UI qo'lda sinov
  faqat foydalanuvchi qurilmasida mumkin; APK `artifacts/` ga nusxalanadi.
- Build buyrug'i (har doim shu muhit o'zgaruvchilari bilan):
  `JAVA_HOME=/opt/tools/jdk-17* ANDROID_HOME=/opt/android-sdk GRADLE_USER_HOME=/opt/gradle-home ./gradlew build --no-daemon`

## Fazalar tarixi

---

## FAZA 0 — Loyiha skeleti va PROGRESS_LOG tizimi
**Sana:** 2026-08-30 | **Holat:** TUGALLANDI VA TO'LIQ TASDIQLANDI
(qurilmada ochilishi 2026-08-30 da foydalanuvchi tomonidan tasdiqlandi: "Apk ishladi")

### Yaratilgan fayllar (to'liq yo'l)

**Build tizimi**
- `AiAgentMobile/settings.gradle.kts`
- `AiAgentMobile/build.gradle.kts`
- `AiAgentMobile/gradle.properties`
- `AiAgentMobile/gradle/libs.versions.toml`
- `AiAgentMobile/gradle/wrapper/gradle-wrapper.jar`, `gradle-wrapper.properties` (Gradle 9.7.1)
- `AiAgentMobile/gradlew`, `gradlew.bat`
- `AiAgentMobile/app/build.gradle.kts`
- `AiAgentMobile/app/proguard-rules.pro`
- `AiAgentMobile/.gitignore`, `AiAgentMobile/local.properties` (gitignore'da)
- `AiAgentMobile/tools/setup-build-env.sh` (muhitni qayta tiklash skripti)

**Kod (8 ta .kt fayl, eng kattasi 129 qator — 400 chegarasi buzilmagan)**
- `app/src/main/java/com/aiagent/mobile/AiAgentApplication.kt` (`@HiltAndroidApp`)
- `app/src/main/java/com/aiagent/mobile/MainActivity.kt` (`@AndroidEntryPoint`, edge-to-edge)
- `app/src/main/java/com/aiagent/mobile/ui/navigation/AiAgentNavHost.kt`
- `app/src/main/java/com/aiagent/mobile/ui/navigation/Routes.kt`
- `app/src/main/java/com/aiagent/mobile/ui/home/HomeScreen.kt` ("Salom!" ekrani)
- `app/src/main/java/com/aiagent/mobile/ui/theme/Theme.kt`, `Color.kt`, `Type.kt` (Material 3)

**Resurslar**
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/values/{strings,themes,colors}.xml`
- `app/src/main/res/values-night/{themes,colors}.xml`
- `app/src/main/res/drawable/ic_launcher.xml` (vector)

**Bo'sh papka strukturasi (26 ta, `.gitkeep` bilan)**
`domain/{model,repository,usecase,agent,tools,context}` ·
`data/{ai,filesystem,terminal,git,index,database,security,colab}` ·
`ui/{workspace,files,chat,agent,diff,terminal,settings,history}`
(qo'shimcha: `ui/{home,navigation,theme}` — navigatsiya va Material 3 uchun zarur)

**Hujjatlar**
- `AiAgentMobile/PROGRESS_LOG.md` (shu fayl)
- `AiAgentMobile/docs/KONTEKST_TAHLILI.md` (spetsifikatsiyaning chuqur tahlili)
- `AiAgentMobile/artifacts/aiagent-faza0-debug.apk` (qurilmada sinash uchun)

### QARORLAR

1. **minSdk 30 / targetSdk 36** (Android 11 → Android 16). Sabab: foydalanuvchi talabi
   spetsifikatsiyadagi "Min SDK 26" dan ustun. Tasdiq: APK'dan o'qildi (`apkanalyzer manifest
   min-sdk` = 30, `target-sdk` = 36). Foydasi: butun diapazonda SAF/scoped storage xatti-harakati
   bir xil, legacy storage ruxsatlari kerak emas.
2. **compileSdk 37** (Android 17 API'lari). Sabab: 2026-yilgi androidx kutubxonalari
   (compose 1.12.0, core-ktx 1.19.0, okhttp 5.5.0, navigation 2.10.0) `minCompileSdk = 37`
   talab qiladi — compileSdk 36 bilan build **real xato** berdi va shundan keyin ko'tarildi.
   Bu faqat kompilyatsiya darajasi, `targetSdk` 36 da qoldi.
3. **Kotlin "built-in" rejimi (AGP 9), `org.jetbrains.kotlin.android` qo'llanilmaydi.**
   Sabab: KGP 2.3.21 bilan build real xato berdi —
   *"The 'org.jetbrains.kotlin.android' plugin is not compatible with AGP's 9.0 new DSL"*.
   AGP 9.3.2 ichidagi KGP versiyasi **2.2.10** (`gradle-9.3.2.pom` dan tekshirildi),
   shuning uchun `kotlin.plugin.compose` va `kotlin.plugin.serialization` ham 2.2.10 ga moslandi.
   Lint "2.4.10 mavjud" deb ogohlantiradi, lekin built-in KGP 2.2.10 bo'lgani uchun
   ko'tarib bo'lmaydi — bu xabarni bosish kerak emas, u kutilgan.
4. **Versiya stacki:** AGP 9.3.2 · Gradle 9.7.1 · JDK 17 · KSP 2.3.11 · Hilt 2.60.1 ·
   Compose BOM 2026.08.00 · Navigation 2.10.0 · Lifecycle 2.11.0 · DataStore 1.2.1 ·
   Retrofit 3.0.0 + kotlinx-serialization konvertori · OkHttp 5.5.0.
   Barchasi versiya katalogida (`gradle/libs.versions.toml`) — Faza 1-3 uchun tayyor.
5. **Hilt hozirdayoq ulandi** (`@HiltAndroidApp` + `@AndroidEntryPoint`), chunki DI'ni keyin
   ulash mavjud kodni qayta yozishni talab qiladi. KSP orqali generatsiya tasdiqlandi.
6. **`applicationIdSuffix = ".debug"`** — debug build `com.aiagent.mobile.debug` bo'ladi,
   release `com.aiagent.mobile`. Sabab: qurilmaga ikki xil versiyani parallel o'rnatish.
7. **Xotira boshqaruvi:** `org.gradle.jvmargs=-Xmx1536m`, `workers.max=1`,
   `kotlin.compiler.execution.strategy=in-process`, `--no-daemon`.
8. **Unit test hozircha yo'q** (`testDebugUnitTest NO-SOURCE`). Sabab: Faza 0 da tekshiriladigan
   mantiq yo'q; "bordek ko'rinadigan" bo'sh test yozish 3-qoidaga (soxta bajarish) zid.
   Testlar Faza 1 da real model/mantiq paydo bo'lganda boshlanadi.

### Ma'lum cheklovlar / keyingi fazaga qoldirilganlar

- **Qurilmada ochilishi tekshirilmadi** (bu muhitda emulyator/qurilma yo'q). Foydalanuvchi
  `artifacts/aiagent-faza0-debug.apk` ni o'rnatib ko'rishi mumkin.
- Faza 2 da `HomeScreen` startDestination emas, `WorkspaceScreen` bo'ladi.
- Faza 3 da `androidx.security:security-crypto` (EncryptedSharedPreferences) deprecated
  ekanligi hisobga olinib qaror qabul qilinishi kerak.
- Faza 4 da agent loop'ni **foreground service** ichida yuritish masalasi hal qilinishi kerak
  (10 daqiqalik sikl fon rejimida o'ldiriladi) — spetsifikatsiyada yozilmagan.
- Lint'da 3 ta kutilgan ogohlantirish qoldi: `OldTargetApi` (targetSdk 36 — ataylab),
  2× `NewerVersionAvailable` (yuqoridagi 3-qarorga qarang). Xato (error) yo'q.

### TEKSHIRUV NATIJASI

**Build (spetsifikatsiya talabi: `./gradlew build` xatosiz o'tishi SHART)**
- `./gradlew assembleDebug` → **BUILD SUCCESSFUL** (1m 1s)
- `./gradlew build` → **BUILD SUCCESSFUL** (2m 55s; manifest tuzatilgach qayta: 36s)
  - `kspDebugKotlin` ✅ · `compileDebugKotlin` ✅ · `hiltJavaCompileDebug` ✅
  - `lintDebug` / `lint` ✅ (0 xato, 3 kutilgan ogohlantirish)
  - `assembleDebug` + `assembleRelease` ✅ (`app-debug.apk` 34.7 MB, `app-release-unsigned.apk` 26.9 MB)
  - `testDebugUnitTest` → NO-SOURCE (test hali yozilmagan — yuqoridagi 8-qaror)
- Build jarayonida topilgan va **shu fazada tuzatilgan** 3 ta real muammo:
  1. KGP 2.3.21 ↔ AGP 9 new DSL ziddiyati → built-in Kotlin'ga o'tildi
  2. Gradle daemon OOM (1.5 GB RSS da o'ldirildi, `dmesg` bilan tasdiqlandi) → 4 GB swap + heap chegarasi
  3. androidx kutubxonalari compileSdk 37 talab qildi → compileSdk 37 ga ko'tarildi

**APK ustida tekshiruv (`apkanalyzer`, nusxalangan fayl orqali)**
- applicationId: `com.aiagent.mobile.debug` · versionName `0.1.0-faza0`
- minSdk **30** · targetSdk **36** ✅ (Android 11 → 16 talabiga mos)
- Ruxsatlar: faqat `INTERNET`, `ACCESS_NETWORK_STATE` (+tizim avtomatik qo'shgan
  `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`). Storage ruxsati YO'Q ✅
- Launcher activity manifest'da mavjud ✅
- Hilt DI haqiqatan ulangan ✅ — KSP 12 ta fayl generatsiya qildi
  (`AiAgentApplication_GeneratedInjector.java`, `MainActivity_GeneratedInjector.java`,
  `Hilt_MainActivity.java`), va `com.aiagent.mobile.Hilt_MainActivity` klassi APK dex ichida
  mavjud (apkanalyzer bilan tasdiqlandi)

**"Hello" ekrani (HomeScreen) — UI/UX ro'yxati (8-qoida bo'yicha har bandga javob)**
| Band | Javob |
|---|---|
| Bo'sh holat | Qo'llanilmaydi — ekran statik, ro'yxat/ma'lumot manbai yo'q |
| Yuklanish holati | Qo'llanilmaydi — tarmoq/fayl operatsiyasi yo'q |
| Xatolik holati | Qo'llanilmaydi — bajariladigan operatsiya yo'q |
| Tasdiqlash / halokatli amallar | Qo'llanilmaydi — halokatli amal yo'q |
| Touch target ≥48dp | Qo'llanilmaydi — interaktiv element yo'q (faqat matn+karta) |
| Fikr-mulohaza (feedback) | Qo'llanilmaydi — tugma/amal yo'q |
| Izchillik (Material 3) | **HA** — yagona `AiAgentTheme`, `AiAgentTypography`, dinamik rang + zaxira palitra |
| Kognitiv yuk | **HA** — sarlavha + 4 qatorli ma'lumot kartasi, ortiqcha tugma yo'q |
| Xavfsiz-standart qiymatlar | Qo'llanilmaydi (sozlama yo'q); tema tizim sozlamasiga amal qiladi |
| Klaviatura / matn kiritish | Qo'llanilmaydi — kiritish maydoni yo'q |
| Orqaga qaytish / navigatsiya | **HA** — TopAppBar sarlavhasi bor; bu start ekran, "orqaga" ilovani yopadi |

**QURILMADA OCHILISHI — 2026-08-30 da YOPILDI.**
Bu sandbox'da `/dev/kvm` yo'q va `adb devices` bo'sh bo'lgani uchun emulyatorda sinab
bo'lmagandi. `artifacts/aiagent-faza0-debug.apk` foydalanuvchiga berildi va u **haqiqiy
Android qurilmasida o'rnatilib, "Salom!" ekrani ochilganini tasdiqladi** ("Apk ishladi").
Shundan keyin Faza 0 to'liq tasdiqlangan deb hisoblandi.

---

## FAZA 1 — Domain modellari va Colab arxitektura interfeysi
**Sana:** 2026-08-30 | **Holat:** TUGALLANDI (bu faza uchun barcha tekshiruvlar bu muhitda bajarildi)

### Yaratilgan fayllar (to'liq yo'l)

**`domain/model/` (6 fayl)** — barchasi spetsifikatsiyadagi maydonlar va standart qiymatlar bilan, aniq shu tartibda:
- `app/src/main/java/com/aiagent/mobile/domain/model/AiProvider.kt` (+ `ProviderType`)
- `app/src/main/java/com/aiagent/mobile/domain/model/Workspace.kt`
- `app/src/main/java/com/aiagent/mobile/domain/model/FileNode.kt`
- `app/src/main/java/com/aiagent/mobile/domain/model/ChatMessage.kt` (+ `MessageRole`)
- `app/src/main/java/com/aiagent/mobile/domain/model/ProposedEdit.kt` (+ `EditStatus`)
- `app/src/main/java/com/aiagent/mobile/domain/model/AppSettings.kt` (+ `EditMode`, `ExecutionPreference`)

**`domain/agent/` (5 fayl)** — Colab arxitektura interfeyslari, IMPLEMENTATSIYASIZ:
- `app/src/main/java/com/aiagent/mobile/domain/agent/ExecutionTarget.kt` (`enum { PHONE, COLAB }`)
- `app/src/main/java/com/aiagent/mobile/domain/agent/ExecutionRouter.kt` (interfeys + `PhoneSpecs`)
- `app/src/main/java/com/aiagent/mobile/domain/agent/RemoteExecutionEngine.kt` (interfeys + `RemoteTask`, `RemoteTaskResult`)
- `app/src/main/java/com/aiagent/mobile/domain/agent/AgentState.kt` (10 ta holat)
- `app/src/main/java/com/aiagent/mobile/domain/agent/AgentLimits.kt`

**Testlar (yangi, 2 fayl — Faza 0 dagi 8-qarorga ko'ra testlar shu fazadan boshlandi)**
- `app/src/test/java/com/aiagent/mobile/domain/model/DomainModelDefaultsTest.kt` (6 test)
- `app/src/test/java/com/aiagent/mobile/domain/DomainPurityTest.kt` (1 test — arxitektura qo'riqchisi)

**O'zgartirilgan fayllar**
- `AiAgentMobile/PROGRESS_LOG.md` (Faza 0 ning "qurilmada ochilishi" bandi yopildi; muhit bo'limi yangilandi)
- `AiAgentMobile/tools/setup-build-env.sh` (2 ta real xato tuzatildi — pastda)
- `app/src/main/java/com/aiagent/mobile/domain/model/.gitkeep` va `.../domain/agent/.gitkeep` o'chirildi (papkalar to'ldi)

### QARORLAR

1. **Modellar sof Kotlin, hech qanday annotatsiya yo'q** (`@Serializable`, `@Parcelize` va h.k. qo'shilmadi).
   Sabab: (a) spetsifikatsiya "aniq shu maydonlar bilan" deb talab qilgan; (b) tarmoq uchun kerak bo'ladigan
   DTO'lar domen modeli emas — ular Faza 3 da `data/ai/` ichida alohida yoziladi. Domen modeli wire-formatga
   bog'lanib qolmasligi kerak.
2. **`domain` qatlami Android'ga bog'liq emas** va bu **test bilan himoya qilindi**
   (`DomainPurityTest`): agar keyingi fazalarda kimdir domen ichiga `android.*`/`androidx.*` import
   qo'shsa, build darhol sinadi. Bu — agent mantiqini emulyatorsiz tekshirish imkonining kafolati.
3. **Standart qiymatlar test bilan kafolatlandi**: `AppSettings.editMode` default `ALWAYS_CONFIRM`
   (8-qoida: xavfsiz standart), `executionPreference` default `COLAB_PRIMARY`,
   `AgentLimits` = 30/50/600_000ms/1_000_000B, `RemoteTask.timeoutMs` = 300_000.
4. **Interfeyslar hech qanday implementatsiyasiz qoldirildi** (spetsifikatsiya talabi).
   Shu sababli Hilt binding'lari ham qo'shilmadi — `@Binds`/`@Module` Faza 4-6 da,
   implementatsiya paydo bo'lganda yoziladi. Bu fazada DI grafi o'zgarmadi.
5. **Enum tartibi ham test qilingan** (`entries.toList()` taqqoslanadi): keyingi fazalarda
   enum'ga qiymat qo'shilsa yoki tartibi o'zgarsa, bu ataylab qilingan o'zgarish bo'lishi kerak.

### Ma'lum cheklovlar / keyingi fazaga qoldirilganlar

- `ExecutionRouter` va `RemoteExecutionEngine` **implementatsiyasi yo'q** (Faza 5-6 da).
  Hozircha ular hech qayerda chaqirilmaydi — bu kutilgan holat.
- Modellar hozircha hech qanday UI/DataStore bilan bog'lanmagan (Faza 2-3 da).
- `PhoneSpecs` ma'lumotini yig'uvchi Android kodi yo'q (Faza 6 da `ActivityManager` orqali).
- **Muhitni qayta tiklashda 2 ta real xato topildi va tuzatildi:**
  1. `tools/setup-build-env.sh` ichida `set -e` + `sdkmanager --licenses` (nol bo'lmagan kod qaytaradi)
     tufayli skript SDK o'rnatish qadamigacha yetib bormagan — **jim muvaffaqiyatsizlik**.
     Tuzatish: `|| true` + o'rnatilganlikni tekshiruvchi sikl (`platforms/android-37.0` va h.k.).
  2. `gradlew` ijra ruxsati snapshot'dan keyin yo'qolgan (`Permission denied`, exit 126) → `chmod +x`.
- **Kotlin izoh qopqog'i (keyingi fazalar uchun muhim):** KDoc ichida `domain/*` kabi matn yozish
  MUMKIN EMAS — Kotlin blok izohlari ichma-ich (nested) bo'la olgani uchun `/*` yangi izoh ochadi va
  fayl "Unclosed comment" bilan compile bo'lmaydi. Bu Faza 1 da real xato sifatida kuzatildi va tuzatildi.

### TEKSHIRUV NATIJASI

**Build (spetsifikatsiya talabi: `./gradlew build` xatosiz o'tishi SHART)**
- 1-urinish: `compileDebugUnitTestKotlin FAILED` —
  `DomainPurityTest.kt:58:1 Syntax error: Unclosed comment` (yuqoridagi Kotlin izoh qopqog'i).
  **Shu fazada tuzatildi**, keyingi fazaga qoldirilmadi.
- 2-urinish: **BUILD SUCCESSFUL in 43s** (108 task)
  - `compileDebugKotlin` ✅ (11 ta yangi domen fayli xatosiz compile bo'ldi)
  - `compileDebugUnitTestKotlin` ✅ · `testDebugUnitTest` ✅ · `lintDebug`/`lint` ✅
  - `assembleDebug` + `assembleRelease` ✅

**Unit testlar (haqiqatan ishga tushdi, `app/build/test-results` XML'dan o'qildi)**
- `DomainModelDefaultsTest` → **6 test, 0 failures, 0 errors, 0 skipped**
  (AiProvider standartlari · AppSettings xavfsiz standartlari · AgentLimits chegaralari ·
  RemoteTask/RemoteTaskResult standartlari · FileNode/ChatMessage bo'sh kolleksiyalari · enum ro'yxatlari)
- `DomainPurityTest` → **1 test, 0 failures** (domen'da `android.*`/`androidx.*` import yo'qligi tasdiqlandi)
- **JAMI: 7 test, 0 muvaffaqiyatsiz, 0 o'tkazib yuborilgan.** Bu — Faza 0 dagi `NO-SOURCE` holatidan
  farqli o'laroq, testlar endi haqiqatan bajarilmoqda.

**Lint:** 0 xato, 3 ta kutilgan ogohlantirish (Faza 0 dagi bilan bir xil: `OldTargetApi` — targetSdk 36
ataylab; 2× `NewerVersionAvailable` — compose/serialization plaginlari built-in KGP 2.2.10 ga bog'liq).

**Eski kod buzilmadimi? (4-qoida)** — YO'Q, buzilmadi. Faza 0 dagi 8 ta `.kt` fayl o'zgartirilmadi,
`compileDebugKotlin` va `assembleDebug` muvaffaqiyatli; yangi modellar mavjud kodga hech qanday
maydon/qo'ng'iroq qo'shmadi (ular hali hech qayerda ishlatilmaydi).

**UI/UX ro'yxati (8-qoida):** Bu fazada **yangi ekran yoki UI komponent yaratilmadi** — faqat domen
modellari va interfeyslar. Shuning uchun 11 ta bandning barchasi "qo'llanilmaydi (UI yo'q)" deb
belgilanadi; sukut saqlanib o'tkazib yuborilmadi. Modellarning UI'ga tegishli qismlari
(xavfsiz standart `ALWAYS_CONFIRM`, sozlamalar "Ilg'or sozlamalar" ostida) Faza 2-3 ekranlarida tekshiriladi.

**Faza chegarasi (5-qoida):** Faqat so'ralgan narsa qilindi — hech qanday implementatsiya, Hilt binding,
DataStore yoki UI yozilmadi.

---

## FAZA 2 — Workspace va fayl tizimi (SAF)
**Sana:** 2026-08-30 | **Holat:** KOD VA TEKSHIRUVLAR TUGALLANDI; qurilmada sinash foydalanuvchida (pastda)

### Yaratilgan fayllar (to'liq yo'l)

**`domain/` — interfeyslar va sof mantiq (5 fayl)**
- `app/src/main/java/com/aiagent/mobile/domain/model/FileContent.kt` (sealed: Text/Binary/TooLarge/Failed)
- `app/src/main/java/com/aiagent/mobile/domain/repository/WorkspaceRepository.kt`
- `app/src/main/java/com/aiagent/mobile/domain/repository/DocumentRepository.kt` (SAF abstraksiyasi)
- `app/src/main/java/com/aiagent/mobile/domain/usecase/FileTreeFlattener.kt` (+ `FileRow`) — sof, test qilinadi
- `app/src/main/java/com/aiagent/mobile/domain/usecase/FileContentClassifier.kt` — sof, test qilinadi

**`data/` — implementatsiya (3 fayl)**
- `app/src/main/java/com/aiagent/mobile/data/database/WorkspaceDto.kt` (`@Serializable` DTO)
- `app/src/main/java/com/aiagent/mobile/data/database/WorkspaceRepositoryImpl.kt` (DataStore Preferences + JSON)
- `app/src/main/java/com/aiagent/mobile/data/filesystem/SafDocumentRepository.kt` (DocumentFile/ContentResolver)

**`di/` (yangi papka)**
- `app/src/main/java/com/aiagent/mobile/di/RepositoryModule.kt` (`@Binds` — 2 ta interfeys)

**`ui/` (6 fayl)**
- `ui/workspace/WorkspaceViewModel.kt`, `ui/workspace/WorkspaceScreen.kt`
- `ui/files/FileTreeViewModel.kt`, `ui/files/FileTreeScreen.kt`, `ui/files/FilePreviewSheet.kt`
- `ui/chat/ChatPlaceholderScreen.kt` — **VAQTINCHALIK, chat ishlamaydi** (Faza 3)
- `ui/common/Formatters.kt` (fayl hajmi formati — sof)

**Resurslar**
- `app/src/main/res/drawable/` — 10 ta yangi vector ikonka (folder, file_text, folder_add, delete,
  warning, expand_more, refresh, content_copy, link_off, arrow_back). Sabab: `material-icons-core`
  1.7.8 da to'xtagan va Compose 1.12 bilan aralashtirish versiya ziddiyati xavfini tug'diradi.
- `app/src/main/res/values/strings.xml` — 30+ ta yangi satr (Faza 0 dagi `home_*` satrlari o'chirildi)

**O'zgartirilgan / o'chirilgan**
- `ui/navigation/Routes.kt` — WORKSPACE, FILE_TREE (argumentli), CHAT (query argumentli) manzillari
- `ui/navigation/AiAgentNavHost.kt` — startDestination endi `WorkspaceScreen`
- **O'CHIRILDI:** `ui/home/HomeScreen.kt` (Faza 0 dagi "Salom!" ekrani) — o'rnini WorkspaceScreen egalladi,
  o'lik kod qoldirmaslik uchun butunlay olib tashlandi
- `gradle/libs.versions.toml` + `app/build.gradle.kts` — `androidx.documentfile:1.1.0` qo'shildi
- `domain/repository/WorkspaceRepository.kt` — `findWorkspace(id)` metodi qo'shildi
- `tools/setup-build-env.sh` — swap qadami qo'shildi (yangi sessiyada /opt bo'sh bo'ladi)
- `artifacts/aiagent-faza2-debug.apk` (eski faza0 APK o'chirildi)

### QARORLAR

1. **SAF abstraksiyasi domen qatlamida** (`DocumentRepository`), implementatsiya `data/filesystem` da.
   Sabab: Faza 4 dagi fayl tool'lari (`read_file`, `list_directory`...) aynan shu interfeysni ishlatadi —
   shunda ular ham emulyatorsiz test qilinadigan mantiqqa ega bo'ladi.
2. **Workspace'lar DataStore Preferences'da bitta JSON kalitida** (Proto DataStore emas).
   Sabab: yozuvlar soni kam, proto sxemasi ortiqcha murakkablik. JSON buzilsa ro'yxat bo'sh deb
   olinadi (crash yo'q) — bu `WorkspaceDtoTest` da tekshirilgan.
3. **Fayl daraxti lazy yuklanadi**: papka birinchi marta ochilgandagina bolalari o'qiladi
   (`childrenByUri` xaritasi). Butun daraxtni birdan o'qish katta loyihalarda sekin va xotira uchun xavfli.
   Yuklanayotgan papka yonida spinner ko'rsatiladi; xato bo'lsa papka avtomatik yopiladi (aks holda
   "ochiq lekin bo'sh" ko'rinib, foydalanuvchini chalg'itadi).
4. **Tekislash (flatten) mantiqi domen'da** (`FileTreeFlattener`) — LazyColumn ierarxiyani to'g'ridan-to'g'ri
   ko'rsata olmaydi. Bu sof funksiya bo'lgani uchun 6 ta test bilan qoplandi (2 daraja chuqurlik ham).
5. **Fayl hajmi chegarasi bilan o'qiladi**: `maxBytes + 1` baytdan ko'p o'qilmaydi, shunda "juda katta"
   holati aniq aniqlanadi va xotira to'ldirilmaydi. `InputStream.readNBytes(int)` ISHLATILMADI —
   u Java 9+ metodi va Android'da faqat API 33 dan bor, bizning minSdk 30 (qo'lda sikl yozildi).
6. **Preview chegarasi 200 000 bayt** (`FileTreeViewModel.PREVIEW_MAX_BYTES`). Faza 3 da bu qiymat
   `AppSettings.maxFileContextSizeBytes` dan olinadi — hozircha sozlamalar ekrani yo'q.
7. **Ikkilik fayl aniqlash**: birinchi 8000 baytda NUL (`0x00`) borligi tekshiriladi — oddiy va ishonchli.
8. **Chat ekrani VAQTINCHALIK**: Faza 2 ning 7-vazifasi "chatga o'tish" navigatsiyasini talab qiladi,
   chatning o'zi Faza 3 da. `ChatPlaceholderScreen` faqat tanlangan fayllarni ko'rsatadi, xabar
   yuborish mantiqi YO'Q va bu "tayyor" deb hisoblanmaydi (3-qoida: soxta bajarish taqiqlangan).
9. **Tanlangan fayllar navigatsiya argumentida** bitta query param sifatida uzatiladi (`Uri.encode` bilan).
   SAF URI'lari `:` `/` `%` belgilarini o'z ichiga olgani uchun kodlash shart, aks holda route buziladi.
   `Routes.parseFiles()` navigator dekodlamagan holat uchun zaxira dekodlashni ham bajaradi.
10. **`applicationIdSuffix ".debug"`** tufayli APK `com.aiagent.mobile.debug` sifatida o'rnatiladi —
    Faza 0 APK'si bilan parallel turadi. Eski APK o'chirildi, yangi `aiagent-faza2-debug.apk`.

### Ma'lum cheklovlar / keyingi fazaga qoldirilganlar

- **QURILMADA SINASH FOYDALANUVCHIDA QOLDI.** Spetsifikatsiyaning 2 ta TEKSHIRUV talabi
  (ruxsat qayta ochilganda saqlanishi va 2 daraja chuqurlikdagi daraxt) emulyator/qurilma talab qiladi.
  Bu sandbox'da `/dev/kvm` yo'q, `adb devices` bo'sh → sinab bo'lmadi. `artifacts/aiagent-faza2-debug.apk`
  tayyor. Bu bandlar yopilmaguncha Faza 2 "to'liq tasdiqlangan" emas.
- Chat haqiqatan ishlamaydi (Faza 3).
- Workspace sozlamalari (editMode, provider) hali yo'q — `AppSettings` modeli mavjud, lekin ekrani Faza 3 da.
- Fayl daraxtida **qidiruv yo'q** (Faza 4: `search_files`/`search_text` tool'lari).
- Preview faqat o'qish uchun; tahrirlash Faza 4 da (diff ekrani bilan).
- Build jarayonida topilgan va shu fazada tuzatilgan 4 ta real xato (pastda) — hech biri keyingi fazaga qoldirilmadi.

### TEKSHIRUV NATIJASI

**Build (`./gradlew build` xatosiz o'tishi SHART)**
- 1-urinish: `compileDebugKotlin FAILED` — 3 ta xato:
  1. `WorkspaceRepositoryImpl`: `Flow.firstOrNull(predicate)` **mavjud emas** (kutilmagan:
     `List<Workspace>?` qaytdi) → `first()` + ro'yxat ustida `firstOrNull` ga o'zgartirildi
  2. `FileTreeScreen`: `showSnackbar` suspend — `rememberCoroutineScope().launch` ichiga olindi
- 2-urinish: `testDebugUnitTest FAILED` — `FileTreeFlattenerTest` dagi **test kutilmasi noto'g'ri edi**
  (kod to'g'ri: avval papkalar, keyin fayllar). Kutilma tuzatildi, ishlab chiqarish kodi o'zgarmadi.
- 3-urinish: **BUILD SUCCESSFUL in 47s**
- 4-urinish (lint tuzatishlaridan keyin): **BUILD SUCCESSFUL in 2m 31s**

**Unit testlar (hisobot XML'idan o'qildi)**
- **JAMI: 25 test, 0 failures, 0 errors, 0 skipped**
  - `FileTreeFlattenerTest` 6 · `FileContentClassifierTest` 5 · `FormattersTest` 3 ·
    `WorkspaceDtoTest` 4 · `DomainModelDefaultsTest` 6 · `DomainPurityTest` 1
- Yangi testlar aynan shu fazaning xavfli mantiqini qoplaydi: 2 daraja chuqurlikdagi daraxt,
  lazy yuklanmagan papka, ikkilik/juda katta fayl aniqlash, JSON formati barqarorligi.

**Lint:** 0 xato. Avval 9 ta ogohlantirish bor edi, 6 tasi tuzatildi (`UseKtx` → `String.toUri()`,
`UnusedResources` → `ic_refresh` "Qayta urinish" tugmasiga qo'shildi). Qolgan 3 tasi kutilgan:
`OldTargetApi` (targetSdk 36 ataylab) va 2× `NewerVersionAvailable` (Faza 0, 3-qaror).

**APK tekshiruvi (`apkanalyzer`, `artifacts/aiagent-faza2-debug.apk`)**
- minSdk **30** · targetSdk **36** ✅ (Android 11 → 16)
- Ruxsatlar: faqat `INTERNET`, `ACCESS_NETWORK_STATE` (+tizim avtomatik qo'shgani).
  **Storage ruxsati YO'Q** ✅ — fayl tizimiga kirish faqat SAF orqali (spetsifikatsiya talabi)
- Hilt: `WorkspaceViewModel_Factory.java`, `FileTreeViewModel_HiltModules.java` va boshqalar
  KSP tomonidan generatsiya qilindi ✅ (DI grafi yangi ViewModel'larni o'z ichiga oladi)

**Qo'lda tekshirish ro'yxati (kod darajasida, qurilmasiz)**
| Band | Natija |
|---|---|
| WorkspaceScreen bo'sh holatda "Papka tanlash" tugmasi bormi | **HA** — ikonka + sarlavha + tushuntirish + OutlinedButton |
| `ACTION_OPEN_DOCUMENT_TREE` ishlatilganmi | **HA** — `ActivityResultContracts.OpenDocumentTree()` |
| `takePersistableUriPermission()` chaqirilganmi | **HA** — `SafDocumentRepository.takePersistablePermission`, read+write; SecurityException'da read-only'ga qaytadi |
| Workspace DataStore'ga saqlanadimi | **HA** — `WorkspaceRepositoryImpl` (DataStore Preferences) |
| Ro'yxat card ko'rinishida: nom + vaqt + o'chirish | **HA** — `WorkspaceCard` (nisbiy vaqt `DateUtils`) |
| Ruxsat yo'qolganda aniq xabar + taklif | **HA** — `errorContainer` rangli kartochka, `ic_link_off`, dialog: "Qayta ulash"/"O'chirish" |
| `DocumentFile.fromTreeUri()` ishlatilganmi | **HA** — ildiz va har bir papka uchun |
| LazyColumn + expand/collapse | **HA** — `FileTreeFlattener`, chevron 90° aylanadi |
| Fayl hajmi va ikonkasi | **HA** — `Formatters.fileSize` + folder/file_text ikonkalari |
| Matn fayli preview (bottom sheet, monospace) | **HA** — `ModalBottomSheet` + `CodeTextStyle` |
| Fayl tanlash checkbox'i + FAB | **HA** — checkbox har faylda; FAB faqat tanlov bo'lganda chiqadi, "(N)" bilan |
| Yuklanish holati | **HA** — ildiz uchun markaziy spinner, har papka uchun qator ichida spinner |
| Xatolik holati + "Qayta urinish" | **HA** — `ErrorContent` (warning ikonka + sabab + retry tugmasi) |
| Halokatli amal tasdiqlanadimi | **HA** — workspace o'chirish `AlertDialog` orqali |
| Touch target ≥48dp | **HA** — qatorlar 56dp, IconButton/Tugmalar 48dp |
| Fikr-mulohaza (feedback) | **HA** — snackbar (qo'shildi/o'chirildi/nusxa olindi/xato), spinner, chevron animatsiyasi |
| Izchillik (Material 3) | **HA** — barcha ekranlar `AiAgentTheme` + bir xil padding/ikonka uslubi |
| Kognitiv yuk | **HA** — asosiy oqim: papka tanlash → ochish; ortiqcha tugma yo'q |
| Xavfsiz-standart qiymatlar | **QO'LLANILMAYDI** — bu fazada sozlama ekrani yo'q (Faza 3) |
| Klaviatura/matn kiritish | **QO'LLANILMAYDI** — matn kiritish maydoni yo'q (chat Faza 3 da) |
| Orqaga qaytish/navigatsiya | **HA** — FileTree/Chat ekranlarida TopAppBar'da orqaga tugmasi; sarlavha = workspace nomi |

**Spetsifikatsiyaning TEKSHIRUV TALABI bandlari:**
1. *"Papka tanlangach, ilova qayta ochilganda ruxsat saqlanib qolishi SHART (real qurilmada tekshir)"* —
   **BU MUHITDA TEKSHIRIB BO'LMADI.** Kod tomoni to'g'ri (`takePersistableUriPermission` chaqiriladi,
   workspace DataStore'da saqlanadi), lekin qurilma/emulyator yo'qligi sababli amalda tasdiqlanmadi.
   Foydalanuvchi `artifacts/aiagent-faza2-debug.apk` da sinashi kerak: papka tanlash → ilovani to'liq
   yopish → qayta ochish → workspace ro'yxatda va ochilishi kerak.
2. *"Fayl daraxti kamida 2 daraja chuqurlikda to'g'ri ko'rsatilsin"* — **MANTIQ DARAJASIDA TEKSHIRILDI**
   (`FileTreeFlattenerTest`: `ikki daraja chuqurlik to'g'ri ko'rsatiladi` testi o'tdi). UI'da ko'z bilan
   tekshirish qurilmada qoldi.
3. *"`./gradlew build` xatosiz o'tishi SHART"* — **BAJARILDI** (BUILD SUCCESSFUL, 0 lint xatosi, 25 test o'tdi).

---

---

# FAZA 3 — AI Provider Sozlamalari va Chat (2026-08-30)

## Yaratilgan fayllar

### Domen qatlami (sof Kotlin, Android'ga bog'liq emas)
- `app/src/main/java/com/aiagent/mobile/domain/model/AiError.kt` — xato turlari (NoNetwork / Timeout / Unauthorized / RateLimited / Server / InvalidResponse / InvalidConfig / VisionUnsupported / Unknown) + `isRetryable`.
- `app/src/main/java/com/aiagent/mobile/domain/model/AiChat.kt` — `AiRequestMessage`, `AiResponse`, `AiResult` (Success/Failure).
- `app/src/main/java/com/aiagent/mobile/domain/model/FileKind.kt` — `FileKind` (TEXT/IMAGE/PDF/ARCHIVE/BINARY) va `FileKindClassifier`.
- `app/src/main/java/com/aiagent/mobile/domain/model/IngestedFile.kt` — AI'ga tayyor fayl (matn + rasmlar + izoh).
- `app/src/main/java/com/aiagent/mobile/domain/model/PdfPages.kt` — PDF sahifa rasmlari natijasi.
- `app/src/main/java/com/aiagent/mobile/domain/repository/AiChatRepository.kt` — `complete()` va `testConnection()`.
- `app/src/main/java/com/aiagent/mobile/domain/repository/SettingsRepository.kt` — provider va sozlamalar oqimlari.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/TokenEstimator.kt` — token taxmini va byudjetga kesish.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/HistoryWindow.kt` — suhbat tarixini byudjetga sig'dirish.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/FileContextBuilder.kt` — fayllardan kontekst bloki + ogohlantirishlar.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/IngestAttachment.kt` — fayl turiga qarab o'qish strategiyasi.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/ApiBaseNormalizer.kt` — base URL normallashtirish.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/ApiKeyMasker.kt` — kalitni `sk-•••a91f` ko'rinishiga keltirish.

### Data qatlami
- `app/src/main/java/com/aiagent/mobile/data/ai/dto/ChatCompletionDtos.kt` — OpenAI-mos wire-format DTO'lar.
- `app/src/main/java/com/aiagent/mobile/data/ai/OpenAiChatApi.kt` — Retrofit `chat/completions` interfeysi.
- `app/src/main/java/com/aiagent/mobile/data/ai/AiChatRepositoryImpl.kt` — chaqiruv, HTTP→`AiError` tasnifi, vision formati.
- `app/src/main/java/com/aiagent/mobile/data/security/KeyEncryptor.kt` — Android Keystore AES/GCM shifrlash.
- `app/src/main/java/com/aiagent/mobile/data/database/SettingsDto.kt` — provider/sozlama yozuvlari (kalit shifrlangan).
- `app/src/main/java/com/aiagent/mobile/data/database/SettingsRepositoryImpl.kt` — DataStore'da provider va sozlamalar.
- `app/src/main/java/com/aiagent/mobile/data/filesystem/ArchiveReader.kt` — ZIP/JAR/APK/AAR o'quvchi (`java.util.zip`).
- `app/src/main/java/com/aiagent/mobile/data/filesystem/PdfPageRenderer.kt` — `PdfRenderer` orqali sahifa rasmlari.
- `app/src/main/java/com/aiagent/mobile/di/NetworkModule.kt` — umumiy `OkHttpClient` (timeout'lar, xavfsiz log).
- `app/src/main/java/com/aiagent/mobile/di/UseCaseModule.kt` — domen use-case'larini Hilt'ga bog'lash.

### UI qatlami
- `app/src/main/java/com/aiagent/mobile/ui/settings/SettingsViewModel.kt` — provider CRUD, validatsiya, test.
- `app/src/main/java/com/aiagent/mobile/ui/settings/SettingsScreen.kt` — provider ro'yxati, bo'sh/yuklanish holatlari, o'chirish dialogi.
- `app/src/main/java/com/aiagent/mobile/ui/settings/ProviderFormSheet.kt` — forma (dropdown, 👁 toggle, slayder, test tugmasi).
- `app/src/main/java/com/aiagent/mobile/ui/settings/SettingsMessageText.kt` — snackbar matnlari (resurslardan).
- `app/src/main/java/com/aiagent/mobile/ui/chat/ChatViewModel.kt` — fayl biriktirish, so'rov yig'ish, xato/qayta urinish.
- `app/src/main/java/com/aiagent/mobile/ui/chat/ChatScreen.kt` — suhbat ekrani.
- `app/src/main/java/com/aiagent/mobile/ui/chat/ChatMessageComponents.kt` — xabar pufakchalari, kod bloki, ogohlantirish kartasi.
- `app/src/main/java/com/aiagent/mobile/ui/chat/MarkdownLite.kt` — ``` kod bloklarini ajratish.
- `app/src/main/java/com/aiagent/mobile/ui/common/AiErrorText.kt` — `AiError` → tushunarli matn.
- `app/src/main/res/drawable/ic_{settings,add,check,check_circle,error_circle,close,send,edit,visibility,visibility_off,attach_file,image}.xml` — 12 ta qo'lda yozilgan vektor ikonka.

### Testlar
- `app/src/test/java/com/aiagent/mobile/data/ai/AiChatRepositoryImplTest.kt` — **11 test, MockWebServer bilan haqiqiy HTTP**.
- `app/src/test/java/com/aiagent/mobile/domain/usecase/BudgetAndConfigTest.kt` — TokenEstimator (4), ApiBaseNormalizer (5), ApiKeyMasker (2), HistoryWindow (4).
- `app/src/test/java/com/aiagent/mobile/domain/usecase/FileContextBuilderTest.kt` — 6 test.
- `app/src/test/java/com/aiagent/mobile/domain/usecase/IngestAttachmentUseCaseTest.kt` — 7 test (har bir fayl turi).
- `app/src/test/java/com/aiagent/mobile/ui/chat/MarkdownLiteTest.kt` — 5 test.

## O'zgartirilgan fayllar
- `domain/model/FileContent.kt` — `Image(mimeType, base64, sizeBytes)` va `Archive(entries)` turlari qo'shildi; `Text` ga `totalBytes` qo'shildi.
- `domain/repository/DocumentRepository.kt` — `readImageBase64`, `listArchiveEntries`, `readArchiveTextEntries`, `renderPdfPages`, `fileSize`, `mimeTypeOf`.
- `domain/usecase/FileContentClassifier.kt` — **katta matn fayli endi rad etilmaydi, kesiladi** (quyidagi QAROR-2).
- `data/filesystem/SafDocumentRepository.kt` — yangi o'qish metodlari + `querySize` (cursor orqali).
- `di/RepositoryModule.kt` — `SettingsRepository` va `AiChatRepository` bog'lanishlari.
- `ui/files/FilePreviewSheet.kt` — `Image`/`Archive` uchun yangi `when` tarmoqlari.
- `ui/files/FileTreeViewModel.kt` — preview chegarasi endi `AppSettings.maxFileContextSizeBytes` dan olinadi.
- `ui/navigation/Routes.kt` + `AiAgentNavHost.kt` — `SETTINGS` manzili, `ChatPlaceholderScreen` o'rniga `ChatScreen`.
- `ui/workspace/WorkspaceScreen.kt` — appbar'da sozlamalar tugmasi.
- `res/values/strings.xml` — Faza 3 matnlari (6 ta ishlatilmagan matn o'chirildi).
- `gradle/libs.versions.toml` + `app/build.gradle.kts` — `okhttp-mockwebserver` (**faqat test**, APK'ga kirmaydi).

## O'chirilgan fayl
- `app/src/main/java/com/aiagent/mobile/ui/chat/ChatPlaceholderScreen.kt` — vaqtinchalik ekran o'z vazifasini bajardi, haqiqiy chat bilan almashtirildi.

## Asosiy texnik qarorlar

1. **QAROR — `EncryptedSharedPreferences` o'rniga Android Keystore (spetsifikatsiyadan og'ish).**
   Spetsifikatsiya `EncryptedSharedPreferences` ni ko'rsatadi, lekin `androidx.security:security-crypto`
   rasman **deprecated** va yangilanmaydi. Shuning uchun platformaning o'zi ishlatildi:
   AES/GCM, 256-bit kalit, har shifrlashda yangi tasodifiy IV, format `enc:v1:<base64(iv+ciphertext)>`.
   Prefikssiz qiymat ochiq matn deb o'qiladi (eski ma'lumot migratsiyasi). Keystore ishlamasa,
   kalit **ochiq saqlanmaydi** — `KeyEncryptorException` chiqadi va UI aniq xabar ko'rsatadi.

2. **QAROR — katta matn fayli rad etilmaydi, kesiladi (foydalanuvchi tanlovi: "to'liq yuklash + kesish").**
   Faza 2 da `FileContent.TooLarge` qaytarilardi; endi fayl chegaragacha o'qiladi va
   `truncated = true` + `totalBytes` bilan qaytadi. Kesish HECH QACHON yashirin emas:
   ham preview'da, ham AI kontekstida "fayl 12 MB, faqat birinchi 100 KB yuborildi" deb yoziladi.
   `TooLarge` faqat rasmlar uchun qoldi (rasmni kesish ma'nosiz).
   Shu sababli `FileContentClassifierTest` dagi "chegaradan katta fayl TooLarge qaytaradi" testi
   yangi kutilmaga almashtirildi (bu — eski kodning buzilishi emas, ongli strategiya o'zgarishi).
   Qo'shimcha: kesilgan matn oxiridagi yarim qolgan UTF-8 belgisi `trimIncompleteUtf8` bilan olinadi.

3. **QAROR — fayl turlari bo'yicha strategiya (foydalanuvchi tanlovi: "barcha turlar", nol yangi kutubxona).**
   TEXT → matn (kesish bilan); IMAGE → base64 multimodal; PDF → `PdfRenderer` sahifa rasmlari (JPEG, 82%);
   ARCHIVE (ZIP/JAR/APK/AAR) → `java.util.zip` bilan ro'yxat + matnli yozuvlar; BINARY → metadata + aniq izoh.
   Barchasi Android platformasi API'lari bilan, hech qanday uchinchi tomon kutubxonasisiz.

4. **QAROR — vision "graceful" (foydalanuvchi tanlovi).**
   Provider rasmlarni qabul qilmasa (400 + `image_url`/`vision`/`multimodal` matni), `AiError.VisionUnsupported`
   qaytadi; `ChatViewModel` so'rovni **rasmsiz, metadata bilan qayta yuboradi** va ekranda aniq xabar chiqadi.
   Crash yo'q, rasm jim tashlab yuborilmaydi.

5. **QAROR — `content` maydoni `JsonElement`.**
   OpenAI sxemasida `content` matn YOKI qismlar massivi bo'la oladi. Maxsus serializer yozmasdan
   `JsonPrimitive` (matn) va `JsonArray` (vision) orqali ikkalasi ham qoplandi.

6. **QAROR — `encodeDefaults = true`.**
   Test shuni ko'rsatdi: `kotlinx.serialization` standart qiymatlarni yozmaydi, ya'ni `"stream":false`
   so'rovga UMUMAN tushmagan edi. Endi aniq yoziladi — "streaming yo'q" qarori simda ham ko'rinadi.

7. **QAROR — Retrofit nusxasi manzil+kalit bo'yicha keshlanadi, `OkHttpClient` bitta.**
   Kesh kalitida API kalit ham bor: kalit o'zgartirilganda eski interceptor ishlatilib qolmaydi.

8. **QAROR — log darajasi `BASIC` + `redactHeader("Authorization")`.**
   `HEADERS`/`BODY` darajasi API kalitini logcat'ga yozib qo'yadi — bu kalit sizib chiqishi.

9. **QAROR — faol provider yagona manbadan.**
   `activeProviderId` alohida saqlanmaydi, provider ro'yxatidagi `isDefault` dan olinadi
   (ikki joyda saqlash ziddiyat keltirardi). Birinchi provider avtomatik faol bo'ladi.

10. **QAROR — provider dropdown standartlari.** TokenRouter → `https://api.tokenrouter.io/v1`,
    DeepSeek → `https://api.deepseek.com/v1`, Custom → bo'sh. Maydon doim tahrirlanadigan.

11. **QAROR — token byudjeti.** Fayllarga kontekstning 60%, qolgani tarix va javobga.
    Tarix `HistoryWindow` bilan eng eskidan boshlab tashlanadi va bu ham ekranda aytiladi.

12. **QAROR — `ChatScreen` ikki faylga bo'lindi** (400 qator chegarasi, 7-qoida).

## Ma'lum cheklovlar
- **Suhbat tarixi faqat xotirada** — ilova qayta ochilsa yo'qoladi. Doimiy saqlash Faza 10 rejasida.
- **Kesish tufayli juda katta faylning oxiri ko'rinmaydi.** Bu foydalanuvchi tanlagan strategiyaning
  to'g'ridan-to'g'ri natijasi; to'liq yechim Faza 9 dagi Room indeksi va token byudjeti.
- **PDF faqat rasm sifatida** yuboriladi (`PdfRenderer` matn chiqarmaydi, matn uchun uchinchi tomon
  kutubxonasi kerak bo'lardi — bu esa "nol yangi kutubxona" shartiga zid).
- **`hiltViewModel()` deprecated ogohlantirishi** (4 faylda). Yangi paketga o'tish Faza 2 kodini
  ham ushlashi kerak, shuning uchun bu fazada tegilmadi — build'ga ta'siri yo'q.
- **Emulyator yo'q** (`/dev/kvm` mavjud emas) — qurilmadagi vizual tekshiruv foydalanuvchiga qoldirildi.
- **API kalit formaga tahrirlashda ochiq qaytariladi** (maydon yashirin holda). Kalitni o'zgartirmasdan
  saqlansa, eski qiymat qoladi; bo'sh qoldirib yangi provider yaratib bo'lmaydi.

## UI/UX 11 mezoni — har bir ekran bo'yicha javob

| Mezon | SettingsScreen | ProviderFormSheet | ChatScreen |
|---|---|---|---|
| 1. Bo'sh holat | Ikonka + tushuntirish + "Provider qo'shish" | — (forma bo'sh ochilmaydi) | "Suhbatni boshlang" + izoh; provider bo'lmasa alohida holat |
| 2. Yuklanish holati | `CircularProgressIndicator` | Test tugmasida spinner | "AI o'ylamoqda…" + fayl o'qish indikatori |
| 3. Xato holati | Snackbar (shifrlash/test xatosi) | Maydon ostida inline xato + ❌ natija qatori | Xato kartasi + sabab + "Qayta urinish" |
| 4. Buzuvchi amal tasdiqlanadi | O'chirish `AlertDialog` orqali | Bekor qilish formani yopadi (saqlanmaydi) | Biriktirilgan faylni o'chirish × bilan (faylga tegmaydi) |
| 5. ≥48dp teginish | FAB, ikonka, TextButton'lar 48dp | Barcha tugma/👁/slayder 48dp+ | Yuborish 48dp, xabar maydoni 48–96dp |
| 6. Amalga javob | Saqlandi/faollashdi/o'chirildi snackbar | ✅ "Ulanish ishlaydi" / ❌ sabab | Javob pufakchasi + token soni |
| 7. Material 3 izchilligi | M3 kartalar, AssistChip, FAB | M3 OutlinedTextField, ExposedDropdownMenu, Slider | M3 Surface/TopAppBar/InputChip |
| 8. Kognitiv yuk | Bir vazifa: provider ro'yxati | Maydonlar guruhlangan, izohlar qisqa | Tarix + biriktirmalar + bitta kiritish qatori |
| 9. Xavfsiz standart | Kalit shifrlangan, ro'yxatda yashirin | Kalit yashirin, `ALWAYS_CONFIRM` saqlanadi | Kesish haqida aniq ogohlantirish |
| 10. Parol maydoni + 👁 | — | `PasswordVisualTransformation` + 👁 toggle + inline validatsiya ("API kalit talab qilinadi") | Qo'llanilmaydi (parol maydoni yo'q) |
| 11. Orqaga navigatsiya | Appbar ← Workspace'ga | Sheet yopilishi = bekor qilish | Appbar ← fayl daraxtiga |

## TEKSHIRUV NATIJASI:

**1. `./gradlew build` — MUVAFFAQIYATLI.**
`BUILD SUCCESSFUL in 2m 51s`, 108 vazifa, 0 xato. Birinchi urinishda 4 ta compile xatosi
(`LazyListScope` ichida `@Composable` chaqiruvi) va 1 ta resurs xatosi (`?attr/colorControlNormal`
o'rniga `?android:attr/colorControlNormal` kerak) chiqdi — barchasi SHU fazada tuzatildi.

**2. Testlar: 72 / 0 muvaffaqiyatsiz / 0 xato** (Faza 2 da 25 edi, +47 yangi).
XML hisobotdan o'qildi: AiChatRepositoryImplTest 11, IngestAttachmentUseCaseTest 7,
FileContentClassifierTest 8, FileContextBuilderTest 6, ApiBaseNormalizerTest 5, MarkdownLiteTest 5,
TokenEstimatorTest 4, HistoryWindowTest 4, FileTreeFlattenerTest 6, DomainModelDefaultsTest 6,
WorkspaceDtoTest 4, FormattersTest 3, ApiKeyMaskerTest 2, DomainPurityTest 1.

**3. So'rov provider'ga yetib borishi — ISBOTLANDI (mock server orqali).**
Qurilmada haqiqiy API kaliti bilan sinab bo'lmadi (emulyator yo'q), shuning uchun spetsifikatsiyaning
"yoki hech bo'lmasa so'rov mock/test serverga yetib borganini logdan isbotlash" bandi bajarildi.
`AiChatRepositoryImplTest` `MockWebServer` ishlatadi: ilova kodi haqiqiy TCP ulanish ochadi va
server tomonida so'rov yozib olinadi. Tekshirilgan faktlar:
- `POST /v1/chat/completions` (manzil to'g'ri),
- `Authorization: Bearer sk-test-1234a91f`,
- `Content-Type: application/json; charset=utf-8`,
- tana: `{"model":"test-model","messages":[{"role":"user","content":"Salom"}],"max_tokens":256,"temperature":0.3,"stream":false}`.

**4. 401 tushunarli xabar beradi, crash bo'lmaydi — ISBOTLANDI.**
Mock server 401 + `{"error":{"message":"Incorrect API key provided"}}` qaytarganda
natija `AiResult.Failure(AiError.Unauthorized)` bo'ladi (exception emas), UI esa
"API kalit noto'g'ri yoki muddati o'tgan. Sozlamalardan kalitni tekshiring (401)" matnini ko'rsatadi.
Xuddi shunday 429 → "Juda ko'p so'rov yuborildi yoki kvota tugadi (429)",
5xx → "Server xatosi (503): upstream provider unavailable",
ulanish yo'q → "Internet aloqasi yo'q…", timeout → "Server javob berishga ulgurmadi…".

**5. Lint: 0 xato, 3 kutilgan ogohlantirish** (`OldTargetApi` + 2 × `NewerVersionAvailable`).
Faza 3 davomida paydo bo'lgan 11 ta `UnusedResources` va 1 ta `UseKtx` ogohlantirishining barchasi
tuzatildi (ikonkalar ishlatildi yoki o'chirildi, `Bitmap.createBitmap` → core-ktx).

**6. APK tekshiruvi (`apkanalyzer`):** `minSdk=30`, `targetSdk=36`; ruxsatlar o'zgarmagan —
`INTERNET`, `ACCESS_NETWORK_STATE` (+ debug dynamic-receiver). `artifacts/aiagent-faza3-debug.apk`
(35 971 839 bayt); eski faza2 APK o'chirildi.

**7. Arxitektura qo'riqchisi:** `DomainPurityTest` yashil — domen qatlamida `android.*`/`androidx.*` import yo'q.
Eng katta fayl 393 qator (`ProviderFormSheet.kt`) — 400 chegarasidan oshmadik.

**Qurilmada tekshirish uchun (foydalanuvchiga):**
1. Sozlamalar → provider qo'shing (haqiqiy API kalit bilan) → "Test qilish" → ✅ chiqishi kerak.
2. Noto'g'ri kalit bilan test → ❌ va "API kalit noto'g'ri…" xabari, ilova crash bo'lmasligi kerak.
3. Ro'yxatda kalit faqat `sk-•••a91f` ko'rinishida ko'rinishi kerak.
4. Fayl daraxtidan fayl tanlab chatga o'ting → xabar yuboring → javob kelishi kerak.
5. Rasm yoki PDF biriktirib ko'ring: multimodal provider bo'lsa javobda rasm tavsifi,
   aks holda "Bu provider rasmlarni qabul qilmaydi" xabari chiqishi kerak.

## Faza 3 — SELF-REVIEW VA YAKUNIY TEKSHIRUV (qo'shimcha, shu kuni)

Faza 3 yashil bo'lgach, mexanik (skript bilan) o'zgartirilgan fayllar qayta o'qib chiqildi.
Bu tekshiruv 4 ta kamchilikni topdi va barchasi tuzatildi:

1. **O'lik kod o'chirildi** — `ChatViewModel.dismissError()` hech qayerdan chaqirilmagan edi
   (xato ekranda karta sifatida ko'rsatiladi, alohida "yopish" amali yo'q).
2. **Noaniq ogohlantirish matni tuzatildi** — tarix qisqartirilganda ekranga
   "Kontekst qisqartirildi: 3" chiqardi (3 nima ekanligi tushunarsiz). Endi maxsus matn:
   "Suhbat tarixidan %1$d ta eski xabar tashlandi — kontekst oynasiga sig'madi."
   Shu sababli `chat_context_truncated_title` keraksiz bo'lib qoldi va o'chirildi.
3. **Muvaffaqiyatli qayta urinishdan keyin eski xato kartasi o'chiriladi** —
   `messages.dropLastWhile(ChatUiMessage::isError)`. Aks holda javob eski xato ostida paydo bo'lib,
   foydalogini chalg'itardi.
4. **Xato kartasi ichidagi indentatsiya** to'g'rilandi (funktional emas, lekin uslub izchilligi).

Yo'l-yo'lakay ikkita xato ham shu tekshiruvda qayta qurish paytida aniqlandi va tuzatildi:
- `strings.xml` dagi yangi matnda apostrof ekranna olinmagan (`sig'madi` → `sig\'madi`) —
  AAPT2 "Invalid unicode escape sequence" deb xato berdi (xabar chalg'ituvchi, asl sabab apostrof).
- Shu bois yakuniy natija quyidagicha yangilandi.

### Yakuniy TEKSHIRUV NATIJASI (oldingi bo'limdagi raqamlarni yangilaydi)
- **`./gradlew build`: `BUILD SUCCESSFUL in 3m 10s`**, 108 vazifa, 0 xato.
- **Testlar: 72 / 0 muvaffaqiyatsiz / 0 xato** (o'zgarmadi).
- **Lint: 0 xato, 3 kutilgan ogohlantirish** (`OldTargetApi` + 2 × `NewerVersionAvailable`).
- **APK:** `artifacts/aiagent-faza3-debug.apk` — **36 264 891 bayt** (oldingi 35 971 839 o'rniga),
  `minSdk=30`, `targetSdk=36`, ruxsatlar o'zgarmagan (`INTERNET`, `ACCESS_NETWORK_STATE`
  + debug dynamic-receiver).
- **Eng katta fayl:** 393 qator (`ProviderFormSheet.kt`) — 400 chegarasidan oshmadik.
- Kompilyator ogohlantirishlari: 8 ta noyob, barchasi mavjud turdagi (4 × `hiltViewModel`
  deprecated, 3 × `@ApplicationContext` value-parameter, 1 × `LocalClipboardManager` deprecated).
  Yangi turdagi ogohlantirish yo'q; `UnusedResources` va `UseKtx` — nol.

---

# FAZA 4 — Tool system va lokal agent loop (2026-08-30)

**Maqsad:** oddiy chatni haqiqiy agentga aylantirish — AI endi telefon fayllari ustida
o'zi tool tanlab ishlaydi. Colab yo'nalishi yo'q, `ExecutionRouter` chaqirilmaydi
(spetsifikatsiya talabi; Faza 5-6 da).

## Yaratilgan fayllar

**Tool tizimi (domen, sof Kotlin):**
- `app/src/main/java/com/aiagent/mobile/domain/tools/ToolResult.kt` (24) — spetsifikatsiyadagi
  aniq shakl: `Success` / `Error(recoverable)` / `PermissionRequired`.
- `app/src/main/java/com/aiagent/mobile/domain/tools/AgentTool.kt` (73) — tool interfeysi,
  `ToolParameter`, `ParamType`, `ToolContext(rootUri, maxFileBytes)`, `requireArg`/`optionalArg`.
- `app/src/main/java/com/aiagent/mobile/domain/tools/ToolPaths.kt` (123) — nisbiy yo'l → SAF URI,
  yaratish/o'qish yordamchilari.
- `app/src/main/java/com/aiagent/mobile/domain/tools/ToolRegistry.kt` (90) — **13 ta tool**
  (spetsifikatsiya: 8 fayl + 2 qidiruv + 3 tahrir), `specs`, `invoke`, noma'lum nom uchun aniq xato.
- `app/src/main/java/com/aiagent/mobile/domain/tools/files/ReadOnlyFileTools.kt` (160) —
  `list_directory`, `read_file`, `get_file_info`.
- `app/src/main/java/com/aiagent/mobile/domain/tools/files/MutatingFileTools.kt` (253) —
  `write_file`, `create_file`, `delete_file`, `move_file`, `copy_file`.
- `app/src/main/java/com/aiagent/mobile/domain/tools/search/SearchTools.kt` (93) —
  `search_files` (max 100), `search_text` (max 30 fayl × 5 moslik).
- `app/src/main/java/com/aiagent/mobile/domain/tools/edit/EditTools.kt` (253) —
  `apply_patch`, `replace_text`, `insert_text`.
- `app/src/main/java/com/aiagent/mobile/domain/tools/edit/PatchEngine.kt` (204) —
  `java-diff-utils` bilan unified diff qo'llash + diff ekrani uchun qatorlar.
- `app/src/main/java/com/aiagent/mobile/domain/tools/edit/EditCoordinator.kt` (296) —
  `ALWAYS_CONFIRM` / `AUTO_APPLY`, tasdiq navbati, Edit History (max 10) va Undo.
- `app/src/main/java/com/aiagent/mobile/domain/tools/edit/FileChecksumStore.kt` (56) —
  SHA-256 bilan conflict nazorati.
- `app/src/main/java/com/aiagent/mobile/domain/tools/edit/ProposedFileEdit.kt` (59).

**Agent sikli:**
- `app/src/main/java/com/aiagent/mobile/domain/agent/AgentController.kt` (354) — sikl,
  `AgentLimits`, "Stop Agent", tasdiq darvozasi.
- `app/src/main/java/com/aiagent/mobile/domain/agent/AgentStep.kt` (37).
- `app/src/main/java/com/aiagent/mobile/domain/agent/AgentPrompt.kt` (42).

**Ma'lumot va UI:**
- `app/src/main/java/com/aiagent/mobile/data/filesystem/SafDocumentWriter.kt` — SAF'ga yozish,
  ko'chirish, o'chirish, yo'l normallashtirish.
- `app/src/main/java/com/aiagent/mobile/data/filesystem/SafSearcher.kt` — rekursiv qidiruv.
- `app/src/main/java/com/aiagent/mobile/di/AgentModule.kt` (58) — barcha agent bog'lanishlari
  `@Singleton`.
- `app/src/main/java/com/aiagent/mobile/ui/diff/DiffPanel.kt` (194) — diff ekrani.
- `app/src/main/java/com/aiagent/mobile/ui/agent/AgentPanel.kt` (165) — qadamlar + Stop.
- `app/src/main/java/com/aiagent/mobile/ui/chat/AgentChatDelegate.kt` (163) — chat ↔ agent ko'prigi.
- `app/src/main/java/com/aiagent/mobile/ui/chat/AgentModeRow.kt` (95) — agent rejimi tugmachasi.
- `app/src/main/java/com/aiagent/mobile/ui/chat/ChatUiState.kt` (52) — UI modellarini ajratish.
- `app/src/main/java/com/aiagent/mobile/domain/usecase/ByteFormatter.kt` — hajm formatlash
  domen qatlamiga ko'chirildi (qarang: qaror 7).

**Testlar:**
- `app/src/test/java/com/aiagent/mobile/domain/tools/FakeDocumentRepository.kt` — in-memory
  fayl tizimi (emulyatorsiz tekshiruv imkonini beradi).
- `app/src/test/java/com/aiagent/mobile/domain/tools/ToolRegistryTest.kt` (131) — 10 test.
- `app/src/test/java/com/aiagent/mobile/domain/tools/FileEditToolsTest.kt` (334) — 18 test.
- `app/src/test/java/com/aiagent/mobile/domain/agent/AgentControllerTest.kt` (356) — 10 test.

## O'zgartirilgan fayllar

- `domain/repository/DocumentRepository.kt` — Faza 4 uchun **10 ta yangi metod**: `resolveChild`,
  `exists`, `writeFile`, `createFile`, `createDirectory`, `deleteDocument`, `moveDocument`,
  `copyDocument`, `searchFiles`, `searchInFiles`.
- `domain/model/TextMatch.kt` — yangi model (`path`, `lineNumber`, `lineText`).
- `domain/model/AiChat.kt` — tool-calling: `ToolCallRequest`, `AiResponse.toolCalls`,
  `AiRequestMessage.toolCallId` va `.toolCalls`.
- `domain/model/ChatMessage.kt` — `MessageRole`ga **`TOOL`** qo'shildi.
- `domain/repository/AiChatRepository.kt` — `complete(..., tools: List<ToolSpec> = emptyList())`.
- `data/ai/dto/ChatCompletionDtos.kt` — function-calling DTO'lari bilan qayta yozildi.
- `data/ai/AiChatRepositoryImpl.kt` (396) — tool sxemasini yuborish, `role:"tool"` xabarlari,
  arguments JSON matnini `Map`ga aylantirish; **bo'sh `content` + `tool_calls` endi xato emas**.
- `data/filesystem/SafDocumentRepository.kt` (276) — yangi 10 metodning SAF implementatsiyasi.
- `ui/chat/ChatViewModel.kt` (394), `ui/chat/ChatScreen.kt` (373) — agent rejimi ulandi.
- `ui/navigation/Routes.kt`, `ui/navigation/AiAgentNavHost.kt` — chat endi `workspaceId` ni
  ham olib yuradi (agent tool'lari ildizni bilmasa ishlamaydi).
- `ui/common/Formatters.kt` — endi `ByteFormatter`ga bir qatorli delegat.
- `res/values/strings.xml` — agent/diff matnlari.
- `gradle/libs.versions.toml`, `app/build.gradle.kts` — `io.github.java-diff-utils:4.17`.
- Testlar: `DomainPurityTest` (qo'riqchi kuchaytirildi), `DomainModelDefaultsTest`
  (`MessageRole` 4 ta), `IngestAttachmentUseCaseTest` (yangi interfeys metodlari).

## Asosiy texnik qarorlar

1. **Tool'lar sof Kotlin, barcha I/O `DocumentRepository` orqali.** Shuning uchun 13 ta tool
   emulyatorsiz, `FakeDocumentRepository` bilan JVM testida tekshirildi. Bu Faza 4 dagi eng
   muhim arxitektura qarori — aks holda tool mantiqini tekshirishning iloji bo'lmas edi.
2. **`java-diff-utils` domen qatlamida qoldi.** Kutubxona sof JVM (Android'ga bog'liq emas),
   shuning uchun `DomainPurityTest` buzilmadi. Yangi Android bog'liqligi qo'shilmadi.
3. **Agent rejimi SUKUT BO'YICHA O'CHIQ.** Foydalanuvchi chat pastidagi tugmachadan o'zi yoqadi.
   Sabab: agent fayllarga yozishi mumkin — xavfsiz standart tamoyili.
4. **Fayl O'CHIRISH `AUTO_APPLY` rejimida ham tasdiq so'raydi.** Spetsifikatsiyaning UI/UX
   qoidasi "fayl o'chirish ... har doim tasdiqlash dialogi orqali o'tadi" deydi. Foydalanuvchi
   avtomatik rejimni tanlagan bo'lsa ham, qaytarib bo'lmaydigan amal jim bajarilmaydi.
   (`EditCoordinator.request` da `edit.kind == EditKind.DELETE` sharti.) Test bilan mustahkamlandi.
5. **`move_file` = nusxa olish + o'chirish**, `DocumentFile.renameTo` emas. `renameTo` ko'p SAF
   provider'larida papkalar aro ko'chirishda ishonchsiz (Faza 2 da kuzatilgan).
6. **Qidiruv indeksiz** (spetsifikatsiya shuni so'raydi: "hozircha oddiy string qidiruv, index yo'q").
   Chegaralar: `MAX_VISITS = 5000`, qator uzunligi 200 belgi. Room indeksi — Faza 9.
7. **Hajm formatlash `ui/common`dan `domain/usecase/ByteFormatter`ga ko'chirildi.** `ReadOnlyFileTools`
   UI'dan import qilayotgan edi, lekin `DomainPurityTest` faqat `android.`/`androidx.` ni tekshirgani
   uchun bu **sezilmay qolgan** edi. Qo'riqchi kengaytirildi: endi `com.aiagent.mobile.ui.` va
   `com.aiagent.mobile.data.` importlari ham taqiqlangan.
8. **Agent `@Singleton` va o'z `CoroutineScope`ida.** `viewModelScope` ishlatilsa, chatdan chiqish
   bilan agent o'lar edi; sikl 10 daqiqagacha davom etishi mumkin.
9. **OpenAI tool-calling tartibi qat'iy rioya qilinadi:** `role:"tool"` xabaridan oldin shu
   chaqiruvlarni o'z ichiga olgan `assistant` xabari yuboriladi. Aks holda provider
   400 qaytaradi. Bu tartib alohida test bilan mustahkamlangan.
10. **Chat tarixi agentga faqat USER/ASSISTANT rollari bilan uzatiladi** — `TOOL` roli
    `tool_call_id` talab qiladi va uni siklning o'zi yaratadi.

## Testlar topgan va tuzatilgan haqiqiy kod xatolari

Bu muhim bo'lim: quyidagi 4 ta xato **ishlab chiqarish kodida** edi va ularni testlar topdi.

1. **`create_file` faylni noto'g'ri papkaga yaratardi.** `EditCoordinator.perform` CREATE tarmog'ida
   `parentUriOf(edit.uri)` chaqirilardi, lekin `MutatingFileTools.CreateFile` `uri`ga **ota papkani**
   yozadi. Natijada fayl ota papkaning ichiga emas, **bobosiga** yaratilardi. Tuzatildi: CREATE
   uchun `edit.uri` to'g'ridan-to'g'ri ota papka sifatida ishlatiladi.
2. **`PatchEngine` real patch'larni buzardi.** `patchText.lines().filter { it.isNotBlank() }`
   diff ichidagi **bo'sh kontekst qatorini** ham o'chirib yuborardi — hunk qatorlar soni mos
   kelmay, har doim conflict chiqardi. Tuzatildi: faqat boshi/oxiri tozalanadi
   (`dropWhile` / `dropLastWhile`).
3. **`AgentController`da poyga (race).** `_state.value = WAITING_FOR_PERMISSION` **oldin** e'lon
   qilinardi, `approvalGate` esa **keyin** o'rnatilardi. UI holatni ko'rib darhol tasdiqlasa,
   `approvalGate` hali `null` bo'lib, tasdiq **jim yo'qolardi** va agent abadiy osilib qolardi.
   Tuzatildi: darvoza holatdan oldin o'rnatiladi.
4. **`delete_file` `AUTO_APPLY`da tasdiqsiz bajarilardi** — yuqoridagi 4-qarorga qarang.
5. **Diff ekrani tasodifan ochilardi (Compose nuqsoni).** `ChatScreen` kutilayotgan amalni
   `viewModel.pendingEdit()` funksiyasidan o'qirdi, `EditCoordinator.pending` esa oddiy `var` edi —
   kuzatiladigan holat emas. Compose uning o'zgarganini bilmasdi va diff ekrani faqat boshqa
   sabab bilan qayta chizilganda, ya'ni **tasodifan** paydo bo'lardi. Tuzatildi: `pending`
   `MutableStateFlow`ga aylantirildi (`EditCoordinator.pendingFlow` → `AgentController.pendingEdit`
   → `AgentChatUi.pendingEdit`) va ekran endi `collectAsStateWithLifecycle` orqali o'qiydi.

Shuningdek: "14 ta tool" degan dastlabki hisob **noto'g'ri** edi (spetsifikatsiya 13 ta: 8+2+3).
KDoc, test kutilmalari va `ToolRegistry` izohi tuzatildi.

## Ma'lum cheklovlar

- **Agent sikli jarayon (process) o'ldirilsa yo'qoladi.** `@Singleton` faqat navigatsiyadan
  himoya qiladi. Haqiqiy fon rejimi uchun foreground service kerak — bu spetsifikatsiyada
  so'ralmagan va Faza 4 chegarasidan tashqarida, shuning uchun ataylab qoldirildi.
- **Suhbat tarixi faqat xotirada** — ilova qayta ochilsa yo'qoladi (doimiy saqlash Faza 10).
- **Edit History faqat xotirada va max 10 ta.** Ilova yopilsa Undo tarixi yo'qoladi.
- **Diff ekrani matnli fayllar uchun.** Ikkilik faylga yozish so'ralsa, diff bo'sh ko'rinadi
  (lekin amal baribir tasdiqdan o'tadi).
- **`AUTO_APPLY` rejimida Undo faqat agent yozgan o'zgartirishlarni qaytaradi**, tashqi
  o'zgarishlarni emas.
- **Qidiruv sekin bo'lishi mumkin** katta workspace'da (indeks yo'q; Faza 9).
- Qurilmada haqiqiy tekshiruv bu muhitda mumkin emas (`/dev/kvm` yo'q — emulyator ishlamaydi).

## UI/UX 11 mezoni — har bir ekran bo'yicha javob

**DiffPanel (diff ekrani):**
- Bo'sh holat — **BOR**: matn o'zgarmasa "Matn o'zgarmadi" yozuvi chiqadi.
- Yuklanish — **QO'LLANILMAYDI**: diff xotirada hisoblanadi (`remember`), tarmoq/fayl I/O yo'q.
- Xato holati — **BOR**: yozish muvaffaqiyatsiz bo'lsa agent xatosi chat'da ko'rsatiladi.
- Tasdiqlash — **BOR (bu ekranning o'zi tasdiqlashdir)**: "Qabul qilish" / "Rad etish".
  O'chirish amali uchun butun fayl o'chirilishi diff'da ko'rinadi.
- 48dp — **BOR**: ikkala tugma `height(48.dp)`.
- Feedback — **BOR**: qabuldan keyin agent qadami va chat xabari paydo bo'ladi.
- Izchillik — **BOR**: Material 3 `ModalBottomSheet`, ranglar `secondaryContainer`/`errorContainer`.
- Kognitiv yuk — **BOR**: faqat yo'l, tavsif, qisqacha hisob va 2 ta tugma.
- Xavfsiz standart — **BOR**: yopish = rad etish (fayl o'zgarmaydi).
- Klaviatura — **QO'LLANILMAYDI**: matn kiritish maydoni yo'q.
- Orqaga — **BOR**: sheet'ni yopish "Rad etish" bilan bir xil, agent osilib qolmaydi.

**AgentPanel (qadamlar paneli):**
- Bo'sh holat — **BOR**: qadamlar bo'lmasa faqat holat sarlavhasi ko'rinadi.
- Yuklanish — **BOR**: `PLANNING`/`RUNNING_TOOL` da `CircularProgressIndicator`.
- Xato holati — **BOR**: muvaffaqiyatsiz qadam qizil ikonka bilan, holat "Agent to'xtatildi (xato)".
- Tasdiqlash — **QO'LLANILMAYDI**: bu faqat kuzatuv paneli (tasdiq DiffPanel'da).
- 48dp — **BOR**: "Stop Agent" tugmasi `height(48.dp)`.
- Feedback — **BOR**: har bir tool chaqiruvi va natijasi darhol ro'yxatga qo'shiladi.
- Izchillik — **BOR**: `surfaceVariant` fon, Material 3 ikonkalari.
- Kognitiv yuk — **BOR**: ro'yxat balandligi 200dp bilan cheklangan, tafsilot 4 qator.
- Xavfsiz standart — **BOR**: agent rejimi o'chiq holda ochiladi.
- Klaviatura — **QO'LLANILMAYDI**.
- Orqaga — **BOR**: chat ekranining bir qismi, alohida navigatsiya yo'q.

**ChatScreen (yangi qismlar):**
- Bo'sh holat — **BOR** (Faza 3 dagidek).
- Yuklanish — **BOR**: agent rejimida indikator AgentPanel ichida, oddiy chatda "AI o'ylamoqda…".
- Xato holati — **BOR**: agent xatosi ham xato kartasi + "Qayta urinish" bilan.
- Tasdiqlash — **BOR**: fayl o'zgartirish DiffPanel orqali.
- 48dp — **BOR**: agent tugmachasi qatori `heightIn(min = 48.dp)`, "Qaytarish" `height(48.dp)`.
- Feedback — **BOR**: tugmachadan keyin izoh matni o'zgaradi ("Agent rejimi: fayllar bilan ishlaydi").
- Izchillik — **BOR**: `Switch`, `TextButton`, Material 3 ranglari.
- Kognitiv yuk — **BOR**: workspace bo'lmasa agent qatori umuman ko'rsatilmaydi.
- Xavfsiz standart — **BOR**: agent rejimi sukut bo'yicha **o'chiq**.
- Klaviatura — **BOR** (Faza 3 dagidek, o'zgarmadi).
- Orqaga — **BOR** (o'zgarmadi).

## TEKSHIRUV NATIJASI:

- **`./gradlew build`: `BUILD SUCCESSFUL in 10m`** — 108 vazifa, **0 xato** (yakuniy, 13-build;
  toza muhitda bog'liqliklar qayta yuklangani uchun uzoq davom etdi).
  Faza 4 davomida jami **13 ta build** ishga tushirildi; 1-4, 9-10 va 12-build xatolari
  shu fazaning o'zida tuzatildi, keyingi fazaga hech narsa qoldirilmadi.
- **Testlar: 110 / 0 muvaffaqiyatsiz / 0 xato** (Faza 3: 72 → Faza 4: **110**, +38 yangi test).
- **Lint: 0 xato, 3 kutilgan ogohlantirish** (`OldTargetApi` + 2 × `NewerVersionAvailable`) —
  Faza 3 bazasi bilan bir xil. Yo'l-yo'lakay paydo bo'lgan 9 ta ogohlantirish
  (7 × `UnusedResources`, 1 × `UseKtx`, 1 × `PluralsCandidate`) tuzatildi/o'chirildi.
- **APK:** `artifacts/aiagent-faza4-debug.apk` — **36 242 545 bayt**, `minSdk=30`, `targetSdk=36`.
  Ruxsatlar o'zgarmadi (`INTERNET`, `ACCESS_NETWORK_STATE`) — tool'lar SAF orqali ishlaydi,
  xotiraga to'g'ridan-to'g'ri ruxsat kerak emas.
- **Eng katta fayl: 396 qator** (`AiChatRepositoryImpl.kt`) — 400 chegarasidan oshmadik.
  Test fayli 419 qatorga yetgani uchun `ToolRegistryTest` / `FileEditToolsTest`ga bo'lindi.
- **`DomainPurityTest` yashil** va endi kuchaytirilgan: domen qatlamida `android.*`, `androidx.*`,
  `com.aiagent.mobile.ui.*`, `com.aiagent.mobile.data.*` importlari taqiqlangan.

**Spetsifikatsiyaning TEKSHIRUV TALABI bo'yicha:**
- ✅ **"Python nima?" uchun hech qanday tool chaqirilmaydi** — `AgentControllerTest` dagi
  `oddiy savol uchun hech qanday tool chaqirilmaydi` testi: `documents.calls` bo'sh,
  `chat.callCount == 1`, javob to'g'ridan-to'g'ri qaytadi. Tool'lar taklif qilingan
  (`lastToolSpecs` 13 ta), lekin AI hech birini tanlamagan.
- ✅ **Fayl so'rovida `list_directory` chaqiriladi** — `fayl so'rovida list_directory chaqiriladi
  va javob yig'iladi` testi: 2 ta so'rov, natija `role:"tool"` xabari bilan qaytarilgan,
  `toolCallId` to'g'ri, tarkibida `src` bor.
- ✅ **Diff + "Qabul qilish" haqiqatan faylga yozadi** — `tasdiqdan keyin fayl haqiqatan
  yoziladi` va `ALWAYS_CONFIRM da agent to'xtaydi va tasdiqdan keyin fayl yoziladi` testlari
  fayl mazmunini o'qib tasdiqlaydi.
- ✅ **`./gradlew build` xatosiz o'tdi.**

**Qurilmada tekshirish uchun (foydalanuvchiga):**
1. Workspace tanlang → fayl daraxti → chat. Pastda "Agent rejimi" tugmachasini yoqing.
2. "Python nima?" deb yozing → agent panelida **hech qanday tool chaqiruvi** bo'lmasligi,
   faqat javob kelishi kerak.
3. "Shu papkadagi fayllarni ko'rsat" → panelda `Tool: list_directory` qadami va fayl ro'yxati.
4. "README.md ga bitta qator qo'sh" → diff ekrani ochilishi, yashil/qizil qatorlar ko'rinishi,
   "Qabul qilish" dan keyin fayl haqiqatan o'zgarganini tekshiring.
5. Sozlamalardan tahrirlash rejimini `AUTO_APPLY`ga o'tkazing → oddiy yozish tasdiqsiz,
   lekin **o'chirish baribir tasdiq so'rashi** kerak.

---

## Faza 5: Colab Server — sozlash va ulanish (2026-08-30)

Maqsad: telefon va Colab o'rtasidagi **ulanish**ni to'liq ishlaydigan holatga keltirish.
Buyruqlarni Colab/telefonga yo'naltirish mantig'i (routing) bu fazaga **kirmaydi** — u
Faza 6 (LLM routing) ishiga qoldirildi.

### Yaratilgan fayllar

**Colab tomoni (yangi papka `colab/`):**
- `colab/aiagent_colab_server.ipynb` — foydalanuvchiga beriladigan notebook shabloni
  (12 katakcha). Yuritish ketma-ketligi:
  1. **Setup** — `NGROK_AUTH_TOKEN = ""` alohida katakchada, aniq yo'l-yo'riq bilan
     ("ngrok.com → Dashboard → 'Your Authtoken'").
  2. **Drive ulash** — `drive.mount('/content/drive')`; birinchi yuritishda OAuth oynasi
     ochilishi va ruxsat berish kerakligi izoh qilib yozilgan.
  3. **Loyih papkasi** — `/content/drive/MyDrive/AiAgentWorkspace/` yaratiladi.
  4. **Server kodi** — FastAPI: `GET /health`, `POST /execute`.
  5. **ngrok** — `pyngrok` orqali ommaviy havola; token bo'sh bo'lsa **stack trace emas**,
     oddiy chop etilgan xabar bilan to'xtaydi.
  6. **Banner** — `'='*50`, "✅ SERVER TAYYOR", havola va "Sozlamalar → Colab URL ga
     joylashtiring" ko'rsatmasi.
- `colab/build_notebook.py` — notebook generatori (364 qator). Notebook qo'lda tahrirlanmaydi,
  shu skript orqali qayta yaratiladi.

**`domain/` (platformadan mustaqil qatlam):**
- `domain/agent/ColabStatus.kt` (36 qator) — `NotConfigured | Connected(workspaceExists) |
  Unreachable(detail) | ServerError(code)`, `isConnected` xossasi bilan.
- `domain/usecase/ColabUrlNormalizer.kt` (62 qator) — havolani tozalash/tekshirish.
- `domain/agent/RemoteExecutionEngine.kt` — `checkStatus(): ColabStatus` qo'shildi.
- `domain/model/AppSettings.kt` — `colabUrl: String = ""` maydoni qo'shildi.

**`data/` (yangi papka `data/colab/`):**
- `data/colab/dto/ColabDtos.kt` (44 qator) — `ColabHealthResponse`, `ColabExecuteRequest`,
  `ColabExecuteResponse`.
- `data/colab/ColabApi.kt` (29 qator) — Retrofit interfeysi.
- `data/colab/ColabExecutionEngine.kt` (182 qator) — Faza 1 dagi `RemoteExecutionEngine`
  interfeysining **haqiqiy** implementatsiyasi.
- `data/database/SettingsDto.kt` — `colabUrl` maydoni.

**`ui/`:**
- `ui/settings/ColabSettingsSection.kt` (291 qator) — Colab URL maydoni, holat qatori,
  "Qanday ulash mumkin?" qo'llanmasi (bottom sheet) va `ColabRequiredDialog`.
- `ui/settings/ColabUiState.kt` (31 qator), `ui/settings/SettingsUiState.kt` (41 qator).
- `ui/settings/SettingsViewModel.kt` — Colab mantiqi (375 qator).
- `ui/settings/SettingsScreen.kt` — bo'lim ulandi (358 qator).

**DI / resurslar / testlar:**
- `di/RepositoryModule.kt` — `@Binds RemoteExecutionEngine ← ColabExecutionEngine`.
- `res/values/strings.xml` — 27 ta yangi `colab_*` yozuvi (takroriy nom yo'q).
- `test/…/domain/usecase/ColabUrlNormalizerTest.kt` (98 qator, 10 test).
- `test/…/data/colab/ColabExecutionEngineTest.kt` (296 qator, 12 test, `MockWebServer`).

### Asosiy texnik qarorlar

1. **Alohida Retrofit namunasi, umumiy `OkHttpClient`.** Health uchun o'qish 15 s
   (sozlamalarda "tekshirish" tugmasi osilib qolmasligi kerak), `/execute` uchun 1200 s
   (uzoq build/test buyruqlari uzilib qolmasligi kerak). Har ikki namuna
   `httpClient.newBuilder()` orqali yasalgani uchun ulanish hovuzi umumiy qoladi.
2. **Normallashtirilgan URL bo'yicha kesh.** Har bosishda yangi Retrofit yaratmaslik uchun
   ikkita `HashMap`. Normalizatsiya: bo'shliqlar olib tashlanadi, sxema bo'lmasa
   `https://` qo'shiladi, oxirida aynan bitta `/` bo'ladi.
3. **Holatlar ierarxiyasi `Boolean`dan boyroq.** Spec "❌ Ulanmagan — havola eskirgan
   bo'lishi mumkin, Colab'da qayta 'Run all' bosib, yangi havolani kiriting" matnini
   talab qiladi. Buning uchun `Unreachable` va `ServerError` alohida turlar bo'ldi:
   "havola o'lik" va "server xato qaytardi" — foydalanuvchi uchun turli yo'l ko'rsatma.
4. **O'lik tunnel kodlari alohida ajratildi.** Ngrok eskirgan tunnel uchun 404/502/503/504
   qaytaradi. Bu kodlar `STALE_TUNNEL_CODES` to'plamiga kiritildi va `ServerError` emas,
   `Unreachable` deb hisoblanadi — aks holda foydalanuvchi tushunarsiz "server xatosi (404)"
   xabarini ko'rgan bo'lardi.
5. **URL bo'sh bo'lsa xato emas, yo'l ko'rsatma.** Spec talabiga ko'ra, Colab URL
   kiritilmagan bo'lsa, oddiy xato emas, "Qanday ulash mumkin?" dialogi ochiladi.
   `SettingsMessage.displayText` shu sababli `String?` ga o'zgartirildi: `null` =
   snackbar ko'rsatma, dialog och (o'lik kod qoldirmaslik uchun aynan shu qilib o'lchandi).
6. **Natija — faqat natija.** `RemoteTaskResult(success, output, errorMessage)` da
   fayl/bayt maydoni **yo'q**. Notebook'dagi `drive_link()` yordamchisi kerak bo'lgan
   fayl (masalan yig'ilgan APK) uchun Drive **havolasini** `output` ichiga qo'yadi —
   oraliq fayllar Androidga hech qachon qaytmaydi.
7. **`SettingsUiState` alohida faylga chiqarildi.** Colab mantiqini qo'shgach
   `SettingsViewModel.kt` 407 qatorga yetib, 400 qator chegarasini buzdi. Ma'lumot
   sinflari (`SettingsUiState`, `TestOutcome`, `SettingsMessage`) o'z fayliga ko'chirilib,
   375 qatorga qaytdi.

### Ma'lum cheklovlar

- **Colab havolasi ~90 daqiqada eskiradi.** Bu sessiyaning tabiiy cheklovi; ilova buni
  yashirmaydi va har holatda "qayta 'Run all' bosing" degan aniq yo'l ko'rsatma beradi.
  Avtomatik yangilash ilova tomonidan qilib bo'lmaydi (Colab brauzer sessiyasi).
- **Autentifikatsiya yo'q.** ngrok havolasi bilgan odam buyruq yubora oladi. Bu Faza 7
  (xavfsizlik) doirasidagi ish; hozircha havola sir tutilishi kerakligi qo'llanmada aytilgan.
- **Bir vaqtda faqat bitta buyruq.** Notebook'dagi FastAPI sinxron ishlaydi; parallel
  buyruq navbati Faza 8 (build-test loop) ehtiyojidan kelib chiqib qo'shiladi.
- **Haqiqiy Colab hisobi bilan tekshirilmagan.** Bu muhitda brauzer/Colab sessiyasi yo'q.
  Notebook kodining barcha katakchalari `ast.parse` orqali sintaksis tekshiruvidan o'tdi,
  HTTP shartnomasi esa `MockWebServer` bilan ikki tomonlama (so'rov va javob) tekshirildi.
  Haqiqiy havola orqali `/health` ni sinash — foydalanuvchi qurilmasidagi qadam.

### TEKSHIRUV NATIJASI:

```
./gradlew build --no-daemon
BUILD SUCCESSFUL in 1m 23s        (3-build, yakuniy)
Kompilyatsiya xatolari: 0
Unit testlar: 132 ta, yiqilgan 0, xato 0
  (yangi: ColabUrlNormalizerTest 10, ColabExecutionEngineTest 12)
Lint: 0 xato, 3 kutilgan ogohlantirish (OldTargetApi ×1, NewerVersionAvailable ×2)
Eng katta fayl: 396 qator (AiChatRepositoryImpl.kt) — 400 chegarasi buzilmagan
APK: artifacts/aiagent-faza5-debug.apk — 36 483 832 bayt (minSdk 30, targetSdk 36)
Notebook: colab/aiagent_colab_server.ipynb — 12 katakcha, hammasi ast.parse'dan o'tgan
```

**Spec talablari bo'yicha:**

| Talab | Holat |
|---|---|
| `drive.mount` + OAuth oynasi izohi | ✅ Setup/Drive katakchasida |
| Loyih papkasi `/content/drive/MyDrive/AiAgentWorkspace/` | ✅ |
| `POST /execute` (stdout/stderr + exit code) | ✅ `subprocess.run` orqali |
| `GET /health` | ✅ `{status, workdir, workspace_exists}` |
| `pyngrok` orqali ommaviy URL | ✅ |
| Alohida Setup katakchasi + "ngrok.com → Dashboard → 'Your Authtoken'" | ✅ |
| Bo'sh token → stack trace emas, oddiy xabar | ✅ `sys.exit` oldidan chop etiladi |
| `'='*50` + "✅ SERVER TAYYOR" banner + URL + ko'rsatma | ✅ |
| Sozlamalarda "Colab URL" maydoni | ✅ |
| "✅ Ulangan" / "❌ Ulanmagan" holat ko'rsatkichi | ✅ 4 xil holat bilan |
| "?" / "Qanday ulash mumkin" qo'llanmasi (4 qadam) | ✅ bottom sheet |
| URL yo'q bo'lsa → xato emas, qo'llanmaga o'tkazuvchi tugma | ✅ `ColabRequiredDialog` |
| O'lik havola uchun aniq matn (specdagi so'zma-so'z) | ✅ `colab_status_unreachable` |
| `RemoteTaskResult` faqat `success/output/errorMessage` | ✅ bayt maydoni yo'q |
| `./gradlew build` 0 xato | ✅ |

**Faza jarayonida topilgan va tuzatilgan haqiqiy nuqsonlar:**

1. **`timeout_seconds` serverga umuman yetib bormasdi.** `kotlinx.serialization`
   standart qiymatli maydonlarni yubormaydi, `timeoutSeconds = 300` esa standart edi.
   Natijada foydalanuvchi bergan boshqa muddat **jim** e'tiborsiz qolardi. Test aynan
   yuborilgan baytlarni tekshirgani uchun xatoni ushladi. Tuzatish: `encodeDefaults = true`.
   (Faza 3 da `stream` maydoni bilan aynan shu xato bo'lgan edi — bu kutilgan tuzoq.)
2. **Eskirgan ngrok havolasi "server xatosi" deb ko'rsatilardi.** 404 javobi
   `ServerError(404)` ga tushar va foydalanuvchi "server xato qaytardi (404)" degan
   tushunarsiz xabar ko'rardi. Endi 404/502/503/504 `Unreachable` deb hisoblanadi va
   spec talab qilgan "havola eskirgan bo'lishi mumkin…" matni chiqadi.
3. **Test barqaror emas edi.** Dastlab "mavjud bo'lmagan ngrok domeni" ishlatilgan,
   lekin wildcard DNS uni 404 bilan javob qaytardi. Endi deterministik ulanish xatosi
   (tinglamaydigan mahalliy port) ishlatiladi.
4. **O'lik kod.** `isColabRequiredDialogOpen` o'zgaruvchisi va `colabUrlPreview()`
   yordamchisi hech qayerdan chaqirilmagan holda yozilgan edi; qayta o'qishda topilib,
   biri `ColabUrlRequired` orqali ishlaydigan qilindi, ikkinchisi o'chirildi.
5. **`TypographyDashes` lint ogohlantirishi** — URL namunasidagi deffislar en-dash ga
   almashtirishni taklif qilardi; URL uchun deffis to'g'ri, shuning uchun ataylab
   `tools:ignore` bilan istisno qilindi.

**Bu fazada o'zim kiritgan va keyin tuzatgan kamchiliklar:** yuqoridagi 1–5 bandlar.
Barchasi build/test/lint orqali aniqlangan, hech biri "keyinroq" ga qoldirilmagan.

### 11 majburiy UI/UX mezoni — Colab bo'limi (Sozlamalar ekrani)

| # | Mezon | Javob |
|---|---|---|
| 1 | Bo'sh holat | Holat qatori `hasChecked || savedUrl.isNotBlank()` bo'lgandagina ko'rinadi. Hech narsa kiritilmagan bo'lsa, "Ulanmagan" degan qo'rqituvchi yozuv chiqmaydi — faqat maydon, tugmalar va "Qanday ulash mumkin?" havolasi. Bo'limga kirish uchun provider bo'lishi shart emas: u `LazyColumn`ning **oxirgi** elementi, ro'yxat bo'sh bo'lsa ham ko'rinadi. |
| 2 | Yuklanish holati | Tekshiruv paytida `CircularProgressIndicator` (18dp, 2dp stroke) tugma ichida aylanadi, tugma `enabled = false` bo'ladi, holat qatori "Tekshirilmoqda…" ni ko'rsatadi. Saqlash paytida ham tugma o'chadi. |
| 3 | Xato holati | Ikki xil: (a) **kiritish xatosi** — `isError = true` + `supportingText` maydon ostida; (b) **ulanish xatosi** — holat qatorida `ic_error_circle` va `error` rangida sababli matn. Ulanib bo'lmasa spec'dagi so'zma-so'z matn: "Ulanmagan — havola eskirgan bo'lishi mumkin, Colab'da qayta 'Run all' bosib, yangi havolani kiriting". |
| 4 | Vayronkor amal uchun tasdiq | **Qo'llanilmaydi** — va bu ataylab. Bo'sh maydonni saqlash URL'ni tozalaydi, lekin bu qaytariladigan amal (havolani yana joylashtirish kifoya) va hech qanday fayl ma'lumotini yo'qotmaydi. Jim o'chirib yuborish o'rniga "Colab URL o'chirildi" snackbar'i beriladi. Fayl o'chirishdagi tasdiq dialogi (Faza 3) bu yerda ortiqcha yuk bo'lardi. |
| 5 | ≥48dp sensorli nishon | 6 ta nishonning hammasi 48dp: Saqlash `height(48.dp)`, Tekshirish `height(48.dp)`, "Qanday ulash mumkin?" `heightIn(min = 48.dp)`, qo'llanma yopish tugmasi 48dp, dialog tasdiq/bekor tugmalari 48dp. |
| 6 | Foydalanuvchiga javob (feedback) | Har amal javobsiz qolmaydi: saqlash → "Saqlandi"/"O'chirildi" snackbar'i; tekshirish → holat qatori o'zgaradi; yaroqsiz URL → maydon ostida izoh; URL yo'q bo'lsa tekshirish → dialog. |
| 7 | Material 3 izchilligi | Faqat Material 3 komponentlari (`OutlinedCard`, `OutlinedTextField`, `Button`, `TextButton`, `ModalBottomSheet`, `AlertDialog`, `CircularProgressIndicator`) va `MaterialTheme.colorScheme` ranglari. Qattiq kodlangan rang yo'q; ikonkalar `colorScheme.primary/tertiary/error/onSurfaceVariant` bilan holatga mos ranglanadi. |
| 8 | Kognitiv yuklama | Bo'lim bitta kartada, 3 ta asosiy element (maydon + 2 tugma) va ixtiyoriy qo'llanma. 4 qadamli yo'riqnoma ekranga doimiy chiqmaydi — so'ralganda bottom sheet'da ochiladi. Holat matnlari sabab bilan yozilgan ("nima bo'ldi" emas, "nima qilish kerak"). |
| 9 | Xavfsiz standart | `colabUrl` standarti bo'sh satr — ilova hech qachon "o'zi o'ylab topgan" manzilga ulanmaydi. Yaroqsiz manzil **saqlanmaydi** (normalizatsiya `null` qaytarsa, `persistColabUrl` chaqirilmaydi). Matn o'zgarsa eski holat `NotConfigured`ga qaytariladi — eskirgan "Ulangan" belgisi qolib ketmaydi. |
| 10 | Parol maydoni (👁 + inline validatsiya) | **Qo'llanilmaydi.** Colab URL — sir emas, uni yashirish foydalanuvchiga ziyon (joylashtirishda xatoni ko'ra olmaydi). Inline validatsiya esa mavjud: `isError` + `supportingText`. (Ngrok havolasining maxfiyligi haqidagi ogohlantirish qo'llanma qadamida berilgan.) |
| 11 | Orqaga navigatsiya | `ModalBottomSheet` va `AlertDialog` tizim "Orqaga" tugmasini o'zi qayta ishlaydi va `onDismissRequest` orqali yopiladi — dialog ustidan chiqib ketish ilovani yopmaydi. Sozlamalar ekranining o'zi `AiAgentNavHost`dagi mavjud orqaga o'tishni buzmaydi; yangi ekran/route qo'shilmagan. |

**Qo'shimcha:** "Colab URL yo'q" holati snackbar emas, **dialog** ochadi va undagi tugma
bevosita qo'llanmaga o'tkazadi (`isColabRequiredDialogOpen = false; isColabGuideOpen = true`).
Bu spetsifikatsiyaning "oddiy xatolik o'rniga qo'llanmaga yo'naltiruvchi tugma" talabini
aynan bajaradi. `SettingsMessage.displayText` aynan shu sababli `String?` ga o'zgartirildi —
`null` qaytarish "snackbar ko'rsatma, dialog och" degan ma'noni kodga o'rniga qo'ydi va
o'lik o'zgaruvchi qoldirishning oldini oldi.

### Yakuniy self-review'da topilgan va tuzatilgan notebook og'ishlari

Faza yozuvi tugagach, notebook kodini spec (`05-faza5-colab-server.md`, 55–56-qatorlar)
bilan qatorma-qator solishtirdim va **ikki haqiqiy og'ish** topildi. Ikkalasi ham tuzatildi
va notebook qayta yaratildi (`python3 colab/build_notebook.py`).

| Spec talabi | Avval edi | Tuzatilgach |
|---|---|---|
| Bo'sh token → **oddiy `print()`**, Python stack trace emas | `raise SystemExit("Ngrok authtoken kiritilmagan…")` — xabarli exception | Xabar **oddiy `print()`** bilan chop etiladi; to'xtatish uchun **bo'sh** `raise SystemExit()`. Argument yo'qligi sababli Jupyter hech qanday traceback chiqarmaydi. |
| Xabar matni spec'dagidek | `XATO: Ngrok authtoken kiritilmagan.` | `❌ Ngrok authtoken kiritilmagan. Yuqoridagi katakchaga tokeningizni kiriting.` (spec'dagi so'zma-so'z) |
| Banner `'='*50` | `"=" * 60` | `"=" * 50` |
| Banner `✅ SERVER TAYYOR` | `SERVER TAYYOR` (belgisiz) | `✅ SERVER TAYYOR` |

**Nega bu muhim edi:** "stack trace emas" talabi shunchaki estetika emas — notebook'ni
birinchi marta ishlatayotgan foydalanuvchi uchun `SystemExit: …` yozuvi "nimadir buzildi"
degan taassurot beradi va u token kiritishni emas, xato qidirishni boshlaydi. Bo'sh
`SystemExit` esa keyingi katakchalarning ishlashini to'xtatadi (aks holda "Run all"
davom etib, chalkash `NameError` chiqarardi) va hech narsa chop etmaydi.

**Jarayon haqida ochiq qayd:** birinchi tuzatish urinishi **muvaffaqiyatsiz** bo'ldi va
buni yashirmaslik kerak — Python heredoc'da `new2 = """…""",` oxiridagi vergul
o'zgaruvchini `tuple` ga aylantirgani uchun `str.replace()` `TypeError` bilan yiqildi.
Xato `open(p, "w")` dan **oldin** yuz bergani uchun generator umuman o'zgarmadi, lekin
`python3 colab/build_notebook.py` o'sha o'zgarmagan generator'dan notebook'ni qayta
yaratdi. Ya'ni notebook "yangilangan" ko'rindi, aslida eski holatda qoldi. Buni
`grep -n "SystemExit\|= \* 60" colab/build_notebook.py` orqali aniqladim (98 va 308-qatorlar
o'z joyida edi) va tuzatishni `edit_file` orqali qayta bajardim. **Xulosa: patchdan keyin
o'zgarishni fayldan qayta tekshirish shart — skriptning muvaffaqiyatli chop etishi
o'zgarish yozilganini bildirmaydi.**

Tuzatishdan keyingi tekshiruv (barcha 9 band `OK`):
```
ast.parse: OK
✅ bo'sh token: ODDIY print() xabari        ✅ banner: '=' * 50
✅ bo'sh token: ❌ belgisi                  ✅ banner: '=' * 60 qolmagan
✅ bo'sh token: xabarli exception YO'Q      ✅ banner: ✅ SERVER TAYYOR
✅ bo'sh token: bo'sh SystemExit            ✅ banner: Sozlamalar -> Colab URL ko'rsatmasi
                                            ✅ banner: public_url chop etiladi
```

---

# FAZA 6 — LLM asosidagi routing (Phone vs Colab) (2026-08-30)

**Maqsad:** og'ir hisoblash vazifalarini (build, test, render) LLM chaqiruvi orqali
telefon yoki Colab'da bajarishni hal qilish + Phone ↔ Colab fayl sinxronlashi.

**Spetsifikatsiya bu fazada YANGILANDI** (90 → 104 qator, 8.4 → 12.5 KB). Yangi
"MUHIM CHEGARA" bo'limi qo'shildi va mening oldingi savolimga o'zi javob berdi:
SAF workspace va Drive papkasi — ikki alohida fayl tizimi, shuning uchun fayl
o'qish/yozish uchun LLM router HECH QACHON ishlatilmaydi.

## Yaratilgan fayllar (to'liq yo'l)

**Domen — routing (sof Kotlin):**
- `domain/model/FileSource.kt` (27) — `enum { PHONE, COLAB }`, `ExecutionTarget` dan
  ATAYLAB alohida (ikki mexanizm aralashtirilmasligi uchun).
- `domain/agent/RouterPrompt.kt` (47) — spetsifikatsiyadagi prompt **so'zma-so'z**.
- `domain/agent/RouterDecisionParser.kt` (70) — `COLAB`/`PHONE` tahlili, default `COLAB`.
- `domain/agent/PhoneSpecsProvider.kt` (17) — domen interfeysi.
- `domain/agent/LlmExecutionRouter.kt` (72) — `ExecutionRouter` ning haqiqiy implementatsiyasi.
- `domain/agent/AgentExecutionPlanner.kt` (148) — fayl manbai + hisoblash joyi rejasi,
  fallback qoidasi, `RunPlan`, `ComputePlan`.
- `domain/agent/AgentRunRequest.kt` (27) — `AgentController` dan ajratildi (400 qator).

**Domen — sinxronlash:**
- `domain/repository/RemoteFileGateway.kt` (58) — `upload`/`download`/`listFiles`.
- `domain/usecase/ProjectSyncUseCase.kt` (273) — push/pull + `planPull` (tasdiq dialogi
  uchun sonlar) + progress.

**Data:**
- `data/device/AndroidPhoneSpecsProvider.kt` (90) — `ActivityManager.MemoryInfo`,
  `Runtime.availableProcessors()`, `StatFs`, `Build.MODEL`; `@Volatile` kesh.
- `data/colab/ColabRetrofitFactory.kt` (85) — umumiy Retrofit/`Json` fabrikasi.
- `data/colab/ColabFileApi.kt` (34) + `data/colab/dto/ColabFileDtos.kt` (77).
- `data/colab/ColabFileGateway.kt` (169) — `RemoteFileGateway` implementatsiyasi.
- `data/colab/ColabShell.kt` (143) — SOF shell buyruqlari + chiqish tahlili.
- `data/colab/ColabDocumentRepository.kt` (275) — `DocumentRepository` ning Drive
  implementatsiyasi.

**UI:**
- `ui/chat/FileSourceSelector.kt` (137) — segmented control + `FileSourceSection` +
  `FileSourceBadge`.
- `ui/settings/SyncViewModel.kt` (192), `ui/settings/SyncSection.kt` (328).
- `res/drawable/` — 5 ta yangi ikonka (`ic_cloud`, `ic_phone`, `ic_sync`, `ic_upload`,
  `ic_download`).
- `res/values/strings.xml` — 24 ta yangi satr (fayl manbai + sinxronlash).

**Testlar:**
- `test/…/domain/agent/RouterDecisionParserTest.kt` (79) — 8 test.
- `test/…/domain/agent/AgentExecutionPlannerTest.kt` (162) — 7 test (fallback qoidasi).
- `test/…/data/colab/ColabShellTest.kt` (155) — 20 test (tirnoq, `..`, `[exit N]`, grep).
- `test/…/domain/agent/AgentTestDoubles.kt` (50) — fake'lar (400 qator uchun ajratildi).

**Colab notebook (`colab/`):**
- `aiagent_colab_server.ipynb` — 3 ta YANGI endpoint: `POST /upload`, `POST /download`,
  `POST /list_tree` + `safe_path()` yo'l xavfsizligi tekshiruvi.

## O'zgartirilgan fayllar

- `domain/agent/ExecutionRouter.kt` — `decideWithReason()` qo'shildi (standart
  implementatsiya bilan — eski fake'lar buzilmadi).
- `domain/agent/AgentStep.kt` — `AgentStepKind.ROUTING` qo'shildi.
- `domain/agent/AgentController.kt` (399) — fayl manbai tanlovi, hisoblash rejasi,
  `computePlan` StateFlow.
- `domain/repository/DocumentRepository.kt` — **`readBytes` / `writeBytes`** qo'shildi.
- `data/filesystem/SafDocumentRepository.kt` + `SafDocumentWriter.kt` — yangi metodlar.
- `data/colab/ColabExecutionEngine.kt` — fabrikaga o'tkazildi (12 test buzilmadi).
- `di/AgentModule.kt` — `@PhoneTools` / `@ColabTools` qualifier'lari, router, planner.
- `di/RepositoryModule.kt`, `di/UseCaseModule.kt` — yangi bog'lanishlar.
- `ui/chat/{ChatScreen,ChatViewModel,AgentChatDelegate,AgentModeRow}.kt` — manba tanlovi.
- `ui/agent/AgentPanel.kt` — "Bajarilish joyi" indikatori.
- `ui/settings/SettingsScreen.kt` — sinxronlash bo'limi.
- Testlar: `FakeDocumentRepository`, `IngestAttachmentUseCaseTest`,
  `ColabExecutionEngineTest`, `AgentControllerTest` — yangi interfeys/konstruktorlar.

## QARORLAR

1. **QAROR — ikki mexanizm qat'iy ajratildi.** `FileSource` (fayl manbasi) va
   `ExecutionTarget` (hisoblash joyi) — ikki ALOHIDA tur. Sabab: bitta enum
   ishlatilsa, kelajakda kimdir "router telefonga yubordi, demak fayllar ham
   telefonda" deb xato xulosa qilishi mumkin. Tur tizimi bu xatoni kompilyatsiya
   darajasida imkonsiz qiladi.
2. **QAROR — `ColabDocumentRepository` orqali 13 ta tool o'zgarmadi.** Tool'lar
   `DocumentRepository` interfeysiga bog'langan. Shu interfeysni Drive ustida amalga
   oshirish yetarli bo'ldi — tool kodiga tegilmadi, ular uchun yangi test yozish
   ham shart emas (mavjud 28 test ikkala manba uchun ham kuchida).
3. **QAROR — URI = mutlaq Drive yo'li.** SAF'da `content://…`, Colab'da
   `/content/drive/MyDrive/AiAgentWorkspace/…`. Tool'lar URI'ni qora quti sifatida
   tashigani uchun almashtirish ularga ko'rinmaydi.
4. **QAROR — o'zgartiruvchi amallar ham Colab'da ishlaydi, lekin tasdiq darvozasi
   saqlanadi.** `EditCoordinator` tanlangan `DocumentRepository` orqali yozadi,
   shuning uchun `ALWAYS_CONFIRM` va diff ekrani Colab manbada ham ishlaydi.
   Bu foydalanuvchi tanloviga qoldirilgan edi (savol berilgan, javob kelmagan) —
   xavfsiz variant tanlandi: tasdiq hech qachon chetlab o'tilmaydi.
5. **QAROR — `readBytes`/`writeBytes` qo'shildi.** Sinxronlash fayl turidan qat'i
   nazar ANIQ nusxa ko'chirishi kerak. `readTextFile` ikkilik fayllarni buzadi
   (UTF-8 bo'lmagan baytlar almashtiriladi). Chegaradan katta fayl KESILMAYDI,
   rad etiladi va natijada aniq ko'rsatiladi.
6. **QAROR — base64 transport.** Fayl mazmuni JSON'da ketadi, xom baytlar yaroqsiz.
   Narxi: hajm ~33% oshadi. Foydasi: bitta HTTP = bitta fayl, shuning uchun
   progress ko'rsatish mumkin (spetsifikatsiya progress'ni SHART deb belgilagan).
7. **QAROR — `Json` sozlamasi bitta fabrikada.** `encodeDefaults = true` unutilsa,
   standart qiymatli maydonlar simga chiqmaydi. Bu xato allaqachon IKKI marta sodir
   bo'lgan (Faza 3 `stream`, Faza 5 `timeout_seconds`). Uchinchi marta takrorlanmasin
   uchun sozlama `ColabRetrofitFactory` ga ko'chirildi.
8. **QAROR — `safe_path()` ikki tomonda.** Server tomoni ham, `ColabShell.resolveWithin`
   ham workspace'dan chiqishni bloklaydi. Bitta tomon buzilsa, ikkinchisi ushlaydi.
9. **QAROR — PDF va arxiv Colab manbada qo'llab-quvvatlanmaydi.** Ular Android
   API'lariga (`PdfRenderer`, `java.util.zip`) bog'liq. Soxta bajarish o'rniga
   `FileContent.Failed` ichida aniq sabab qaytadi.
10. **QAROR — router javob bermasa ham agent to'xtamaydi.** Provider yo'q, so'rov
    muvaffaqiyatsiz yoki javob tushunarsiz → standart `COLAB`. Lekin izohda
    "router tanladi" DEYILMAYDI — bu yolg'on bo'lardi (pastdagi 1-xatoga qarang).

## Testlar topgan va tuzatilgan haqiqiy kod xatolari

1. **Router izohi YOLG'ON edi.** `noProvider`/`requestFailed` izohi faqat PHONE
   tarmog'ida yozilgan edi. LLM javob bermasa va standart COLAB qo'llansa, izoh
   "Router Colab'da bajarishni tanladi" derdi — lekin router hech narsa tanlamagan.
   Aynan shu aldanishning oldini olish uchun `fromLlm` bayrog'i yozilgan edi, lekin
   u ishlatilmagan. Tuzatildi: izoh endi TARGET'dan qat'i nazar to'g'ri tanlanadi.
   (`AgentExecutionPlannerTest` topdi.)
2. **`timeout_seconds` va `stream` xatosi uchinchi marta takrorlanishi mumkin edi.**
   `ColabFileGateway` uchun `Json` sozlamasi nusxalanganida `encodeDefaults`
   unutilishi ehtimoli bor edi. Oldini olish uchun fabrikaga birlashtirildi.
3. **`ProjectSyncUseCase.planPush` kompilyatsiya bo'lmadi** — `walkPhone` `FileNode`
   emas, `Pair` qaytaradi. Hajm endi `documents.fileSize()` orqali hisoblanadi.
4. **`SyncViewModel.currentRootUri()` ishlamaydigan kod edi** — hech qachon
   to'ldirilmaydigan `cachedRootUris` xaritasiga tayangan va `?: name?.let { null }`
   kabi mantiqsiz ifoda bor edi. O'zim topib, `Workspace` ob'ektini to'g'ridan-to'g'ri
   saqlaydigan qilib qayta yozdim.
5. **4 ta satr `strings.xml`da yozilib, ViewModel'da qattiq kodlangan edi** (lint
   `UnusedResources`). Matn endi natija TURI sifatida qaytadi (`SyncOutcome`) va
   tarjima qilinadigan matnni UI tanlaydi.

## Ma'lum cheklovlar

- **Hisoblash tool'lari hali yo'q.** Router mexanizmi to'liq qurildi va test bilan
  isbotlandi, lekin build/test buyruqlarini bajaradigan tool Faza 7-8 da keladi
  (spetsifikatsiya buni ochiq aytadi: "router mexanizmi shu fazada quriladi").
- **Colab manbada PDF va arxiv o'qilmaydi** — aniq xabar bilan rad etiladi (9-qaror).
- **Sinxronlash fayl chegarasi 5 MB, soni 2000.** Xotira cheklangan (fayl to'liq
  xotiraga o'qiladi, base64 yana ~33% qo'shadi). Chegaradan oshgan fayl natijada
  ANIQ ko'rsatiladi, jim o'tkazilmaydi.
- **Sinxronlash o'chirishni ko'chirmaydi.** Colab'da o'chirilgan fayl telefondan
  o'chirilmaydi (bu "mirror" emas, "copy"). Aksi ham shunday.
- **`/upload` bir faylga bitta HTTP.** Juda ko'p faylli loyihada sekin. Tar (yagona
  arxiv) tezroq bo'lardi, lekin progress ko'rsatish imkonini yo'qotadi.
- **Haqiqiy Colab bilan tekshirilmadi** (bu muhitda brauzer/sessiya yo'q). HTTP
  shartnomasi `MockWebServer` bilan, notebook kodi `ast.parse` bilan tekshirildi.

## TEKSHIRUV NATIJASI:

```
./gradlew build --no-daemon
BUILD SUCCESSFUL in 3m 50s        (8-build, yakuniy)
Kompilyatsiya xatolari: 0
Unit testlar: 167 ta, yiqilgan 0, xato 0     (Faza 5: 132 → Faza 6: 167, +35)
  yangi: ColabShellTest 20, RouterDecisionParserTest 8, AgentExecutionPlannerTest 7
Lint: 0 xato, 3 kutilgan ogohlantirish (OldTargetApi ×1, NewerVersionAvailable ×2)
Eng katta fayl: 399 qator (AgentController.kt) — 400 chegarasi buzilmagan
APK: artifacts/aiagent-faza6-debug.apk — 37 299 726 bayt (minSdk 30, targetSdk 36)
Ruxsatlar o'zgarmadi: INTERNET, ACCESS_NETWORK_STATE (+ debug dynamic-receiver)
Notebook: 12 katakcha, ast.parse OK, 8/8 endpoint talabi OK
```

Faza davomida jami **8 ta build** ishga tushirildi. 1–7 build xatolari shu fazada
tuzatildi, keyingi fazaga hech narsa qoldirilmadi:
16 xato (import/`Column`/`Spacer`, `observeWorkspaces()`) → 2 xato (`$USER` Kotlin
shabloni) → 2 test yiqilishi (yuqoridagi 1-xato + noto'g'ri test kutilmasi) → yashil.

**Spetsifikatsiyaning TEKSHIRUV TALABI bo'yicha:**

| Talab | Holat |
|---|---|
| Og'ir so'rovda router `COLAB` qaytaradi | ✅ `AgentExecutionPlannerTest` + `RouterDecisionParserTest` |
| Colab ulanmagan bo'lsa telefon fallback + foydalanuvchiga ko'rsatiladi | ✅ `planCompute` testi: `fallbackUsed=true`, matn "Colab mavjud emas, telefonda bajarilmoqda" |
| Fayl o'qish/yozishda LLM router HECH QACHON chaqirilmaydi | ✅ kod orqali: `AgentController.runLoop` router'ni faqat `planCompute` da chaqiradi, fayl tool'lari `activeRegistry` orqali boradi; `planRun` fayl manbasi uchun router'ga UMUMAN tegmaydi |
| Foydalanuvchi tanlagan manba ishlatiladi | ✅ `activeDocuments`/`activeRegistry` sikl boshida tanlanadi va tasdiqda ham ishlatiladi |
| Colab tanlangan + ulanmagan → avtomatik telefonga O'TILMAYDI | ✅ `RunPlan.Blocked`, sikl UMUMAN boshlanmaydi, spec'dagi aniq matn |
| Ikkala sinxronlash ishlaydi | ✅ `ProjectSyncUseCase.push`/`pull` |
| Progress ko'rsatiladi | ✅ `LinearProgressIndicator` + "N / M" + joriy fayl nomi |
| "Colab'dan olish" tasdiqsiz boshlanmaydi | ✅ `planPull` → `AlertDialog` (almashtiriladigan fayllar soni bilan) → `confirmPull` |
| `./gradlew build` xatosiz | ✅ |

**Qurilmada tekshirish uchun (foydalanuvchiga):**
1. Chat → agent rejimini yoqing → pastda "Fayl manbai" tanlovi ko'rinishi kerak
   (standart: 📱 Telefon).
2. "Python nima?" → agent panelida "Bajarilish joyi: …" qatori ko'rinishi kerak.
3. Sozlamalar → "🔄 Sinxronlash" → workspace tanlang → "→ Colab'ga yuborish".
   Progress "N / M" ko'rinishi va natija chiqishi kerak.
4. "← Colab'dan olish" → AVVAL tasdiq dialogi ("Telefondagi N ta fayl
   almashtiriladi") chiqishi, tasdiqsiz hech narsa boshlanmasligi kerak.
5. Colab URL'ni o'chirib, fayl manbaini Colab qilib so'rov yuboring → agent
   ISHLAMASLIGI va "Colab ulanmagan — Sozlamalardan ulanishni tekshiring, yoki
   fayl manbaini Telefon'ga o'zgartiring" xabari chiqishi kerak.

## UI/UX 11 mezoni — Faza 6 ekranlari bo'yicha

| Mezon | FileSourceSelector (Chat) | SyncSection (Sozlamalar) | AgentPanel (yangi qism) |
|---|---|---|---|
| 1. Bo'sh holat | Qo'llanilmaydi — ikkita variant doim bor | **BOR**: workspace bo'lmasa "Sinxronlash uchun avval workspace tanlang" | **BOR**: qaror bo'lmasa indikator umuman chiqmaydi |
| 2. Yuklanish | Qo'llanilmaydi (tarmoq I/O yo'q) | **BOR**: `LinearProgressIndicator` + "N / M" + fayl nomi; reja hisoblanayotganda spinner | **BOR** (Faza 4 dagidek) |
| 3. Xato holati | Qo'llanilmaydi | **BOR**: `SyncOutcome.Failed` qizil rangda + xato fayllar ro'yxati (sababi bilan) | **BOR**: fallback sababi izohda |
| 4. Buzuvchi amal tasdiqlanadi | Qo'llanilmaydi | **BOR**: "Colab'dan olish" `AlertDialog` orqali, almashtiriladigan fayllar SONI bilan. "Colab'ga yuborish" tasdiqsiz — telefon fayllari o'chirilmaydi | Qo'llanilmaydi |
| 5. ≥48dp teginish | **BOR**: har ikki segment `height(48.dp)` | **BOR**: ikkala tugma 48dp, dropdown `heightIn(min=48.dp)`, dialog tugmalari 48dp | **BOR** (Faza 4 dagidek) |
| 6. Amalga javob | **BOR**: tanlov darhol rang bilan aks etadi + badge o'zgaradi | **BOR**: progress → natija matni → xatolar ro'yxati | **BOR**: "Bajarilish joyi" qatori darhol paydo bo'ladi |
| 7. Material 3 izchilligi | **BOR**: `SingleChoiceSegmentedButtonRow`, `colorScheme` | **BOR**: `OutlinedCard`, `AlertDialog`, `LinearProgressIndicator` | **BOR**: `colorScheme.primary` |
| 8. Kognitiv yuk | **BOR**: 2 variant + qisqa izoh; faqat agent rejimida ko'rinadi | **BOR**: sarlavha + izoh + workspace + 2 tugma; xatolar max 10 ta ko'rsatiladi | **BOR**: bitta qator |
| 9. Xavfsiz standart | **BOR**: standart **PHONE** (Colab ulanishini talab qilmaydi) | **BOR**: ustidan yozish tasdiqsiz boshlanmaydi | **BOR**: shubhada `COLAB` (spec talabi) |
| 10. Klaviatura/matn kiritish | Qo'llanilmaydi — maydon yo'q | Qo'llanilmaydi — maydon yo'q (workspace dropdown'dan tanlanadi) | Qo'llanilmaydi |
| 11. Orqaga navigatsiya | **BOR**: chat ekranining bir qismi | **BOR**: Sozlamalar appbar'i ← Workspace; dialog yopilishi = bekor qilish | **BOR** (Faza 4 dagidek) |

---

# FAZA 6 — TIKLASH (fayllar yo'qolgandan keyin qayta qurish) (2026-08-30)

## Nima bo'ldi

Faza 6 tugaganidan keyin workspace snapshot'i Faza 5 holatiga qaytdi. Aniq holat
tekshirildi (faylma-fayl):

| Narsa | Holat |
|---|---|
| **29 ta yangi Faza 6 `.kt` fayli** | HAMMASI YO'Q edi (`domain/agent/` da faqat 9 ta Faza 1 fayli qolgan) |
| **17 ta o'zgargan fayl** | Barchasi Faza 5 holatiga qaytgan (`AgentController.kt` 357 qator, `executionPlanner`/`FileSource` izlari 0 ta) |
| `colab/build_notebook.py` (519 qator) | **SAQLANGAN** — `/upload`, `/download`, `/list_tree` joyida |
| `colab/aiagent_colab_server.ipynb` (12 katakcha) | **SAQLANGAN** |
| `PROGRESS_LOG.md` (1325 qator) | **SAQLANGAN** — Faza 6 yozuvi to'liq |
| `artifacts/aiagent-faza6-debug.apk` | YO'Q edi (faza3/4/5 saqlangan) |
| `.git` | YO'Q — tiklash uchun versiya tarixi mavjud emas |

**Xulosa:** butun Kotlin manba daraxti yo'qolgan, lekin notebook va PROGRESS_LOG
omon qolgan. Shuning uchun tiklash manbasi = `PROGRESS_LOG.md` dagi Faza 6
shartnomalari + `uploads/06-faza6-llm-routing.md`. Kod qayta YOZILDI (nusxa
ko'chirilmadi — nusxa yo'q edi).

## Qayta yaratilgan fayllar (31 ta yangi)

**Domen (9):** `domain/model/FileSource.kt`, `domain/agent/{RouterPrompt,
RouterDecisionParser,PhoneSpecsProvider,LlmExecutionRouter,AgentExecutionPlanner,
AgentRunRequest}.kt`, `domain/repository/RemoteFileGateway.kt`,
`domain/usecase/ProjectSyncUseCase.kt`

**Data (7):** `data/device/AndroidPhoneSpecsProvider.kt`,
`data/colab/{ColabRetrofitFactory,ColabFileApi,ColabFileGateway,ColabShell,
ColabDocumentRepository}.kt`, `data/colab/dto/ColabFileDtos.kt`

**DI (1):** `di/AgentBindingsModule.kt`

**UI (3):** `ui/chat/FileSourceSelector.kt`, `ui/settings/SyncViewModel.kt`,
`ui/settings/SyncSection.kt`

**Resurs (5):** `res/drawable/ic_{cloud,phone,sync,upload,download}.xml`

**Test (6):** `domain/agent/{RouterDecisionParserTest,AgentExecutionPlannerTest,
AgentTestDoubles,AgentFileSourceTest}.kt`, `data/colab/ColabShellTest.kt`,
`domain/usecase/ProjectSyncUseCaseTest.kt`

## Qayta qo'llangan o'zgarishlar (19 ta fayl)

`domain/agent/{ExecutionRouter,AgentStep,AgentController}.kt`,
`domain/repository/DocumentRepository.kt` (`readBytes`/`writeBytes`),
`data/filesystem/{SafDocumentRepository,SafDocumentWriter}.kt`,
`data/colab/ColabExecutionEngine.kt` (fabrikaga o'tkazildi),
`di/{AgentModule,RepositoryModule,UseCaseModule}.kt`,
`ui/chat/{ChatScreen,ChatViewModel,AgentChatDelegate}.kt`,
`ui/agent/AgentPanel.kt`, `ui/settings/SettingsScreen.kt`,
`res/values/strings.xml` (+26 satr),
test: `FakeDocumentRepository`, `IngestAttachmentUseCaseTest`,
`AgentControllerTest`

## TIKLASHDA TOPILGAN VA TUZATILGAN XATOLAR

1. **`ColabShell.resolveWithin` `..` ni tashlab yuborardi — XAVFSIZLIK XATOSI.**
   Avvalgi implementatsiyada `..` segmentlari shunchaki o'chirilar edi. Natijada
   `../../etc/passwd` RAD ETILMAY, `$root/etc/passwd` ga aylantirilar edi —
   chiqib ketilmaydi, lekin yo'l JIM qayta talqin qilinadi va foydalanuvchi
   so'ramagan faylga yoziladi. Notebook tomondagi `safe_path()` esa rad etadi,
   ya'ni ikki tomon nomutanosib edi. **Tuzatildi:** `..` endi haqiqiy "bir daraja
   yuqoriga" deb hisoblanadi va ildizdan chiqsa `null` qaytadi.
   (`ColabShellTest` dagi 2 ta test topdi.)
2. **`PullPlan` pozitsion argumenti.** `PullPlan(0, 0, 0L, it)` — 4-pozitsiya
   `truncated: Boolean`, shuning uchun String xato joyga tushdi. Nomlangan
   argumentga o'tkazildi.
3. **O'lik kod yana takrorlandi.** `ColabFileGateway.kt` oxirida ishlatilmagan
   `internal typealias ColabUploadOk` va KDoc'da kirill harfli typo (`tiliда`)
   qoldirdim — o'zim topib o'chirdim. Bu PROGRESS_LOG'da allaqachon qayd etilgan
   takroriy xato; yana sodir bo'ldi.
4. **Test fayli 400 qatordan oshdi.** `AgentControllerTest` 413 qatorga yetdi →
   Faza 6 testlari `AgentFileSourceTest.kt` ga ajratildi (379 + 137).
5. **Test ichida mantiqsiz kod.** Prompt testida `ramMb = "{ram}" as Any as Long`
   yozib qo'yibman — kompilyatsiya bo'lmaydigan ifoda. Testni butun matnni
   solishtiradigan qilib qayta yozdim (endi shablon ham, almashtirish qoidalari
   ham tekshiriladi).
6. **`ast.parse` "xatosi" yolg'on signal edi.** Notebook'dagi 4-katakcha
   `!pip install …` IPython magik'i — bu Python emas. Haqiqiy 5 ta Python
   katakchasi (2, 6, 7, 9, 11) toza. Faza 6 dagi "ast.parse OK" yozuvi Python
   katakchalariga tegishli edi — bu aniqlashtirish shu yerga qayd etildi.

## Original Faza 6 dan farqlar

| Ko'rsatkich | Original Faza 6 | Tiklangan |
|---|---|---|
| Unit testlar | 167 | **186** (+`ProjectSyncUseCaseTest` 8, +`AgentFileSourceTest` 3, `ColabShellTest` 20→27) |
| Eng katta fayl | 399 | **398** (`ChatViewModel.kt`) |
| APK hajmi | 37 299 726 | **36 694 671** (yangi build — tarkib emas, yig'ish tartibi farqi) |
| Lint | 0 xato, 3 ogohlantirish | 0 xato, 3 ogohlantirish (bir xil) |

**Yangi test sinflari sababi:** sinxronlash (`ProjectSyncUseCase`) spec'da SHART
deb belgilangan, lekin original fazada testi yo'q edi — bu bo'shliq edi. Tiklashda
to'ldirildi.

## TEKSHIRUV NATIJASI:

```
./gradlew build --no-daemon
BUILD SUCCESSFUL in 6m 23s
Kompilyatsiya xatolari: 0
Unit testlar: 186 ta, yiqilgan 0, xato 0    (Faza 5: 132 → 186, +54)
  ColabShellTest 27 · RouterDecisionParserTest 8 · AgentExecutionPlannerTest 8
  ProjectSyncUseCaseTest 8 · AgentFileSourceTest 3 · AgentControllerTest 10
Lint: 0 xato, 3 kutilgan ogohlantirish (OldTargetApi ×1, NewerVersionAvailable ×2)
Eng katta fayl: 398 qator — 400 chegarasi buzilmagan
APK: artifacts/aiagent-faza6-debug.apk — 36 694 671 bayt
  minSdk 30, targetSdk 36
  Ruxsatlar: INTERNET, ACCESS_NETWORK_STATE (+ debug dynamic-receiver)
Notebook: 12 katakcha, 8/8 endpoint talabi OK, Python katakchalari ast.parse OK
Prompt: RouterPrompt TEMPLATE spec bilan bire-mos (test orqali kafolatlangan)
```

Tiklash davomida **8 ta build** ishga tushirildi: 1 xato (`PullPlan` pozitsion
argument) → 2 test yiqilishi (`ColabShell.resolveWithin` xavfsizlik xatosi) →
1 xato (`waited` Int/Long) → yashil.

**Spetsifikatsiyaning TEKSHIRUV TALABI bo'yicha (qayta tekshirildi):**

| Talab | Holat |
|---|---|
| Og'ir so'rovda router `COLAB` qaytaradi | ✅ `AgentExecutionPlannerTest` + `RouterDecisionParserTest` |
| Colab ulanmagan → telefon fallback + ko'rsatiladi | ✅ `planCompute` testi: `fallbackUsed=true`, matn bire-mos |
| Fayl o'qish/yozishda router HECH QACHON chaqirilmaydi | ✅ `AgentExecutionPlanner.planRun` router'ga tegmaydi; `AgentController.runLoop` router'ni faqat `planCompute` orqali chaqiradi |
| Foydalanuvchi tanlagan manba ishlatiladi | ✅ `activeDocuments`/`activeRegistry` sikl boshida tanlanadi va tasdiqda ham ishlatiladi |
| Colab tanlangan + ulanmagan → avtomatik O'TILMAYDI | ✅ `AgentFileSourceTest`: `RunPlan.Blocked`, `chat.callCount == 0` (AI'ga so'rov UMUMAN yuborilmadi) |
| Ikkala sinxronlash ishlaydi | ✅ `ProjectSyncUseCaseTest` (push/pull, 8 test) |
| Progress ko'rsatiladi | ✅ `SyncProgress` testi + `LinearProgressIndicator` + "N / M" |
| "Colab'dan olish" tasdiqsiz boshlanmaydi | ✅ `planPull` → `willOverwrite` → `AlertDialog` → `confirmPull` |
| `./gradlew build` xatosiz | ✅ |

**Qurilmada tekshirish uchun (bu muhitda imkonsiz — brauzer/Colab sessiyasi yo'q):**
1. Chat → agent rejimi → pastda "Fayl manbai" tanlovi (standart: Telefon).
2. Agent panelida "Bajarilish joyi: …" qatori.
3. Sozlamalar → "Sinxronlash" → workspace → "Colab'ga yuborish" (progress "N / M").
4. "Colab'dan olish" → AVVAL tasdiq dialogi (almashtiriladigan fayllar soni bilan).
5. Colab URL'ni o'chirib, manbani Colab qilib so'rov yuborish → agent ishlamasligi
   va "Colab ulanmagan — Sozlamalardan ulanishni tekshiring, yoki fayl manbaini
   Telefon'ga o'zgartiring" xabari.

## UI/UX 11 mezoni — qayta tiklangan ekranlar

| Mezon | FileSourceSelector | SyncSection | AgentPanel (yangi qism) |
|---|---|---|---|
| 1. Bo'sh holat | Qo'llanilmaydi — ikki variant doim bor | **BOR**: workspace bo'lmasa aniq matn | **BOR**: `computePlan == null` bo'lsa qator chiqmaydi |
| 2. Yuklanish | Qo'llanilmaydi | **BOR**: `LinearProgressIndicator` + "N / M" + fayl nomi; reja uchun spinner | **BOR** (Faza 4 dagidek) |
| 3. Xato holati | Qo'llanilmaydi | **BOR**: `SyncOutcome.Failed` qizil + xato fayllar ro'yxati | **BOR**: fallback izohi qizil rangda |
| 4. Halokatli amal tasdiqlanadi | Qo'llanilmaydi | **BOR**: "Colab'dan olish" `AlertDialog`, soni bilan | Qo'llanilmaydi |
| 5. ≥48dp | **BOR**: segmentlar 48dp | **BOR**: tugmalar 48dp, dropdown/dialog 48dp | **BOR** |
| 6. Amalga javob | **BOR**: darhol rang + badge | **BOR**: progress → natija → xatolar | **BOR**: qator darhol paydo bo'ladi |
| 7. Material 3 izchilligi | **BOR**: `SingleChoiceSegmentedButtonRow` | **BOR**: `OutlinedCard`, `AlertDialog`, `LinearProgressIndicator` | **BOR**: `colorScheme` |
| 8. Kognitiv yuk | **BOR**: 2 variant, faqat agent rejimida | **BOR**: xatolar ko'pi bilan 10 ta | **BOR**: bitta qator |
| 9. Xavfsiz standart | **BOR**: standart **PHONE** | **BOR**: ustidan yozish tasdiqsiz boshlanmaydi | **BOR**: shubhada `COLAB` |
| 10. Klaviatura/matn | Qo'llanilmaydi — maydon yo'q | Qo'llanilmaydi — workspace dropdown'dan | Qo'llanilmaydi |
| 11. Orqaga navigatsiya | **BOR**: chat ekranining qismi | **BOR**: Sozlamalar appbar'i; dialog yopilishi = bekor | **BOR** |

## Keyingi faza uchun eslatma

Bu tiklash shuni ko'rsatdi: **`.git` yo'qligi katta xavf.** Faza 7 da birinchi
ish sifatida loyihani git bilan boshqarishni ko'rib chiqish kerak (yoki kamida
har faza oxirida manba daraxtining arxiv nusxasini saqlash).
