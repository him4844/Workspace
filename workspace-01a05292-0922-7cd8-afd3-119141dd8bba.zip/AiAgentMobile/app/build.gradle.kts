import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    // Kotlin AGP 9 tomonidan "built-in" tarzda qo'llaniladi (android.builtInKotlin=true).
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "com.aiagent.mobile"
    // compileSdk 37 (Android 17 API'lari) — 2026-yilgi androidx kutubxonalari
    // (compose 1.12, core-ktx 1.19, okhttp 5.5) kamida 37 talab qiladi.
    // Bu FAQAT kompilyatsiya darajasi; ilovaning ishlash diapazoniga ta'sir qilmaydi.
    compileSdk = 37

    defaultConfig {
        applicationId = "com.aiagent.mobile"
        // Foydalanuvchi talabi: ilova Android 11 (API 30) dan Android 16 (API 36) gacha ishlashi kerak.
        // Spetsifikatsiyadagi "Min SDK 26" shu talab bilan almashtirildi (PROGRESS_LOG.md -> QARORLAR).
        minSdk = 30
        targetSdk = 36 // Android 16 — ilovaning rasmiy mo'ljallangan yuqori chegarasi
        versionCode = 1
        versionName = "0.1.0-faza0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/DEPENDENCIES")
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    lint {
        abortOnError = true
        warningsAsErrors = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // ---- Asos ----
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.kotlinx.coroutines.android)

    // ---- Compose (Material 3) ----
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    debugImplementation(libs.compose.ui.tooling)

    // ---- Hilt (DI) ----
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    // ---- DataStore (Faza 2: workspace / sozlamalar saqlash) ----
    implementation(libs.androidx.datastore.preferences)

    // ---- SAF: DocumentFile (Faza 2: fayl daraxti) ----
    implementation(libs.androidx.documentfile)

    // ---- Tarmoq (Faza 3: AI provider, Faza 5: Colab) ----
    implementation(libs.retrofit)
    implementation(libs.retrofit.converter.kotlinx.serialization)
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging.interceptor)
    implementation(libs.kotlinx.serialization.json)

    // ---- Diff (Faza 4: diff ekrani va patch qo'llash) ----
    implementation(libs.java.diff.utils)

    // ---- Test ----
    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    // Faza 3: AI chaqiruvini haqiqiy lokal HTTP server bilan tekshirish.
    testImplementation(libs.okhttp.mockwebserver)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.compose.ui.test.junit4)
    debugImplementation(libs.compose.ui.test.manifest)
}
