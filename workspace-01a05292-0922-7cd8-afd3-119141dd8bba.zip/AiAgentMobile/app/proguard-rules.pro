# ProGuard/R8 qoidalari. Faza 0 da minify o'chirilgan (isMinifyEnabled = false).
# Keyingi fazalarda kerak bo'ladigan qoidalar izoh sifatida tayyorlab qo'yilgan:

# Retrofit + kotlinx.serialization (Faza 3)
#-keepattributes *Annotation*, InnerClasses
#-dontnote kotlinx.serialization.**
#-keepclassmembers class com.aiagent.mobile.data.ai.** {
#    *** Companion;
#}
#-keepclasseswithmembers class com.aiagent.mobile.data.ai.** {
#    kotlinx.serialization.KSerializer serializer(...);
#}

# OkHttp / Okio platform ogohlantirishlarini bosish
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
