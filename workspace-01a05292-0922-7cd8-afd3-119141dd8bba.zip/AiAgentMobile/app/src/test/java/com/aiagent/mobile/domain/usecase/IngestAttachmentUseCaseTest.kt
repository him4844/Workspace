package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileKind
import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.model.PdfPages
import com.aiagent.mobile.domain.model.TextMatch
import com.aiagent.mobile.domain.repository.DocumentRepository
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Fayl turiga qarab AI kontekstini tayyorlash (Faza 3).
 *
 * Foydalanuvchi talabi: HAR QANDAY turdagi fayl ishlatilishi kerak. Shuning uchun
 * har bir tur alohida tekshiriladi — hech biri jim tashlab ketilmasligi kerak.
 */
class IngestAttachmentUseCaseTest {

    /** Faqat test uchun: kerakli metodni oldindan tayyor qiymat bilan qaytaradi. */
    private class FakeDocuments(
        val mime: String?,
        val size: Long,
        val text: FileContent = FileContent.Failed("so'ralmagan"),
        val image: FileContent = FileContent.Failed("so'ralmagan"),
        val listing: FileContent = FileContent.Failed("so'ralmagan"),
        val archiveTexts: FileContent = FileContent.Failed("so'ralmagan"),
        val pdf: PdfPages = PdfPages(emptyList(), 0, "so'ralmagan"),
    ) : DocumentRepository {
        override fun takePersistablePermission(uri: String) = Unit
        override fun hasPersistablePermission(uri: String) = true
        override suspend fun treeDisplayName(uri: String) = "test"
        override suspend fun listChildren(uri: String): List<FileNode> = emptyList()
        override suspend fun readTextFile(uri: String, maxBytes: Int) = text
        override suspend fun readImageBase64(uri: String, maxBytes: Int) = image
        override suspend fun listArchiveEntries(uri: String, maxEntries: Int) = listing
        override suspend fun readArchiveTextEntries(
            uri: String,
            maxEntries: Int,
            maxBytesPerEntry: Int,
        ) = archiveTexts

        override suspend fun renderPdfPages(
            uri: String,
            maxPages: Int,
            maxDimensionPx: Int,
        ) = pdf

        override suspend fun fileSize(uri: String) = size
        override suspend fun mimeTypeOf(uri: String) = mime

        // ---- Faza 4 da interfeys kengaytirildi; bu test ulardan foydalanmaydi,
        // ---- shuning uchun "qo'llab-quvvatlanmaydi" javobi qaytariladi (jim emas).
        override suspend fun resolveChild(rootUri: String, path: String): String? = null
        override suspend fun exists(uri: String) = false
        override suspend fun writeFile(uri: String, content: String) = false
        override suspend fun createFile(parentUri: String, fileName: String, content: String) = null
        override suspend fun createDirectory(parentUri: String, name: String) = null
        override suspend fun deleteDocument(uri: String) = false
        override suspend fun moveDocument(uri: String, targetParentUri: String, newName: String) = null
        override suspend fun copyDocument(uri: String, targetParentUri: String, newName: String) = null
        override suspend fun searchFiles(rootUri: String, query: String, maxResults: Int) =
            emptyList<FileNode>()
        override suspend fun searchInFiles(
            rootUri: String,
            query: String,
            maxFiles: Int,
            maxMatchesPerFile: Int,
            maxFileBytes: Int,
        ) = emptyList<TextMatch>()
    }

    @Test
    fun `matn fayli to'liq o'qiladi`() = runTest {
        val documents = FakeDocuments(
            mime = "text/x-kotlin",
            size = 12,
            text = FileContent.Text("fun main() {}", truncated = false, totalBytes = 12),
        )

        val result = IngestAttachmentUseCase(documents).ingest("uri", "Main.kt")

        assertEquals(FileKind.TEXT, result.kind)
        assertEquals("fun main() {}", result.text)
        assertNull("Kesish bo'lmasa izoh bo'lmasligi kerak", result.note)
    }

    @Test
    fun `katta matn fayli kesilgani haqida aniq izoh beriladi`() = runTest {
        val documents = FakeDocuments(
            mime = "text/plain",
            size = 12_000_000,
            text = FileContent.Text("boshi...", truncated = true, totalBytes = 12_000_000),
        )

        val result = IngestAttachmentUseCase(documents).ingest("uri", "Big.log")

        assertTrue(result.truncated)
        assertNotNull(result.note)
        assertTrue(
            "Izohda hajm aytilishi kerak: ${result.note}",
            result.note!!.contains("12000000"),
        )
    }

    @Test
    fun `rasm base64 sifatida biriktiriladi`() = runTest {
        val documents = FakeDocuments(
            mime = "image/png",
            size = 3_000,
            image = FileContent.Image(mimeType = "image/png", base64 = "iVBORw0", sizeBytes = 3_000),
        )

        val result = IngestAttachmentUseCase(documents).ingest("uri", "shot.png")

        assertEquals(FileKind.IMAGE, result.kind)
        assertEquals(1, result.images.size)
        assertEquals("iVBORw0", result.images.first().base64)
    }

    @Test
    fun `PDF sahifalari rasm sifatida qaytariladi`() = runTest {
        val documents = FakeDocuments(
            mime = "application/pdf",
            size = 50_000,
            pdf = PdfPages(
                pages = listOf(
                    IngestedImage(mimeType = "image/jpeg", base64 = "AAA", label = "PDF 1-sahifa"),
                ),
                totalPages = 9,
            ),
        )

        val result = IngestAttachmentUseCase(documents).ingest("uri", "doc.pdf")

        assertEquals(FileKind.PDF, result.kind)
        assertEquals(1, result.images.size)
        // 9 sahifadan faqat biri yuborildi — bu yashirin bo'lmasligi kerak.
        assertTrue(result.note!!.contains("9"))
    }

    @Test
    fun `arxiv ro'yxati va matnli yozuvlari birlashtiriladi`() = runTest {
        val documents = FakeDocuments(
            mime = "application/zip",
            size = 20_000,
            listing = FileContent.Archive(
                entries = listOf(
                    com.aiagent.mobile.domain.model.ArchiveEntry("a.txt", 10, false),
                    com.aiagent.mobile.domain.model.ArchiveEntry("res", 0, true),
                ),
            ),
            archiveTexts = FileContent.Text("a.txt mazmuni", truncated = false, totalBytes = 13),
        )

        val result = IngestAttachmentUseCase(documents).ingest("uri", "bundle.zip")

        assertEquals(FileKind.ARCHIVE, result.kind)
        assertTrue(result.text!!.contains("a.txt"))
        assertTrue(result.text!!.contains("a.txt mazmuni"))
    }

    @Test
    fun `ikkilik fayl uchun metadata va aniq izoh qaytariladi`() = runTest {
        val documents = FakeDocuments(mime = "application/octet-stream", size = 9_999)

        val result = IngestAttachmentUseCase(documents).ingest("uri", "data.bin")

        assertEquals(FileKind.BINARY, result.kind)
        assertNull(result.text)
        assertNotNull("Ikkilik fayl jim tashlab ketilmasligi kerak", result.note)
        assertTrue(result.note!!.contains("9999"))
    }

    @Test
    fun `o'qib bo'lmagan fayl ham izoh bilan qaytadi`() = runTest {
        val documents = FakeDocuments(
            mime = "text/plain",
            size = 100,
            text = FileContent.Failed("ruxsat yo'q"),
        )

        val result = IngestAttachmentUseCase(documents).ingest("uri", "secret.txt")

        assertNotNull(result.note)
        assertTrue(result.note!!.contains("ruxsat yo'q"))
    }
}
