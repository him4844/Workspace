package com.aiagent.mobile.domain.agent

import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.AiResponse
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.domain.model.ProviderType
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.tools.FakeDocumentRepository
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.ToolSpec
import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import com.aiagent.mobile.domain.tools.ToolContext
import com.aiagent.mobile.domain.tools.ToolRegistry
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Agent sikli testlari (Faza 4, 5-vazifa + TEKSHIRUV talabi).
 *
 * TEKSHIRUV talabidagi ikki holat aynan shu yerda tekshiriladi:
 * 1. Oddiy savol ("Python nima?") uchun HECH QANDAY tool chaqirilmaydi.
 * 2. Fayl so'rovida agent `list_directory` chaqiradi va natijani javobga aylantiradi.
 */
class AgentControllerTest {

    private lateinit var documents: FakeDocumentRepository
    private lateinit var chat: FakeAiChatRepository
    private lateinit var coordinator: EditCoordinator
    private lateinit var controller: AgentController

    private val provider = AiProvider(
        id = "p1",
        name = "Test",
        type = ProviderType.CUSTOM,
        apiBase = "http://localhost",
        apiKey = "sk-test",
        model = "test-model",
    )

    @Before
    fun setUp() {
        documents = FakeDocumentRepository().apply {
            putFile("src/main.kt", "fun main() {}\n")
            putFile("README.md", "# Loyiha\n")
        }
        chat = FakeAiChatRepository()
        coordinator = EditCoordinator()
        controller = AgentController(
            chatRepository = chat,
            documents = documents,
            toolRegistry = ToolRegistry(documents, coordinator, FileChecksumStore()),
            editCoordinator = coordinator,
        )
    }

    // --------------------------------------------------- TEKSHIRUV talablari

    @Test
    fun `oddiy savol uchun hech qanday tool chaqirilmaydi`() = runTest {
        chat.script = listOf(plainAnswer("Python — dasturlash tili."))

        controller.start(request("Python nima?"))
        awaitCompletion()

        assertEquals(AgentState.COMPLETED, controller.state.value)
        assertEquals("Python — dasturlash tili.", controller.finalAnswer.value)
        // MUHIM: so'rovda tool'lar taklif qilingan, lekin AI hech birini tanlamagan
        assertTrue("tool'lar taklif qilinishi kerak", chat.lastToolSpecs.isNotEmpty())
        assertTrue("hech qanday tool chaqirilmagan", documents.calls.isEmpty())
        assertEquals(1, chat.callCount)
    }

    @Test
    fun `fayl so'rovida list_directory chaqiriladi va javob yig'iladi`() = runTest {
        chat.script = listOf(
            toolCallAnswer(
                callId = "call_1",
                toolName = "list_directory",
                args = mapOf("path" to "."),
            ),
            plainAnswer("Loyihada src papkasi va README.md bor."),
        )

        controller.start(request("Loyihada qanday fayllar bor?"))
        awaitCompletion()

        assertEquals(AgentState.COMPLETED, controller.state.value)
        assertEquals(2, chat.callCount)
        // Tool natijasi tarixga `role = tool` sifatida qo'shilgan bo'lishi kerak
        val toolMessage = chat.lastMessages.firstOrNull { it.role == MessageRole.TOOL }
        assertNotNull("tool natijasi tarixga qo'shilishi kerak", toolMessage)
        assertEquals("call_1", toolMessage?.toolCallId)
        assertTrue(toolMessage!!.content.contains("src"))
    }

    @Test
    fun `tool natijasidan oldin tool_calls li assistant xabari yuboriladi`() = runTest {
        // OpenAI qoidasi: role:"tool" dan oldin tool_calls li assistant bo'lishi SHART.
        // Aks holda provider 400 qaytaradi — shuning uchun tartibni test qilamiz.
        chat.script = listOf(
            toolCallAnswer("call_x", "get_file_info", mapOf("path" to "README.md")),
            plainAnswer("Tayyor."),
        )

        controller.start(request("README haqida ayt"))
        awaitCompletion()

        val roles = chat.lastMessages.map { it.role.name }
        val toolIndex = roles.indexOf("TOOL")
        val assistantWithCalls = chat.lastMessages.getOrNull(toolIndex - 1)
        assertEquals("tool dan oldin assistant bo'lishi kerak", MessageRole.ASSISTANT, assistantWithCalls?.role)
        assertTrue("assistant xabari tool_calls ni olib yurishi kerak", assistantWithCalls!!.toolCalls.isNotEmpty())
        assertEquals("call_x", assistantWithCalls.toolCalls.first().id)
    }

    // ------------------------------------------------------- tasdiq oqimi

    @Test
    fun `ALWAYS_CONFIRM da agent to'xtaydi va tasdiqdan keyin fayl yoziladi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM
        chat.script = listOf(
            toolCallAnswer(
                "call_w",
                "write_file",
                mapOf("path" to "src/main.kt", "content" to "fun main() { } // yangi"),
            ),
            plainAnswer("Fayl yangilandi."),
        )

        controller.start(request("main.kt ni yangila"))
        awaitPermission()

        assertEquals(AgentState.WAITING_FOR_PERMISSION, controller.state.value)
        assertNotNull(controller.pendingEdit.value)
        // Fayl hali o'zgarmagan
        assertTrue(documents.contentOf("src/main.kt")!!.startsWith("fun main() {}"))

        controller.approvePendingEdit()
        awaitCompletion()

        assertEquals(AgentState.COMPLETED, controller.state.value)
        assertEquals("fun main() { } // yangi", documents.contentOf("src/main.kt"))
        assertNull(controller.pendingEdit.value)
    }

    @Test
    fun `rad etilganda agent xato oladi, lekin sikl davom etadi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM
        chat.script = listOf(
            toolCallAnswer("call_w", "write_file", mapOf("path" to "README.md", "content" to "x")),
            plainAnswer("Mayli, o'zgartirmadim."),
        )

        controller.start(request("README'ni o'zgartir"))
        awaitPermission()
        controller.rejectPendingEdit()
        awaitCompletion()

        assertEquals(AgentState.COMPLETED, controller.state.value)
        assertTrue(documents.contentOf("README.md")!!.contains("Loyiha"))
        // Agent rad etilganini bilishi kerak
        val toolMessage = chat.lastMessages.firstOrNull { it.role == MessageRole.TOOL }
        assertTrue(toolMessage!!.content.contains("rad etdi"))
    }

    // -------------------------------------------------------------- chegaralar

    @Test
    fun `qadam chegarasiga yetganda agent to'xtaydi (cheksiz sikl yo'q)`() = runTest {
        // Har doim tool chaqiradigan javob — chegarasiz sikl bo'lardi.
        chat.script = List(40) {
            toolCallAnswer("c$it", "get_file_info", mapOf("path" to "README.md"))
        }

        controller.start(request("cheksiz sikl"))
        awaitTerminal()

        assertEquals(AgentState.FAILED, controller.state.value)
        assertTrue(
            "qadam chegarasida to'xtashi kerak",
            controller.steps.value.any { it.kind == AgentStepKind.LIMIT },
        )
        assertTrue(chat.callCount <= AgentLimits().maxSteps + 1)
    }

    @Test
    fun `provider xatosi agentni FAILED holatiga o'tkazadi`() = runTest {
        chat.script = listOf(AiResult.Failure(AiError.Unauthorized))

        controller.start(request("xato holati"))
        awaitTerminal()

        assertEquals(AgentState.FAILED, controller.state.value)
        assertEquals(AiError.Unauthorized, controller.error.value)
    }

    @Test
    fun `stop agent siklini bekor qiladi`() = runTest {
        chat.script = listOf(
            toolCallAnswer("c1", "get_file_info", mapOf("path" to "README.md")),
            plainAnswer("hech qachon yetib bormaydi"),
        )
        chat.delayMs = 60

        controller.start(request("sekin so'rov"))
        delay(20)
        controller.stop()

        assertEquals(AgentState.CANCELLED, controller.state.value)
    }

    @Test
    fun `undo oxirgi o'zgartirishni qaytaradi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY
        val before = documents.contentOf("src/main.kt")
        val toolResult = ToolRegistry(documents, coordinator, FileChecksumStore())
            .invoke("write_file", mapOf("path" to "src/main.kt", "content" to "almashtirildi"), context())
        assertTrue(toolResult is ToolResult.Success)
        assertEquals("almashtirildi", documents.contentOf("src/main.kt"))

        var undone: ToolResult? = null
        controller.undoLastEdit { undone = it }
        // undoLastEdit o'z scope'ida ishlaydi — natija kelguncha kutamiz
        var waited = 0
        while (undone == null && waited < 2000) {
            delay(10)
            waited += 10
        }

        assertTrue("undo natijasi kelishi kerak", undone is ToolResult.Success)
        assertEquals(before, documents.contentOf("src/main.kt"))
    }

    // ---------------------------------------------------------------- yordamchi

    private fun context() =
        ToolContext(rootUri = FakeDocumentRepository.ROOT, maxFileBytes = 100_000)

    private fun request(message: String) = AgentRunRequest(
        provider = provider,
        rootUri = FakeDocumentRepository.ROOT,
        workspaceName = "Test",
        userMessage = message,
    )

    private fun plainAnswer(text: String) = AiResult.Success(
        AiResponse(content = text, model = "test-model", promptTokens = 10, completionTokens = 5),
    )

    private fun toolCallAnswer(
        callId: String,
        toolName: String,
        args: Map<String, String>,
    ) = AiResult.Success(
        AiResponse(
            // Tool chaqiruvida matn bo'sh bo'lishi mumkin — bu xato EMAS.
            content = "",
            model = "test-model",
            promptTokens = 10,
            completionTokens = 5,
            toolCalls = listOf(
                com.aiagent.mobile.domain.model.ToolCallRequest(callId, toolName, args),
            ),
        ),
    )

    private suspend fun awaitCompletion() {
        awaitState(AgentState.COMPLETED)
    }

    private suspend fun awaitPermission() {
        awaitState(AgentState.WAITING_FOR_PERMISSION)
    }

    private suspend fun awaitTerminal() {
        var waited = 0
        while (waited < 5000) {
            val state = controller.state.value
            if (state == AgentState.COMPLETED || state == AgentState.FAILED) return
            delay(10)
            waited += 10
        }
        throw AssertionError("agent terminal holatga o'tmadi: ${controller.state.value}")
    }

    private suspend fun awaitState(target: AgentState) {
        var waited = 0
        while (waited < 5000) {
            if (controller.state.value == target) return
            delay(10)
            waited += 10
        }
        throw AssertionError("$target kutilgandi, lekin ${controller.state.value} edi")
    }

    /** Oldindan yozilgan javoblar ketma-ketligini beradigan soxta provider. */
    private class FakeAiChatRepository : AiChatRepository {

        var script: List<AiResult> = emptyList()
        var callCount = 0
            private set
        var lastMessages: List<AiRequestMessage> = emptyList()
            private set
        var lastToolSpecs: List<ToolSpec> = emptyList()
            private set
        var delayMs = 0L

        override suspend fun complete(
            provider: AiProvider,
            messages: List<AiRequestMessage>,
            images: List<IngestedImage>,
            tools: List<ToolSpec>,
        ): AiResult {
            if (delayMs > 0) delay(delayMs)
            lastMessages = messages
            lastToolSpecs = tools
            val index = callCount
            callCount++
            return script.getOrElse(index) { script.last() }
        }

        override suspend fun testConnection(provider: AiProvider): AiResult =
            plainTestAnswer

        private companion object {
            val plainTestAnswer: AiResult = AiResult.Success(
                AiResponse(content = "ok", model = "test", promptTokens = 1, completionTokens = 1),
            )
        }
    }

    @Test
    fun `agent sikli tool ro'yxatini AI'ga yuboradi`() = runTest {
        chat.script = listOf(plainAnswer("ok"))
        controller.start(request("salom"))
        awaitCompletion()

        // 13 ta tool taklif qilinishi kerak — aks holda AI fayl ustida ishlay olmaydi
        assertEquals(13, chat.lastToolSpecs.size)
        assertTrue(chat.lastToolSpecs.any { it.name == "read_file" })
        assertFalse(chat.lastToolSpecs.first().description.isBlank())
    }
}
