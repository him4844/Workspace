package com.aiagent.mobile.ui.common

import org.junit.Assert.assertEquals
import org.junit.Test

/** Fayl hajmi formati — fayl daraxtida har bir fayl yonida ko'rinadi. */
class FormattersTest {

    @Test
    fun `bir kilobaytdan kichik hajm baytda ko'rsatiladi`() {
        assertEquals("0 B", Formatters.fileSize(0))
        assertEquals("512 B", Formatters.fileSize(512))
        assertEquals("1023 B", Formatters.fileSize(1023))
    }

    @Test
    fun `kilobayt va undan yuqori birliklar bitta o'nlik bilan ko'rsatiladi`() {
        assertEquals("1.0 KB", Formatters.fileSize(1024))
        assertEquals("1.5 KB", Formatters.fileSize(1536))
        assertEquals("1.0 MB", Formatters.fileSize(1024L * 1024L))
        assertEquals("1.0 GB", Formatters.fileSize(1024L * 1024L * 1024L))
    }

    @Test
    fun `chegara qiymatlari yuqori birlikka o'tadi`() {
        // 1023.9 KB emas, 1024 KB = 1.0 MB bo'lishi kerak.
        assertEquals("1.0 MB", Formatters.fileSize(1024L * 1024L))
        assertEquals("1023.9 KB", Formatters.fileSize(1024L * 1024L - 100L))
    }
}
