package com.aiagent.mobile.data.database

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Workspace'lar DataStore'da JSON ko'rinishida saqlanadi (Faza 2 QAROR).
 * Bu test shu formatni kafolatlaydi: agar DTO maydoni o'zgarsa, eski saqlangan
 * ma'lumotni o'qib bo'lishi kerak (ignoreUnknownKeys) yoki test darhol sinadi.
 */
class WorkspaceDtoTest {

    private val json = Json { ignoreUnknownKeys = true }

    @Test
    fun `DTO va domen modeli o'rtasida aylantirish ma'lumotni yo'qotmaydi`() {
        val dto = WorkspaceDto(
            id = "id-1",
            name = "MeningLoyiham",
            uri = "content://com.android.externalstorage.documents/tree/primary%3ADownload",
            lastOpenedAt = 1_700_000_000_000L,
        )

        val restored = WorkspaceDto.fromDomain(dto.toDomain())

        assertEquals(dto, restored)
    }

    @Test
    fun `ro'yxat JSON'ga yozilib qayta o'qiladi`() {
        val original = WorkspaceListDto(
            items = listOf(
                WorkspaceDto("a", "Birinchi", "uri://a", 1000L),
                WorkspaceDto("b", "Ikkinchi", "uri://b", 2000L),
            ),
        )

        val raw = json.encodeToString(WorkspaceListDto.serializer(), original)
        val decoded = json.decodeFromString(WorkspaceListDto.serializer(), raw)

        assertEquals(original, decoded)
    }

    @Test
    fun `kelajakda qo'shilgan noma'lum maydon eski yozuvni buzmaydi`() {
        val raw = """{"items":[{"id":"a","name":"Birinchi","uri":"uri://a","lastOpenedAt":1000,"yangiMaydon":true}]}"""

        val decoded = json.decodeFromString(WorkspaceListDto.serializer(), raw)

        assertEquals(1, decoded.items.size)
        assertEquals("Birinchi", decoded.items.first().name)
    }

    @Test
    fun `buzilgan JSON o'rniga bo'sh ro'yxat qaytadi`() {
        val result = runCatching {
            json.decodeFromString(WorkspaceListDto.serializer(), "{buzilgan")
        }

        assertEquals(true, result.isFailure)
    }
}
