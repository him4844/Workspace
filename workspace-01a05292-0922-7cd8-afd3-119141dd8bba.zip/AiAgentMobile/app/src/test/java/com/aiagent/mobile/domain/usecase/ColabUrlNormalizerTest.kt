package com.aiagent.mobile.domain.usecase

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Colab (ngrok) havolasini tozalash testlari (Faza 5).
 *
 * Nima uchun muhim: foydalanuvchi havolani Colab chiqishidan nusxalaydi va unga
 * bo'shliq, yangi qator yoki ortiqcha `/` qo'shilib qolishi mumkin. Retrofit
 * `baseUrl` esa aniq bitta oxirgi slash talab qiladi — aks holda ilova qulaydi.
 */
class ColabUrlNormalizerTest {

    @Test
    fun `toza https havola o'zgarmaydi`() {
        assertEquals(
            "https://abcd-12-34.ngrok-free.app/",
            ColabUrlNormalizer.normalize("https://abcd-12-34.ngrok-free.app/"),
        )
    }

    @Test
    fun `oxirgi slash bo'lmasa qo'shiladi`() {
        assertEquals(
            "https://abcd-12-34.ngrok-free.app/",
            ColabUrlNormalizer.normalize("https://abcd-12-34.ngrok-free.app"),
        )
    }

    @Test
    fun `atrofidagi bo'shliq va yangi qator tozalanadi`() {
        // Nusxalashda eng ko'p uchraydigan holat.
        assertEquals(
            "https://abcd-12-34.ngrok-free.app/",
            ColabUrlNormalizer.normalize("  https://abcd-12-34.ngrok-free.app \n"),
        )
    }

    @Test
    fun `ichki bo'shliq ham olib tashlanadi`() {
        assertEquals(
            "https://abcd-12-34.ngrok-free.app/",
            ColabUrlNormalizer.normalize("https://abcd-12-34. ngrok-free.app"),
        )
    }

    @Test
    fun `sxema yozilmasa https qo'shiladi`() {
        // Ngrok har doim https beradi, shuning uchun xavfsiz standart — https.
        assertEquals(
            "https://abcd-12-34.ngrok-free.app/",
            ColabUrlNormalizer.normalize("abcd-12-34.ngrok-free.app"),
        )
    }

    @Test
    fun `http sxemasi saqlanadi (localhost uchun kerak)`() {
        assertEquals(
            "http://10.0.2.2:8000/",
            ColabUrlNormalizer.normalize("http://10.0.2.2:8000"),
        )
    }

    @Test
    fun `localhost port bilan qabul qilinadi`() {
        assertEquals(
            "https://localhost:8000/",
            ColabUrlNormalizer.normalize("localhost:8000"),
        )
    }

    @Test
    fun `bo'sh va null qiymat null qaytaradi`() {
        assertNull(ColabUrlNormalizer.normalize(null))
        assertNull(ColabUrlNormalizer.normalize(""))
        assertNull(ColabUrlNormalizer.normalize("   "))
        assertNull(ColabUrlNormalizer.normalize("\n\t "))
    }

    @Test
    fun `URL ga o'xshamagan matn rad etiladi`() {
        // "salom" da nuqta yo'q — domen emas.
        assertNull(ColabUrlNormalizer.normalize("salom"))
        assertNull(ColabUrlNormalizer.normalize("http://"))
        assertNull(ColabUrlNormalizer.normalize("https://"))
    }

    @Test
    fun `forDisplay oxirgi slash ni olib tashlaydi`() {
        assertEquals(
            "https://abcd-12-34.ngrok-free.app",
            ColabUrlNormalizer.forDisplay("https://abcd-12-34.ngrok-free.app/"),
        )
        assertEquals("", ColabUrlNormalizer.forDisplay(null))
    }
}
