package com.aiagent.mobile.domain.tools

import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Faza 4 tool testlari (1-5 vazifalar).
 *
 * Barcha tool'lar sof Kotlin va `DocumentRepository` orqali ishlaydi, shuning uchun
 * [FakeDocumentRepository] bilan emulyatorsiz tekshiriladi.
 */
class ToolRegistryTest {

    private lateinit var documents: FakeDocumentRepository
    private lateinit var coordinator: EditCoordinator
    private lateinit var checksums: FileChecksumStore
    private lateinit var registry: ToolRegistry

    private val context = ToolContext(rootUri = FakeDocumentRepository.ROOT, maxFileBytes = 100_000)

    @Before
    fun setUp() {
        documents = FakeDocumentRepository().apply {
            putFile("src/main.kt", "fun main() {\n    println(\"Salom\")\n}\n")
            putFile("src/util/helper.kt", "class Helper {\n    val name = \"Salom\"\n}\n")
            putFile("README.md", "# Loyiha\n\nBu test loyihasi.\n")
            putDirectory("docs")
        }
        coordinator = EditCoordinator()
        checksums = FileChecksumStore()
        registry = ToolRegistry(documents, coordinator, checksums)
    }

    // ------------------------------------------------------------- ro'yxat

    @Test
    fun `13 ta tool ro'yxatdan topiladi`() {
        assertEquals(13, registry.tools.size)
        listOf(
            "list_directory", "read_file", "get_file_info",
            "write_file", "create_file", "delete_file", "move_file", "copy_file",
            "search_files", "search_text",
            "apply_patch", "replace_text", "insert_text",
        ).forEach { name ->
            assertNotNull("$name topilmadi", registry.find(name))
        }
        // Hamma tool nomi noyob bo'lishi kerak (aks holda AI ikki xil toolni aralashtiradi)
        assertEquals(13, registry.tools.map(AgentTool::name).distinct().size)
    }

    @Test
    fun `noma'lum tool nomi aniq xato qaytaradi, agent o'zini tuzata oladi`() = runTest {
        val result = registry.invoke("read_files", mapOf("path" to "a.txt"), context)
        val error = result as ToolResult.Error
        assertTrue(error.recoverable)
        assertTrue(error.message.contains("read_file"))
    }

    @Test
    fun `kerakli parametr berilmasa aniq xato qaytadi`() = runTest {
        val result = registry.invoke("read_file", emptyMap(), context)
        val error = result as ToolResult.Error
        assertTrue(error.recoverable)
        assertTrue(error.message.contains("path"))
    }

    // -------------------------------------------------------------- o'qish

    @Test
    fun `read_file fayl mazmunini qaytaradi`() = runTest {
        val result = registry.invoke("read_file", mapOf("path" to "src/main.kt"), context)
        val success = result as ToolResult.Success
        assertTrue(success.output.contains("fun main()"))
    }

    @Test
    fun `read_file mavjud bo'lmagan fayl uchun xato qaytaradi`() = runTest {
        val result = registry.invoke("read_file", mapOf("path" to "yoq.kt"), context)
        assertTrue(result is ToolResult.Error)
    }

    @Test
    fun `ildizdan chiqishga urinish (dot-dot) bloklangan`() = runTest {
        // `..` tashlab yuboriladi — agent tanlangan papkadan chiqib keta olmaydi.
        val result = registry.invoke("read_file", mapOf("path" to "../../etc/passwd"), context)
        assertTrue("ildiz tashqarisiga chiqib ketmasligi kerak", result is ToolResult.Error)
        assertNull(documents.contentOf("../etc/passwd"))
    }

    @Test
    fun `list_directory faqat bevosita bolalarni ko'rsatadi`() = runTest {
        val result = registry.invoke("list_directory", mapOf("path" to "."), context)
        val output = (result as ToolResult.Success).output
        assertTrue(output.contains("src"))
        assertTrue(output.contains("README.md"))
        // ichki fayl ko'rinmasligi kerak (faqat 1 daraja)
        assertFalse(output.contains("helper.kt"))
    }

    @Test
    fun `get_file_info hajm va turni ko'rsatadi`() = runTest {
        val result = registry.invoke("get_file_info", mapOf("path" to "README.md"), context)
        val output = (result as ToolResult.Success).output
        assertTrue(output.contains("README.md"))
    }

    // -------------------------------------------------------------- qidiruv

    @Test
    fun `search_files nom bo'yicha topadi`() = runTest {
        val result = registry.invoke("search_files", mapOf("query" to "helper"), context)
        val output = (result as ToolResult.Success).output
        assertTrue(output.contains("src/util/helper.kt"))
    }

    @Test
    fun `search_text qator raqami bilan topadi`() = runTest {
        val result = registry.invoke("search_text", mapOf("query" to "Salom"), context)
        val output = (result as ToolResult.Success).output
        assertTrue("qator raqami bo'lishi kerak", output.contains("2:"))
        assertTrue(output.contains("Salom"))
    }
}
