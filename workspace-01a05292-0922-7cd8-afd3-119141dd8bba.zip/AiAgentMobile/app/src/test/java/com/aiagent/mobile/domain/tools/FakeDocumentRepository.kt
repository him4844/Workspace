package com.aiagent.mobile.domain.tools

import com.aiagent.mobile.domain.model.ArchiveEntry
import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.model.PdfPages
import com.aiagent.mobile.domain.model.TextMatch
import com.aiagent.mobile.domain.repository.DocumentRepository

/**
 * In-memory fayl tizimi — Faza 4 tool testlari uchun.
 *
 * Nima uchun kerak: tool'lar SOF KOTLIN va barcha I/O `DocumentRepository` orqali,
 * shuning uchun emulyator yoki haqiqiy papka kerak emas. Shu fake bilan
 * o'qish/yozish/o'chirish/qidiruv JVM testida tekshiriladi.
 *
 * **URI shakli ataylab haqiqiy SAF URI'siga o'xshatilgan** (`content://test/tree/...`):
 * `EditCoordinator.parentUriOf` "://" sxemasini talab qiladi, shuning uchun sodda
 * `root/src/a.kt` ko'rinishi production kod yo'lini to'g'ri tekshirmas edi.
 *
 * Yo'l qoidalari (haqiqiy `SafDocumentRepository` bilan bir xil):
 * - papkalar kaliti slash bilan TUGAMAYDI (`content://test/tree/src`)
 * - `..` segmentlari tashlab yuboriladi — agent ildizdan chiqib keta olmaydi
 */
class FakeDocumentRepository : DocumentRepository {

    /** Papkalar (ildiz ham shu yerda). */
    private val directories = mutableSetOf(ROOT)

    /** Fayllar: to'liq yo'l -> matn. */
    val files = mutableMapOf<String, String>()

    /** Chaqiruvlar tarixi — test "qaysi amal bajarildi" ni tekshirishi uchun. */
    val calls = mutableListOf<String>()

    /** Yozishni sun'iy ravishda buzish (xato yo'lini tekshirish uchun). */
    var failWrites = false

    override fun takePersistablePermission(uri: String) = Unit

    override fun hasPersistablePermission(uri: String): Boolean = true

    override suspend fun treeDisplayName(uri: String): String? = "Soxta workspace"

    override suspend fun listChildren(uri: String): List<FileNode> {
        val base = canonical(uri)
        val prefix = "$base/"
        val found = mutableMapOf<String, FileNode>()

        directories.filter { it != base && it.startsWith(prefix) }.forEach { dir ->
            val relative = dir.removePrefix(prefix)
            if (relative.isNotEmpty() && !relative.contains('/')) {
                found[dir] = FileNode(
                    name = relative,
                    uri = dir,
                    isDirectory = true,
                    sizeBytes = 0,
                    mimeType = null,
                )
            }
        }
        files.keys.filter { it.startsWith(prefix) }.forEach { path ->
            val relative = path.removePrefix(prefix)
            if (relative.isNotEmpty() && !relative.contains('/')) {
                found[path] = FileNode(
                    name = relative,
                    uri = path,
                    isDirectory = false,
                    sizeBytes = files.getValue(path).toByteArray(Charsets.UTF_8).size.toLong(),
                    mimeType = "text/plain",
                )
            }
        }
        return found.values.sortedBy(FileNode::name)
    }

    override suspend fun readTextFile(uri: String, maxBytes: Int): FileContent {
        val path = canonical(uri)
        val content = files[path] ?: return FileContent.Failed("Fayl topilmadi: $path")
        val bytes = content.toByteArray(Charsets.UTF_8)
        return if (bytes.size > maxBytes) {
            FileContent.Text(
                content = String(bytes.copyOf(maxBytes), Charsets.UTF_8),
                truncated = true,
                totalBytes = bytes.size.toLong(),
            )
        } else {
            FileContent.Text(content = content, truncated = false, totalBytes = bytes.size.toLong())
        }
    }

    override suspend fun readImageBase64(uri: String, maxBytes: Int): FileContent =
        FileContent.Failed("Fake'da rasm yo'q")

    override suspend fun listArchiveEntries(uri: String, maxEntries: Int): FileContent =
        FileContent.Archive(listOf(ArchiveEntry("ichidagi.txt", 10, false)))

    override suspend fun readArchiveTextEntries(
        uri: String,
        maxEntries: Int,
        maxBytesPerEntry: Int,
    ): FileContent = FileContent.Text("arxiv matni", false, 11)

    override suspend fun renderPdfPages(uri: String, maxPages: Int, maxDimensionPx: Int): PdfPages =
        PdfPages(pages = emptyList(), totalPages = 0, failedReason = "fake")

    override suspend fun fileSize(uri: String): Long =
        files[canonical(uri)]?.toByteArray(Charsets.UTF_8)?.size?.toLong() ?: -1L

    override suspend fun mimeTypeOf(uri: String): String? =
        if (files.containsKey(canonical(uri))) "text/plain" else null

    // ---------------------------------------------------------------- Faza 4

    override suspend fun resolveChild(rootUri: String, path: String): String? {
        val full = join(rootUri, path)
        return if (files.containsKey(full) || directories.contains(full)) full else null
    }

    override suspend fun exists(uri: String): Boolean {
        val full = canonical(uri)
        return files.containsKey(full) || directories.contains(full)
    }

    override suspend fun writeFile(uri: String, content: String): Boolean {
        calls += "writeFile:$uri"
        if (failWrites) return false
        files[canonical(uri)] = content
        return true
    }

    override suspend fun createFile(
        parentUri: String,
        fileName: String,
        content: String,
    ): String? {
        calls += "createFile:$parentUri/$fileName"
        if (failWrites) return null
        val parent = canonical(parentUri)
        if (!directories.contains(parent)) return null
        val path = "$parent/$fileName"
        if (files.containsKey(path)) return null
        files[path] = content
        return path
    }

    override suspend fun createDirectory(parentUri: String, name: String): String? {
        calls += "createDirectory:$parentUri/$name"
        val parent = canonical(parentUri)
        if (!directories.contains(parent)) return null
        val path = "$parent/$name"
        if (directories.contains(path)) return null
        directories += path
        return path
    }

    override suspend fun deleteDocument(uri: String): Boolean {
        calls += "deleteDocument:$uri"
        val full = canonical(uri)
        if (files.remove(full) != null) return true
        return directories.remove(full)
    }

    override suspend fun moveDocument(
        uri: String,
        targetParentUri: String,
        newName: String,
    ): String? {
        calls += "moveDocument:$uri->$targetParentUri/$newName"
        val source = canonical(uri)
        val content = files[source] ?: return null
        val targetParent = canonical(targetParentUri)
        if (!directories.contains(targetParent)) return null
        val target = "$targetParent/$newName"
        files.remove(source)
        files[target] = content
        return target
    }

    override suspend fun copyDocument(
        uri: String,
        targetParentUri: String,
        newName: String,
    ): String? {
        calls += "copyDocument:$uri->$targetParentUri/$newName"
        val content = files[canonical(uri)] ?: return null
        val targetParent = canonical(targetParentUri)
        if (!directories.contains(targetParent)) return null
        val target = "$targetParent/$newName"
        if (files.containsKey(target)) return null
        files[target] = content
        return target
    }

    override suspend fun searchFiles(
        rootUri: String,
        query: String,
        maxResults: Int,
    ): List<FileNode> {
        val prefix = canonical(rootUri) + "/"
        return files.keys.asSequence()
            .filter { it.startsWith(prefix) }
            .filter { it.removePrefix(prefix).contains(query, ignoreCase = true) }
            .sorted()
            .take(maxResults)
            .map { path ->
                FileNode(
                    name = path.removePrefix(prefix),
                    uri = path,
                    isDirectory = false,
                    sizeBytes = files.getValue(path).toByteArray(Charsets.UTF_8).size.toLong(),
                    mimeType = "text/plain",
                )
            }
            .toList()
    }

    override suspend fun searchInFiles(
        rootUri: String,
        query: String,
        maxFiles: Int,
        maxMatchesPerFile: Int,
        maxFileBytes: Int,
    ): List<TextMatch> {
        val prefix = canonical(rootUri) + "/"
        val matches = mutableListOf<TextMatch>()
        var visitedFiles = 0
        files.keys.filter { it.startsWith(prefix) }.sorted().forEach { path ->
            if (visitedFiles >= maxFiles) return@forEach
            visitedFiles++
            val relative = path.removePrefix(prefix)
            var matchesInFile = 0
            files.getValue(path).lines().forEachIndexed { index, line ->
                if (matchesInFile < maxMatchesPerFile && line.contains(query, ignoreCase = true)) {
                    matches += TextMatch(relative, index + 1, line.trim())
                    matchesInFile++
                }
            }
        }
        return matches
    }

    // ---------------------------------------------------------------- yordamchi

    /** Test uchun fayl qo'shish (oraliq papkalar avtomatik yaratiladi). */
    fun putFile(path: String, content: String) {
        val clean = path.replace('\\', '/').trim('/')
        val segments = clean.split('/').filter(String::isNotBlank)
        // Ota papkalarni ildizdan boshlab bosqichma-bosqich yaratamiz.
        for (depth in 1 until segments.size) {
            directories += ROOT + "/" + segments.take(depth).joinToString("/")
        }
        files["$ROOT/${segments.joinToString("/")}"] = content
    }

    /** Test uchun papka qo'shish. */
    fun putDirectory(path: String) {
        val clean = path.replace('\\', '/').trim('/')
        directories += "$ROOT/$clean"
    }

    fun contentOf(path: String): String? = files[join(ROOT, path)]

    companion object {
        const val ROOT = "content://test/tree"

        /**
         * ildiz + nisbiy yo'l. `..` segmentlari tashlab yuboriladi, shuning uchun
         * `../../etc/passwd` ildiz ichidagi `etc/passwd`ga aylanadi — chiqib ketilmaydi.
         */
        fun join(rootUri: String, path: String): String {
            val segments = mutableListOf<String>()
            path.replace('\\', '/').split('/').forEach { part ->
                when (part) {
                    "", "." -> Unit
                    ".." -> if (segments.isNotEmpty()) segments.removeAt(segments.lastIndex)
                    else -> segments += part
                }
            }
            val base = rootUri.trimEnd('/')
            return if (segments.isEmpty()) base else base + "/" + segments.joinToString("/")
        }

        /** Faqat oxiridagi slash'ni olib tashlaydi — qolgan yo'l allaqachon kanonik. */
        fun canonical(uri: String): String = uri.trimEnd('/')
    }
}
