package com.aiagent.mobile.data.ai

import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.ProviderType
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * AI chaqiruvi HAQIQIY lokal HTTP server bilan tekshiriladi (Faza 3 TEKSHIRUV TALABI).
 *
 * Nima uchun bu test muhim: spetsifikatsiya "so'rov provider'ga yetib borganini
 * isbotlash" va "401 tushunarli xabar berishi, crash bo'lmasligi" ni talab qiladi.
 * Emulyator bu muhitda yo'q, shuning uchun `MockWebServer` ishlatildi: ilova
 * kodining o'zi haqiqiy TCP ulanish ochadi, haqiqiy HTTP so'rov yuboradi va
 * javobni o'zi parsing qiladi. Testda so'rovning manzili, sarlavhalari va tanasi
 * server tomonida yozib olinadi — ya'ni "yetib bordi" degan da'vo tekshiriladi.
 *
 * Diqqat: bu FAQAT test bog'liqligi (`testImplementation`), ilova APK'siga kirmaydi.
 */
class AiChatRepositoryImplTest {

    private lateinit var server: MockWebServer
    private lateinit var repository: AiChatRepositoryImpl

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        repository = AiChatRepositoryImpl(
            OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .build(),
        )
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private fun provider(apiBase: String = server.url("/v1").toString()) = AiProvider(
        id = "p1",
        name = "Test",
        type = ProviderType.CUSTOM,
        apiBase = apiBase,
        apiKey = "sk-test-1234a91f",
        model = "test-model",
        maxTokens = 256,
        temperature = 0.3f,
        contextLength = 8_000,
    )

    private fun userMessage(text: String) =
        AiRequestMessage(role = MessageRole.USER, content = text)

    @Test
    fun `so'rov serverga to'g'ri manzil va sarlavhalar bilan yetib boradi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"choices":[{"message":{"role":"assistant","content":"Salom!"}}]}""",
            ),
        )

        val result = repository.complete(provider(), listOf(userMessage("Salom")))

        assertTrue("Muvaffaqiyatli javob kutilgandi: $result", result is AiResult.Success)

        val recorded = server.takeRequest()
        assertEquals("POST", recorded.method)
        assertEquals("/v1/chat/completions", recorded.path)
        assertEquals("Bearer sk-test-1234a91f", recorded.getHeader("Authorization"))
        // Konverter media type'ga charset qo'shadi ("application/json; charset=utf-8"),
        // shuning uchun aniq tenglik emas, prefix tekshiriladi.
        assertTrue(
            "Content-Type JSON bo'lishi kerak: ${recorded.getHeader("Content-Type")}",
            recorded.getHeader("Content-Type").orEmpty().startsWith("application/json"),
        )

        val body = recorded.body.readUtf8()
        assertTrue("Model nomi so'rovda bo'lishi kerak: $body", body.contains("\"model\":\"test-model\""))
        assertTrue("Streaming o'chirilgan bo'lishi kerak: $body", body.contains("\"stream\":false"))
        assertTrue("Xabar matni so'rovda bo'lishi kerak: $body", body.contains("Salom"))
    }

    @Test
    fun `muvaffaqiyatli javob domen modeliga to'g'ri aylantiriladi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"model":"deepseek-chat","usage":{"prompt_tokens":11,"completion_tokens":7},""" +
                    """"choices":[{"message":{"role":"assistant","content":"Javob matni"},""" +
                    """"finish_reason":"stop"}]}""",
            ),
        )

        val result = repository.complete(provider(), listOf(userMessage("savol")))

        val response = (result as AiResult.Success).response
        assertEquals("Javob matni", response.content)
        assertEquals("deepseek-chat", response.model)
        assertEquals(11, response.promptTokens)
        assertEquals(7, response.completionTokens)
    }

    @Test
    fun `401 javob Unauthorized xatosiga aylantiriladi va crash bo'lmaydi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(401).setBody(
                """{"error":{"message":"Incorrect API key provided"}}""",
            ),
        )

        val result = repository.complete(provider(), listOf(userMessage("Salom")))

        val error = (result as AiResult.Failure).error
        assertTrue("401 -> Unauthorized kutilgandi, keldi: $error", error is AiError.Unauthorized)
    }

    @Test
    fun `429 javob RateLimited xatosiga aylantiriladi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(429).setBody("""{"error":{"message":"quota exceeded"}}"""),
        )

        val result = repository.complete(provider(), listOf(userMessage("Salom")))

        assertTrue((result as AiResult.Failure).error is AiError.RateLimited)
    }

    @Test
    fun `5xx javob Server xatosiga va xabar matniga aylantiriladi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(503).setBody(
                """{"error":{"message":"upstream provider unavailable"}}""",
            ),
        )

        val result = repository.complete(provider(), listOf(userMessage("Salom")))

        val error = (result as AiResult.Failure).error as AiError.Server
        assertEquals(503, error.code)
        assertEquals("upstream provider unavailable", error.detail)
    }

    @Test
    fun `rasmlarni qabul qilmaydigan provider VisionUnsupported deb aniqlanadi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(400).setBody(
                """{"error":{"message":"This model does not support image_url input"}}""",
            ),
        )

        val result = repository.complete(
            provider = provider(),
            messages = listOf(userMessage("rasm nima haqida?")),
            images = listOf(IngestedImage(mimeType = "image/png", base64 = "AAAA", label = "a.png")),
        )

        val error = (result as AiResult.Failure).error
        assertTrue("VisionUnsupported kutilgandi, keldi: $error", error is AiError.VisionUnsupported)
    }

    @Test
    fun `rasm biriktirilganda so'rov OpenAI vision formatida yuboriladi`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"choices":[{"message":{"content":"ko'k osmon"}}]}""",
            ),
        )

        repository.complete(
            provider = provider(),
            messages = listOf(userMessage("bu nima?")),
            images = listOf(IngestedImage(mimeType = "image/jpeg", base64 = "Zm9v", label = "a.jpg")),
        )

        val body = server.takeRequest().body.readUtf8()
        assertTrue("image_url qismi bo'lishi kerak: $body", body.contains("\"type\":\"image_url\""))
        assertTrue("data URI bo'lishi kerak: $body", body.contains("data:image/jpeg;base64,Zm9v"))
    }

    @Test
    fun `server javob bermasa NoNetwork xatosi qaytadi`() = runTest {
        // Server oldindan yopiladi -> ulanish rad etiladi (DNS/ulanish xatosi).
        val port = server.port
        server.shutdown()

        val result = repository.complete(
            provider = provider("http://127.0.0.1:$port/v1"),
            messages = listOf(userMessage("Salom")),
        )

        val error = (result as AiResult.Failure).error
        assertTrue("NoNetwork kutilgandi, keldi: $error", error is AiError.NoNetwork)

        // tearDown'da ikkinchi marta yopmaslik uchun yangi server ishga tushiriladi.
        server = MockWebServer().also { it.start() }
    }

    @Test
    fun `bo'sh choices InvalidResponse deb hisoblanadi`() = runTest {
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"choices":[]}"""))

        val result = repository.complete(provider(), listOf(userMessage("Salom")))

        assertTrue((result as AiResult.Failure).error is AiError.InvalidResponse)
    }

    @Test
    fun `yaroqsiz API manzil so'rov yubormasdan to'xtatiladi`() = runTest {
        val result = repository.complete(
            provider = provider(apiBase = "not-a-url"),
            messages = listOf(userMessage("Salom")),
        )

        val error = (result as AiResult.Failure).error
        assertTrue("InvalidConfig kutilgandi, keldi: $error", error is AiError.InvalidConfig)
        assertEquals("Hech qanday so'rov yuborilmasligi kerak", 0, server.requestCount)
    }

    @Test
    fun `bo'sh API kalit so'rov yubormasdan to'xtatiladi`() = runTest {
        val result = repository.complete(
            provider = provider().copy(apiKey = ""),
            messages = listOf(userMessage("Salom")),
        )

        assertTrue((result as AiResult.Failure).error is AiError.InvalidConfig)
        assertEquals(0, server.requestCount)
    }
}
