package com.aiagent.mobile.data.colab

import com.aiagent.mobile.domain.agent.ColabStatus
import com.aiagent.mobile.domain.agent.RemoteTask
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AppSettings
import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.repository.SettingsRepository
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Colab serveri bilan ishlash testlari (Faza 5 TEKSHIRUV TALABI).
 *
 * `MockWebServer` ishlatilgan: ilova kodi haqiqiy TCP ulanish ochadi va haqiqiy
 * HTTP so'rov yuboradi. Shunday qilib "so'rov serverga yetib bordi" degan da'vo
 * server tomonida yozib olingan so'rov orqali isbotlanadi.
 *
 * Tekshiriladigan asosiy holatlar:
 * - URL kiritilmagan → `NotConfigured` (xato emas)
 * - `/health` javob bergan → `Connected`
 * - server xato qaytargan → `ServerError(kod)`
 * - ulanib bo'lmagan → `Unreachable` (havola eskirgan holati)
 * - `/execute` → `RemoteTaskResult` va so'rov tanasi to'g'ri
 */
class ColabExecutionEngineTest {

    private lateinit var server: MockWebServer
    private lateinit var settings: FakeSettingsRepository
    private lateinit var engine: ColabExecutionEngine

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        settings = FakeSettingsRepository()
        engine = ColabExecutionEngine(
            httpClient = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .build(),
            settingsRepository = settings,
        )
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    // -------------------------------------------------------------- health

    @Test
    fun `URL kiritilmagan bo'lsa NotConfigured qaytadi (xato emas)`() = runTest {
        settings.colabUrl = ""

        val status = engine.checkStatus()

        assertEquals(ColabStatus.NotConfigured, status)
        assertFalse(status.isConnected)
        // Hech qanday so'rov yuborilmagan bo'lishi kerak
        assertEquals(0, server.requestCount)
    }

    @Test
    fun `health javob berganda Connected qaytadi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(
            MockResponse()
                .setHeader("Content-Type", "application/json")
                .setBody("""{"status":"ok","workdir":"/content/drive/MyDrive/AiAgentWorkspace","workspace_exists":true}"""),
        )

        val status = engine.checkStatus()

        assertTrue("Connected kutilgandi, $status keldi", status is ColabStatus.Connected)
        assertTrue((status as ColabStatus.Connected).workspaceExists)
        assertTrue(status.isConnected)
        assertEquals("/health", server.takeRequest().path)
    }

    @Test
    fun `workspace_exists false bo'lsa ham Connected, lekin belgisi bilan`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(
            MockResponse()
                .setHeader("Content-Type", "application/json")
                .setBody("""{"status":"ok","workdir":"/x","workspace_exists":false}"""),
        )

        val status = engine.checkStatus()

        assertTrue(status is ColabStatus.Connected)
        assertFalse((status as ColabStatus.Connected).workspaceExists)
    }

    @Test
    fun `server 500 qaytarsa ServerError va kod ko'rsatiladi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(MockResponse().setResponseCode(500))

        val status = engine.checkStatus()

        assertTrue("ServerError kutilgandi, $status keldi", status is ColabStatus.ServerError)
        assertEquals(500, (status as ColabStatus.ServerError).code)
        assertFalse(status.isConnected)
    }

    @Test
    fun `serverga ulanib bo'lmasa Unreachable qaytadi (havola eskirgan holati)`() = runTest {
        // Deterministik ulanish xatosi: hech narsa tinglamaydigan mahalliy port.
        // (Avval "mavjud bo'lmagan ngrok domeni" ishlatilgan edi, lekin wildcard DNS
        // uni 404 bilan javob qaytardi — test barqaror emas edi.)
        settings.colabUrl = "http://127.0.0.1:1/"

        val status = engine.checkStatus()

        assertTrue("Unreachable kutilgandi, $status keldi", status is ColabStatus.Unreachable)
        assertFalse(status.isConnected)
    }

    @Test
    fun `o'lik tunnel kodi (404) Unreachable deb hisoblanadi, ServerError emas`() = runTest {
        // Ngrok eskirgan tunnel uchun aynan 404 qaytaradi. Foydalanuvchi uchun bu
        // "server buzildi" emas, "havola eskirgan" degani — shuning uchun alohida tur.
        settings.colabUrl = server.url("/").toString()
        server.enqueue(MockResponse().setResponseCode(404))

        val status = engine.checkStatus()

        assertTrue("Unreachable kutilgandi, $status keldi", status is ColabStatus.Unreachable)
    }

    @Test
    fun `isAvailable health natijasi bilan mos keladi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(
            MockResponse()
                .setHeader("Content-Type", "application/json")
                .setBody("""{"status":"ok","workdir":"/x","workspace_exists":true}"""),
        )

        assertTrue(engine.isAvailable())
    }

    // ------------------------------------------------------------- execute

    @Test
    fun `execute buyrug'i serverga yetib boradi va natija qaytadi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(
            MockResponse()
                .setHeader("Content-Type", "application/json")
                .setBody("""{"success":true,"output":"[exit 0]\nBUILD SUCCESSFUL","errorMessage":null}"""),
        )

        val result = engine.executeTask(
            RemoteTask(
                id = "t1",
                command = "./gradlew assembleDebug",
                workdir = "/content/drive/MyDrive/AiAgentWorkspace",
                timeoutMs = 300_000,
            ),
        )

        assertTrue(result.success)
        assertTrue(result.output.contains("BUILD SUCCESSFUL"))
        assertNull(result.errorMessage)

        // So'rov haqiqatan to'g'ri tana bilan borganini isbotlaymiz.
        val request = server.takeRequest()
        assertEquals("/execute", request.path)
        assertEquals("POST", request.method)
        val body = request.body.readUtf8()
        assertTrue("buyruq tanada bo'lishi kerak", body.contains("./gradlew assembleDebug"))
        assertTrue("workdir tanada bo'lishi kerak", body.contains("AiAgentWorkspace"))
        // 300_000 ms = 300 s — notebook `timeout_seconds` kutadi
        // `encodeDefaults` bo'lmasa bu maydon umuman yuborilmasdi (haqiqiy xato edi).
        assertTrue("timeout soniyalarda bo'lishi kerak: $body", body.contains("\"timeout_seconds\":300"))
    }

    @Test
    fun `buyruq muvaffaqiyatsiz bo'lsa success false va errorMessage keladi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(
            MockResponse()
                .setHeader("Content-Type", "application/json")
                .setBody("""{"success":false,"output":"[exit 1]\nxato","errorMessage":"Buyruq 1 kod bilan tugadi."}"""),
        )

        val result = engine.executeTask(
            RemoteTask(id = "t2", command = "false", workdir = "/w"),
        )

        assertFalse(result.success)
        assertEquals("Buyruq 1 kod bilan tugadi.", result.errorMessage)
    }

    @Test
    fun `URL kiritilmagan bo'lsa execute aniq yo'l ko'rsatma bilan xato qaytaradi`() = runTest {
        settings.colabUrl = ""

        val result = engine.executeTask(
            RemoteTask(id = "t3", command = "ls", workdir = "/w"),
        )

        assertFalse(result.success)
        assertNotNull(result.errorMessage)
        // Foydalanuvchi nima qilishini bilishi kerak — shunchaki "xato" emas.
        assertTrue(
            "yo'l ko'rsatma bo'lishi kerak: ${result.errorMessage}",
            result.errorMessage!!.contains("Colab URL"),
        )
        assertEquals(0, server.requestCount)
    }

    @Test
    fun `server 404 qaytarsa havola eskirgani haqida aytiladi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        server.enqueue(MockResponse().setResponseCode(404))

        val result = engine.executeTask(
            RemoteTask(id = "t4", command = "ls", workdir = "/w"),
        )

        assertFalse(result.success)
        assertTrue(
            "eskirgan havola sababi aytilishi kerak: ${result.errorMessage}",
            result.errorMessage!!.contains("eskirgan"),
        )
    }

    @Test
    fun `bo'sh javob tanasi crash qildirmaydi`() = runTest {
        settings.colabUrl = server.url("/").toString()
        // Noto'g'ri JSON — `coerceInputValues` va xato ushlash tekshiriladi.
        server.enqueue(
            MockResponse()
                .setHeader("Content-Type", "application/json")
                .setBody("bu json emas"),
        )

        val result = engine.executeTask(
            RemoteTask(id = "t5", command = "ls", workdir = "/w"),
        )

        assertFalse(result.success)
        assertNotNull(result.errorMessage)
    }

    // ------------------------------------------------------------- yordamchi

    private fun assertNotNull(value: String?) {
        assertTrue("qiymat null bo'lmasligi kerak", value != null)
    }

    /** Faqat `colabUrl` muhim — qolgan metodlar minimal implementatsiya. */
    private class FakeSettingsRepository : SettingsRepository {

        var colabUrl: String = ""

        private val flow = MutableStateFlow(listOf<AiProvider>())

        override val providers: Flow<List<AiProvider>> = flow

        override val settings: Flow<AppSettings> = flow.map {
            AppSettings(
                activeProviderId = null,
                editMode = EditMode.ALWAYS_CONFIRM,
                colabUrl = colabUrl,
            )
        }

        override suspend fun saveProvider(provider: AiProvider) = Unit
        override suspend fun deleteProvider(providerId: String) = Unit
        override suspend fun setActiveProvider(providerId: String) = Unit
        override suspend fun updateSettings(settings: AppSettings) {
            colabUrl = settings.colabUrl
        }

        override suspend fun activeProvider(): AiProvider? = null
    }
}
