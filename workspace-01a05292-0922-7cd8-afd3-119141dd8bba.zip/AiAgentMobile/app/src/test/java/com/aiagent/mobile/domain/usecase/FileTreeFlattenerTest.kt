package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.FileNode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Fayl daraxtini tekislash mantiqi — Faza 2 UI'ning asosi.
 * Bu testlar emulyatorsiz ishlaydi, chunki mantiq domen qatlamida (sof Kotlin).
 */
class FileTreeFlattenerTest {

    private val rootChildren = listOf(
        fileNode(name = "README.md", uri = "uri://readme", isDirectory = false),
        fileNode(name = "src", uri = "uri://src", isDirectory = true),
        fileNode(name = "build.gradle.kts", uri = "uri://gradle", isDirectory = false),
        fileNode(name = "app", uri = "uri://app", isDirectory = true),
    )

    private val srcChildren = listOf(
        fileNode(name = "main", uri = "uri://src/main", isDirectory = true),
        fileNode(name = "Main.kt", uri = "uri://src/main_kt", isDirectory = false),
    )

    private val mainChildren = listOf(
        fileNode(name = "App.kt", uri = "uri://src/main/app_kt", isDirectory = false),
    )

    @Test
    fun `yopiq holda faqat ildiz bolalari ko'rinadi`() {
        val rows = FileTreeFlattener.flatten(
            rootChildren = rootChildren,
            childrenByUri = mapOf("uri://src" to srcChildren),
            expandedUris = emptySet(),
        )

        // Avval papkalar (app, src), keyin fayllar (build.gradle.kts, README.md) —
        // har bir guruh ichida nomi bo'yicha.
        assertEquals(
            listOf("app", "src", "build.gradle.kts", "README.md"),
            rows.map { it.node.name },
        )
        assertTrue(rows.all { it.depth == 0 })
        assertTrue(rows.none { it.isExpanded })
    }

    @Test
    fun `ochilgan papka bolalari chuqurlik bilan qo'shiladi`() {
        val rows = FileTreeFlattener.flatten(
            rootChildren = rootChildren,
            childrenByUri = mapOf("uri://src" to srcChildren),
            expandedUris = setOf("uri://src"),
        )

        // src papkasi ochilgach, uning bolalari darhol keyin keladi.
        val srcIndex = rows.indexOfFirst { it.node.uri == "uri://src" }
        assertEquals("main", rows[srcIndex + 1].node.name)
        assertEquals(1, rows[srcIndex + 1].depth)
        assertEquals("Main.kt", rows[srcIndex + 2].node.name)
        assertEquals(1, rows[srcIndex + 2].depth)
        assertTrue(rows[srcIndex].isExpanded)
    }

    @Test
    fun `ikki daraja chuqurlik to'g'ri ko'rsatiladi`() {
        val rows = FileTreeFlattener.flatten(
            rootChildren = rootChildren,
            childrenByUri = mapOf(
                "uri://src" to srcChildren,
                "uri://src/main" to mainChildren,
            ),
            expandedUris = setOf("uri://src", "uri://src/main"),
        )

        val appRow = rows.first { it.node.name == "App.kt" }
        assertEquals(2, appRow.depth)

        // Tartib: src -> main -> App.kt
        val srcIndex = rows.indexOfFirst { it.node.uri == "uri://src" }
        assertEquals("main", rows[srcIndex + 1].node.name)
        assertEquals("App.kt", rows[srcIndex + 2].node.name)
    }

    @Test
    fun `ochilgan lekin hali yuklanmagan papka bolalari ko'rsatilmaydi`() {
        val rows = FileTreeFlattener.flatten(
            rootChildren = rootChildren,
            childrenByUri = emptyMap(),
            expandedUris = setOf("uri://src"),
        )

        // Faqat ildiz bolalari qoladi — yuklanmagan papka bo'sh deb ko'rsatilmaydi,
        // UI o'z holatida spinner ko'rsatadi.
        assertEquals(4, rows.size)
        assertTrue(rows.first { it.node.uri == "uri://src" }.isExpanded)
    }

    @Test
    fun `papkalar har doim fayllardan oldin va nomi bo'yicha turadi`() {
        val sorted = FileTreeFlattener.sortForDisplay(rootChildren).map { it.name }

        assertEquals(listOf("app", "src", "build.gradle.kts", "README.md"), sorted)
    }

    @Test
    fun `fayl hech qachon expanded bo'lmaydi`() {
        val rows = FileTreeFlattener.flatten(
            rootChildren = rootChildren,
            childrenByUri = emptyMap(),
            expandedUris = setOf("uri://readme"),
        )

        val readme = rows.first { it.node.name == "README.md" }
        assertFalse(readme.isExpanded)
    }

    private fun fileNode(name: String, uri: String, isDirectory: Boolean) = FileNode(
        name = name,
        uri = uri,
        isDirectory = isDirectory,
        sizeBytes = if (isDirectory) 0 else 1_024,
        mimeType = if (isDirectory) "vnd.android.document/directory" else "text/plain",
    )
}
