package com.aiagent.mobile.domain.usecase

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Token byudjeti — kontekst oynasini to'ldirib yubormaslik uchun muhim. */
class TokenEstimatorTest {

    @Test
    fun `matn uzunligidan token soni taxmin qilinadi`() {
        assertEquals(1, TokenEstimator.estimateTokens("abc"))
        assertEquals(3, TokenEstimator.estimateTokens("123456789"))
        assertEquals(0, TokenEstimator.estimateTokens(""))
    }

    @Test
    fun `byudjetga sig'adigan matn kesilmaydi`() {
        val result = TokenEstimator.truncateToTokens("qisqa matn", maxTokens = 100)

        assertEquals("qisqa matn", result.text)
        assertFalse(result.truncated)
    }

    @Test
    fun `byudjetdan katta matn kesiladi va belgi qo'yiladi`() {
        val long = (1..200).joinToString(" ") { "so'z$it" }

        val result = TokenEstimator.truncateToTokens(long, maxTokens = 10)

        assertTrue(result.truncated)
        assertTrue("Kesilgan matn aslidan qisqa bo'lishi kerak", result.text.length < long.length)
        assertTrue("Kesish bo'shliq chegarasida bo'lishi kerak", !result.text.endsWith(" "))
    }

    @Test
    fun `nol byudjet bo'sh matn qaytaradi`() {
        val result = TokenEstimator.truncateToTokens("biror matn", maxTokens = 0)

        assertEquals("", result.text)
        assertTrue(result.truncated)
    }
}

/** Foydalanuvchi kiritgan API manzili har xil ko'rinishda keladi — barchasi ishlashi kerak. */
class ApiBaseNormalizerTest {

    @Test
    fun `slash'siz manzil oxiriga slash qo'shadi`() {
        assertEquals(
            "https://api.deepseek.com/v1/",
            ApiBaseNormalizer.normalize("https://api.deepseek.com/v1"),
        )
    }

    @Test
    fun `slash'li manzil o'zgarmaydi`() {
        assertEquals(
            "https://api.tokenrouter.io/v1/",
            ApiBaseNormalizer.normalize("https://api.tokenrouter.io/v1/"),
        )
    }

    @Test
    fun `ortiqcha bo'shliqlar tozalanadi`() {
        assertEquals(
            "https://api.deepseek.com/v1/",
            ApiBaseNormalizer.normalize("  https://api.deepseek.com/v1  "),
        )
    }

    @Test
    fun `http manzil ham qabul qilinadi`() {
        assertEquals(
            "http://10.0.2.2:8000/v1/",
            ApiBaseNormalizer.normalize("http://10.0.2.2:8000/v1"),
        )
    }

    @Test
    fun `yaroqsiz manzillar null qaytaradi`() {
        assertEquals(null, ApiBaseNormalizer.normalize(""))
        assertEquals(null, ApiBaseNormalizer.normalize("   "))
        assertEquals(null, ApiBaseNormalizer.normalize("api.deepseek.com/v1"))
        assertEquals(null, ApiBaseNormalizer.normalize("https://"))
        assertEquals(null, ApiBaseNormalizer.normalize("ftp://example.com"))
    }
}

/** API kalit ekranda hech qachon to'liq ko'rsatilmasligi kerak. */
class ApiKeyMaskerTest {

    @Test
    fun `kalitning faqat boshi va oxirgi 4 belgisi ko'rinadi`() {
        val masked = ApiKeyMasker.mask("sk-abcdef123456a91f")

        assertEquals("sk-•••a91f", masked)
        assertFalse("To'liq kalit ekranga chiqmasligi kerak", masked.contains("abcdef123456"))
    }

    @Test
    fun `juda qisqa kalit butunlay yashiriladi`() {
        assertEquals("••••", ApiKeyMasker.mask("ab12"))
        assertEquals("", ApiKeyMasker.mask(""))
    }
}

/** Tarix byudjetga sig'masa, eng eski xabarlar tashlanadi. */
class HistoryWindowTest {

    private fun message(text: String) =
        com.aiagent.mobile.domain.model.AiRequestMessage(
            role = com.aiagent.mobile.domain.model.MessageRole.USER,
            content = text,
        )

    @Test
    fun `byudjet yetarli bo'lsa butun tarix qoladi`() {
        val history = listOf(message("a"), message("b"), message("c"))

        assertEquals(3, HistoryWindow.fit(history, tokenBudget = 1000).size)
    }

    @Test
    fun `byudjet yetishmasa oxirgi xabarlar saqlanadi`() {
        val history = List(10) { index -> message("so'z ".repeat(300) + index) }

        val fitted = HistoryWindow.fit(history, tokenBudget = 200)

        assertTrue("Kamida bitta xabar qolishi kerak", fitted.isNotEmpty())
        assertTrue(fitted.size < history.size)
        assertEquals("Oxirgi xabar har doim saqlanadi", history.last(), fitted.last())
    }

    @Test
    fun `bo'sh tarix bo'sh qaytadi`() {
        assertTrue(HistoryWindow.fit(emptyList(), tokenBudget = 100).isEmpty())
    }

    @Test
    fun `nol byudjetda ham oxirgi xabar yuboriladi`() {
        val history = listOf(message("a"), message("b"))

        assertEquals(listOf(message("b")), HistoryWindow.fit(history, tokenBudget = 0))
    }
}
