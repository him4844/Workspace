package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.FileContent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Fayl mazmunini tasniflash — preview va AI konteksti uchun muhim.
 *
 * Faza 3 o'zgarishi: katta matn fayl endi rad ETILMAYDI, balki kesiladi va
 * `truncated = true` + `totalBytes` qaytariladi (foydalanuvchi tanlagan
 * "to'liq yuklash + kesish" strategiyasi). Eski "TooLarge qaytaradi" testi
 * shu sababli yangi kutilmaga almashtirildi.
 */
class FileContentClassifierTest {

    @Test
    fun `oddiy matn fayl Text qaytaradi`() {
        val raw = "fun main() {}".toByteArray(Charsets.UTF_8)

        val result = FileContentClassifier.classify(
            raw = raw,
            reportedSizeBytes = raw.size.toLong(),
            maxBytes = 200_000,
            mimeType = "text/x-kotlin",
        )

        assertTrue(result is FileContent.Text)
        result as FileContent.Text
        assertEquals("fun main() {}", result.content)
        assertFalse(result.truncated)
        assertEquals(raw.size.toLong(), result.totalBytes)
    }

    @Test
    fun `chegaradan katta matn fayl kesiladi va truncated belgisi bilan qaytadi`() {
        val maxBytes = 100
        val raw = ByteArray(maxBytes) { 'a'.code.toByte() }
        val realSize = 12_000_000L

        val result = FileContentClassifier.classify(
            raw = raw,
            reportedSizeBytes = realSize,
            maxBytes = maxBytes,
        )

        assertTrue("Kutilgan: Text (kesilgan), lekin keldi: $result", result is FileContent.Text)
        result as FileContent.Text
        assertTrue("Katta fayl uchun truncated = true bo'lishi kerak", result.truncated)
        assertEquals(maxBytes, result.content.length)
        assertEquals(realSize, result.totalBytes)
    }

    @Test
    fun `NUL bayti bo'lgan fayl Binary deb hisoblanadi`() {
        val raw = byteArrayOf('P'.code.toByte(), 'K'.code.toByte(), 0, 0, 1, 2)

        val result = FileContentClassifier.classify(
            raw = raw,
            reportedSizeBytes = raw.size.toLong(),
            maxBytes = 200_000,
            mimeType = "application/zip",
        )

        assertTrue(result is FileContent.Binary)
        val binary = result as FileContent.Binary
        assertEquals("application/zip", binary.mimeType)
        assertEquals(raw.size.toLong(), binary.sizeBytes)
    }

    @Test
    fun `to'liq o'qilmagan fayl truncated belgisini oladi`() {
        val raw = "birinchi qism".toByteArray(Charsets.UTF_8)

        val result = FileContentClassifier.classify(
            raw = raw,
            reportedSizeBytes = (raw.size + 500).toLong(),
            maxBytes = 200_000,
        )

        assertTrue(result is FileContent.Text)
        assertTrue((result as FileContent.Text).truncated)
    }

    @Test
    fun `bo'sh fayl bo'sh Text qaytaradi`() {
        val result = FileContentClassifier.classify(
            raw = ByteArray(0),
            reportedSizeBytes = 0,
            maxBytes = 200_000,
        )

        assertTrue(result is FileContent.Text)
        assertEquals("", (result as FileContent.Text).content)
    }

    @Test
    fun `kesilgan ko'p baytli UTF-8 belgisi oxirdan olib tashlanadi`() {
        // "salom" + kirill "ў" (2 bayt: 0xD1 0x8E) — oxirgi bayt kesilganini taqlid qilamiz.
        val full = ("salom" + "\u045E").toByteArray(Charsets.UTF_8)
        val cut = full.copyOf(full.size - 1) // oxirgi bayt yo'q -> belgi yarim qolgan

        val trimmed = FileContentClassifier.trimIncompleteUtf8(cut)

        assertEquals("salom", String(trimmed, Charsets.UTF_8))
        assertFalse(
            "Natijada almashtirish belgisi qolmasligi kerak",
            String(trimmed, Charsets.UTF_8).contains('\uFFFD'),
        )
    }

    @Test
    fun `to'liq UTF-8 belgisi kesilmaydi`() {
        val full = ("salom" + "\u045E").toByteArray(Charsets.UTF_8)

        val trimmed = FileContentClassifier.trimIncompleteUtf8(full)

        assertEquals("salom" + "\u045E", String(trimmed, Charsets.UTF_8))
    }

    @Test
    fun `ASCII matn hech qanday holatda kesilmaydi`() {
        val raw = "plain ascii text".toByteArray(Charsets.UTF_8)

        val trimmed = FileContentClassifier.trimIncompleteUtf8(raw)

        assertEquals(raw.size, trimmed.size)
    }
}
