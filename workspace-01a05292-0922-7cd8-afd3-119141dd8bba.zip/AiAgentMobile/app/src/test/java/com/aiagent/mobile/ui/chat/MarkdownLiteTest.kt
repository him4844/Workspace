package com.aiagent.mobile.ui.chat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Javobdagi kod bloklarini ajratish — kod monospace ko'rinishi kerak (Faza 3, 4-vazifa). */
class MarkdownLiteTest {

    @Test
    fun `kod bloksiz matn bitta segment bo'ladi`() {
        val segments = parseCodeBlocks("Oddiy javob matni")

        assertEquals(1, segments.size)
        assertEquals(MessageSegment.Text("Oddiy javob matni"), segments.first())
    }

    @Test
    fun `kod bloki ajratiladi va tili saqlanadi`() {
        val source = "Mana kod:\n```kotlin\nfun main() {}\n```\nTamom."

        val segments = parseCodeBlocks(source)

        assertEquals(3, segments.size)
        assertEquals(MessageSegment.Text("Mana kod:\n"), segments[0])
        val code = segments[1] as MessageSegment.Code
        assertEquals("kotlin", code.language)
        assertEquals("fun main() {}", code.value)
        assertEquals(MessageSegment.Text("\nTamom."), segments[2])
    }

    @Test
    fun `bir nechta kod bloklari ham ajratiladi`() {
        val source = "```a\n1\n```\no'rtada\n```b\n2\n```"

        val segments = parseCodeBlocks(source)

        // Ikki kod bloki orasida AYNAN BITTA matn segmenti bo'ladi ("o'rtada"):
        // bloklardan oldin va keyin bo'sh joy segment hisoblanmaydi.
        assertEquals(2, segments.count { it is MessageSegment.Code })
        assertEquals(1, segments.count { it is MessageSegment.Text })
        assertEquals("o'rtada", (segments[1] as MessageSegment.Text).value.trim())
    }

    @Test
    fun `yopilmagan kod bloki ham yo'qolib qolmaydi`() {
        val source = "Boshi\n```python\nprint('salom')"

        val segments = parseCodeBlocks(source)

        assertTrue(segments.any { it is MessageSegment.Code })
        assertTrue(
            "Kod matni saqlanishi kerak",
            segments.any { it is MessageSegment.Code && it.value.contains("print") },
        )
    }

    @Test
    fun `bo'sh matn bo'sh ro'yxat qaytaradi`() {
        assertTrue(parseCodeBlocks("").isEmpty())
    }
}
