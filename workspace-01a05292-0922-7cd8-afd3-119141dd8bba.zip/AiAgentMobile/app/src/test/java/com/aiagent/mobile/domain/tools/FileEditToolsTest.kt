package com.aiagent.mobile.domain.tools

import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Fayl o'zgartiruvchi va tahrirlovchi tool testlari (Faza 4, 2/4/5/8-vazifalar).
 *
 * `ToolRegistryTest`dan ajratilgan: ikkala fayl ham 400 qator chegarasida qolishi kerak.
 * Bu yerda tekshiriladigan asosiy xatti-harakatlar:
 * - `ALWAYS_CONFIRM` (xavfsiz standart) — hech bir fayl tasdiqsiz o'zgarmaydi
 * - `AUTO_APPLY` — oddiy amallar darhol bajariladi, lekin O'CHIRISH har doim tasdiq so'raydi
 * - checksum conflict — fayl tashqaridan o'zgargan bo'lsa yozish to'xtatiladi
 * - Undo — oxirgi o'zgartirishni qaytarish
 */
class FileEditToolsTest {

    private lateinit var documents: FakeDocumentRepository
    private lateinit var coordinator: EditCoordinator
    private lateinit var registry: ToolRegistry

    private val context = ToolContext(rootUri = FakeDocumentRepository.ROOT, maxFileBytes = 100_000)

    @Before
    fun setUp() {
        documents = FakeDocumentRepository().apply {
            putFile("src/main.kt", "fun main() {\n    println(\"Salom\")\n}\n")
            putFile("src/util/helper.kt", "class Helper {\n    val name = \"Salom\"\n}\n")
            putFile("README.md", "# Loyiha\n\nBu test loyihasi.\n")
            putDirectory("docs")
        }
        coordinator = EditCoordinator()
        registry = ToolRegistry(documents, coordinator, FileChecksumStore())
    }

    // --------------------------------------------------------------- yozish

    @Test
    fun `ALWAYS_CONFIRM rejimida write_file faylga tegmaydi, tasdiq so'raydi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM

        val result = registry.invoke(
            "write_file",
            mapOf("path" to "src/main.kt", "content" to "o'zgargan"),
            context,
        )

        assertTrue("tasdiq so'ralishi kerak", result is ToolResult.PermissionRequired)
        assertEquals("o'zgargan", coordinator.pending?.newContent)
        // MUHIM: fayl hali o'zgarmagan
        assertTrue(documents.contentOf("src/main.kt")!!.contains("fun main()"))
        assertTrue("hech qanday yozuv bo'lmasligi kerak", documents.calls.none { "writeFile" in it })
    }

    @Test
    fun `tasdiqdan keyin fayl haqiqatan yoziladi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM
        registry.invoke(
            "write_file",
            mapOf("path" to "src/main.kt", "content" to "yangi matn"),
            context,
        )

        val accepted = coordinator.accept(documents)

        assertTrue(accepted is ToolResult.Success)
        assertEquals("yangi matn", documents.contentOf("src/main.kt"))
    }

    @Test
    fun `rad etilganda fayl o'zgarmaydi va agent davom eta oladi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM
        registry.invoke(
            "write_file",
            mapOf("path" to "src/main.kt", "content" to "yangi matn"),
            context,
        )

        val rejected = coordinator.reject()

        val error = rejected as ToolResult.Error
        assertTrue("agent boshqa yechim sinashi uchun recoverable", error.recoverable)
        assertTrue(documents.contentOf("src/main.kt")!!.contains("fun main()"))
        assertNull(coordinator.pending)
    }

    @Test
    fun `AUTO_APPLY rejimida write_file darhol yozadi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "write_file",
            mapOf("path" to "src/main.kt", "content" to "avto yozildi"),
            context,
        )

        assertTrue(result is ToolResult.Success)
        assertEquals("avto yozildi", documents.contentOf("src/main.kt"))
        assertEquals(1, coordinator.history().size)
    }

    @Test
    fun `write_file tashqi o'zgarishni (checksum) sezadi va yozmaydi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM
        // Agent faylni o'qidi — checksum saqlandi
        registry.invoke("read_file", mapOf("path" to "src/main.kt"), context)
        // Foydalanuvchi tashqarida faylni o'zgartirdi
        documents.putFile("src/main.kt", "tashqarida o'zgardi")

        val result = registry.invoke(
            "write_file",
            mapOf("path" to "src/main.kt", "content" to "yozmoqchiman"),
            context,
        )

        val error = result as ToolResult.Error
        assertTrue("ziddiyet haqida aniq aytishi kerak", error.message.contains("o'zgargan"))
        assertEquals("tashqarida o'zgardi", documents.contentOf("src/main.kt"))
    }

    @Test
    fun `create_file yangi fayl yaratadi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "create_file",
            mapOf("path" to "docs/yangi.md", "content" to "# Yangi"),
            context,
        )

        assertTrue(result is ToolResult.Success)
        assertEquals("# Yangi", documents.contentOf("docs/yangi.md"))
    }

    @Test
    fun `delete_file o'chiradi va undo qayta tiklaydi`() = runTest {
        coordinator.editMode = EditMode.ALWAYS_CONFIRM
        val before = documents.contentOf("README.md")

        val requested = registry.invoke("delete_file", mapOf("path" to "README.md"), context)
        assertTrue("o'chirish tasdiq so'rashi kerak", requested is ToolResult.PermissionRequired)
        assertEquals("tasdiqdan oldin fayl o'chmasligi kerak", before, documents.contentOf("README.md"))

        val deleted = coordinator.accept(documents)
        assertTrue(deleted is ToolResult.Success)
        assertNull(documents.contentOf("README.md"))

        val undone = coordinator.undoLast(documents)
        assertTrue(undone is ToolResult.Success)
        assertEquals(before, documents.contentOf("README.md"))
    }

    @Test
    fun `delete_file AUTO_APPLY rejimida ham tasdiq so'raydi (halokatli amal)`() = runTest {
        // Spetsifikatsiya: fayl o'chirish HAR DOIM tasdiqlashdan o'tadi.
        // Foydalanuvchi avtomatik rejimni tanlagan bo'lsa ham, qaytarib bo'lmaydigan
        // amal jim bajarilmasligi kerak.
        coordinator.editMode = EditMode.AUTO_APPLY
        // Kutilmani qat'iy matn bilan emas, haqiqiy boshlang'ich holatdan olamiz —
        // aks holda setUp'dagi fayl matni o'zgarsa test yolg'on xato beradi.
        val before = documents.contentOf("README.md")
        assertNotNull(before)

        val result = registry.invoke("delete_file", mapOf("path" to "README.md"), context)

        assertTrue(
            "AUTO_APPLY'da ham o'chirish tasdiq so'rashi shart",
            result is ToolResult.PermissionRequired,
        )
        assertNotNull("diff ekrani uchun amal navbatda bo'lishi kerak", coordinator.pending)
        assertEquals("fayl hali o'chmagan", before, documents.contentOf("README.md"))
    }

    @Test
    fun `write_file AUTO_APPLY'da tasdiqsiz bajariladi (oddiy amal)`() = runTest {
        // Qarama-qarshi holat: o'chirish EMAS, shuning uchun avtomatik bajariladi.
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "write_file",
            mapOf("path" to "README.md", "content" to "yangi"),
            context,
        )

        assertTrue(result is ToolResult.Success)
        assertNull("navbatda kutilayotgan amal bo'lmasligi kerak", coordinator.pending)
    }

    @Test
    fun `undo tarixi bo'sh bo'lsa aniq xabar beradi`() = runTest {
        val result = coordinator.undoLast(documents)
        val error = result as ToolResult.Error
        assertTrue(error.message.contains("yo'q"))
    }

    @Test
    fun `yozish muvaffaqiyatsiz bo'lsa aniq xato qaytadi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY
        documents.failWrites = true

        val result = registry.invoke(
            "write_file",
            mapOf("path" to "src/main.kt", "content" to "x"),
            context,
        )

        assertTrue(result is ToolResult.Error)
    }

    // --------------------------------------------------------------- tahrir

    @Test
    fun `replace_text bitta moslikni almashtiradi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "replace_text",
            mapOf(
                "path" to "README.md",
                "old_text" to "test loyihasi",
                "new_text" to "real loyiha",
            ),
            context,
        )

        assertTrue(result is ToolResult.Success)
        assertTrue(documents.contentOf("README.md")!!.contains("real loyiha"))
    }

    @Test
    fun `replace_text moslik topilmasa xato qaytaradi (jim o'tmaydi)`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "replace_text",
            mapOf("path" to "README.md", "old_text" to "YOQ_MATN", "new_text" to "x"),
            context,
        )

        val error = result as ToolResult.Error
        assertTrue(error.recoverable)
        assertTrue(documents.contentOf("README.md")!!.contains("test loyihasi"))
    }

    @Test
    fun `replace_text bir nechta moslikda rad etadi (noaniq amal)`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY
        // "Salom" bu faylda ikki marta uchraydi — qaysi birini almashtirish noaniq.
        documents.putFile("src/repeat.kt", "val a = \"Salom\"\nval b = \"Salom\"\n")

        val result = registry.invoke(
            "replace_text",
            mapOf(
                "path" to "src/repeat.kt",
                "old_text" to "Salom",
                "new_text" to "Salom!",
            ),
            context,
        )

        val error = result as ToolResult.Error
        assertTrue("noaniq almashtirish rad etilishi kerak", error.recoverable)
        // Fayl o'zgarmasligi shart: hali ham 2 ta "Salom" bor.
        assertEquals(2, documents.contentOf("src/repeat.kt")!!.split("Salom").size - 1)
    }

    @Test
    fun `insert_text ko'rsatilgan qatorga qo'shadi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "insert_text",
            mapOf("path" to "README.md", "line_number" to "2", "text" to "QO'SHILDI"),
            context,
        )

        assertTrue(result is ToolResult.Success)
        val lines = documents.contentOf("README.md")!!.lines()
        assertEquals("QO'SHILDI", lines[1])
    }

    @Test
    fun `insert_text chegaradan tashqari qatorni rad etadi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY

        val result = registry.invoke(
            "insert_text",
            mapOf("path" to "README.md", "line_number" to "999", "text" to "x"),
            context,
        )

        assertTrue(result is ToolResult.Error)
    }

    @Test
    fun `apply_patch unified diff'ni qo'llaydi`() = runTest {
        coordinator.editMode = EditMode.AUTO_APPLY
        // Patch qatorlar ro'yxatidan yig'iladi: `trimIndent` bo'sh KONTEKST qatoridagi
        // majburiy bosh bo'shliqni yo'q qiladi va patch noto'g'ri bo'lib qoladi.
        val patch = listOf(
            "--- a/README.md",
            "+++ b/README.md",
            "@@ -1,3 +1,3 @@",
            " # Loyiha",
            " ",
            "-Bu test loyihasi.",
            "+Bu real loyiha.",
        ).joinToString("\n")

        val result = registry.invoke(
            "apply_patch",
            mapOf("path" to "README.md", "patch" to patch),
            context,
        )

        assertTrue(result is ToolResult.Success)
        assertTrue(documents.contentOf("README.md")!!.contains("real loyiha"))
    }

    // ------------------------------------------------------- EditMode standart

    @Test
    fun `EditCoordinator xavfsiz standart bilan ALWAYS_CONFIRM da ochiladi`() {
        assertEquals(EditMode.ALWAYS_CONFIRM, EditCoordinator().editMode)
    }
}
