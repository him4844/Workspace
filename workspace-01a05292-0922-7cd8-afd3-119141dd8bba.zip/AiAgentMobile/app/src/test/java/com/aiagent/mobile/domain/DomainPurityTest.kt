package com.aiagent.mobile.domain

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Arxitektura qo'riqchisi: `domain` qatlami Android kutubxonalariga bog'liq
 * bo'lmasligi KERAK (PROGRESS_LOG.md -> "Umumiy arxitektura qarorlari", 1-band).
 *
 * Eslatma: bu izohda ataylab "domain slash yulduzcha" ko'rinishi yozilmagan —
 * Kotlin izohlari ichma-ich (nested) bo'la olgani uchun KDoc ichidagi bunday
 * ketma-ketlik izohni yopmay qoldiradi va fayl compile bo'lmaydi (Faza 1 da kuzatilgan).
 *
 * Nima uchun muhim: domain sof Kotlin bo'lsa, agent mantiqini (router qarori,
 * token budget, patch conflict...) emulyatorsiz, oddiy JVM testida tekshirish mumkin.
 * Bu test buzilsa — demak kimdir domen ichiga `android.*` import qo'shgan.
 */
class DomainPurityTest {

    @Test
    fun `domain qatlamida android, androidx, ui yoki data importlari yo'q`() {
        val domainDir = locateDomainDir()
        val ktFiles = domainDir.walkTopDown().filter { it.isFile && it.extension == "kt" }.toList()

        assertTrue(
            "domain papkasida hech qanday .kt fayl topilmadi: ${domainDir.absolutePath}",
            ktFiles.isNotEmpty(),
        )

        val violations = mutableListOf<String>()
        ktFiles.forEach { file ->
            file.readLines()
                .filter { it.startsWith("import ") }
                .filter { line -> FORBIDDEN_PREFIXES.any { line.startsWith(it) } }
                .forEach { violations += "${file.name}: $it" }
        }

        assertTrue(
            "domain qatlami taqiqlangan qatlamga bog'liq bo'lib qoldi:\n" +
                violations.joinToString("\n"),
            violations.isEmpty(),
        )
    }

    /**
     * Taqiqlangan importlar. `android.*`/`androidx.*` dan tashqari Faza 4 da
     * `ui.*` va `data.*` ham qo'shildi: domen qatlami UI yoki Android SDK
     * implementatsiyasiga bog'lanib qolsa, tool mantiqini JVM testida tekshirib
     * bo'lmaydi. (Bu xato Faza 4 da real kuzatildi: tool fayli
     * `ui.common.Formatters` ni import qilib qo'ygandi.)
     */
    private val FORBIDDEN_PREFIXES = listOf(
        "import android.",
        "import androidx.",
        "import com.aiagent.mobile.ui.",
        "import com.aiagent.mobile.data.",
    )

    /**
     * Unit test ishchi katalogi odatda modul papkasi (`app/`), lekin IDE'dan
     * ishga tushirilganda loyiha ildizi bo'lishi mumkin — ikki holat ham qo'llab-quvvatlanadi.
     */
    private fun locateDomainDir(): File {
        val relative = "src/main/java/com/aiagent/mobile/domain"
        val candidates = listOf(
            File(relative),
            File("app/$relative"),
        )
        return candidates.firstOrNull { it.isDirectory }
            ?: error(
                "domain papkasi topilmadi. Ishchi katalog: ${File(".").absolutePath}; " +
                    "sinovchi yo'llar: ${candidates.map { it.absolutePath }}",
            )
    }
}
