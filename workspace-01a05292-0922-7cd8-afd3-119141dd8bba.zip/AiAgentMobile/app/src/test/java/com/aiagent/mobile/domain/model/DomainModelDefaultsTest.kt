package com.aiagent.mobile.domain.model

import com.aiagent.mobile.domain.agent.AgentLimits
import com.aiagent.mobile.domain.agent.ExecutionTarget
import com.aiagent.mobile.domain.agent.RemoteTask
import com.aiagent.mobile.domain.agent.RemoteTaskResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Faza 1 modellari spetsifikatsiyadagi standart qiymatlar va maydonlar bilan
 * yaratilganini tekshiradi. Bu testlar real domen klasslarini chaqiradi —
 * shuning uchun kelajakda biror default tasodifan o'zgarsa, build darhol sinadi.
 */
class DomainModelDefaultsTest {

    @Test
    fun `AiProvider standart qiymatlari spetsifikatsiyaga mos`() {
        val provider = AiProvider(
            id = "p1",
            name = "Test",
            type = ProviderType.CUSTOM,
            apiBase = "https://api.example.com/v1",
            apiKey = "sk-test",
            model = "test-model",
        )

        assertEquals(4096, provider.maxTokens)
        assertEquals(0.2f, provider.temperature, 0.0001f)
        assertEquals(128_000, provider.contextLength)
        assertEquals(false, provider.isDefault)
    }

    @Test
    fun `AppSettings xavfsiz standart qiymatlarga ega`() {
        val settings = AppSettings(activeProviderId = null, editMode = EditMode.ALWAYS_CONFIRM)

        // 8-qoida: tahrirlash rejimi default holda ALWAYS_CONFIRM, AUTO_APPLY emas.
        assertEquals(EditMode.ALWAYS_CONFIRM, settings.editMode)
        // Routing standarti: Colab birinchi navbatda.
        assertEquals(ExecutionPreference.COLAB_PRIMARY, settings.executionPreference)
        assertEquals(100_000, settings.maxFileContextSizeBytes)
        assertNull(settings.isDarkTheme)
        assertNull(settings.activeProviderId)
    }

    @Test
    fun `AgentLimits standart chegaralari`() {
        val limits = AgentLimits()

        assertEquals(30, limits.maxSteps)
        assertEquals(50, limits.maxToolCalls)
        assertEquals(600_000L, limits.maxExecutionTimeMs)
        assertEquals(1_000_000L, limits.maxCommandOutputBytes)
    }

    @Test
    fun `RemoteTask va RemoteTaskResult standartlari`() {
        val task = RemoteTask(id = "t1", command = "./gradlew assembleDebug", workdir = "/work")

        assertEquals(300_000L, task.timeoutMs)

        val result = RemoteTaskResult(success = true, output = "BUILD SUCCESSFUL")
        assertNull(result.errorMessage)
    }

    @Test
    fun `FileNode bolalari standart holda bo'sh va ChatMessage biriktirmalari bo'sh`() {
        val node = FileNode(
            name = "src",
            uri = "content://tree/src",
            isDirectory = true,
            sizeBytes = 0,
            mimeType = null,
        )
        assertTrue(node.children.isEmpty())

        val message = ChatMessage(id = "m1", role = MessageRole.USER, content = "salom", timestamp = 0L)
        assertTrue(message.attachedFiles.isEmpty())
        assertTrue(message.proposedEdits.isEmpty())
    }

    @Test
    fun `enum qiymatlari spetsifikatsiyadagi ro'yxat bilan bir xil`() {
        assertEquals(
            listOf(ProviderType.TOKENROUTER, ProviderType.DEEPSEEK, ProviderType.CUSTOM),
            ProviderType.entries.toList(),
        )
        assertEquals(
            // Faza 4: TOOL roli qo'shildi (agent tool natijasini AI'ga qaytaradi).
            listOf(MessageRole.USER, MessageRole.ASSISTANT, MessageRole.SYSTEM, MessageRole.TOOL),
            MessageRole.entries.toList(),
        )
        assertEquals(
            listOf(
                EditStatus.PENDING,
                EditStatus.ACCEPTED,
                EditStatus.REJECTED,
                EditStatus.APPLIED,
            ),
            EditStatus.entries.toList(),
        )
        assertEquals(
            listOf(EditMode.ALWAYS_CONFIRM, EditMode.AUTO_APPLY),
            EditMode.entries.toList(),
        )
        assertEquals(
            listOf(ExecutionPreference.COLAB_PRIMARY, ExecutionPreference.PHONE_ONLY),
            ExecutionPreference.entries.toList(),
        )
        assertEquals(
            listOf(ExecutionTarget.PHONE, ExecutionTarget.COLAB),
            ExecutionTarget.entries.toList(),
        )
    }
}
