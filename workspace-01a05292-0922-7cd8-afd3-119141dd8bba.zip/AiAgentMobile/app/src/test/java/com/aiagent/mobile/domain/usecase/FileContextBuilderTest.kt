package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.IngestedFile
import com.aiagent.mobile.domain.model.IngestedImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Biriktirilgan fayllardan kontekst bloki qurish (Faza 3). */
class FileContextBuilderTest {

    private fun file(
        name: String,
        text: String?,
        note: String? = null,
        images: List<IngestedImage> = emptyList(),
        sizeBytes: Long = 1_000,
    ) = IngestedFile(
        fileName = name,
        uri = "content://test/$name",
        kind = com.aiagent.mobile.domain.model.FileKind.TEXT,
        mimeType = "text/plain",
        sizeBytes = sizeBytes,
        text = text,
        images = images,
        note = note,
    )

    @Test
    fun `bo'sh ro'yxat bo'sh kontekst qaytaradi`() {
        val result = FileContextBuilder.build(emptyList(), availableTokens = 1000)

        assertEquals("", result.text)
        assertTrue(result.images.isEmpty())
        assertTrue(result.warnings.isEmpty())
    }

    @Test
    fun `fayl nomi va turi kontekst blokida ko'rinadi`() {
        val result = FileContextBuilder.build(
            files = listOf(file("Main.kt", "fun main() {}")),
            availableTokens = 5_000,
        )

        assertTrue(result.text.contains("Main.kt"))
        assertTrue(result.text.contains("fun main() {}"))
    }

    @Test
    fun `kesilgan fayl haqida ANIQ ogohlantirish qaytariladi`() {
        val longText = "so'z ".repeat(5_000)

        val result = FileContextBuilder.build(
            files = listOf(file("Big.log", longText, sizeBytes = 12_000_000)),
            availableTokens = 500,
        )

        assertTrue("Kesish yashirin bo'lmasligi kerak", result.warnings.isNotEmpty())
        assertTrue(result.warnings.first().contains("Big.log"))
    }

    @Test
    fun `fayl izohi (note) ham matnga, ham ogohlantirishga qo'shiladi`() {
        val result = FileContextBuilder.build(
            files = listOf(
                file(
                    "app.apk",
                    text = null,
                    note = "Bu ikkilik fayl — faqat metadata yuborildi",
                ),
            ),
            availableTokens = 1_000,
        )

        assertTrue(result.text.contains("metadata"))
        assertTrue(result.warnings.any { it.contains("app.apk") })
    }

    @Test
    fun `rasmlar matn byudjetini egallamaydi`() {
        val result = FileContextBuilder.build(
            files = listOf(
                file(
                    "diagram.png",
                    text = null,
                    images = listOf(
                        IngestedImage(mimeType = "image/png", base64 = "AAA", label = "diagram.png"),
                    ),
                ),
            ),
            availableTokens = 10,
        )

        assertEquals(1, result.images.size)
    }

    @Test
    fun `bir nechta fayl bo'yicha byudjet bo'linadi`() {
        val longText = "so'z ".repeat(2_000)
        val files = listOf(file("A.txt", longText), file("B.txt", longText))

        val result = FileContextBuilder.build(files, availableTokens = 600)

        // Har ikkala fayl ham qisman bo'lsa ko'rinadi — bittasi butunlay tushib qolmaydi.
        assertTrue(result.text.contains("A.txt"))
        assertTrue(result.text.contains("B.txt"))
        assertTrue(result.warnings.size >= 1)
    }
}
