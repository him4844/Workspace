package com.aiagent.mobile.ui.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.agent.AgentState
import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.ui.agent.AgentPanel
import com.aiagent.mobile.ui.common.toDisplayText
import com.aiagent.mobile.ui.diff.DiffPanel
import com.aiagent.mobile.ui.theme.CodeTextStyle

/**
 * Chat ekrani (Faza 3, 4-6 vazifalar).
 *
 * UI/UX talablari va javoblari:
 * - Bo'sh holat: "Suhbatni boshlang" + izoh.
 * - Yuklanish: fayllar o'qilayotganda va javob kutilayotganda aniq indikator.
 * - Xato: alohida xato kartasi + "Qayta urinish" (xato turi bo'yicha tushunarli matn).
 * - Kod bloklari monospace shriftda (`CodeTextStyle`), sintaksis ranglashsiz.
 * - Biriktirilgan fayllar ko'rinadi va o'chirish mumkin; kesish haqida ogohlantirish bor.
 * - Yuborish tugmasi 48dp; xabar bo'sh bo'lsa o'chirilgan.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    attachedFileUris: List<String>,
    workspaceId: String,
    onNavigateBack: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: ChatViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val agent by viewModel.agentUi.collectAsStateWithLifecycle()
    // Diff ekrani `ALWAYS_CONFIRM` rejimida ochiladi va agent shu paytda kutadi.
    // Kuzatiladigan holatdan o'qiladi — aks holda Compose qayta chizishni bilmaydi.
    val pendingEdit = agent.pendingEdit

    LaunchedEffect(attachedFileUris) {
        if (attachedFileUris.isNotEmpty()) viewModel.attachFiles(attachedFileUris)
    }

    // Agent tool'lari workspace ildizini bilishi shart — ekran ochilganda bog'lanadi.
    LaunchedEffect(workspaceId) { viewModel.bindWorkspace(workspaceId) }

    val listState = rememberLazyListState()
    LaunchedEffect(state.messages.size, state.contextWarnings.size, state.isSending) {
        val itemCount = state.contextWarnings.size + state.messages.size +
            (if (state.isSending) 1 else 0)
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.chat_title))
                        state.activeProvider?.let { provider ->
                            Text(
                                text = provider.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        modifier = Modifier.size(48.dp),
                        onClick = onNavigateBack,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = stringResource(R.string.common_back),
                        )
                    }
                },
            )
        },
        bottomBar = {
            ChatInputBar(
                state = state,
                agent = agent,
                onInputChange = viewModel::onInputChange,
                onSend = viewModel::send,
                onRemoveAttachment = viewModel::removeAttachment,
                onToggleAgentMode = viewModel::toggleAgentMode,
                onUndo = viewModel::undoLastEdit,
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            when {
                state.isLoadingProvider -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                )

                state.activeProvider == null -> NoProviderState(
                    onOpenSettings = onOpenSettings,
                    modifier = Modifier.align(Alignment.Center),
                )

                state.messages.isEmpty() && state.attachedFiles.isEmpty() -> EmptyChat(
                    modifier = Modifier.align(Alignment.Center),
                )

                else -> LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(state.contextWarnings) { warning ->
                        WarningCard(warning)
                    }
                    items(state.messages, key = ChatUiMessage::id) { message ->
                        MessageBubble(
                            message = message,
                            error = state.error,
                            onRetry = viewModel::retry,
                        )
                    }
                    // Faza 4: agent qadamlari suhbat oqimining oxirida ko'rinadi.
                    if (agent.isAgentMode && agent.steps.isNotEmpty()) {
                        item {
                            AgentPanel(
                                agentState = agent.agentState,
                                steps = agent.steps,
                                onStop = viewModel::stopAgent,
                            )
                        }
                    }
                    // Agent rejimida yuklanish indikatori AgentPanel'ning o'zida bor.
                    if (state.isSending && !agent.isAgentMode) {
                        item { ThinkingRow() }
                    }
                }
            }
        }
    }

    pendingEdit?.let { edit ->
        DiffPanel(
            edit = edit,
            onAccept = viewModel::approveEdit,
            onReject = viewModel::rejectEdit,
            // Yopish = rad etish: agent "rad etildi" deb bilishi kerak, aks holda
            // sikl hech qanday natija olmagan holda osilib qoladi.
            onDismiss = viewModel::rejectEdit,
        )
    }
}

@Composable
private fun NoProviderState(onOpenSettings: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_settings),
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.chat_no_provider_title),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.chat_no_provider_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        Button(modifier = Modifier.height(48.dp), onClick = onOpenSettings) {
            Text(stringResource(R.string.chat_open_settings))
        }
    }
}

@Composable
private fun EmptyChat(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(R.string.chat_empty_title),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.chat_empty_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ChatInputBar(
    state: ChatUiState,
    agent: AgentChatUi,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onToggleAgentMode: () -> Unit,
    onUndo: () -> Unit,
) {
    Column(modifier = Modifier.imePadding()) {
        // Workspace bo'lmasa agent rejimi umuman ko'rsatilmaydi (oddiy chat ishlaydi).
        if (agent.available) {
            AgentModeRow(
                agent = agent,
                onToggle = onToggleAgentMode,
                onUndo = onUndo,
            )
        }
        if (state.attachedFiles.isNotEmpty() || state.isPreparingFiles) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        painter = painterResource(R.drawable.ic_attach_file),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(
                            R.string.chat_attached_files,
                            state.attachedFiles.size,
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(6.dp))
                // Fayllar gorizontal aylanadigan qatorda — ko'p fayl ham joylashadi.
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.attachedFiles, key = AttachedFileUi::uri) { file ->
                        InputChip(
                            selected = false,
                            onClick = { onRemoveAttachment(file.uri) },
                            label = { Text(file.fileName, maxLines = 1) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(
                                        if (file.hasImages) R.drawable.ic_image
                                        else R.drawable.ic_file_text,
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                )
                            },
                            // Biriktirilgan faylni olib tashlash — chip ustidagi ×.
                            trailingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.ic_close),
                                    contentDescription = stringResource(R.string.common_delete),
                                    modifier = Modifier.size(18.dp),
                                )
                            },
                        )
                    }
                    // `LazyListScope` @Composable EMAS — shuning uchun `item { }` ichida.
                    if (state.isPreparingFiles) {
                        item {
                            Text(
                                text = stringResource(R.string.chat_files_preparing),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                state.attachedFiles.firstOrNull { it.note != null }?.let { file ->
                    // Kesish/o'qib bo'lmagan holat ANIQ ko'rsatiladi — yashirin emas.
                    Text(
                        text = "${file.fileName}: ${file.note}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.tertiary,
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = state.input,
                onValueChange = onInputChange,
                placeholder = { Text(stringResource(R.string.chat_input_hint)) },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp, max = 96.dp),
                maxLines = 4,
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                modifier = Modifier.size(48.dp),
                onClick = onSend,
                enabled = state.input.isNotBlank() && !state.isSending,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_send),
                    contentDescription = stringResource(R.string.chat_send),
                )
            }
        }
    }
}
