package com.aiagent.mobile.ui.files

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.ui.common.Formatters
import com.aiagent.mobile.ui.theme.CodeTextStyle

/**
 * Matn faylini ko'rsatadigan bottom sheet (Faza 2, 6-vazifa).
 * Matn monospace uslubida; ikkilik/juda katta/xato holatlari alohida xabarga ega.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilePreviewSheet(
    state: PreviewUiState,
    onDismiss: () -> Unit,
    onCopied: (String) -> Unit,
) {
    val clipboard = LocalClipboardManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
        ) {
            Text(
                text = state.fileName,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
            )
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(Modifier.height(12.dp))

            when {
                state.isLoading -> PreviewLoading()
                else -> when (val content = state.content) {
                    is FileContent.Text -> PreviewText(
                        text = content.content,
                        truncated = content.truncated,
                        onCopy = {
                            clipboard.setText(AnnotatedString(content.content))
                            onCopied("Nusxa olindi")
                        },
                    )

                    is FileContent.Binary -> PreviewNotice(
                        icon = R.drawable.ic_file_text,
                        message = stringResource(R.string.files_preview_binary),
                    )

                    // Faza 3: FileContent'ga rasm va arxiv turlari qo'shildi,
                    // shuning uchun `when` ni to'ldirish shart (aks holda compile xatosi).
                    is FileContent.Image -> PreviewNotice(
                        icon = R.drawable.ic_image,
                        message = stringResource(R.string.files_preview_image),
                    )

                    is FileContent.Archive -> PreviewNotice(
                        icon = R.drawable.ic_folder,
                        message = stringResource(
                            R.string.files_preview_archive,
                            content.entries.size,
                        ),
                    )

                    // Faza 3 dan TooLarge faqat rasmlar uchun qoldi (matn kesiladi).
                    is FileContent.TooLarge -> PreviewNotice(
                        icon = R.drawable.ic_warning,
                        message = stringResource(
                            R.string.files_preview_too_large,
                            Formatters.fileSize(content.sizeBytes),
                            Formatters.fileSize(content.maxBytes),
                        ),
                    )

                    is FileContent.Failed -> PreviewNotice(
                        icon = R.drawable.ic_warning,
                        message = content.reason,
                    )

                    null -> PreviewNotice(
                        icon = R.drawable.ic_warning,
                        message = stringResource(R.string.files_preview_failed),
                    )
                }
            }
        }
    }
}

@Composable
private fun PreviewLoading() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        Spacer(Modifier.size(12.dp))
        Text(
            text = stringResource(R.string.files_preview_loading),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun PreviewText(text: String, truncated: Boolean, onCopy: () -> Unit) {
    Column {
        if (truncated) {
            Text(
                text = stringResource(R.string.files_preview_truncated),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.tertiary,
            )
            Spacer(Modifier.height(8.dp))
        }
        Text(
            text = text.ifBlank { stringResource(R.string.files_preview_empty) },
            style = CodeTextStyle,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp)
                .verticalScroll(rememberScrollState()),
        )
        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            modifier = Modifier.height(48.dp),
            onClick = onCopy,
        ) {
            Icon(painterResource(R.drawable.ic_content_copy), contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.files_preview_copy))
        }
    }
}

@Composable
private fun PreviewNotice(icon: Int, message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.size(12.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
