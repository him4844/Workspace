package com.aiagent.mobile.domain.model

/**
 * AI taklif qilgan bitta fayl o'zgartirishi.
 *
 * [originalContent] patch'ni qo'llashdan oldin checksum/conflict tekshiruvi uchun kerak:
 * fayl AI o'qiganidan keyin tashqaridan o'zgargan bo'lsa, Faza 4 da conflict ko'rsatiladi.
 */
data class ProposedEdit(
    val filePath: String,
    val originalContent: String,
    val newContent: String,
    val status: EditStatus,
)

/**
 * O'zgartirish holati.
 * - `PENDING` — hali foydalanuvchi qarori yo'q
 * - `ACCEPTED` / `REJECTED` — foydalanuvchi diff ekranida qaror qabul qildi
 * - `APPLIED` — faylga haqiqatan yozildi (`AUTO_APPLY` rejimida ham shu holat)
 */
enum class EditStatus { PENDING, ACCEPTED, REJECTED, APPLIED }
