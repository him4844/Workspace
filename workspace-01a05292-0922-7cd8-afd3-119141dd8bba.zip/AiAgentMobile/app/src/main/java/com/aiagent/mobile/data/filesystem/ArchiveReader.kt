package com.aiagent.mobile.data.filesystem

import android.content.ContentResolver
import android.net.Uri
import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileKind
import com.aiagent.mobile.domain.model.FileKindClassifier
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.zip.ZipInputStream

/**
 * ZIP oilasidagi arxivlarni o'qish (Faza 3).
 *
 * Nima uchun `java.util.zip`: Android platformasining bir qismi, shuning uchun
 * YANGI KUTUBXONA talab qilinmaydi (foydalanuvchi sharti: nol yangi kutubxona).
 * ZIP, JAR, AAR va APK fayllari bir xil ZIP konteyner formatida — shuning uchun
 * bitta o'quvchi barchasini qoplaydi.
 *
 * Cheklovlar ataylab bor: minglab yozuvli arxiv kontekst oynasini yeb qo'ymasligi
 * kerak. Kesilgan holat natijada aniq ko'rsatiladi.
 */
internal class ArchiveReader(private val resolver: ContentResolver) {

    /** Arxiv yozuvlari ro'yxati (hajmi bilan). */
    fun listEntries(uri: Uri, maxEntries: Int): FileContent {
        val entries = mutableListOf<com.aiagent.mobile.domain.model.ArchiveEntry>()
        var overflow = false
        try {
            openZip(uri)?.use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entries.size >= maxEntries) {
                        overflow = true
                        break
                    }
                    entries += com.aiagent.mobile.domain.model.ArchiveEntry(
                        path = entry.name,
                        // ZIP oqimida hajm ba'zan -1 (streaming yozilgan arxivlar).
                        sizeBytes = entry.size.coerceAtLeast(-1),
                        isDirectory = entry.isDirectory,
                    )
                    zip.closeEntry()
                }
            } ?: return FileContent.Failed(reason = "Arxiv ochilmadi yoki ruxsat yo'q")
        } catch (exception: IOException) {
            return FileContent.Failed(reason = "Arxivni o'qib bo'lmadi: ${exception.message}")
        }

        if (overflow) {
            entries += com.aiagent.mobile.domain.model.ArchiveEntry(
                path = "... (ro'yxat $maxEntries ta yozuvda to'xtatildi)",
                sizeBytes = -1,
                isDirectory = false,
            )
        }
        return FileContent.Archive(entries = entries)
    }

    /**
     * Arxivdagi matnli yozuvlarni o'qib bitta matnga birlashtiradi.
     * Ikkilik yozuvlar o'tkazib yuboriladi, lekin ro'yxatda ko'rinadi.
     */
    fun readTextEntries(uri: Uri, maxEntries: Int, maxBytesPerEntry: Int): FileContent {
        val builder = StringBuilder()
        var readCount = 0
        var truncated = false
        try {
            openZip(uri)?.use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory) {
                        zip.closeEntry()
                        continue
                    }
                    if (readCount >= maxEntries) {
                        truncated = true
                        break
                    }
                    val kind = FileKindClassifier.classify(mimeType = null, fileName = entry.name)
                    if (kind != FileKind.TEXT) {
                        zip.closeEntry()
                        continue
                    }

                    val bytes = readAtMost(zip, maxBytesPerEntry)
                    val entryTruncated = bytes.size >= maxBytesPerEntry
                    builder.append("\n### ${entry.name}\n")
                    builder.append(String(bytes, Charsets.UTF_8))
                    if (entryTruncated) {
                        truncated = true
                        builder.append("\n[... yozuv kesildi, $maxBytesPerEntry baytdan ko'pi o'qilmadi]")
                    }
                    readCount++
                    zip.closeEntry()
                }
            } ?: return FileContent.Failed(reason = "Arxiv ochilmadi yoki ruxsat yo'q")
        } catch (exception: IOException) {
            return FileContent.Failed(reason = "Arxiv yozuvlarini o'qib bo'lmadi: ${exception.message}")
        }

        return FileContent.Text(
            content = builder.toString().trim(),
            truncated = truncated,
            totalBytes = builder.length.toLong(),
        )
    }

    private fun openZip(uri: Uri): ZipInputStream? {
        val input = runCatching { resolver.openInputStream(uri) }.getOrNull() ?: return null
        return ZipInputStream(input)
    }

    /** Oqimdan ko'pi bilan [limit] bayt o'qiydi (`readNBytes` API 33+, minSdk 30). */
    private fun readAtMost(stream: java.io.InputStream, limit: Int): ByteArray {
        val accumulator = ByteArrayOutputStream()
        val buffer = ByteArray(BUFFER_BYTES)
        var total = 0
        while (total < limit) {
            val read = stream.read(buffer, 0, minOf(buffer.size, limit - total))
            if (read <= 0) break
            accumulator.write(buffer, 0, read)
            total += read
        }
        return accumulator.toByteArray()
    }

    private companion object {
        const val BUFFER_BYTES = 8 * 1024
    }
}
