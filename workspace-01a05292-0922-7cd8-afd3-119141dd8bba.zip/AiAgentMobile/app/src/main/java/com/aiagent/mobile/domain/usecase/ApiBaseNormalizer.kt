package com.aiagent.mobile.domain.usecase

/**
 * Foydalanuvchi kiritgan `apiBase` ni Retrofit uchun yaroqli holatga keltirish.
 *
 * Retrofit `baseUrl` oxiri `/` bilan tugashi shart, aks holda `IllegalArgumentException`.
 * Foydalanuvchilar esa `https://api.deepseek.com/v1` (slash'siz) yoki
 * `https://api.deepseek.com/v1/` (slash'li) ko'rinishida yozadi — ikkalasi ham ishlashi kerak.
 */
object ApiBaseNormalizer {

    /** Normallashtirilgan base URL yoki `null` (manzil yaroqsiz bo'lsa). */
    fun normalize(rawApiBase: String): String? {
        val trimmed = rawApiBase.trim()
        if (trimmed.isEmpty()) return null
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) return null

        val withoutTrailingSlash = trimmed.trimEnd('/')
        // "https://" dan boshqa hech narsa qolmagan bo'lsa (masalan "https://") — yaroqsiz.
        val hostPart = trimmed.substringAfter("://", "")
        if (hostPart.isBlank()) return null

        return "$withoutTrailingSlash/"
    }
}
