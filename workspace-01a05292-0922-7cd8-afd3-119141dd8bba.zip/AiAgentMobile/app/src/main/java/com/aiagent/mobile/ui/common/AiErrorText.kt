package com.aiagent.mobile.ui.common

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.model.AiError

/**
 * [AiError] ni foydalogi uchun tushunarli matnga aylantirish (Faza 3, 5-vazifa).
 *
 * Talab: tarmoq yo'q, 401, 429 va timeout holatlari ALOHIDA va texnik jargonsiz
 * bo'lishi kerak. Domen qatlami resurslarni bilmaydi — shuning uchun tarjima
 * faqat shu yerda, UI qatlamida amalga oshiriladi.
 */

/** Xato matni (tekshiruv uchun: `stringResource` chaqiruvi Compose kontekstida). */
@Composable
fun AiError.toDisplayText(): String = stringResource(id = messageRes(), formatArgs())

/** Xato turi bo'yicha string resurs. */
@StringRes
fun AiError.messageRes(): Int = when (this) {
    AiError.NoNetwork -> R.string.ai_error_no_network
    AiError.Timeout -> R.string.ai_error_timeout
    AiError.Unauthorized -> R.string.ai_error_unauthorized
    AiError.RateLimited -> R.string.ai_error_rate_limited
    is AiError.Server -> R.string.ai_error_server
    is AiError.InvalidResponse -> R.string.ai_error_invalid_response
    is AiError.InvalidConfig -> R.string.ai_error_invalid_config
    is AiError.VisionUnsupported -> R.string.ai_error_vision
    is AiError.Unknown -> R.string.ai_error_unknown
}

/**
 * Format argumentlari. Eslatma: `%d` o'rniga `%1$d` ishlatilgani uchun argument
 * soni har doim aniq mos kelishi kerak, aks holda Android runtime exception beradi.
 */
fun AiError.formatArgs(): Array<Any> = when (this) {
    is AiError.Server -> arrayOf(code, detail ?: "server javob bermadi")
    is AiError.InvalidResponse -> arrayOf(detail ?: "javob formati noma'lum")
    is AiError.InvalidConfig -> arrayOf(detail)
    is AiError.Unknown -> arrayOf(detail ?: "sabab aniqlanmadi")
    // Qolgan turlar argument talab qilmaydi.
    AiError.NoNetwork,
    AiError.Timeout,
    AiError.Unauthorized,
    AiError.RateLimited,
    is AiError.VisionUnsupported,
    -> emptyArray()
}
