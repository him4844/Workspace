package com.aiagent.mobile.domain.model

/**
 * Fayl daraxtining bitta tuguni (Faza 2 dagi `FileTreeScreen` uchun).
 *
 * [children] faqat papka ochildanida to'ldiriladi (lazy) — butun daraxtni
 * birdan o'qish katta loyihalarda sekin va xotira uchun xavfli.
 * [uri] — SAF hujjat URI'si; [name] — foydalanuvchiga ko'rsatiladigan nom.
 */
data class FileNode(
    val name: String,
    val uri: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val mimeType: String?,
    val children: List<FileNode> = emptyList(),
)
