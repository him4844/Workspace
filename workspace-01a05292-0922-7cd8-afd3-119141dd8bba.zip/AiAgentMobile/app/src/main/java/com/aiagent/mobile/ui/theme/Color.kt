package com.aiagent.mobile.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Dinamik rang (Android 12+) mavjud bo'lmagan qurilmalar uchun zaxira palitra.
 * Material 3 tonal palitrasiga mos, kod muharriri kontekstiga moslashtirilgan.
 */
internal val PrimaryLight = Color(0xFF3F51B5)
internal val OnPrimaryLight = Color(0xFFFFFFFF)
internal val PrimaryContainerLight = Color(0xFFDDE1FF)
internal val OnPrimaryContainerLight = Color(0xFF00105C)

internal val SecondaryLight = Color(0xFF00696E)
internal val OnSecondaryLight = Color(0xFFFFFFFF)
internal val SecondaryContainerLight = Color(0xFF6FF6FE)
internal val OnSecondaryContainerLight = Color(0xFF002022)

internal val BackgroundLight = Color(0xFFFBF8FF)
internal val SurfaceLight = Color(0xFFFBF8FF)
internal val OnBackgroundLight = Color(0xFF1B1B21)
internal val OnSurfaceLight = Color(0xFF1B1B21)
internal val ErrorLight = Color(0xFFBA1A1A)
internal val OnErrorLight = Color(0xFFFFFFFF)
internal val OutlineLight = Color(0xFF767680)

internal val PrimaryDark = Color(0xFFBAC3FF)
internal val OnPrimaryDark = Color(0xFF08218A)
internal val PrimaryContainerDark = Color(0xFF263BA0)
internal val OnPrimaryContainerDark = Color(0xFFDDE1FF)

internal val SecondaryDark = Color(0xFF4CD9E2)
internal val OnSecondaryDark = Color(0xFF00373A)
internal val SecondaryContainerDark = Color(0xFF004F53)
internal val OnSecondaryContainerDark = Color(0xFF6FF6FE)

internal val BackgroundDark = Color(0xFF131318)
internal val SurfaceDark = Color(0xFF131318)
internal val OnBackgroundDark = Color(0xFFE4E1E9)
internal val OnSurfaceDark = Color(0xFFE4E1E9)
internal val ErrorDark = Color(0xFFFFB4AB)
internal val OnErrorDark = Color(0xFF690005)
internal val OutlineDark = Color(0xFF90909A)
