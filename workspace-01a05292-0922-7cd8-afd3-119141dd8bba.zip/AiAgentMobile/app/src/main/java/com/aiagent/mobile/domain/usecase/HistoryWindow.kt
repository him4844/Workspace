package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.AiRequestMessage

/**
 * Suhbat tarixini kontekst byudjetiga sig'adigan qismgacha qisqartirish — sof mantiq.
 *
 * Nima uchun kerak: har bir xabarda butun tarixni yuborish kontekst oynasini
 * tez to'ldiradi (ayniqsa fayl konteksti biriktirilganda). Eng ESKI xabarlar
 * tashlanadi, chunki oxirgi savol-javoblar agent uchun muhimroq.
 */
object HistoryWindow {

    /**
     * [tokenBudget] ga sig'adigan eng oxirgi xabarlarni qaytaradi (tartib saqlanadi).
     * Hech bo'lmaganda oxirgi xabar har doim qaytariladi — aks holda so'rov bo'sh
     * ketadi va provider xato beradi.
     */
    fun fit(messages: List<AiRequestMessage>, tokenBudget: Int): List<AiRequestMessage> {
        if (messages.isEmpty()) return emptyList()
        if (tokenBudget <= 0) return listOf(messages.last())

        val selected = ArrayList<AiRequestMessage>()
        var used = 0
        for (index in messages.indices.reversed()) {
            val cost = TokenEstimator.estimateTokens(messages[index].content)
            if (used + cost > tokenBudget && selected.isNotEmpty()) break
            selected += messages[index]
            used += cost
        }
        selected.reverse()
        return selected
    }
}
