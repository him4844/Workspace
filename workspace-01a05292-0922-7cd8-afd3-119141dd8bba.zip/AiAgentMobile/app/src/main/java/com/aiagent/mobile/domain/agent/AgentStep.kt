package com.aiagent.mobile.domain.agent

/**
 * Agent siklining bitta qadami — UI shu ro'yxatni ko'rsatadi (Faza 4, 5-6 vazifalar).
 *
 * Nima uchun alohida model kerak: foydalanuvchi "agent nima qilyapti" ni ko'rishi
 * shart. Qora quti (so'rov yuborildi → javob keldi) ishonch bermaydi va xato
 * bo'lganda sababini tushunib bo'lmaydi.
 */
data class AgentStep(
    val id: String,
    val kind: AgentStepKind,
    val title: String,
    val detail: String? = null,
    val isSuccess: Boolean? = null,
    val timestamp: Long,
)

enum class AgentStepKind {
    /** AI'ga so'rov yuborildi. */
    REQUEST,

    /** AI javob berdi (tool chaqiruvisiz — oddiy javob). */
    RESPONSE,

    /** Tool chaqirildi. */
    TOOL_CALL,

    /** Tool natijasi. */
    TOOL_RESULT,

    /** Foydalanuvchi tasdig'i kutilmoqda (diff ekrani). */
    AWAITING_APPROVAL,

    /** Cheklov buzildi yoki sikl xato bilan to'xtadi. */
    LIMIT,
}
