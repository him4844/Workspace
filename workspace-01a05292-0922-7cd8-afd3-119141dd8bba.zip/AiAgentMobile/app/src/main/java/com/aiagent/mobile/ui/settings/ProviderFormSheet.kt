package com.aiagent.mobile.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.model.ProviderType
import com.aiagent.mobile.ui.common.toDisplayText
import java.util.Locale

/**
 * Provider qo'shish/tahrirlash formasi (Faza 3, 1-vazifa).
 *
 * Spetsifikatsiya talablari va ularning bajarilishi:
 * - Nom, Tur (dropdown), API manzil, API kalit, Model, Maks. tokenlar,
 *   Temperature (slayder + joriy qiymat), Kontekst uzunligi — barchasi bor.
 * - Tur tanlanganda API manzil avtomatik to'ldiriladi (maydon baribir tahrirlanadigan).
 * - API kalit standart holda YASHIRIN, 👁 tugmasi bilan ochiladi.
 * - Bo'sh API kalit YUBORISHDAN OLDIN to'xtatiladi va "API kalit talab qilinadi"
 *   xabari maydon ostida ko'rinadi (snackbar kutish shart emas).
 * - "Test qilish" tugmasi yuklanish indikatorisiz ishlamaydi.
 * - Barcha teginish maydonlari ≥ 48dp.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProviderFormSheet(
    form: ProviderFormState,
    isTesting: Boolean,
    testResult: TestOutcome?,
    onDismiss: () -> Unit,
    onNameChange: (String) -> Unit,
    onTypeChange: (ProviderType) -> Unit,
    onApiBaseChange: (String) -> Unit,
    onApiKeyChange: (String) -> Unit,
    onModelChange: (String) -> Unit,
    onMaxTokensChange: (String) -> Unit,
    onContextLengthChange: (String) -> Unit,
    onTemperatureChange: (Float) -> Unit,
    onMakeActiveChange: (Boolean) -> Unit,
    onTest: () -> Unit,
    onSave: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 640.dp)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
        ) {
            Text(
                text = stringResource(
                    if (form.id.isBlank()) R.string.provider_form_new_title
                    else R.string.provider_form_edit_title,
                ),
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = form.name,
                onValueChange = onNameChange,
                label = { Text(stringResource(R.string.provider_field_name)) },
                singleLine = true,
                isError = form.nameError,
                supportingText = errorText(form.nameError, R.string.provider_error_name),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))

            TypeDropdown(selected = form.type, onSelect = onTypeChange)
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = form.apiBase,
                onValueChange = onApiBaseChange,
                label = { Text(stringResource(R.string.provider_field_api_base)) },
                singleLine = true,
                isError = form.apiBaseError,
                supportingText = errorText(form.apiBaseError, R.string.provider_error_api_base),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))

            ApiKeyField(
                value = form.apiKey,
                isError = form.apiKeyError,
                storedKeyPresent = form.storedKeyPresent,
                onValueChange = onApiKeyChange,
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = form.model,
                onValueChange = onModelChange,
                label = { Text(stringResource(R.string.provider_field_model)) },
                singleLine = true,
                isError = form.modelError,
                supportingText = errorText(form.modelError, R.string.provider_error_model),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = form.maxTokens,
                onValueChange = onMaxTokensChange,
                label = { Text(stringResource(R.string.provider_field_max_tokens)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = form.numberError,
                supportingText = errorText(
                    form.numberError,
                    R.string.provider_error_number,
                    stringResource(R.string.provider_field_max_tokens),
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))

            TemperatureField(value = form.temperature, onValueChange = onTemperatureChange)
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = form.contextLength,
                onValueChange = onContextLengthChange,
                label = { Text(stringResource(R.string.provider_field_context_length)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = form.numberError,
                supportingText = errorText(
                    form.numberError,
                    R.string.provider_error_number,
                    stringResource(R.string.provider_field_context_length),
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.provider_field_make_active),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = form.makeActive, onCheckedChange = onMakeActiveChange)
            }
            Spacer(Modifier.height(16.dp))

            OutlinedButton(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                onClick = onTest,
                enabled = !isTesting,
            ) {
                if (isTesting) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.provider_testing))
                } else {
                    Text(stringResource(R.string.provider_test))
                }
            }
            // Test natijasi: ✅ yoki ❌ + sabab. Yuklanish holati yuqoridagi
            // tugmada (spinner) ko'rsatiladi — spetsifikatsiya talabi.
            testResult?.let { outcome ->
                Spacer(Modifier.height(8.dp))
                TestResultRow(outcome)
            }
            Spacer(Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(modifier = Modifier.height(48.dp), onClick = onDismiss) {
                    Text(stringResource(R.string.common_cancel))
                }
                Spacer(Modifier.width(8.dp))
                Button(modifier = Modifier.height(48.dp), onClick = onSave) {
                    Text(stringResource(R.string.common_save))
                }
            }
        }
    }
}

@Composable
private fun TestResultRow(outcome: TestOutcome) {
    val success = outcome is TestOutcome.Success
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            painter = painterResource(
                if (success) R.drawable.ic_check_circle else R.drawable.ic_error_circle,
            ),
            contentDescription = null,
            tint = if (success) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.error,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = if (success) {
                stringResource(R.string.provider_test_success)
            } else {
                (outcome as TestOutcome.Failed).error.toDisplayText()
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (success) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.error,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TypeDropdown(selected: ProviderType, onSelect: (ProviderType) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
    ) {
        OutlinedTextField(
            value = providerTypeName(selected),
            onValueChange = {},
            readOnly = true,
            label = { Text(stringResource(R.string.provider_field_type)) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                // material3 1.4.0: `menuAnchor()` (parametrsiz) eskirgan — yangi
                // `ExposedDropdownMenuAnchorType` API'si ishlatiladi.
                .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            ProviderType.entries.forEach { type ->
                DropdownMenuItem(
                    text = { Text(providerTypeName(type)) },
                    onClick = {
                        onSelect(type)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
private fun ApiKeyField(
    value: String,
    isError: Boolean,
    storedKeyPresent: Boolean,
    onValueChange: (String) -> Unit,
) {
    // Standart holat: yashirin. Ko'z tugmasi bosilganda ochiladi.
    var visible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(stringResource(R.string.provider_field_api_key)) },
        singleLine = true,
        isError = isError,
        visualTransformation = if (visible) {
            VisualTransformation.None
        } else {
            PasswordVisualTransformation()
        },
        trailingIcon = {
            IconButton(
                modifier = Modifier.size(48.dp),
                onClick = { visible = !visible },
            ) {
                Icon(
                    painter = painterResource(
                        if (visible) R.drawable.ic_visibility_off else R.drawable.ic_visibility,
                    ),
                    contentDescription = stringResource(
                        if (visible) R.string.provider_hide_key else R.string.provider_show_key,
                    ),
                )
            }
        },
        supportingText = {
            Text(
                when {
                    isError -> stringResource(R.string.provider_error_api_key)
                    storedKeyPresent -> stringResource(R.string.provider_key_unchanged)
                    else -> stringResource(R.string.provider_key_hint)
                },
                color = if (isError) MaterialTheme.colorScheme.error else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
        },
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun TemperatureField(value: Float, onValueChange: (Float) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.provider_field_temperature),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
            )
            // Joriy qiymat har doim ko'rinadi (spetsifikatsiya talabi).
            Text(
                text = String.format(Locale.US, "%.1f", value),
                style = MaterialTheme.typography.titleMedium,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..2f,
            steps = TEMPERATURE_STEPS,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun errorText(show: Boolean, resId: Int, arg: String? = null): (@Composable () -> Unit)? =
    if (!show) {
        null
    } else {
        {
            Text(
                text = if (arg == null) stringResource(resId) else stringResource(resId, arg),
                color = MaterialTheme.colorScheme.error,
            )
        }
    }

private const val TEMPERATURE_STEPS = 19 // 0.0 dan 2.0 gacha, 0.1 qadam bilan
