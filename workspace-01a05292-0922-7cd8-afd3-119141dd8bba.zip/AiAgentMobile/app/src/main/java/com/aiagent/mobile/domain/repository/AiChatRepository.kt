package com.aiagent.mobile.domain.repository

import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.tools.ToolSpec

/**
 * AI provider bilan ishlash abstraksiyasi (Faza 3).
 *
 * Implementatsiya: `data/ai/AiChatRepositoryImpl` (Retrofit, OpenAI-mos
 * `/chat/completions`, streaming yo'q). Domen qatlami tarmoqni bilmaydi —
 * shuning uchun xato tasnifi (`AiError`) ham sof va test qilinadigan.
 */
interface AiChatRepository {

    /**
     * Suhbat so'rovi. [images] bo'sh bo'lmasa va provider multimodal bo'lsa,
     * xabar `content` qismi OpenAI vision formatida (matn + `image_url`) yuboriladi.
     *
     * Faza 4: [tools] bo'sh bo'lmasa so'rovga OpenAI function-calling sxemasi qo'shiladi
     * va javobda [com.aiagent.mobile.domain.model.AiResponse.toolCalls] kelishi mumkin.
     */
    suspend fun complete(
        provider: AiProvider,
        messages: List<AiRequestMessage>,
        images: List<IngestedImage> = emptyList(),
        tools: List<ToolSpec> = emptyList(),
    ): AiResult

    /**
     * "Test qilish" tugmasi uchun qisqa so'rov. `max_tokens = 1` —
     * pul va vaqt tejash uchun javob minimal bo'lishi yetarli.
     */
    suspend fun testConnection(provider: AiProvider): AiResult
}
