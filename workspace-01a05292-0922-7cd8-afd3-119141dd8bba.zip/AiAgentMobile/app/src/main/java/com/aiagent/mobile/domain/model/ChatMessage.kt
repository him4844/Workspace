package com.aiagent.mobile.domain.model

/**
 * Suhbatning bitta xabari (Faza 3 — oddiy chat, Faza 4 — agent tool natijalari).
 *
 * [attachedFiles] — foydalanuvchi biriktirgan fayllarning workspace'ga nisbatan yo'li.
 * [proposedEdits] — assistant taklif qilgan o'zgartirishlar; `ALWAYS_CONFIRM` rejimida
 * ular Faza 4 diff ekranida ko'rsatiladi.
 */
data class ChatMessage(
    val id: String,
    val role: MessageRole,
    val content: String,
    val attachedFiles: List<String> = emptyList(),
    val proposedEdits: List<ProposedEdit> = emptyList(),
    val timestamp: Long,
)

/**
 * Xabar roli.
 *
 * `TOOL` Faza 4 da qo'shildi: agent tool natijasini AI'ga qaytarishi kerak va
 * OpenAI sxemasida bu alohida rol (`role: "tool"` + `tool_call_id`).
 */
enum class MessageRole { USER, ASSISTANT, SYSTEM, TOOL }
