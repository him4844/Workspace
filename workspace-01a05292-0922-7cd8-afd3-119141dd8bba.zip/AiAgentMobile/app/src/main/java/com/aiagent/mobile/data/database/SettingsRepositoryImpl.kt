package com.aiagent.mobile.data.database

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aiagent.mobile.data.security.KeyEncryptor
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AppSettings
import com.aiagent.mobile.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "settings",
)

/**
 * Provider va ilova sozlamalari (Faza 3).
 *
 * QAROR: `EncryptedSharedPreferences` o'rniga DataStore + Android Keystore.
 * `androidx.security:security-crypto` deprecated; Keystore esa platformaning o'zi
 * va kalitni diskka hech qachon ochiq tushirmaydi. Tafsilot: `data/security/KeyEncryptor`.
 *
 * Buzilgan JSON holatida ro'yxat bo'sh deb hisoblanadi (Faza 2 dagi kabi) — ilova
 * crash bo'lmaydi, foydalanuvchi provider'ni qayta kiritadi.
 */
@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val keyEncryptor: KeyEncryptor,
) : SettingsRepository {

    private val json = Json { ignoreUnknownKeys = true }

    override val providers: Flow<List<AiProvider>> =
        context.settingsDataStore.data
            .catch { throwable ->
                if (throwable is IOException) emit(emptyPreferences()) else throw throwable
            }
            .map { preferences -> decodeProviders(preferences[KEY_PROVIDERS]) }

    override val settings: Flow<AppSettings> =
        context.settingsDataStore.data
            .catch { throwable ->
                if (throwable is IOException) emit(emptyPreferences()) else throw throwable
            }
            .map { preferences ->
                val activeId = decodeProviders(preferences[KEY_PROVIDERS]).firstActiveOrNull()?.id
                decodeSettings(preferences[KEY_SETTINGS]).toDomain(activeProviderId = activeId)
            }

    override suspend fun saveProvider(provider: AiProvider) {
        mutateProviders { current ->
            val isFirst = current.isEmpty()
            val previousActiveId = current.firstActiveOrNull()?.id
            // Birinchi provider avtomatik faol bo'ladi — aks holda foydalanuvchi
            // saqlagandan keyin ham "faol provider yo'q" xabarini ko'radi.
            val shouldBeActive = isFirst || provider.isDefault
            val prepared = provider.copy(isDefault = shouldBeActive)

            val index = current.indexOfFirst { it.id == provider.id }
            val updated = if (index >= 0) {
                current.toMutableList().also { list -> list[index] = prepared }
            } else {
                current + prepared
            }

            // Invariant: ro'yxat bo'sh bo'lmasa, faol provider AYNAN BITTA bo'ladi.
            // (Passiv provider saqlanganda avvalgi faol provider o'z kuchida qoladi.)
            val activeId = if (shouldBeActive) prepared.id else (previousActiveId ?: prepared.id)
            updated.map { it.copy(isDefault = it.id == activeId) }
        }
    }

    override suspend fun deleteProvider(providerId: String) {
        mutateProviders { current ->
            val remaining = current.filterNot { it.id == providerId }
            // O'chirilgan provider faol bo'lgan bo'lsa, faollikni birinchisiga o'tkazamiz.
            val needsNewActive = current.firstActiveOrNull()?.id == providerId
            if (needsNewActive && remaining.isNotEmpty()) {
                remaining.toMutableList().also { list ->
                    list[0] = list[0].copy(isDefault = true)
                }
            } else {
                remaining
            }
        }
    }

    override suspend fun setActiveProvider(providerId: String) {
        mutateProviders { current ->
            if (current.none { it.id == providerId }) {
                current
            } else {
                current.map { it.copy(isDefault = it.id == providerId) }
            }
        }
    }

    override suspend fun updateSettings(settings: AppSettings) {
        context.settingsDataStore.edit { preferences ->
            preferences[KEY_SETTINGS] = json.encodeToString(
                SettingsDto.serializer(),
                SettingsDto.fromDomain(settings),
            )
        }
    }

    override suspend fun activeProvider(): AiProvider? {
        val all = providers.first()
        return all.firstActiveOrNull()
    }

    /** Faol provider; hech biri belgilanmagan bo'lsa — ro'yxatdagi birinchi. */
    private fun List<AiProvider>.firstActiveOrNull(): AiProvider? =
        firstOrNull { it.isDefault } ?: firstOrNull()

    private suspend fun mutateProviders(transform: (List<AiProvider>) -> List<AiProvider>) {
        context.settingsDataStore.edit { preferences ->
            val current = decodeProviders(preferences[KEY_PROVIDERS])
            val updated = transform(current)
            preferences[KEY_PROVIDERS] = encodeProviders(updated)
        }
    }

    private fun decodeProviders(raw: String?): List<AiProvider> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            json.decodeFromString(ProviderListDto.serializer(), raw)
                .items
                .map { dto -> dto.toDomain(keyEncryptor::decrypt) }
        }.getOrElse { emptyList() }
    }

    private fun encodeProviders(providers: List<AiProvider>): String =
        json.encodeToString(
            ProviderListDto.serializer(),
            ProviderListDto(items = providers.map { ProviderDto.fromDomain(it, keyEncryptor::encrypt) }),
        )

    private fun decodeSettings(raw: String?): SettingsDto {
        if (raw.isNullOrBlank()) return SettingsDto()
        return runCatching {
            json.decodeFromString(SettingsDto.serializer(), raw)
        }.getOrElse { SettingsDto() }
    }

    private companion object {
        val KEY_PROVIDERS = stringPreferencesKey("provider_list_json")
        val KEY_SETTINGS = stringPreferencesKey("app_settings_json")
    }
}
