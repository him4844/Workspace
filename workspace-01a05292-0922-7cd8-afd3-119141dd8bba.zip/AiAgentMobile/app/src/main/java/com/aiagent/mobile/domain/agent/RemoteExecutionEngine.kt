package com.aiagent.mobile.domain.agent

/**
 * Colab tomonidagi ishlarni bajaradigan qatlam (Faza 5 da `ColabExecutionEngine`
 * nomi bilan haqiqiy implementatsiya yoziladi: Retrofit → FastAPI `/execute`, `/health`).
 *
 * Faza 1 da bu faqat interfeys — hech qanday tarmoq chaqiruvi yo'q.
 */
interface RemoteExecutionEngine {
    /** Colab serveri ulanishga tayyormi (Faza 5 da `/health` orqali tekshiriladi). */
    suspend fun isAvailable(): Boolean

    /**
     * Ulanishning BATAFSIL holati (Faza 5).
     *
     * Nima uchun [isAvailable] dan tashqari bu ham kerak: spetsifikatsiya har bir
     * holat uchun alohida, sababli xabar talab qiladi — "URL kiritilmagan",
     * "havola eskirgan" va "server xato qaytardi" bir xil "xatolik" emas.
     */
    suspend fun checkStatus(): ColabStatus

    /** Buyruqni Colab'da bajaradi va FAQAT natijani qaytaradi. */
    suspend fun executeTask(task: RemoteTask): RemoteTaskResult
}

/**
 * Colab'da bajariladigan bitta vazifa.
 * [workdir] — Drive'dagi loyiha papkasi (masalan `/content/drive/MyDrive/AiAgentWorkspace/`).
 * [timeoutMs] — standart 5 daqiqa; og'ir build'lar uchun yetarli.
 */
data class RemoteTask(
    val id: String,
    val command: String,
    val workdir: String,
    val timeoutMs: Long = 300_000,
)

/**
 * Colab javobi. **Faqat natija** qaytadi: oraliq fayllar, build artifaktlari yoki
 * boshqa katta ma'lumotlar Android'ga yuborilmaydi. Agar foydalanuvchiga fayl kerak
 * bo'lsa (masalan tayyor APK), [output] ichida Drive havolasi qaytariladi.
 */
data class RemoteTaskResult(
    val success: Boolean,
    val output: String,
    val errorMessage: String? = null,
)
