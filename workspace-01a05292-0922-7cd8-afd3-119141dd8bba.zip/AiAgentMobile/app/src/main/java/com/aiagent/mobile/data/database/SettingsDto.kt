package com.aiagent.mobile.data.database

import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AppSettings
import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.model.ExecutionPreference
import com.aiagent.mobile.domain.model.ProviderType
import kotlinx.serialization.Serializable

/**
 * DataStore'ga yoziladigan provider yozuvi (Faza 3).
 *
 * Muhim: [encryptedApiKey] — OCHIQ KALIT EMAS. U `KeyEncryptor` (Android Keystore
 * AES/GCM) orqali shifrlangan va `enc:v1:` prefiksiga ega. Domen modeliga esa
 * ochiq kalit qaytariladi, chunki uni HTTP `Authorization` sarlavhasiga qo'yish kerak.
 */
@Serializable
data class ProviderDto(
    val id: String,
    val name: String,
    val type: String,
    val apiBase: String,
    val encryptedApiKey: String,
    val model: String,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.2f,
    val contextLength: Int = 128000,
    val isDefault: Boolean = false,
) {
    /** [decryptKey] — shifrlangan qiymatni ochish uchun callback (data qatlami ichida). */
    fun toDomain(decryptKey: (String) -> String): AiProvider = AiProvider(
        id = id,
        name = name,
        type = type.toProviderType(),
        apiBase = apiBase,
        apiKey = decryptKey(encryptedApiKey),
        model = model,
        maxTokens = maxTokens,
        temperature = temperature,
        contextLength = contextLength,
        isDefault = isDefault,
    )

    companion object {
        fun fromDomain(provider: AiProvider, encryptKey: (String) -> String) = ProviderDto(
            id = provider.id,
            name = provider.name,
            type = provider.type.name,
            apiBase = provider.apiBase,
            encryptedApiKey = encryptKey(provider.apiKey),
            model = provider.model,
            maxTokens = provider.maxTokens,
            temperature = provider.temperature,
            contextLength = provider.contextLength,
            isDefault = provider.isDefault,
        )

        /**
         * Noma'lum tur nomi kelganda (masalan eski versiyadan) ilova crash bo'lmasligi
         * uchun `CUSTOM` ga qaytamiz — foydalanuvchi apiBase'ni o'zi ko'radi.
         */
        private fun String.toProviderType(): ProviderType =
            ProviderType.entries.firstOrNull { it.name == this } ?: ProviderType.CUSTOM
    }
}

@Serializable
data class ProviderListDto(val items: List<ProviderDto> = emptyList())

/**
 * Ilova sozlamalari yozuvi.
 *
 * `activeProviderId` BU YERDA saqlanmaydi: faol provider yagona manbadan —
 * provider ro'yxatidagi `isDefault` bayrog'idan olinadi. Ikki joyda saqlash
 * ziddiyat (birida A, ikkinchisida B faol) holatini keltirib chiqarardi.
 */
@Serializable
data class SettingsDto(
    val editMode: String = EditMode.ALWAYS_CONFIRM.name,
    val isDarkTheme: Boolean? = null,
    val maxFileContextSizeBytes: Int = 100_000,
    val executionPreference: String = ExecutionPreference.COLAB_PRIMARY.name,
    val colabUrl: String = "",
) {
    fun toDomain(activeProviderId: String?): AppSettings = AppSettings(
        activeProviderId = activeProviderId,
        editMode = EditMode.entries.firstOrNull { it.name == editMode } ?: EditMode.ALWAYS_CONFIRM,
        isDarkTheme = isDarkTheme,
        maxFileContextSizeBytes = maxFileContextSizeBytes,
        executionPreference = ExecutionPreference.entries.firstOrNull { it.name == executionPreference }
            ?: ExecutionPreference.COLAB_PRIMARY,
        colabUrl = colabUrl,
    )

    companion object {
        fun fromDomain(settings: AppSettings) = SettingsDto(
            editMode = settings.editMode.name,
            isDarkTheme = settings.isDarkTheme,
            maxFileContextSizeBytes = settings.maxFileContextSizeBytes,
            executionPreference = settings.executionPreference.name,
            colabUrl = settings.colabUrl,
        )
    }
}
