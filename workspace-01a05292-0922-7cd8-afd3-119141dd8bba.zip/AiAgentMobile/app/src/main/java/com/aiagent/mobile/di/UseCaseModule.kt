package com.aiagent.mobile.di

import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.usecase.IngestAttachmentUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Domen use-case'larini bog'lash (Faza 3).
 *
 * Nima uchun `@Provides` va `@Inject constructor` emas: domen qatlami Android va
 * Hilt'ga bog'liq bo'lmasligi kerak (qarang: `DomainPurityTest`). Shuning uchun
 * use-case'lar oddiy Kotlin klasslari bo'lib qoladi va bu modul ularni taqdim etadi.
 */
@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    @Provides
    @Singleton
    fun provideIngestAttachmentUseCase(
        documents: DocumentRepository,
    ): IngestAttachmentUseCase = IngestAttachmentUseCase(documents)
}
