package com.aiagent.mobile.data.filesystem

import android.content.ContentResolver
import android.content.Context
import androidx.core.net.toUri
import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.model.TextMatch
import com.aiagent.mobile.domain.model.FileKindClassifier
import com.aiagent.mobile.domain.model.FileKind
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

/**
 * Fayl nomlari va matn qidirish (Faza 4, 3-vazifa).
 *
 * Spetsifikatsiya: "hozircha oddiy string qidiruv, index yo'q". Shuning uchun
 * har qidiruvda papka daraxti aylanib chiqiladi — bu sekin, lekin sodda va
 * ishonchli. Room indeksi Faza 9 da qo'shiladi.
 *
 * Cheklovlar ataylab bor: [maxVisits] fayl ko'pi bilan ko'riladi, matn qidiruvda
 * [maxFileBytes] dan katta fayl o'qilmaydi — aks holda katta loyihada qidiruv
 * telefonda daqiqalab davom etadi va xotirani to'ldiradi.
 */
internal class SafSearcher(
    private val context: Context,
    private val writer: SafDocumentWriter,
) {

    private val resolver: ContentResolver get() = context.contentResolver

    /** Fayl NOMI bo'yicha qidiruv (katta/kichik harfdan qat'i nazar). */
    fun searchFiles(rootUri: String, query: String, maxResults: Int): List<FileNode> {
        val needle = query.lowercase()
        val results = mutableListOf<FileNode>()

        writer.walk(rootUri, maxVisits = MAX_VISITS) { node, path ->
            if (node.name.lowercase().contains(needle)) {
                results += node.copy(name = path)
            }
            results.size < maxResults
        }
        return results
    }

    /** Matn fayllari ichidan qidiruv — qator raqami bilan. */
    fun searchInFiles(
        rootUri: String,
        query: String,
        maxFiles: Int,
        maxMatchesPerFile: Int,
        maxFileBytes: Int,
    ): List<TextMatch> {
        val needle = query.lowercase()
        val results = mutableListOf<TextMatch>()
        var filesWithMatch = 0

        writer.walk(rootUri, maxVisits = MAX_VISITS) { node, path ->
            if (filesWithMatch >= maxFiles) return@walk false
            if (node.sizeBytes > maxFileBytes) return@walk true // katta faylni o'qimaymiz
            if (!isTextLike(node)) return@walk true

            val matches = findInFile(node.uri, needle, maxMatchesPerFile)
            if (matches.isNotEmpty()) {
                filesWithMatch++
                matches.forEach { (lineNumber, lineText) ->
                    results += TextMatch(path = path, lineNumber = lineNumber, lineText = lineText)
                }
            }
            filesWithMatch < maxFiles
        }
        return results
    }

    /**
     * Fayl matnli deb hisoblanadimi? MIME ishonchsiz bo'lishi mumkin, shuning uchun
     * Faza 3 dagi `FileKindClassifier` ishlatiladi (kengaytma bo'yicha ham tekshiradi).
     */
    private fun isTextLike(node: FileNode): Boolean =
        FileKindClassifier.classify(node.mimeType, node.name) == FileKind.TEXT

    /** @return (qator raqami, qator matni) juftliklari. */
    private fun findInFile(
        uriString: String,
        needle: String,
        maxMatches: Int,
    ): List<Pair<Int, String>> {
        val stream = runCatching { resolver.openInputStream(uriString.toUri()) }.getOrNull()
            ?: return emptyList()

        val found = mutableListOf<Pair<Int, String>>()
        try {
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                var lineNumber = 0
                while (true) {
                    val line = reader.readLine() ?: break
                    lineNumber++
                    if (line.lowercase().contains(needle)) {
                        found += lineNumber to line.trim().take(MAX_LINE_CHARS)
                        if (found.size >= maxMatches) break
                    }
                }
            }
        } catch (ioException: IOException) {
            // Ikkilik yoki o'qib bo'lmaydigan fayl — jim o'tkazib yuboramiz,
            // chunki qidiruv bitta buzilgan fayl tufayli to'xtamasligi kerak.
            return found
        }
        return found
    }

    private companion object {
        /** Bir qidiruvda ko'pi bilan shuncha hujjat ko'riladi (DoS/uzoq kutishning oldini oladi). */
        const val MAX_VISITS = 5_000
        const val MAX_LINE_CHARS = 200
    }
}
