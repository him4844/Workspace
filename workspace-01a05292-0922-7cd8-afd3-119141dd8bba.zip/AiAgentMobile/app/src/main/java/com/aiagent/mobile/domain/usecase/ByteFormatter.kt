package com.aiagent.mobile.domain.usecase

import java.util.Locale

/**
 * Baytlarni o'qishga qulay ko'rinishga aylantirish — sof funksiya (test qilinadi).
 *
 * Nima uchun domenda: Faza 4 dagi fayl tool'lari (`list_directory`, `get_file_info`)
 * natijani AI'ga matn sifatida qaytaradi va hajmni shu yerda formatlaydi. Domen
 * qatlami UI'ga bog'lana olmaydi, shuning uchun mantiq bu yerga ko'chirildi;
 * `ui.common.Formatters` esa shu ob'ektga yo'naltiruvchi qobiq bo'lib qoldi
 * (Faza 2-3 dagi UI kodi o'zgarmasligi uchun).
 */
object ByteFormatter {

    fun fileSize(bytes: Long): String {
        if (bytes < BYTES_IN_KILOBYTE) return "$bytes B"

        var value = bytes.toDouble() / BYTES_IN_KILOBYTE
        var unitIndex = 0
        while (value >= BYTES_IN_KILOBYTE && unitIndex < UNITS.lastIndex) {
            value /= BYTES_IN_KILOBYTE
            unitIndex++
        }
        return String.format(Locale.US, "%.1f %s", value, UNITS[unitIndex])
    }

    private const val BYTES_IN_KILOBYTE = 1024.0

    private val UNITS = listOf("KB", "MB", "GB", "TB")
}
