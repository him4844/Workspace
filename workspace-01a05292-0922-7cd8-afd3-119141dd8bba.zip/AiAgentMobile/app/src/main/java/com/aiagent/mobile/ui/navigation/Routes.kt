package com.aiagent.mobile.ui.navigation

import android.net.Uri

/**
 * Barcha navigatsiya manzillari bir joyda.
 * Faza 2: workspace va fayl daraxti. Faza 3: haqiqiy chat va sozlamalar ekrani.
 * Faza 4: chat endi `workspaceId` ni ham olib yuradi — agent tool'lari workspace
 * ildizini bilmasa, fayllar ustida ishlolmaydi (barcha yo'l nisbiy).
 */
object Routes {

    const val WORKSPACE: String = "workspace"

    /** AI provider sozlamalari (Faza 3). */
    const val SETTINGS: String = "settings"

    const val ARG_WORKSPACE_ID: String = "workspaceId"
    const val FILE_TREE: String = "file_tree/{$ARG_WORKSPACE_ID}"
    fun fileTree(workspaceId: String): String = "file_tree/$workspaceId"

    const val ARG_FILES: String = "files"
    const val CHAT: String = "chat?$ARG_FILES={$ARG_FILES}&$ARG_WORKSPACE_ID={$ARG_WORKSPACE_ID}"

    /**
     * Tanlangan fayl URI'lari bitta argumentga joylanadi (yangi qator bilan ajratilgan).
     * `Uri.encode` shart: SAF URI'lari `:` , `/` va `%` belgilarini o'z ichiga oladi va
     * ular kodlanmasa route moslashuvi buziladi. NavController qiymatni qayta ochib beradi.
     *
     * `workspaceId` ham uzatiladi: Faza 4 dan agent rejimi fayl ustida ishlaydi.
     */
    fun chat(files: List<String>, workspaceId: String): String =
        "chat?" + ARG_FILES + "=" + Uri.encode(files.joinToString("\n")) +
            "&" + ARG_WORKSPACE_ID + "=" + Uri.encode(workspaceId)

    /** Navigator qayta ochib bermagan holat uchun zaxira dekodlash. */
    fun parseFiles(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        val decoded = if (raw.contains('%')) Uri.decode(raw) else raw
        return decoded.split("\n").filter(String::isNotBlank)
    }

    /** `workspaceId` bo'sh bo'lishi mumkin (chat to'g'ridan-to'g'ri ochilsa) — agent o'chadi. */
    fun parseWorkspaceId(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        return if (raw.contains('%')) Uri.decode(raw) else raw
    }
}
