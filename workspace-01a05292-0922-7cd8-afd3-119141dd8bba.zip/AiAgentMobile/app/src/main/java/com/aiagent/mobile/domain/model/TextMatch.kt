package com.aiagent.mobile.domain.model

/**
 * Matn qidiruvining bitta natijasi (Faza 4, `search_text` tool'i).
 *
 * [path] — workspace ildiziga nisbatan yo'l (AI shu yo'l bilan faylga qayta murojaat qiladi).
 * [lineNumber] — 1 dan boshlanadi (odamlar va diff uchun qulay).
 */
data class TextMatch(
    val path: String,
    val lineNumber: Int,
    val lineText: String,
)
