package com.aiagent.mobile.domain.tools.edit

/**
 * Agent taklif qilgan fayl amali (Faza 4).
 *
 * Bitta tuzilma barcha o'zgartirishlarni qoplaydi — shuning uchun diff ekrani,
 * tasdiq oqimi va Undo tarixi bitta mantiq bilan ishlaydi.
 *
 * [originalContent] conflict tekshiruvi va diff uchun; [newContent] — yoziladigan matn.
 * DELETE/MOVE/COPY uchun [newContent] `null`.
 */
data class ProposedFileEdit(
    val rootUri: String,
    val path: String,
    val uri: String,
    val kind: EditKind,
    val originalContent: String?,
    val newContent: String?,
    val targetPath: String? = null,
    val description: String,
)

enum class EditKind {
    /** Mavjud faylni butunlay almashtirish (`write_file`, `apply_patch`, ...). */
    OVERWRITE,

    /** Yangi fayl yaratish (`create_file`). */
    CREATE,

    /** Faylni o'chirish (`delete_file`). */
    DELETE,

    /** Faylni ko'chirish/nomini o'zgartirish (`move_file`). */
    MOVE,

    /** Nusxa olish (`copy_file`). */
    COPY,
}

/**
 * Undo uchun saqlanadigan yozuv (Faza 4, 8-vazifa — oxirgi 10 ta).
 *
 * Har bir amal turi uchun "qanday qaytarish" ma'lumoti saqlanadi:
 * - OVERWRITE → eski matn qayta yoziladi
 * - CREATE → yaratilgan fayl o'chiriladi
 * - DELETE → o'chirilgan fayl qayta yaratiladi
 * - MOVE → fayl eski joyiga qaytariladi
 * - COPY → nusxa o'chiriladi
 */
data class EditHistoryEntry(
    val path: String,
    val uri: String,
    val kind: EditKind,
    val previousContent: String?,
    val createdUri: String?,
    val sourceUri: String? = null,
    val description: String,
    val timestamp: Long,
)
