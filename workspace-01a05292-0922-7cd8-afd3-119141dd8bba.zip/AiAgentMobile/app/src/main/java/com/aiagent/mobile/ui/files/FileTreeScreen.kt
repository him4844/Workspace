package com.aiagent.mobile.ui.files

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.usecase.FileRow
import com.aiagent.mobile.ui.common.Formatters
import kotlinx.coroutines.launch

private val MinTouchTarget = 48.dp
private val RowHeight = 56.dp
private val IndentStep = 16.dp

/**
 * Faza 2 — fayl daraxti: ierarxik ro'yxat (expand/collapse), fayl hajmi va ikonkasi,
 * matn fayllari uchun preview, fayl tanlash va chatga o'tish.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileTreeScreen(
    onNavigateBack: () -> Unit,
    onGoToChat: (List<String>) -> Unit,
    viewModel: FileTreeViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val preview by viewModel.preview.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        viewModel.messageFlow.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = state.workspaceName.ifBlank { stringResource(R.string.files_title) },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                navigationIcon = {
                    IconButton(
                        modifier = Modifier.size(MinTouchTarget),
                        onClick = onNavigateBack,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = stringResource(R.string.common_back),
                        )
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            if (state.selectedUris.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { onGoToChat(state.selectedUris.toList()) },
                    icon = { Icon(painterResource(R.drawable.ic_content_copy), contentDescription = null) },
                    text = {
                        Text(stringResource(R.string.files_go_to_chat, state.selectedUris.size))
                    },
                )
            }
        },
    ) { innerPadding ->
        when {
            state.isLoadingRoot -> LoadingContent(innerPadding)

            state.rootError != null -> ErrorContent(
                innerPadding = innerPadding,
                message = state.rootError.orEmpty(),
                onRetry = viewModel::retry,
            )

            state.rows.isEmpty() -> EmptyContent(innerPadding)

            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                items(state.rows, key = { it.node.uri }) { row ->
                    FileTreeRow(
                        row = row,
                        isSelected = row.node.uri in state.selectedUris,
                        isLoadingChildren = row.node.uri in state.loadingUris,
                        onToggleExpand = { viewModel.onToggleExpand(row.node) },
                        onToggleSelect = { viewModel.onToggleSelect(row.node) },
                        onOpenPreview = { viewModel.onOpenPreview(row.node) },
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                }
            }
        }
    }

    preview?.let { previewState ->
        FilePreviewSheet(
            state = previewState,
            onDismiss = viewModel::onClosePreview,
            // showSnackbar — suspend funksiya, shuning uchun coroutine scope kerak.
            onCopied = { message -> scope.launch { snackbarHostState.showSnackbar(message) } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FileTreeRow(
    row: FileRow,
    isSelected: Boolean,
    isLoadingChildren: Boolean,
    onToggleExpand: () -> Unit,
    onToggleSelect: () -> Unit,
    onOpenPreview: () -> Unit,
) {
    val isDirectory = row.node.isDirectory

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(RowHeight)
            .padding(start = (row.depth * IndentStep.value).dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (isDirectory) {
            IconButton(
                modifier = Modifier.size(MinTouchTarget),
                onClick = onToggleExpand,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_expand_more),
                    contentDescription = stringResource(
                        if (row.isExpanded) R.string.files_collapse else R.string.files_expand,
                    ),
                    modifier = Modifier.rotate(if (row.isExpanded) 0f else -90f),
                )
            }
        } else {
            Spacer(Modifier.width(MinTouchTarget))
        }

        Icon(
            painter = painterResource(
                if (isDirectory) R.drawable.ic_folder else R.drawable.ic_file_text,
            ),
            contentDescription = null,
            tint = if (isDirectory) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
        )
        Spacer(Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                text = row.node.name,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (!isDirectory) {
                Text(
                    text = Formatters.fileSize(row.node.sizeBytes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        when {
            isLoadingChildren -> CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
            )

            isDirectory -> IconButton(
                modifier = Modifier.size(MinTouchTarget),
                onClick = onToggleExpand,
            ) {
                Text(
                    text = stringResource(R.string.files_open),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }

            else -> {
                IconButton(
                    modifier = Modifier.size(MinTouchTarget),
                    onClick = onOpenPreview,
                ) {
                    Text(
                        text = stringResource(R.string.files_preview),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Checkbox(checked = isSelected, onCheckedChange = { onToggleSelect() })
            }
        }
    }
}

@Composable
private fun LoadingContent(innerPadding: PaddingValues) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.files_loading),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ErrorContent(innerPadding: PaddingValues, message: String, onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                painter = painterResource(R.drawable.ic_warning),
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.files_error_title),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedButton(
                modifier = Modifier.height(MinTouchTarget),
                onClick = onRetry,
            ) {
                Icon(painterResource(R.drawable.ic_refresh), contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.common_retry))
            }
        }
    }
}

@Composable
private fun EmptyContent(innerPadding: PaddingValues) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                painter = painterResource(R.drawable.ic_folder),
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.files_empty_folder),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
