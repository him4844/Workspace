package com.aiagent.mobile.data.filesystem

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Base64
import androidx.core.graphics.createBitmap
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.model.PdfPages
import java.io.ByteArrayOutputStream

/**
 * PDF sahifalarini rasmga aylantirish (Faza 3).
 *
 * Nima uchun rasm: Android'ning `PdfRenderer` API'si sahifani faqat bitmap qilib
 * beradi (matn chiqarish imkoni yo'q), PDF matnini olish uchun esa uchinchi tomon
 * kutubxonasi (PdfBox va h.k.) kerak bo'lardi. Foydalanuvchi sharti — nol yangi
 * kutubxona. Shuning uchun sahifalar rasm sifatida multimodal provider'ga yuboriladi;
 * provider rasmlarni qabul qilmasa, `IngestAttachmentUseCase` buni aniq aytadi.
 *
 * Cheklovlar: [maxPages] sahifa va [maxDimensionPx] piksel — aks holda 100 sahifali
 * PDF telefonda ham xotirani, ham API'ni portlatadi.
 */
internal class PdfPageRenderer(private val resolver: ContentResolver) {

    fun render(uri: Uri, maxPages: Int, maxDimensionPx: Int): PdfPages {
        val descriptor = runCatching {
            resolver.openFileDescriptor(uri, "r")
        }.getOrNull() ?: return PdfPages(
            pages = emptyList(),
            totalPages = 0,
            failedReason = "PDF fayli ochilmadi yoki ruxsat yo'q",
        )

        return descriptor.use { fileDescriptor ->
            val renderer = try {
                PdfRenderer(fileDescriptor)
            } catch (exception: Exception) {
                return PdfPages(
                    pages = emptyList(),
                    totalPages = 0,
                    failedReason = "PDF o'qilmadi: ${exception.message ?: "format xatosi"}",
                )
            }
            try {
                renderPages(renderer, maxPages, maxDimensionPx)
            } catch (exception: Exception) {
                PdfPages(
                    pages = emptyList(),
                    totalPages = renderer.pageCount,
                    failedReason = "PDF sahifalarini chizib bo'lmadi: ${exception.message}",
                )
            } finally {
                // PdfRenderer sahifani ochiq qoldirsa fayl descriptor yopilmaydi —
                // shuning uchun close() doim chaqiriladi.
                runCatching { renderer.close() }
            }
        }
    }

    private fun renderPages(
        renderer: PdfRenderer,
        maxPages: Int,
        maxDimensionPx: Int,
    ): PdfPages {
        val totalPages = renderer.pageCount
        val pageCount = minOf(totalPages, maxPages)
        val images = ArrayList<IngestedImage>(pageCount)

        for (index in 0 until pageCount) {
            // PdfRenderer bitta vaqtda faqat bitta sahifani ochiq tutadi.
            renderer.openPage(index).use { page ->
                val scale = minOf(
                    1f,
                    maxDimensionPx.toFloat() / maxOf(page.width, page.height, 1),
                )
                val width = (page.width * scale).toInt().coerceAtLeast(1)
                val height = (page.height * scale).toInt().coerceAtLeast(1)

                // Lint `UseKtx`: core-ktx kengaytmasi ishlatiladi (Faza 2 dagi qaror bilan izchil).
                val bitmap = createBitmap(width, height, Bitmap.Config.ARGB_8888)
                // PDF fonida shaffoflik bo'lsa, JPEG'da qora bo'lib chiqadi —
                // shuning uchun avval oq fon bilan to'ldiriladi.
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                images += IngestedImage(
                    mimeType = IMAGE_MIME_TYPE,
                    base64 = encodeJpeg(bitmap),
                    label = "PDF ${index + 1}-sahifa",
                )
                bitmap.recycle()
            }
        }

        return PdfPages(
            pages = images,
            totalPages = totalPages,
            failedReason = if (images.isEmpty()) "PDF'da sahifa topilmadi" else null,
        )
    }

    private fun encodeJpeg(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private companion object {
        const val IMAGE_MIME_TYPE = "image/jpeg"
        const val JPEG_QUALITY = 82
    }
}
