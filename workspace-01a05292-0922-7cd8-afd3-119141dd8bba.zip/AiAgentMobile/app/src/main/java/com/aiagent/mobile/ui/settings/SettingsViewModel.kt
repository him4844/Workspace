package com.aiagent.mobile.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.mobile.data.security.KeyEncryptorException
import com.aiagent.mobile.domain.agent.ColabStatus
import com.aiagent.mobile.domain.agent.RemoteExecutionEngine
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.ProviderType
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.repository.SettingsRepository
import com.aiagent.mobile.domain.usecase.ApiBaseNormalizer
import com.aiagent.mobile.domain.usecase.ColabUrlNormalizer
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * AI provider sozlamalari (Faza 3, 1-2 vazifa).
 *
 * Ekran matnlari bu yerda YO'Q — ViewModel Android resurslarini bilmaydi,
 * shuning uchun hodisalar [SettingsMessage] sifatida chiqariladi va ularni
 * `SettingsScreen` string resurslarga aylantiradi.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val chatRepository: AiChatRepository,
    private val remoteEngine: RemoteExecutionEngine,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    private val _form = MutableStateFlow(ProviderFormState())
    val form: StateFlow<ProviderFormState> = _form.asStateFlow()

    private val _messages = Channel<SettingsMessage>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    init {
        viewModelScope.launch {
            settingsRepository.providers
                // DataStore fayli o'qilmaydigan bo'lsa (buzilgan) bo'sh ro'yxat ko'rsatamiz —
                // ilova crash bo'lmaydi, foydalanuvchi provider'ni qayta kiritadi.
                .catch { emit(emptyList()) }
                .collect { list ->
                    _uiState.update { it.copy(isLoading = false, providers = list) }
                }
        }
        // Faza 5: Colab URL va ulanish holati. Sozlamalar o'zgarsa (masalan boshqa
        // ekrandan) bu yerda ham aks etadi.
        viewModelScope.launch {
            settingsRepository.settings
                .catch { /* DataStore buzilgan bo'lsa — Colab bo'limi bo'sh qoladi */ }
                .collect { settings ->
                    _colab.update {
                        it.copy(
                            savedUrl = settings.colabUrl,
                            urlInput = settings.colabUrl,
                        )
                    }
                }
        }
    }

    // ------------------------------------------------------------- Colab (Faza 5)

    private val _colab = MutableStateFlow(ColabUiState())
    val colab: StateFlow<ColabUiState> = _colab.asStateFlow()

    fun onColabUrlChange(value: String) {
        _colab.update {
            it.copy(
                urlInput = value,
                // Matn o'zgarsa eski holat eskiradi — foydalanuvchini chalg'itmaslik uchun.
                status = ColabStatus.NotConfigured,
                hasChecked = false,
            )
        }
    }

    /** Colab URL'ni saqlash. Manzil yaroqsiz bo'lsa saqlanmaydi va aniq xabar beriladi. */
    fun saveColabUrl() {
        val raw = _colab.value.urlInput
        val normalized = ColabUrlNormalizer.normalize(raw)

        // Bo'sh maydon — bu "o'chirish" ma'nosini beradi (xato emas).
        if (raw.isBlank()) {
            persistColabUrl("")
            _colab.update {
                it.copy(
                    savedUrl = "",
                    status = ColabStatus.NotConfigured,
                    hasChecked = false,
                    isSaving = false,
                )
            }
            viewModelScope.launch {
                _messages.send(SettingsMessage.ColabCleared)
            }
            return
        }

        if (normalized == null) {
            _colab.update { it.copy(isSaving = false, urlError = ColabUrlError.Invalid) }
            return
        }

        persistColabUrl(normalized)
        _colab.update {
            it.copy(
                urlInput = normalized,
                savedUrl = normalized,
                urlError = null,
                isSaving = false,
            )
        }
        viewModelScope.launch { _messages.send(SettingsMessage.ColabSaved) }
    }

    /**
     * "Ulanishni tekshirish" — `/health` orqali.
     *
     * URL hali saqlanmagan bo'lsa, "xato" chiqarmaymiz: spetsifikatsiya talabiga ko'ra
     * foydalanuvchi to'g'ridan-to'g'ri **qo'llanmaga** yo'naltiriladi.
     */
    fun checkColabConnection() {
        if (_colab.value.isChecking) return

        if (_colab.value.savedUrl.isBlank()) {
            viewModelScope.launch { _messages.send(SettingsMessage.ColabUrlRequired) }
            return
        }

        _colab.update { it.copy(isChecking = true, urlError = null) }

        viewModelScope.launch {
            val status = remoteEngine.checkStatus()
            _colab.update { it.copy(isChecking = false, status = status, hasChecked = true) }
        }
    }

    private fun persistColabUrl(url: String) {
        viewModelScope.launch {
            val current = settingsRepository.settings.first()
            settingsRepository.updateSettings(current.copy(colabUrl = url))
        }
    }

    // ---------------------------------------------------------------- forma

    fun startNewProvider() {
        _form.value = ProviderFormState()
        _uiState.update { it.copy(isFormOpen = true, isTesting = false) }
    }

    fun startEditProvider(provider: AiProvider) {
        _form.value = ProviderFormState(
            id = provider.id,
            name = provider.name,
            type = provider.type,
            apiBase = provider.apiBase,
            // Xavfsizlik: kalit formaga OCHIQ holda qaytariladi (tahrirlash uchun kerak),
            // lekin maydon standart holda yashirin va "o'zgartirmasangiz eski kalit qoladi"
            // deb yoziladi.
            apiKey = "",
            storedKeyPresent = provider.apiKey.isNotBlank(),
            model = provider.model,
            maxTokens = provider.maxTokens.toString(),
            temperature = provider.temperature,
            contextLength = provider.contextLength.toString(),
            makeActive = provider.isDefault,
        )
        _uiState.update { it.copy(isFormOpen = true, isTesting = false) }
    }

    fun closeForm() {
        _uiState.update { it.copy(isFormOpen = false) }
    }

    fun onNameChange(value: String) = _form.update { it.copy(name = value, nameError = false) }

    fun onTypeChange(value: ProviderType) = _form.update {
        it.copy(
            type = value,
            // Tur tanlanganda API manzil avtomatik to'ldiriladi (spetsifikatsiya talabi).
            // Foydalanuvchi uni baribir o'zgartira oladi — maydon doim tahrirlanadigan.
            apiBase = value.defaultApiBase(),
            apiBaseError = false,
        )
    }

    fun onApiBaseChange(value: String) = _form.update { it.copy(apiBase = value, apiBaseError = false) }

    fun onApiKeyChange(value: String) = _form.update { it.copy(apiKey = value, apiKeyError = false) }

    fun onModelChange(value: String) = _form.update { it.copy(model = value, modelError = false) }

    fun onMaxTokensChange(value: String) =
        _form.update { it.copy(maxTokens = value.filter(Char::isDigit), numberError = false) }

    fun onContextLengthChange(value: String) =
        _form.update { it.copy(contextLength = value.filter(Char::isDigit), numberError = false) }

    fun onTemperatureChange(value: Float) = _form.update { it.copy(temperature = value) }

    fun onMakeActiveChange(value: Boolean) = _form.update { it.copy(makeActive = value) }

    /**
     * Saqlashdan OLDIN validatsiya (spetsifikatsiya: bo'sh API kalit yuborishdan
     * oldin to'xtatilishi va aniq xabar berishi kerak).
     */
    fun save() {
        val current = _form.value
        val validated = current.validate()
        _form.value = validated
        if (!validated.isValid) return

        viewModelScope.launch {
            val resolvedKey = if (validated.apiKey.isNotBlank()) {
                validated.apiKey
            } else {
                // Tahrirlashda kalit maydoni bo'sh qoldirilsa — eski kalit saqlanadi.
                _uiState.value.providers
                    .firstOrNull { it.id == validated.id }
                    ?.apiKey
                    .orEmpty()
            }
            val provider = AiProvider(
                id = validated.id.ifBlank { UUID.randomUUID().toString() },
                name = validated.name.trim(),
                type = validated.type,
                apiBase = validated.apiBase.trim(),
                apiKey = resolvedKey,
                model = validated.model.trim(),
                maxTokens = validated.maxTokens.toIntOrNull() ?: DEFAULT_MAX_TOKENS,
                temperature = validated.temperature,
                contextLength = validated.contextLength.toIntOrNull() ?: DEFAULT_CONTEXT_LENGTH,
                isDefault = validated.makeActive,
            )
            try {
                settingsRepository.saveProvider(provider)
                _messages.send(SettingsMessage.Saved(provider.name))
                closeForm()
            } catch (encryptorException: KeyEncryptorException) {
                // Keystore ishlamadi — kalitni ochiq saqlab yubormaymiz (xavfsizlik).
                _messages.send(
                    SettingsMessage.EncryptFailed(
                        encryptorException.message ?: "noma'lum xato",
                    ),
                )
            }
        }
    }

    fun deleteProvider(provider: AiProvider) {
        viewModelScope.launch {
            settingsRepository.deleteProvider(provider.id)
            _messages.send(SettingsMessage.Deleted(provider.name))
        }
    }

    fun activateProvider(provider: AiProvider) {
        viewModelScope.launch {
            settingsRepository.setActiveProvider(provider.id)
            _messages.send(SettingsMessage.Activated(provider.name))
        }
    }

    /**
     * "Test qilish" (2-vazifa): SAQLANMAGAN forma qiymatlari bilan qisqa so'rov.
     * Yuklanish holati MAJBURIY — `_uiState.isTesting` UI'da spinner ko'rsatadi.
     */
    fun testConnection() {
        val current = _form.value
        val validated = current.validate()
        _form.value = validated
        if (!validated.isValid) return

        val apiKey = validated.apiKey.ifBlank {
            _uiState.value.providers.firstOrNull { it.id == validated.id }?.apiKey.orEmpty()
        }
        val probe = AiProvider(
            id = validated.id.ifBlank { "probe" },
            name = validated.name.trim(),
            type = validated.type,
            apiBase = validated.apiBase.trim(),
            apiKey = apiKey,
            model = validated.model.trim(),
            maxTokens = validated.maxTokens.toIntOrNull() ?: DEFAULT_MAX_TOKENS,
            temperature = validated.temperature,
            contextLength = validated.contextLength.toIntOrNull() ?: DEFAULT_CONTEXT_LENGTH,
        )

        _uiState.update { it.copy(isTesting = true, testResult = null) }
        viewModelScope.launch {
            val result = chatRepository.testConnection(probe)
            when (result) {
                is AiResult.Success -> {
                    // Natija faqat snackbar'da emas, forma ichida ham ko'rinadi (✅).
                    _uiState.update { it.copy(isTesting = false, testResult = TestOutcome.Success) }
                    _messages.send(SettingsMessage.TestSuccess)
                }

                is AiResult.Failure -> {
                    _uiState.update {
                        it.copy(isTesting = false, testResult = TestOutcome.Failed(result.error))
                    }
                    _messages.send(SettingsMessage.TestFailed(result.error))
                }
            }
        }
    }

    private fun ProviderType.defaultApiBase(): String = when (this) {
        ProviderType.TOKENROUTER -> "https://api.tokenrouter.io/v1"
        ProviderType.DEEPSEEK -> "https://api.deepseek.com/v1"
        // Custom: manzil noma'lum — foydalanuvchi o'zi yozadi.
        ProviderType.CUSTOM -> ""
    }

    private companion object {
        const val DEFAULT_MAX_TOKENS = 4096
        const val DEFAULT_CONTEXT_LENGTH = 128_000
    }
}

/** Forma holati + validatsiya xatolari. `String` sonlar — kiritish maydoni uchun. */
data class ProviderFormState(
    val id: String = "",
    val name: String = "",
    val type: ProviderType = ProviderType.TOKENROUTER,
    val apiBase: String = "https://api.tokenrouter.io/v1",
    val apiKey: String = "",
    val storedKeyPresent: Boolean = false,
    val model: String = "",
    val maxTokens: String = "4096",
    val temperature: Float = 0.2f,
    val contextLength: String = "128000",
    val makeActive: Boolean = true,
    val nameError: Boolean = false,
    val apiBaseError: Boolean = false,
    val apiKeyError: Boolean = false,
    val modelError: Boolean = false,
    val numberError: Boolean = false,
) {
    val isValid: Boolean
        get() = !nameError && !apiBaseError && !apiKeyError && !modelError && !numberError

    fun validate(): ProviderFormState {
        val apiBaseValid = ApiBaseNormalizer.normalize(apiBase) != null
        val keyMissing = apiKey.isBlank() && !storedKeyPresent
        val maxTokensValid = maxTokens.toIntOrNull()?.let { it > 0 } == true
        val contextValid = contextLength.toIntOrNull()?.let { it > 0 } == true

        return copy(
            nameError = name.isBlank(),
            apiBaseError = !apiBaseValid,
            apiKeyError = keyMissing,
            modelError = model.isBlank(),
            numberError = !maxTokensValid || !contextValid,
        )
    }
}
