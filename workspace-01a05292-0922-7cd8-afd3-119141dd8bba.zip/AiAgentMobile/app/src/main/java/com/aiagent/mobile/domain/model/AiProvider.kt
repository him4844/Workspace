package com.aiagent.mobile.domain.model

/**
 * AI provider sozlamalari (Faza 3 da Settings ekranida boshqariladi).
 *
 * Diqqat: [apiKey] bu yerda ochiq holda saqlanadi, chunki bu — xotiradagi (in-memory)
 * domen modeli. Doimiy saqlash Faza 3 da shifrlangan holda amalga oshiriladi,
 * ro'yxatda esa kalitning faqat oxirgi 4 belgisi ko'rsatiladi.
 */
data class AiProvider(
    val id: String,
    val name: String,
    val type: ProviderType,
    val apiBase: String,
    val apiKey: String,
    val model: String,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.2f,
    val contextLength: Int = 128000,
    val isDefault: Boolean = false,
)

/** Qo'llab-quvvatlanadigan provider turlari. `CUSTOM` — istalgan OpenAI-mos server. */
enum class ProviderType { TOKENROUTER, DEEPSEEK, CUSTOM }
