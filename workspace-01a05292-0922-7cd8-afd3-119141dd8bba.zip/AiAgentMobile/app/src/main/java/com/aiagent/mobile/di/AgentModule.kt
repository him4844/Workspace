package com.aiagent.mobile.di

import com.aiagent.mobile.domain.agent.AgentController
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.ToolRegistry
import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Agent qatlami bog'lanishlari (Faza 4).
 *
 * Barchasi `@Singleton`: agent sikli navigatsiyadan omon qolishi kerak
 * (`AgentController` ichidagi qarorga qarang) va checksum/tool reyestri butun
 * sessiya davomida bir xil bo'lishi shart — aks holda conflict tekshiruvi ishlamaydi.
 *
 * Domen klasslari `@Inject constructor` emas, `@Provides` orqali beriladi:
 * domen qatlami Hilt'ga bog'lanmasligi kerak (`DomainPurityTest` shuni nazorat qiladi).
 */
@Module
@InstallIn(SingletonComponent::class)
object AgentModule {

    @Provides
    @Singleton
    fun provideFileChecksumStore(): FileChecksumStore = FileChecksumStore()

    @Provides
    @Singleton
    fun provideEditCoordinator(): EditCoordinator = EditCoordinator()

    @Provides
    @Singleton
    fun provideToolRegistry(
        documents: DocumentRepository,
        editCoordinator: EditCoordinator,
        checksumStore: FileChecksumStore,
    ): ToolRegistry = ToolRegistry(documents, editCoordinator, checksumStore)

    @Provides
    @Singleton
    fun provideAgentController(
        chatRepository: AiChatRepository,
        documents: DocumentRepository,
        toolRegistry: ToolRegistry,
        editCoordinator: EditCoordinator,
    ): AgentController = AgentController(
        chatRepository = chatRepository,
        documents = documents,
        toolRegistry = toolRegistry,
        editCoordinator = editCoordinator,
    )
}
