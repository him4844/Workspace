package com.aiagent.mobile.domain.agent

/**
 * Colab ulanishining batafsil holati (Faza 5).
 *
 * Nima uchun `Boolean` yetmaydi: spetsifikatsiya har bir holat uchun **alohida,
 * sababli** xabar talab qiladi. "Ulanmagan" ning kamida uch xil sababi bor va
 * foydalanuvchi har birida boshqa narsa qilishi kerak:
 *
 * - [NotConfigured] — URL umuman kiritilmagan → qo'llanmani ochish kerak.
 * - [Unreachable] — havola eskirgan yoki Colab sessiyasi tugagan → Colab'da
 *   "Run all" qayta bosilib, yangi havola olinishi kerak.
 * - [ServerError] — server javob berdi, lekin xato qaytardi → notebook'da
 *   xato ko'rsatilgan bo'ladi.
 *
 * Domen qatlami sof Kotlin: HTTP kodlari `data` qatlamida shu turga aylantiriladi.
 */
sealed interface ColabStatus {

    /** Colab URL kiritilmagan. Bu xato emas — shunchaki hali sozlanmagan. */
    data object NotConfigured : ColabStatus

    /** `/health` muvaffaqiyatli javob qaytardi. */
    data class Connected(val workspaceExists: Boolean) : ColabStatus

    /**
     * Serverga umuman ulanib bo'lmadi (DNS, timeout, havola eskirgan).
     * [detail] — texnik sabab (log uchun); foydalanuvchiga umumiy tushuntirish beriladi.
     */
    data class Unreachable(val detail: String) : ColabStatus

    /** Server javob berdi, lekin xato kodi qaytardi. */
    data class ServerError(val code: Int) : ColabStatus

    val isConnected: Boolean get() = this is Connected
}
