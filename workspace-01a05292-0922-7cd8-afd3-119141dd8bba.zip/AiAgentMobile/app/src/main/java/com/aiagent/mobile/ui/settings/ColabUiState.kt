package com.aiagent.mobile.ui.settings

import com.aiagent.mobile.domain.agent.ColabStatus

/**
 * Sozlamalar ekranidagi Colab bo'limi holati (Faza 5).
 *
 * Nima uchun alohida fayl: `SettingsViewModel` 400 qator chegarasiga yetib qolgan,
 * UI modellarini ajratish mantiqni o'qishni osonlashtiradi.
 *
 * [urlInput] va [savedUrl] ataylab ikkita: foydalanuvchi yozayotgan matn bilan
 * diskka yozilgan manzil farq qilishi mumkin. Holat belgisi faqat **saqlangan**
 * manzilga nisbatan ko'rsatiladi — aks holda "✅ Ulangan" yozuvi hali saqlanmagan
 * matn ustida turib, foydalogini aldardi.
 */
data class ColabUiState(
    val urlInput: String = "",
    val savedUrl: String = "",
    val status: ColabStatus = ColabStatus.NotConfigured,
    val isChecking: Boolean = false,
    val isSaving: Boolean = false,
    /** Foydalanuvchi hech bo'lmaganda bir marta tekshirganmi (bo'sh holatni ajratish uchun). */
    val hasChecked: Boolean = false,
    val urlError: ColabUrlError? = null,
)

/** Colab URL maydonidagi validatsiya xatosi (submit qilishdan oldin ko'rsatiladi). */
enum class ColabUrlError {
    /** Manzil URL'ga o'xshamaydi (masalan "salom"). */
    Invalid,
}
