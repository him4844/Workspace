package com.aiagent.mobile.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.agent.ColabStatus

/**
 * Sozlamalar ekranidagi Colab ulanish bo'limi (Faza 5, 2-vazifa).
 *
 * Spetsifikatsiyaning UX talablari va ularning javobi:
 * - **"Qanday ulash mumkin?" havolasi** → 4 qadamli qo'llanma (bottom sheet).
 *   Ulanish ko'p qadamli tashqi jarayon, shuning uchun yo'l ko'rsatma majburiy.
 * - **Holat belgisi sababli**: "Ulanmagan" shunchaki xato emas — havola eskirgani
 *   va nima qilish kerakligi yoziladi.
 * - **Yuklanish holati**: tekshiruv paytida indikator, tugma o'chiriladi.
 * - **Validatsiya**: yaroqsiz manzil saqlanmaydi va darhol xabar chiqadi.
 * - **48dp**: barcha tugma va maydonlar.
 */
@Composable
fun ColabSettingsSection(
    state: ColabUiState,
    onUrlChange: (String) -> Unit,
    onSave: () -> Unit,
    onCheck: () -> Unit,
    onOpenGuide: () -> Unit,
) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painter = painterResource(R.drawable.ic_link_off),
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.colab_section_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.colab_section_body),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = state.urlInput,
                onValueChange = onUrlChange,
                label = { Text(stringResource(R.string.colab_url_label)) },
                placeholder = { Text(stringResource(R.string.colab_url_hint)) },
                // Manzil — bu URL, shuning uchun URL klaviaturasi va " Tayyor" tugmasi.
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Done,
                ),
                isError = state.urlError != null,
                supportingText = state.urlError?.let {
                    { Text(stringResource(R.string.colab_url_invalid)) }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            if (state.hasChecked || state.savedUrl.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                StatusRow(state = state)
            }

            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(
                    modifier = Modifier.height(48.dp),
                    onClick = onSave,
                    enabled = !state.isSaving,
                ) { Text(stringResource(R.string.colab_save)) }

                Button(
                    modifier = Modifier.height(48.dp),
                    onClick = onCheck,
                    // Tekshirish faqat SAQLANGAN manzil bilan ma'noli — engine
                    // sozlamalardan o'qiydi.
                    enabled = !state.isChecking && state.savedUrl.isNotBlank(),
                ) {
                    if (state.isChecking) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                        )
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(stringResource(R.string.colab_check))
                }
            }

            TextButton(
                modifier = Modifier.heightIn(min = 48.dp),
                onClick = onOpenGuide,
            ) {
                Text(stringResource(R.string.colab_how_to))
            }
        }
    }
}

/** Ulanish holati — har bir holat uchun alohida, sababli matn. */
@Composable
private fun StatusRow(state: ColabUiState) {
    val (icon, tint, text) = when {
        state.isChecking -> Triple(
            R.drawable.ic_refresh,
            MaterialTheme.colorScheme.onSurfaceVariant,
            stringResource(R.string.colab_status_checking),
        )

        state.status is ColabStatus.Connected && state.status.workspaceExists -> Triple(
            R.drawable.ic_check_circle,
            MaterialTheme.colorScheme.primary,
            stringResource(R.string.colab_status_connected),
        )

        state.status is ColabStatus.Connected -> Triple(
            R.drawable.ic_warning,
            MaterialTheme.colorScheme.tertiary,
            stringResource(R.string.colab_status_connected_no_workspace),
        )

        state.status is ColabStatus.ServerError -> Triple(
            R.drawable.ic_error_circle,
            MaterialTheme.colorScheme.error,
            stringResource(
                R.string.colab_status_server_error,
                (state.status as ColabStatus.ServerError).code,
            ),
        )

        state.status is ColabStatus.Unreachable -> Triple(
            R.drawable.ic_error_circle,
            MaterialTheme.colorScheme.error,
            stringResource(R.string.colab_status_unreachable),
        )

        else -> Triple(
            R.drawable.ic_link_off,
            MaterialTheme.colorScheme.onSurfaceVariant,
            stringResource(R.string.colab_status_not_configured),
        )
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = tint,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = tint,
        )
    }
}

/**
 * 4 qadamli ulanish qo'llanmasi (spetsifikatsiya talabi).
 *
 * Nima uchun bottom sheet: foydalanuvchi Sozlamalar ekranidan chiqib ketmasligi kerak —
 * qo'llanmani o'qib, darhol shu ekranda URL kiritishi mumkin.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColabGuideSheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
        ) {
            Text(
                text = stringResource(R.string.colab_guide_title),
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(12.dp))
            listOf(
                R.string.colab_guide_step1,
                R.string.colab_guide_step2,
                R.string.colab_guide_step3,
                R.string.colab_guide_step4,
            ).forEach { res ->
                Text(
                    text = stringResource(res),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.colab_guide_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.colab_open_notebook) +
                    ": colab/aiagent_colab_server.ipynb",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                onClick = onDismiss,
            ) { Text(stringResource(R.string.colab_guide_close)) }
        }
    }
}

/**
 * Colab talab qiladigan amal URL kiritilmaganda chaqirilganda ko'rsatiladigan
 * yo'naltiruvchi dialog (spetsifikatsiya: "oddiy xatolik o'rniga ... qo'llanmaga
 * yo'naltiruvchi tugma").
 */
@Composable
fun ColabRequiredDialog(onDismiss: () -> Unit, onOpenGuide: () -> Unit) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                painter = painterResource(R.drawable.ic_warning),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
            )
        },
        title = { Text(stringResource(R.string.colab_need_url_title)) },
        text = { Text(stringResource(R.string.colab_need_url_body)) },
        confirmButton = {
            TextButton(modifier = Modifier.height(48.dp), onClick = onOpenGuide) {
                Text(stringResource(R.string.colab_need_url_action))
            }
        },
        dismissButton = {
            TextButton(modifier = Modifier.height(48.dp), onClick = onDismiss) {
                Text(stringResource(R.string.common_cancel))
            }
        },
    )
}
