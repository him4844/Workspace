package com.aiagent.mobile

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Ilova entry point'i.
 *
 * [HiltAndroidApp] Hilt'ning dependency injection konteynerini shu yerda yaratadi.
 * Faza 0 da hali hech qanday binding yo'q — bu faqat toolchain (KSP + Hilt)
 * haqiqatan ishlayotganini tekshirish uchun zarur.
 */
@HiltAndroidApp
class AiAgentApplication : Application()
