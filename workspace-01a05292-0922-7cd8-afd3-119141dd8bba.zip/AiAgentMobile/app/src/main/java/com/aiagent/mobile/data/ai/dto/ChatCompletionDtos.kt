package com.aiagent.mobile.data.ai.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * OpenAI-mos `/chat/completions` so'rov va javob modellari.
 *
 * Bu DTO'lar FAQAT data qatlamida yashaydi — domen modeli (`AiProvider`,
 * `AiRequestMessage`, `AiResponse`) wire-format'ga bog'lanmaydi.
 *
 * [ChatMessageDto.content] ni `JsonElement` qilish sababi: OpenAI sxemasida
 * `content` ikki xil bo'la oladi — oddiy matn (`"salom"`) yoki vision uchun
 * qismlar massivi (`[{"type":"text",...},{"type":"image_url",...}]`).
 *
 * Faza 4: function-calling qo'shildi — [ChatCompletionRequest.tools],
 * [ChatMessageDto.toolCalls] va [ChatMessageDto.toolCallId].
 */
@Serializable
data class ChatCompletionRequest(
    val model: String,
    val messages: List<ChatMessageDto>,
    @SerialName("max_tokens") val maxTokens: Int? = null,
    val temperature: Float? = null,
    /** Spetsifikatsiya talabi: streaming YO'Q. */
    val stream: Boolean = false,
    /** Bo'sh bo'lmasa provider tool chaqiruvini taklif qilishi mumkin. */
    val tools: List<ToolDto>? = null,
)

@Serializable
data class ChatMessageDto(
    val role: String,
    val content: JsonElement? = null,
    /** `role = "tool"` uchun: qaysi chaqiruvga javob ekanini bildiradi. */
    @SerialName("tool_call_id") val toolCallId: String? = null,
    /** `role = "assistant"` va tool chaqiruvi bo'lganda. */
    @SerialName("tool_calls") val toolCalls: List<ToolCallDto>? = null,
)

/** OpenAI function-calling: tool tavsifi. */
@Serializable
data class ToolDto(
    val type: String = "function",
    val function: ToolFunctionDto,
)

@Serializable
data class ToolFunctionDto(
    val name: String,
    val description: String,
    /** JSON schema — domen `ToolParameter` ro'yxatidan quriladi. */
    val parameters: JsonObject,
)

/** Javobdagi tool chaqiruvi. */
@Serializable
data class ToolCallDto(
    val id: String? = null,
    val type: String? = null,
    val function: ToolCallFunctionDto? = null,
)

@Serializable
data class ToolCallFunctionDto(
    val name: String? = null,
    /**
     * Argumentlar JSON **matn** sifatida keladi (OpenAI shunday qaytaradi),
     * shuning uchun uni alohida tahlil qilish kerak — `AiChatRepositoryImpl` shuni qiladi.
     */
    val arguments: String? = null,
)

@Serializable
data class ChatCompletionResponse(
    val choices: List<ChatChoiceDto> = emptyList(),
    val model: String? = null,
    val usage: ChatUsageDto? = null,
    val error: ChatErrorDto? = null,
)

@Serializable
data class ChatChoiceDto(
    val message: ChatChoiceMessageDto? = null,
    @SerialName("finish_reason") val finishReason: String? = null,
)

@Serializable
data class ChatChoiceMessageDto(
    val role: String? = null,
    val content: String? = null,
    @SerialName("tool_calls") val toolCalls: List<ToolCallDto> = emptyList(),
)

@Serializable
data class ChatUsageDto(
    @SerialName("prompt_tokens") val promptTokens: Int? = null,
    @SerialName("completion_tokens") val completionTokens: Int? = null,
)

/** Ba'zi serverlar xatoni 200 bilan, `error` maydonida qaytaradi. */
@Serializable
data class ChatErrorDto(
    val message: String? = null,
    val type: String? = null,
    val code: String? = null,
)
