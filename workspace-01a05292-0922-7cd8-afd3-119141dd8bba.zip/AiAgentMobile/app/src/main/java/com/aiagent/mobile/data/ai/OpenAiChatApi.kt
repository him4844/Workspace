package com.aiagent.mobile.data.ai

import com.aiagent.mobile.data.ai.dto.ChatCompletionRequest
import com.aiagent.mobile.data.ai.dto.ChatCompletionResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * OpenAI-mos chat endpoint'i (Faza 3, 3-vazifa).
 *
 * `Response<...>` qaytariladi, chunki xato holatlarida (401/429/5xx) HTTP kodini
 * o'qib, uni foydalogi uchun tushunarli xabarga aylantirishimiz kerak.
 *
 * Yo'l nisbiy (`chat/completions`) — shuning uchun Retrofit `baseUrl` har bir
 * provider uchun alohida bo'ladi (TokenRouter, DeepSeek yoki Custom server).
 */
interface OpenAiChatApi {

    @POST("chat/completions")
    suspend fun chatCompletions(
        @Body request: ChatCompletionRequest,
    ): Response<ChatCompletionResponse>
}
