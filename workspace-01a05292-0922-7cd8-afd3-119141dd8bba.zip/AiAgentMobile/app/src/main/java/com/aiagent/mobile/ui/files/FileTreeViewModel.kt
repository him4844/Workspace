package com.aiagent.mobile.ui.files

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.repository.SettingsRepository
import com.aiagent.mobile.domain.repository.WorkspaceRepository
import com.aiagent.mobile.domain.usecase.FileTreeFlattener
import com.aiagent.mobile.domain.usecase.FileRow
import com.aiagent.mobile.ui.navigation.Routes
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Fayl daraxti ekranining holati. */
data class FileTreeUiState(
    val workspaceName: String = "",
    val isLoadingRoot: Boolean = true,
    val rootError: String? = null,
    val rows: List<FileRow> = emptyList(),
    val loadingUris: Set<String> = emptySet(),
    val selectedUris: Set<String> = emptySet(),
)

/** Ochilgan fayl preview'si (bottom sheet). */
data class PreviewUiState(
    val fileName: String,
    val uri: String,
    val isLoading: Boolean,
    val content: FileContent?,
)

/** ViewModel ichki holati — UI'ga faqat [FileTreeUiState] uzatiladi. */
private data class TreeState(
    val workspaceName: String = "",
    val isLoadingRoot: Boolean = true,
    val rootError: String? = null,
    val rootChildren: List<FileNode> = emptyList(),
    val childrenByUri: Map<String, List<FileNode>> = emptyMap(),
    val expandedUris: Set<String> = emptySet(),
    val loadingUris: Set<String> = emptySet(),
    val selectedUris: Set<String> = emptySet(),
)

@HiltViewModel
class FileTreeViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val documentRepository: DocumentRepository,
    private val workspaceRepository: WorkspaceRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val workspaceId: String = checkNotNull(savedStateHandle[Routes.ARG_WORKSPACE_ID]) {
        "FileTreeScreen workspaceId argumentisiz ochildi"
    }

    private val state = MutableStateFlow(TreeState())

    val uiState: StateFlow<FileTreeUiState> = state
        .map { current ->
            FileTreeUiState(
                workspaceName = current.workspaceName,
                isLoadingRoot = current.isLoadingRoot,
                rootError = current.rootError,
                rows = FileTreeFlattener.flatten(
                    rootChildren = current.rootChildren,
                    childrenByUri = current.childrenByUri,
                    expandedUris = current.expandedUris,
                ),
                loadingUris = current.loadingUris,
                selectedUris = current.selectedUris,
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), FileTreeUiState())

    private val _preview = MutableStateFlow<PreviewUiState?>(null)
    val preview: StateFlow<PreviewUiState?> = _preview.asStateFlow()

    private val messages = Channel<String>(capacity = Channel.BUFFERED)
    val messageFlow: Flow<String> = messages.receiveAsFlow()

    init {
        loadRoot()
    }

    fun retry() = loadRoot()

    private fun loadRoot() {
        viewModelScope.launch {
            state.update { it.copy(isLoadingRoot = true, rootError = null) }

            val workspace = workspaceRepository.findWorkspace(workspaceId)
            if (workspace == null) {
                state.update {
                    it.copy(isLoadingRoot = false, rootError = "Workspace topilmadi. Ro'yxatga qaytib, papkani qayta tanlang.")
                }
                return@launch
            }

            if (!documentRepository.hasPersistablePermission(workspace.uri)) {
                state.update {
                    it.copy(
                        isLoadingRoot = false,
                        workspaceName = workspace.name,
                        rootError = "Bu papkaga ruxsat yo'qolgan. Workspace ekranida qayta ulang.",
                    )
                }
                return@launch
            }

            runCatching { documentRepository.listChildren(workspace.uri) }
                .onSuccess { children ->
                    state.update {
                        it.copy(
                            isLoadingRoot = false,
                            rootError = null,
                            workspaceName = workspace.name,
                            rootChildren = children,
                        )
                    }
                }
                .onFailure { error ->
                    state.update {
                        it.copy(
                            isLoadingRoot = false,
                            workspaceName = workspace.name,
                            rootError = "Fayllarni o'qib bo'lmadi: ${error.message ?: "noma'lum xato"}",
                        )
                    }
                }
        }
    }

    /** Papkani ochish/yopish. Birinchi ochilishda bolalar sekin (lazy) yuklanadi. */
    fun onToggleExpand(node: FileNode) {
        if (!node.isDirectory) return
        val uri = node.uri
        val wasExpanded = state.value.expandedUris.contains(uri)

        if (wasExpanded) {
            state.update { it.copy(expandedUris = it.expandedUris - uri) }
            return
        }

        state.update { it.copy(expandedUris = it.expandedUris + uri) }
        if (state.value.childrenByUri.containsKey(uri)) return // allaqachon yuklangan
        loadChildren(uri)
    }

    /** Faylni tanlash/bekor qilish (chatga biriktirish uchun). */
    fun onToggleSelect(node: FileNode) {
        if (node.isDirectory) return
        state.update { current ->
            val selected = current.selectedUris
            current.copy(
                selectedUris = if (selected.contains(node.uri)) selected - node.uri else selected + node.uri,
            )
        }
    }

    fun onOpenPreview(node: FileNode) {
        if (node.isDirectory) return
        _preview.value = PreviewUiState(
            fileName = node.name,
            uri = node.uri,
            isLoading = true,
            content = null,
        )
        viewModelScope.launch {
            // Faza 3: preview chegarasi endi sozlamadan olinadi — fayl AI'ga
            // yuboriladigan hajm bilan bir xil, shuning uchun foydalanuvchi
            // preview'da ko'rgan matn modelga ketadigan matn bilan mos keladi.
            val maxBytes = runCatching { settingsRepository.settings.first() }
                .getOrNull()
                ?.maxFileContextSizeBytes
                ?: PREVIEW_MAX_BYTES
            val content = runCatching {
                documentRepository.readTextFile(node.uri, maxBytes)
            }.getOrElse { error ->
                FileContent.Failed(reason = "Faylni o'qib bo'lmadi: ${error.message ?: "noma'lum xato"}")
            }
            // Foydalanuvchi shu orada boshqa fayl ochgan bo'lishi mumkin — eskisini yozmaymiz.
            if (_preview.value?.uri == node.uri) {
                _preview.value = _preview.value?.copy(isLoading = false, content = content)
            }
        }
    }

    fun onClosePreview() {
        _preview.value = null
    }

    private fun loadChildren(uri: String) {
        viewModelScope.launch {
            state.update { it.copy(loadingUris = it.loadingUris + uri) }
            runCatching { documentRepository.listChildren(uri) }
                .onSuccess { children ->
                    state.update {
                        it.copy(
                            childrenByUri = it.childrenByUri + (uri to children),
                            loadingUris = it.loadingUris - uri,
                        )
                    }
                }
                .onFailure { error ->
                    state.update {
                        it.copy(
                            loadingUris = it.loadingUris - uri,
                            // Xato tufayli papkani yopamiz — aks holda bo'sh va "ochiq" ko'rinadi.
                            expandedUris = it.expandedUris - uri,
                        )
                    }
                    messages.trySend("Papkani ochib bo'lmadi: ${error.message ?: "noma'lum xato"}")
                }
        }
    }

    private companion object {
        const val STOP_TIMEOUT_MS = 5_000L

        /** Preview uchun maksimal hajm (bayt). Faza 3 da sozlamadan olinadi. */
        /** Sozlamani o'qib bo'lmasa ishlatiladigan zaxira chegara. */
        const val PREVIEW_MAX_BYTES = 200_000
    }
}
