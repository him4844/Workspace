package com.aiagent.mobile.ui.chat

import com.aiagent.mobile.domain.agent.AgentController
import com.aiagent.mobile.domain.agent.AgentRunRequest
import com.aiagent.mobile.domain.agent.AgentState
import com.aiagent.mobile.domain.agent.AgentStep
import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.domain.repository.WorkspaceRepository
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.edit.ProposedFileEdit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Chat ekrani bilan agent sikli orasidagi ko'prik (Faza 4, 6-vazifa).
 *
 * Nima uchun alohida klass: `ChatViewModel` 400 qator chegarasiga yaqin edi,
 * agent holatlari esa o'ziga yarasha joy oladi. Bu klass sof UI mantiq —
 * domen qatlami unga bog'lanmaydi.
 *
 * Agent sikli `AgentController` (singleton) da yashaydi, shuning uchun chat
 * ekranidan chiqib ketganda ham davom etadi; bu delegat faqat holatni ko'rsatadi
 * va foydalanuvchi amallarini (tasdiq / rad / stop / undo) uzatadi.
 */
class AgentChatDelegate(
    private val scope: CoroutineScope,
    private val agent: AgentController,
    private val workspaces: WorkspaceRepository,
    private val onFinalAnswer: (String) -> Unit,
    private val onError: (AiError) -> Unit,
    private val onUndoResult: (ToolResult) -> Unit,
) {

    private val _ui = MutableStateFlow(AgentChatUi())
    val ui: StateFlow<AgentChatUi> = _ui.asStateFlow()

    init {
        scope.launch {
            agent.state.collect { state -> _ui.update { it.copy(agentState = state) } }
        }
        scope.launch {
            agent.steps.collect { steps -> _ui.update { it.copy(steps = steps) } }
        }
        // Diff ekrani shu holatga qarab ochiladi. `StateFlow` bo'lgani uchun Compose
        // o'zgarishni darhol ko'radi (oddiy funksiyadan o'qilsa, qayta chizish bo'lmasdi).
        scope.launch {
            agent.pendingEdit.collect { pending -> _ui.update { it.copy(pendingEdit = pending) } }
        }
        // Yakuniy javob bir marta keladi — chat tarixiga yozamiz.
        scope.launch {
            agent.finalAnswer.collect { answer ->
                if (!answer.isNullOrBlank()) onFinalAnswer(answer)
            }
        }
        scope.launch {
            agent.error.collect { error ->
                if (error != null) onError(error)
            }
        }
    }

    /**
     * Chat qaysi workspace ichida ochilganini bilish.
     * Bo'sh `workspaceId` → agent rejimi mavjud emas (xatolik emas, oddiy chat ishlaydi).
     */
    fun bindWorkspace(workspaceId: String) {
        if (workspaceId.isBlank()) {
            _ui.update { it.copy(available = false, rootUri = null, workspaceName = null) }
            return
        }
        scope.launch {
            val workspace = workspaces.findWorkspace(workspaceId)
            _ui.update {
                it.copy(
                    available = workspace != null,
                    rootUri = workspace?.uri,
                    workspaceName = workspace?.name,
                )
            }
        }
    }

    fun setAgentMode(enabled: Boolean) {
        _ui.update { it.copy(isAgentMode = enabled) }
    }

    fun toggleAgentMode() = setAgentMode(!_ui.value.isAgentMode)

    fun isBusy(): Boolean = _ui.value.agentState == AgentState.PLANNING ||
        _ui.value.agentState == AgentState.RUNNING_TOOL

    /** Agent siklini boshlash. Qaytish qiymati: boshlandimi. */
    fun start(request: AgentLaunch): Boolean {
        val state = _ui.value
        val rootUri = state.rootUri ?: return false
        if (isBusy()) return false

        val editMode = request.settings?.editMode ?: EditMode.ALWAYS_CONFIRM
        _ui.update { it.copy(agentState = AgentState.PLANNING, steps = emptyList()) }
        agent.start(
            AgentRunRequest(
                provider = request.provider,
                rootUri = rootUri,
                workspaceName = state.workspaceName.orEmpty(),
                userMessage = request.userMessage,
                history = request.history,
                attachmentContext = request.attachmentContext,
                editMode = editMode,
                maxFileBytes = request.settings?.maxFileContextSizeBytes ?: DEFAULT_MAX_FILE_BYTES,
            ),
        )
        return true
    }

    fun approveEdit() = agent.approvePendingEdit()

    fun rejectEdit() = agent.rejectPendingEdit()

    fun stop() = agent.stop()

    fun undoLastEdit() = agent.undoLastEdit(onUndoResult)

    fun hasUndoHistory(): Boolean = agent.editHistory().isNotEmpty()

    private companion object {
        const val DEFAULT_MAX_FILE_BYTES = 100_000
    }
}

/** Agent siklini boshlash uchun chat tomonidan beriladigan ma'lumotlar. */
data class AgentLaunch(
    val provider: com.aiagent.mobile.domain.model.AiProvider,
    val settings: com.aiagent.mobile.domain.model.AppSettings?,
    val userMessage: String,
    val history: List<AiRequestMessage>,
    val attachmentContext: String,
)

/** Agent paneli uchun UI holati. */
data class AgentChatUi(
    val available: Boolean = false,
    val rootUri: String? = null,
    val workspaceName: String? = null,
    val isAgentMode: Boolean = false,
    val agentState: AgentState = AgentState.IDLE,
    val steps: List<AgentStep> = emptyList(),
    /** Tasdiq kutilayotgan fayl amali — diff ekrani shu bo'lsa ochiladi. */
    val pendingEdit: ProposedFileEdit? = null,
)

/**
 * Xabar rolini `AiRequestMessage`ga aylantirish (agent tarixi uchun).
 *
 * Faqat USER va ASSISTANT olinadi: TOOL roli `tool_call_id` talab qiladi va uni
 * agent siklining o'zi yaratadi; SYSTEM xabari `AgentPrompt`dan keladi. Xato
 * kartalari (`isError`) tarixga kirmaydi — ular foydalanuvchiga mo'ljallangan.
 */
fun List<ChatUiMessage>.toAgentHistory(): List<AiRequestMessage> =
    filter { !it.isError }
        .filter { it.role == MessageRole.USER || it.role == MessageRole.ASSISTANT }
        .map { AiRequestMessage(role = it.role, content = it.content) }
