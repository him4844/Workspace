package com.aiagent.mobile.domain.tools.files

import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.AgentTool
import com.aiagent.mobile.domain.tools.ParamType
import com.aiagent.mobile.domain.tools.ToolContext
import com.aiagent.mobile.domain.tools.ToolParameter
import com.aiagent.mobile.domain.tools.ToolPaths
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.EditKind
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import com.aiagent.mobile.domain.tools.edit.ProposedFileEdit
import com.aiagent.mobile.domain.tools.optionalArg
import com.aiagent.mobile.domain.tools.requireArg
import com.aiagent.mobile.domain.tools.toToolMessage
import com.aiagent.mobile.domain.tools.toolError

/**
 * Fayl o'zgartiruvchi tool'lar: `write_file`, `create_file`, `delete_file`,
 * `move_file`, `copy_file` (Faza 4, 2-vazifa).
 *
 * Muhim: bu tool'lar faylga TO'G'RIDAN-TO'G'RI YOZMAYDI. Ular [EditCoordinator]ga
 * taklif yuboradi:
 * - `ALWAYS_CONFIRM` (standart) → coordinator `PermissionRequired` qaytaradi, agent
 *   to'xtaydi, foydalanuvchi diff ekranida qaror qabul qiladi;
 * - `AUTO_APPLY` → darhol yoziladi va Undo tarixiga tushadi.
 *
 * Conflict nazorati (4-vazifa): `write_file` yozishdan oldin faylning hozirgi
 * checksum'ini `read_file` paytida yozilgani bilan solishtiradi. Farq bo'lsa —
 * yozilmaydi va agentga aniq conflict xabari qaytadi.
 */
class MutatingFileTools(
    private val documents: DocumentRepository,
    private val edits: EditCoordinator,
    private val checksums: FileChecksumStore,
) {

    val tools: List<AgentTool> =
        listOf(WriteFile(), CreateFile(), DeleteFile(), MoveFile(), CopyFile())

    /** Mavjud faylni butunlay almashtirish. */
    inner class WriteFile : AgentTool {
        override val name = "write_file"
        override val description =
            "Mavjud faylni butunlay yangi matn bilan almashtiradi. Katta fayllar uchun " +
                "apply_patch yoki replace_text afzal — butun faylni yozish xato xavfini oshiradi."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Fayl yo'li (workspace ildiziga nisbatan)"),
            ToolParameter("content", ParamType.STRING, "Faylning yangi to'liq mazmuni"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val content = args["content"]
                ?: return toolError("Kerakli parametr berilmagan: 'content'")

            val uri = when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                is ToolPaths.Resolved.Found -> resolved.uri
                is ToolPaths.Resolved.Failure -> return resolved.error
            }

            val original = ToolPaths.readText(documents, context, uri)
            val originalText = (original as? ToolPaths.ReadOutcome.Text)?.content

            // CONFLICT TEKSHIRUVI: fayl AI o'qigandan keyin o'zgargan bo'lsa, yozmaymiz.
            conflictCheck(path, originalText)?.let { return it }

            return edits.request(
                ProposedFileEdit(
                    rootUri = context.rootUri,
                    path = path,
                    uri = uri,
                    kind = EditKind.OVERWRITE,
                    originalContent = originalText,
                    newContent = content,
                    description = "'$path' faylini yozish (${content.length} belgi)",
                ),
                documents,
            ).also { result -> rememberIfApplied(path, result, content) }
        }
    }

    /** Yangi fayl yaratish. */
    inner class CreateFile : AgentTool {
        override val name = "create_file"
        override val description =
            "Yangi fayl yaratadi. Fayl allaqachon mavjud bo'lsa xato qaytadi."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Yangi fayl yo'li, masalan src/New.kt"),
            ToolParameter(
                name = "content",
                type = ParamType.STRING,
                description = "Fayl mazmuni (bo'sh fayl uchun bo'sh qator)",
                required = false,
            ),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val content = args.optionalArg("content")

            val target = when (val resolved = ToolPaths.resolveForCreate(documents, context, path)) {
                is ToolPaths.CreateTarget.Found -> resolved
                is ToolPaths.CreateTarget.Failure -> return resolved.error
            }

            return edits.request(
                ProposedFileEdit(
                    rootUri = context.rootUri,
                    path = path,
                    // CREATE uchun `uri` = ota papka (perform shundan fayl yaratadi).
                    uri = target.parentUri,
                    kind = EditKind.CREATE,
                    originalContent = null,
                    newContent = content,
                    description = "'$path' faylini yaratish (${content.length} belgi)",
                ),
                documents,
            ).also { result -> rememberIfApplied(path, result, content) }
        }
    }

    /** Faylni o'chirish — halokatli amal, shuning uchun har doim tasdiqdan o'tadi. */
    inner class DeleteFile : AgentTool {
        override val name = "delete_file"
        override val description =
            "Faylni O'CHIRADI. Bu halokatli amal — foydalanuvchi tasdig'ini talab qiladi. " +
                "Faqat aniq so'ralganda ishlating."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "O'chiriladigan fayl yo'li"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val uri = when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                is ToolPaths.Resolved.Found -> resolved.uri
                is ToolPaths.Resolved.Failure -> return resolved.error
            }

            // Undo imkoni bo'lishi uchun matn oldindan o'qib olinadi.
            val original = (ToolPaths.readText(documents, context, uri) as? ToolPaths.ReadOutcome.Text)
                ?.content

            return edits.request(
                ProposedFileEdit(
                    rootUri = context.rootUri,
                    path = path,
                    uri = uri,
                    kind = EditKind.DELETE,
                    originalContent = original,
                    newContent = null,
                    description = "'$path' faylini O'CHIRISH (qaytarib bo'lmaydi)",
                ),
                documents,
            ).also { if (it is ToolResult.Success) checksums.forget(path) }
        }
    }

    /** Faylni ko'chirish yoki nomini o'zgartirish. */
    inner class MoveFile : AgentTool {
        override val name = "move_file"
        override val description =
            "Faylni boshqa papkaga ko'chiradi yoki nomini o'zgartiradi."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Hozirgi fayl yo'li"),
            ToolParameter("new_path", ParamType.STRING, "Yangi yo'l, masalan src/utils/Helper.kt"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val newPath = args.requireArg("new_path").getOrElse { return toolError(it.toToolMessage()) }

            val uri = when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                is ToolPaths.Resolved.Found -> resolved.uri
                is ToolPaths.Resolved.Failure -> return resolved.error
            }
            if (documents.resolveChild(context.rootUri, newPath) != null) {
                return toolError("'$newPath' allaqachon mavjud — ustidan yozib yubormaslik uchun to'xtatildi.")
            }

            return edits.request(
                ProposedFileEdit(
                    rootUri = context.rootUri,
                    path = path,
                    uri = uri,
                    kind = EditKind.MOVE,
                    originalContent = null,
                    newContent = null,
                    targetPath = newPath,
                    description = "'$path' ni '$newPath' ga ko'chirish",
                ),
                documents,
            ).also { if (it is ToolResult.Success) checksums.forget(path) }
        }
    }

    /** Nusxa olish. */
    inner class CopyFile : AgentTool {
        override val name = "copy_file"
        override val description = "Fayldan nusxa oladi (asl fayl o'zgarmaydi)."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Asl fayl yo'li"),
            ToolParameter("new_path", ParamType.STRING, "Nusxa yo'li"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val newPath = args.requireArg("new_path").getOrElse { return toolError(it.toToolMessage()) }

            val uri = when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                is ToolPaths.Resolved.Found -> resolved.uri
                is ToolPaths.Resolved.Failure -> return resolved.error
            }

            return edits.request(
                ProposedFileEdit(
                    rootUri = context.rootUri,
                    path = path,
                    uri = uri,
                    kind = EditKind.COPY,
                    originalContent = null,
                    newContent = null,
                    targetPath = newPath,
                    description = "'$path' dan '$newPath' ga nusxa olish",
                ),
                documents,
            )
        }
    }

    /**
     * Conflict tekshiruvi: `read_file` yozgan checksum hozirgi matnga mos kelmasa,
     * fayl tashqaridan o'zgargan — yozish xavfli.
     */
    private fun conflictCheck(path: String, currentContent: String?): ToolResult? {
        val stored = checksums.recorded(path) ?: return null // hali o'qilmagan — conflict yo'q
        val current = currentContent ?: return null
        if (checksums.checksumOf(current) == stored) return null

        return toolError(
            "CONFLICT: '$path' fayli siz o'qiganingizdan keyin o'zgargan. " +
                "Buzilishning oldini olish uchun yozish to'xtatildi. " +
                "Faylni `read_file` bilan qayta o'qing va o'zgartirishni yangi matn asosida qiling.",
            recoverable = true,
        )
    }

    /** Yozish muvaffaqiyatli bo'lsa (AUTO_APPLY), checksum yangilanadi. */
    private fun rememberIfApplied(path: String, result: ToolResult, content: String) {
        if (result is ToolResult.Success) checksums.updateAfterWrite(path, content)
    }
}
