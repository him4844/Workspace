package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.FileContent

/**
 * O'qilgan baytlarni [FileContent] turiga ajratish — sof mantiq (Android'ga bog'liq emas).
 *
 * Qoidalar (Faza 3 da o'zgardi):
 * 1. Birinchi bo'lakda NUL (`0x00`) bayti bo'lsa — bu ikkilik fayl ([FileContent.Binary]).
 *    Oddiy va ishonchli heuristic: haqiqiy matn fayllarida NUL uchramaydi.
 * 2. Aks holda — UTF-8 matn. Agar fayl chegaradan katta bo'lsa, matn KESILADI va
 *    `truncated = true` + `totalBytes` qaytariladi.
 *
 * Faza 2 da katta fayl [FileContent.TooLarge] sifatida rad etilardi. Faza 3 da
 * foydalanuvchi strategiyani tanladi: "to'liq yuklash + kesish" — agent har qanday
 * hajmdagi fayldan foydalana olishi kerak. Kesish HECH QACHON yashirin emas:
 * UI va AI konteksti "fayl X bayt, faqat birinchi Y bayti yuborildi" deb aytadi.
 * [FileContent.TooLarge] endi faqat rasmlar uchun ishlatiladi (rasmda kesish
 * ma'nosiz — buzilgan rasm modelga foyda bermaydi).
 */
object FileContentClassifier {

    /** Ikkilik faylni aniqlash uchun tekshiriladigan boshlang'ich baytlar soni. */
    private const val BINARY_SNIFF_BYTES = 8_000

    fun classify(
        raw: ByteArray,
        reportedSizeBytes: Long,
        maxBytes: Int,
        mimeType: String? = null,
    ): FileContent {
        val sniffLength = minOf(raw.size, BINARY_SNIFF_BYTES)
        for (i in 0 until sniffLength) {
            if (raw[i] == ZERO_BYTE) {
                return FileContent.Binary(
                    mimeType = mimeType,
                    sizeBytes = if (reportedSizeBytes > 0) reportedSizeBytes else raw.size.toLong(),
                )
            }
        }

        val truncated = reportedSizeBytes > raw.size.toLong()
        val usable = if (truncated) trimIncompleteUtf8(raw) else raw
        return FileContent.Text(
            content = String(usable, Charsets.UTF_8),
            truncated = truncated,
            totalBytes = if (reportedSizeBytes > 0) reportedSizeBytes else raw.size.toLong(),
        )
    }

    /**
     * Kesilgan matn oxirida ko'p baytli UTF-8 belgisi yarim qolishi mumkin —
     * u holda oxirida "alik almashinma belgisi" paydo bo'ladi. Shuning uchun
     * tugallanmagan oxirgi belgi tashlab yuboriladi.
     *
     * maxBytes chegarasiga bog'liq emas, sof bayt mantiqi — shuning uchun test qilinadi.
     */
    fun trimIncompleteUtf8(raw: ByteArray): ByteArray {
        if (raw.isEmpty()) return raw

        // Oxirgi 3 bayt ichida ko'p baytli belgi boshini qidiramiz.
        for (back in 1..3) {
            val index = raw.size - back
            if (index < 0) break
            val byte = raw[index].toInt() and 0xFF

            val isLead = (byte and 0xC0) == 0xC0
            if (isLead) {
                val expectedLength = when {
                    (byte and 0xE0) == 0xC0 -> 2
                    (byte and 0xF0) == 0xE0 -> 3
                    else -> 4
                }
                // Agar belgi to'liq emas bo'lsa — uni butunlay kesamiz.
                return if (expectedLength > back) raw.copyOf(index) else raw
            }

            val isContinuation = (byte and 0xC0) == 0x80
            if (!isContinuation) break // oddiy ASCII — hech narsa kesilmaydi
        }
        return raw
    }

    private const val ZERO_BYTE: Byte = 0
}
