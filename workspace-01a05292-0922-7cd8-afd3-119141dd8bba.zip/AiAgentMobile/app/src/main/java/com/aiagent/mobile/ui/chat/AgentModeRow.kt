package com.aiagent.mobile.ui.chat

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R

/**
 * Agent rejimi tugmachasi (Faza 4, 6-vazifa).
 *
 * Nima uchun foydalanuvchiga tanlov beriladi:
 * - **Xavfsiz standart** — agent rejimi SUKUT BO'YICHA O'CHIQ. Foydalanuvchi uni
 *   o'zi yoqadi, chunki agent fayllarga yozishi mumkin (tasdiq so'raladi, lekin
 *   baribir katta imkoniyat).
 * - Oddiy savol ("Python nima?") uchun tool chaqirilmaydi — bu `AgentPrompt`dagi
 *   1-qoida bilan kafolatlanadi, rejim yoqilgan bo'lsa ham.
 *
 * Qo'shimcha "Qaytarish" tugmasi `AUTO_APPLY` rejimidagi oxirgi amalni bekor qiladi.
 */
@Composable
fun AgentModeRow(
    agent: AgentChatUi,
    onToggle: () -> Unit,
    onUndo: () -> Unit,
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_folder),
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = if (agent.isAgentMode) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.agent_mode_toggle),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    text = if (agent.isAgentMode) {
                        stringResource(R.string.agent_mode_on)
                    } else {
                        stringResource(R.string.agent_mode_off)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(
                modifier = Modifier.height(48.dp),
                onClick = onUndo,
            ) {
                Text(
                    text = stringResource(R.string.agent_undo),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Spacer(Modifier.width(4.dp))
            Switch(
                checked = agent.isAgentMode,
                onCheckedChange = { onToggle() },
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    }
}
