package com.aiagent.mobile.ui.diff

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.tools.edit.PatchEngine
import com.aiagent.mobile.domain.tools.edit.ProposedFileEdit
import com.aiagent.mobile.ui.theme.CodeTextStyle

/**
 * Diff ekrani (Faza 4, 7-vazifa).
 *
 * Qo'shilgan qatorlar yashil, o'chirilganlar qizil fonda — rang Material 3
 * palitrasidan olinadi (`secondaryContainer` / `errorContainer`), shuning uchun
 * qorong'i va yorug' mavzuda ham o'qishli. Kod monospace shriftda.
 *
 * Ikki tugma: "Qabul qilish" (faylga haqiqatan yoziladi) va "Rad etish".
 * O'chirish amali uchun alohida ogohlantirish ko'rsatiladi — bu halokatli amal.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiffPanel(
    edit: ProposedFileEdit,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val diffLines = remember(edit.originalContent, edit.newContent) {
        PatchEngine.diffLines(
            original = edit.originalContent.orEmpty(),
            updated = edit.newContent.orEmpty(),
        )
    }
    val summary = remember(edit.originalContent, edit.newContent) {
        PatchEngine.summarize(edit.originalContent.orEmpty(), edit.newContent.orEmpty())
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painter = painterResource(R.drawable.ic_edit),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = edit.path,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = edit.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(
                    R.string.diff_summary,
                    summary.first,
                    summary.second,
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.tertiary,
            )
            Spacer(Modifier.height(12.dp))

            if (diffLines.isEmpty()) {
                Text(
                    text = stringResource(R.string.diff_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp),
                ) {
                    items(diffLines, key = { line -> lineKey(line) }) { line ->
                        DiffLineRow(line)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlinedButton(modifier = Modifier.height(48.dp), onClick = onReject) {
                    Text(stringResource(R.string.diff_reject))
                }
                Spacer(Modifier.width(8.dp))
                Button(modifier = Modifier.height(48.dp), onClick = onAccept) {
                    Icon(
                        painter = painterResource(R.drawable.ic_check),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.diff_accept))
                }
            }
        }
    }
}

@Composable
private fun DiffLineRow(line: PatchEngine.DiffLine) {
    val background = when (line.type) {
        PatchEngine.DiffLineType.ADDED -> MaterialTheme.colorScheme.secondaryContainer
        PatchEngine.DiffLineType.REMOVED -> MaterialTheme.colorScheme.errorContainer
        PatchEngine.DiffLineType.UNCHANGED -> MaterialTheme.colorScheme.surfaceVariant
    }
    val marker = when (line.type) {
        PatchEngine.DiffLineType.ADDED -> "+"
        PatchEngine.DiffLineType.REMOVED -> "-"
        PatchEngine.DiffLineType.UNCHANGED -> " "
    }

    Surface(
        color = background,
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
    ) {
        Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)) {
            Text(
                text = line.oldNumber?.toString().orEmpty().padStart(4),
                style = CodeTextStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = line.newNumber?.toString().orEmpty().padStart(4),
                style = CodeTextStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = marker,
                style = CodeTextStyle,
                modifier = Modifier.width(12.dp),
            )
            // Bo'sh qator ham ko'rinishi kerak — aks holda diff "yo'qolib qolgan" ko'rinadi.
            Text(
                text = line.text.ifEmpty { " " },
                style = CodeTextStyle,
                modifier = Modifier.background(background),
            )
        }
    }
}

/** LazyColumn uchun barqaror kalit (qator matni takrorlanishi mumkin). */
private fun lineKey(line: PatchEngine.DiffLine): String =
    "${line.type.name}:${line.oldNumber ?: "-"}:${line.newNumber ?: "-"}:${line.text}"
