package com.aiagent.mobile.domain.usecase

/**
 * Foydalanuvchi kiritgan Colab (ngrok) havolasini tozalash (Faza 5).
 *
 * Nima uchun kerak: foydalanuvchi havolani Colab chiqishidan **nusxalaydi** va ko'pincha
 * yoniga bo'shliq, yangi qator yoki oxiriga `/` qo'shib qo'yadi. Retrofit `baseUrl`
 * esa **aynan bitta oxirgi slash** talab qiladi — aks holda `IllegalArgumentException`
 * bilan ilova qulaydi. Shuning uchun so'rov yuborishdan oldin manzil tozalanadi.
 *
 * Sof Kotlin — JVM testida tekshiriladi.
 */
object ColabUrlNormalizer {

    /**
     * Manzilni Retrofit uchun yaroqli ko'rinishga keltiradi.
     * @return tozalangan manzil yoki `null` (bo'sh/yaroqsiz bo'lsa).
     */
    fun normalize(raw: String?): String? {
        val trimmed = raw?.trim().orEmpty()
        if (trimmed.isEmpty()) return null

        // Ko'chirib-joylashtirishda ichki bo'shliq/yangi qator qolib ketishi mumkin.
        val withoutSpaces = trimmed.replace(WHITESPACE_REGEX, "")
        if (withoutSpaces.isEmpty()) return null

        val withScheme = if (withoutSpaces.startsWith("http://") ||
            withoutSpaces.startsWith("https://")
        ) {
            withoutSpaces
        } else {
            // Foydalanuvchi sxemani yozmasa — ngrok har doim https, shuning uchun https.
            "https://$withoutSpaces"
        }

        val withSlash = if (withSlash(withScheme)) withScheme else "$withScheme/"
        return if (isPlausible(withSlash)) withSlash else null
    }

    /** Foydalanuvchiga ko'rsatish uchun (oxirgi slash'siz). */
    fun forDisplay(raw: String?): String = normalize(raw)?.trimEnd('/').orEmpty()

    /**
     * Manzil haqiqiy server manzliga o'xshaydimi?
     *
     * Qat'iy URL parser ishlatilmaydi: maqsad — aniq noto'g'ri qiymatlarni
     * (masalan "salom", "http://") ushlash, barcha ekzotik manzillarni rad etish emas.
     */
    private fun isPlausible(url: String): Boolean {
        val host = url.substringAfter("://").substringBefore('/').substringBefore(':')
        if (host.isEmpty()) return false
        // Kamida bitta nuqta (domen) yoki localhost bo'lishi kerak.
        return host.contains('.') || host == "localhost"
    }

    private fun withSlash(url: String): Boolean {
        val afterScheme = url.substringAfter("://")
        return afterScheme.contains('/')
    }

    private val WHITESPACE_REGEX = Regex("\\s+")
}
