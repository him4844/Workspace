package com.aiagent.mobile.data.filesystem

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import com.aiagent.mobile.domain.model.FileNode
import java.io.IOException

/**
 * SAF orqali fayl YOZISH amallari (Faza 4).
 *
 * `SafDocumentRepository` 400 qator chegarasidan oshmasligi uchun alohida klass.
 *
 * Xavfsizlik qarori — [resolve] metodi: agent faqat tanlangan workspace ichida
 * ishlaydi. Nisbiy yo'l normallashtiriladi va `..` bilan ildizdan yuqoriga chiqishga
 * urinish yo'l oxirida ildizda qolishini kafolatlaydi (ya'ni `../../etc/passwd`
 * ildiz ichidagi `etc/passwd` ga aylanadi, tizim fayliga emas).
 */
internal class SafDocumentWriter(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    /**
     * `src/main.kt` ko'rinishidagi nisbiy yo'lni SAF URI'ga aylantiradi.
     * Oraliq papka mavjud bo'lmasa `null` qaytadi (tool uni `create_file` bilan yaratadi).
     */
    fun resolve(rootUri: String, path: String): String? {
        val segments = normalizeSegments(path)
        var current = DocumentFile.fromTreeUri(context, rootUri.toUri()) ?: return null
        for (segment in segments) {
            current = current.findFile(segment) ?: return null
        }
        return current.uri.toString()
    }

    /** Yo'lni xavfsiz segmentlar ro'yxatiga aylantirish. */
    fun normalizeSegments(path: String): List<String> {
        val cleaned = path.replace('\\', '/').trim('/')
        if (cleaned.isEmpty()) return emptyList()
        // `..` va `.` tashlab yuboriladi — ildizdan chiqib ketish imkonsiz bo'ladi.
        return cleaned.split('/').filter { it.isNotEmpty() && it != "." && it != ".." }
    }

    fun exists(uri: String): Boolean =
        DocumentFile.fromTreeUri(context, uri.toUri())?.exists() == true

    fun writeFile(uri: String, content: String): Boolean {
        val stream = runCatching {
            // "wt" — mavjud faylni to'liq tozalab yozadi (truncate).
            resolver.openOutputStream(uri.toUri(), "wt")
        }.getOrNull() ?: return false
        return try {
            stream.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            true
        } catch (ioException: IOException) {
            false
        }
    }

    fun createFile(parentUri: String, fileName: String, content: String): String? {
        val parent = DocumentFile.fromTreeUri(context, parentUri.toUri()) ?: return null
        if (!parent.isDirectory) return null
        if (parent.findFile(fileName) != null) return null // duplikat yaratmaymiz

        val created = runCatching {
            parent.createFile(mimeTypeFor(fileName), fileName)
        }.getOrNull() ?: return null

        // Ba'zi provider'lar nomga kengaytma qo'shib beradi (masalan "a.txt" -> "a.txt.txt");
        // shuning uchun haqiqiy nomni tekshiramiz.
        val actualName = created.name
        if (actualName != null && actualName != fileName && actualName.endsWith(".$fileName")) {
            runCatching { created.renameTo(fileName) }
        }

        return if (writeFile(created.uri.toString(), content)) created.uri.toString() else null
    }

    fun createDirectory(parentUri: String, name: String): String? {
        val parent = DocumentFile.fromTreeUri(context, parentUri.toUri()) ?: return null
        if (!parent.isDirectory) return null
        parent.findFile(name)?.let { return it.uri.toString() }
        return runCatching { parent.createDirectory(name)?.uri?.toString() }.getOrNull()
    }

    fun deleteDocument(uri: String): Boolean =
        DocumentFile.fromTreeUri(context, uri.toUri())?.delete() == true

    fun moveDocument(uri: String, targetParentUri: String, newName: String): String? {
        val source = DocumentFile.fromTreeUri(context, uri.toUri()) ?: return null
        val target = DocumentFile.fromTreeUri(context, targetParentUri.toUri()) ?: return null
        if (!target.isDirectory) return null

        // SAF'da "ko'chirish" = avval nusxa, keyin o'chirish. `renameTo` faqat nom
        // o'zgartirish uchun ishonchli, papkalararo ko'chirishda ko'p provider'da rad etiladi.
        val copy = copyInternal(source, target, newName) ?: return null
        return if (source.delete()) copy else null
    }

    fun copyDocument(uri: String, targetParentUri: String, newName: String): String? {
        val source = DocumentFile.fromTreeUri(context, uri.toUri()) ?: return null
        val target = DocumentFile.fromTreeUri(context, targetParentUri.toUri()) ?: return null
        if (!target.isDirectory) return null
        return copyInternal(source, target, newName)
    }

    private fun copyInternal(source: DocumentFile, target: DocumentFile, newName: String): String? {
        val created = runCatching {
            target.createFile(mimeTypeFor(newName), newName)
        }.getOrNull() ?: return null

        val input = runCatching { resolver.openInputStream(source.uri) }.getOrNull()
            ?: return null
        val output = runCatching { resolver.openOutputStream(created.uri, "wt") }.getOrNull()
        if (output == null) {
            runCatching { created.delete() }
            return null
        }

        val copied = try {
            input.use { source_ -> output.use { dest -> source_.copyTo(dest) } }
            true
        } catch (ioException: IOException) {
            false
        }

        if (!copied) {
            runCatching { created.delete() }
            return null
        }
        return created.uri.toString()
    }

    /** Kengaytma bo'yicha MIME tur. Noma'lum bo'lsa `text/plain` (xavfsiz standart). */
    private fun mimeTypeFor(fileName: String): String {
        val extension = MimeTypeMap.getFileExtensionFromUrl(
            Uri.encode(fileName).replace("%2E", "."),
        )
        val mime = extension?.let { MimeTypeMap.getSingleton().getMimeTypeFromExtension(it) }
        return mime ?: DEFAULT_MIME
    }

    /** Papka ichini rekursiv aylanish (qidiruv uchun). */
    fun walk(rootUri: String, maxVisits: Int, onFile: (FileNode, String) -> Boolean) {
        val root = DocumentFile.fromTreeUri(context, rootUri.toUri()) ?: return
        val rootName = root.name.orEmpty()
        walkRecursive(document = root, relativePath = rootName, visited = 0, maxVisits = maxVisits, onFile = onFile)
    }

    /** @return davom etish kerakmi (false = qidiruv to'xtatildi). */
    private fun walkRecursive(
        document: DocumentFile,
        relativePath: String,
        visited: Int,
        maxVisits: Int,
        onFile: (FileNode, String) -> Boolean,
    ): Boolean {
        if (visited >= maxVisits) return false
        var visits = visited

        val children = document.listFiles()
        for (child in children) {
            if (visits >= maxVisits) return false
            visits++
            val name = child.name ?: continue
            val path = if (relativePath.isEmpty()) name else "$relativePath/$name"

            if (child.isDirectory) {
                if (!walkRecursive(child, path, visits, maxVisits, onFile)) return false
            } else {
                val node = FileNode(
                    name = name,
                    uri = child.uri.toString(),
                    isDirectory = false,
                    sizeBytes = child.length(),
                    mimeType = child.type,
                )
                if (!onFile(node, path)) return false
            }
        }
        return true
    }

    private companion object {
        const val DEFAULT_MIME = "text/plain"
    }
}
