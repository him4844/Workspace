package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileKind
import com.aiagent.mobile.domain.model.FileKindClassifier
import com.aiagent.mobile.domain.model.IngestedFile
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.repository.DocumentRepository

/**
 * Biriktirilgan faylni AI'ga yuborishga tayyorlash (Faza 3).
 *
 * Foydalanuvchi talabi: agent tanlangan papkadagi HAR QANDAY turdagi va hajmdagi
 * fayldan foydalana olishi kerak. Strategiya (foydalanuvchi tanlovi):
 * - to'liq o'qish, kontekstga sig'masa KESISH va buni aniq aytish (yashirin emas);
 * - rasm → base64, PDF → sahifa rasmlari, arxiv → ro'yxat + matnli yozuvlar;
 * - boshqa ikkilik fayl → metadata va aniq izoh, hech qachon crash yoki jim tashlash.
 *
 * Bu klass sof domen: Android API'lari chaqirilmaydi, I/O [DocumentRepository]ga
 * topshirilgan — shuning uchun fake repository bilan JVM testida tekshiriladi.
 */
class IngestAttachmentUseCase(
    private val documents: DocumentRepository,
) {

    /** Cheklovlar — sozlamalardan keladi ([com.aiagent.mobile.domain.model.AppSettings]). */
    data class Limits(
        val maxTextBytes: Int = 100_000,
        val maxImageBytes: Int = 8_000_000,
        val maxPdfPages: Int = 5,
        val pdfDimensionPx: Int = 1200,
        val maxArchiveEntries: Int = 200,
        val maxArchiveTextEntries: Int = 20,
        val maxArchiveBytesPerEntry: Int = 20_000,
    )

    suspend fun ingest(uri: String, fileName: String, limits: Limits = Limits()): IngestedFile {
        val mimeType = documents.mimeTypeOf(uri)
        val size = documents.fileSize(uri)
        val kind = FileKindClassifier.classify(mimeType, fileName)

        return when (kind) {
            FileKind.TEXT -> ingestText(uri, fileName, kind, mimeType, size, limits)
            FileKind.IMAGE -> ingestImage(uri, fileName, kind, mimeType, size, limits)
            FileKind.PDF -> ingestPdf(uri, fileName, kind, mimeType, size, limits)
            FileKind.ARCHIVE -> ingestArchive(uri, fileName, kind, mimeType, size, limits)
            FileKind.BINARY -> ingestBinary(uri, fileName, kind, mimeType, size)
        }
    }

    private suspend fun ingestText(
        uri: String,
        fileName: String,
        kind: FileKind,
        mimeType: String?,
        size: Long,
        limits: Limits,
    ): IngestedFile = when (val result = documents.readTextFile(uri, limits.maxTextBytes)) {
        is FileContent.Text -> IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = size,
            text = result.content,
            truncated = result.truncated,
            note = if (result.truncated) {
                "fayl ${result.totalBytes} bayt, faqat birinchi ${limits.maxTextBytes} bayti yuborildi"
            } else {
                null
            },
        )

        is FileContent.Binary -> ingestBinary(uri, fileName, kind, mimeType, size)

        is FileContent.TooLarge -> IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = result.sizeBytes,
            text = null,
            note = "fayl juda katta (${result.sizeBytes} bayt > ${result.maxBytes}), " +
                "yuborilmadi",
        )

        is FileContent.Failed -> IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = size,
            text = null,
            note = "o'qib bo'lmadi: ${result.reason}",
        )

        else -> binaryFallback(uri, fileName, kind, mimeType, size)
    }

    private suspend fun ingestImage(
        uri: String,
        fileName: String,
        kind: FileKind,
        mimeType: String?,
        size: Long,
        limits: Limits,
    ): IngestedFile = when (val result = documents.readImageBase64(uri, limits.maxImageBytes)) {
        is FileContent.Image -> IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = result.mimeType,
            sizeBytes = result.sizeBytes,
            text = null,
            images = listOf(
                IngestedImage(
                    mimeType = result.mimeType,
                    base64 = result.base64,
                    label = fileName,
                ),
            ),
        )

        is FileContent.TooLarge -> IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = result.sizeBytes,
            text = null,
            note = "rasm juda katta (${result.sizeBytes} bayt > ${result.maxBytes}), " +
                "yuborilmadi",
        )

        is FileContent.Failed -> IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = size,
            text = null,
            note = "rasmni o'qib bo'lmadi: ${result.reason}",
        )

        else -> binaryFallback(uri, fileName, kind, mimeType, size)
    }

    private suspend fun ingestPdf(
        uri: String,
        fileName: String,
        kind: FileKind,
        mimeType: String?,
        size: Long,
        limits: Limits,
    ): IngestedFile {
        val pages = documents.renderPdfPages(uri, limits.maxPdfPages, limits.pdfDimensionPx)
        val note = when {
            pages.failedReason != null -> "PDF sahifalarini rasmga aylantirib bo'lmadi: " +
                pages.failedReason
            pages.totalPages > pages.pages.size ->
                "PDF ${pages.totalPages} sahifali, faqat birinchi ${pages.pages.size} " +
                    "sahifasi yuborildi"
            else -> null
        }
        return IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = size,
            text = null,
            images = pages.pages,
            note = note,
        )
    }

    private suspend fun ingestArchive(
        uri: String,
        fileName: String,
        kind: FileKind,
        mimeType: String?,
        size: Long,
        limits: Limits,
    ): IngestedFile {
        val listing = documents.listArchiveEntries(uri, limits.maxArchiveEntries)
        val texts = documents.readArchiveTextEntries(
            uri = uri,
            maxEntries = limits.maxArchiveTextEntries,
            maxBytesPerEntry = limits.maxArchiveBytesPerEntry,
        )

        val listingText = (listing as? FileContent.Archive)
            ?.entries
            ?.joinToString("\n") { entry ->
                val marker = if (entry.isDirectory) "/" else ""
                "  ${entry.path}$marker (${entry.sizeBytes} bayt)"
            }
            .orEmpty()

        val entryCount = (listing as? FileContent.Archive)?.entries?.size ?: 0
        val textParts = buildList {
            if (listingText.isNotEmpty()) {
                add("Arxiv ichidagi fayllar ($entryCount ta):")
                add(listingText)
            }
            (texts as? FileContent.Text)?.let { add("\nArxiv ichidagi matnli fayllar:\n" + it.content) }
            (texts as? FileContent.Failed)?.let { add("\n[Matnli yozuvlarni o'qib bo'lmadi: ${it.reason}]") }
        }

        val note = when {
            listing is FileContent.Failed -> "arxivni o'qib bo'lmadi: ${listing.reason}"
            texts is FileContent.Text && texts.truncated ->
                "arxivdagi matnli fayllar qisman yuborildi"
            else -> null
        }

        return IngestedFile(
            fileName = fileName,
            uri = uri,
            kind = kind,
            mimeType = mimeType,
            sizeBytes = size,
            text = textParts.joinToString("\n").ifBlank { null },
            note = note,
        )
    }

    private fun ingestBinary(
        uri: String,
        fileName: String,
        kind: FileKind,
        mimeType: String?,
        size: Long,
    ): IngestedFile = IngestedFile(
        fileName = fileName,
        uri = uri,
        kind = kind,
        mimeType = mimeType,
        sizeBytes = size,
        text = null,
        note = "Bu ikkilik fayl (tur: ${mimeType ?: "noma'lum"}, hajm: $size bayt). " +
            "Uni matn sifatida o'qib bo'lmaydi, shuning uchun modelga faqat metadata yuborildi.",
    )

    /** Kutilmagan `FileContent` turi uchun zaxira — hech qachon jim tashlab ketmaydi. */
    private fun binaryFallback(
        uri: String,
        fileName: String,
        kind: FileKind,
        mimeType: String?,
        size: Long,
    ): IngestedFile = IngestedFile(
        fileName = fileName,
        uri = uri,
        kind = kind,
        mimeType = mimeType,
        sizeBytes = size,
        text = null,
        note = "faylni o'qib bo'lmadi — faqat metadata yuborildi",
    )
}
