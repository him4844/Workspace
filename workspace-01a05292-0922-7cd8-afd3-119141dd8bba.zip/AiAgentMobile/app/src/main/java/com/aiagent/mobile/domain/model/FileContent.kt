package com.aiagent.mobile.domain.model

/**
 * Fayl mazmunini o'qish natijasi (Faza 2 — preview, Faza 3 — AI konteksti).
 *
 * Faza 3 da kengaytirildi: foydalanuvchi talabiga ko'ra agent HAR QANDAY turdagi
 * fayldan foydalana olishi kerak, shuning uchun rasm va arxiv turlari qo'shildi.
 */
sealed interface FileContent {

    /**
     * Matn fayli. [truncated] = fayl chegaradan katta bo'lgani uchun qisqartirildi
     * (foydalanuvchi tanlovi: "to'liq yuklash + kesish"). [totalBytes] — faylning
     * haqiqiy hajmi, foydalanuvchiga "qancha qismi ko'rsatildi" ni aytish uchun.
     */
    data class Text(
        val content: String,
        val truncated: Boolean,
        val totalBytes: Long = 0L,
    ) : FileContent

    /** Rasm yoki PDF sahifasi — multimodal provider'ga base64 sifatida yuboriladi. */
    data class Image(
        val mimeType: String,
        val base64: String,
        val sizeBytes: Long,
    ) : FileContent

    /** Arxiv (ZIP oilasi) — ichidagi fayllar ro'yxati. */
    data class Archive(val entries: List<ArchiveEntry>) : FileContent

    /** Matn sifatida o'qib bo'lmaydigan ikkilik fayl — faqat metadata uzatiladi. */
    data class Binary(val mimeType: String?, val sizeBytes: Long = 0L) : FileContent

    /** Ruxsat etilgan hajmdan katta (rasmlar uchun). */
    data class TooLarge(val sizeBytes: Long, val maxBytes: Long) : FileContent

    /** O'qib bo'lmadi (ruxsat yo'q, fayl o'chirilgan, I-O xatosi). */
    data class Failed(val reason: String) : FileContent
}

/** Arxiv ichidagi bitta yozuv. */
data class ArchiveEntry(
    val path: String,
    val sizeBytes: Long,
    val isDirectory: Boolean,
)
