package com.aiagent.mobile.domain.tools

import com.aiagent.mobile.domain.repository.DocumentRepository

/**
 * Tool argumentidagi nisbiy yo'lni SAF URI'ga aylantirish (barcha fayl tool'lari uchun).
 *
 * Xavfsizlik: agent faqat tanlangan workspace ichida ishlaydi. `..` segmentlari
 * `DocumentRepository.resolveChild` ichida tashlab yuboriladi, shuning uchun
 * `../../etc/passwd` kabi yo'l ildizdan chiqib keta olmaydi.
 */
object ToolPaths {

    /** Mavjud hujjatni topish. Xato bo'lsa aniq sabab bilan `ToolResult.Error`. */
    suspend fun resolveExisting(
        documents: DocumentRepository,
        context: ToolContext,
        path: String,
    ): Resolved {
        if (path.isBlank()) return Resolved.Failure(toolError("Fayl yo'li bo'sh berildi."))
        val uri = documents.resolveChild(context.rootUri, path)
            ?: return Resolved.Failure(
                toolError(
                    "'$path' topilmadi. Workspace ildiziga nisbatan to'g'ri yo'l yozing " +
                        "(masalan `src/Main.kt`). Mavjud fayllarni `list_directory` bilan ko'ring.",
                ),
            )
        return Resolved.Found(uri)
    }

    /**
     * Yaratish uchun yo'l: fayl mavjud bo'LMASligi kerak, lekin ota papkasi mavjud bo'lishi shart.
     * @return (ota papka URI, fayl nomi)
     */
    suspend fun resolveForCreate(
        documents: DocumentRepository,
        context: ToolContext,
        path: String,
    ): CreateTarget {
        if (path.isBlank()) return CreateTarget.Failure(toolError("Fayl yo'li bo'sh berildi."))

        if (documents.resolveChild(context.rootUri, path) != null) {
            return CreateTarget.Failure(
                toolError(
                    "'$path' allaqachon mavjud. Yangi fayl uchun boshqa nom tanlang yoki " +
                        "`write_file` bilan ustidan yozing.",
                ),
            )
        }

        val normalized = path.replace('\\', '/').trim('/')
        val parentPath = normalized.substringBeforeLast('/', "")
        val fileName = normalized.substringAfterLast('/')
        if (fileName.isBlank()) {
            return CreateTarget.Failure(toolError("Fayl nomi ko'rsatilmagan: '$path'"))
        }

        val parentUri = if (parentPath.isEmpty()) {
            context.rootUri
        } else {
            documents.resolveChild(context.rootUri, parentPath)
                ?: return CreateTarget.Failure(
                    toolError(
                        "'$parentPath' papkasi mavjud emas. Avval papkani yarating " +
                            "yoki mavjud papka yo'lini yozing.",
                    ),
                )
        }
        return CreateTarget.Found(parentUri = parentUri, fileName = fileName)
    }

    /** Fayl matnini o'qish — natija `ToolResult`ga o'ralgan holda. */
    suspend fun readText(
        documents: DocumentRepository,
        context: ToolContext,
        uri: String,
    ): ReadOutcome = when (val content = documents.readTextFile(uri, context.maxFileBytes)) {
        is com.aiagent.mobile.domain.model.FileContent.Text -> ReadOutcome.Text(
            content = content.content,
            truncated = content.truncated,
            totalBytes = content.totalBytes,
        )

        is com.aiagent.mobile.domain.model.FileContent.Binary -> ReadOutcome.NotText(
            toolError(
                "Bu ikkilik fayl (tur: ${content.mimeType ?: "noma'lum"}, " +
                    "hajm: ${content.sizeBytes} bayt) — matn sifatida o'qib bo'lmaydi. " +
                    "Metadata uchun `get_file_info` ishlating.",
            ),
        )

        is com.aiagent.mobile.domain.model.FileContent.TooLarge -> ReadOutcome.NotText(
            toolError(
                "Fayl juda katta (${content.sizeBytes} bayt > ${content.maxBytes}) — o'qilmadi.",
            ),
        )

        is com.aiagent.mobile.domain.model.FileContent.Failed -> ReadOutcome.NotText(
            toolError("Faylni o'qib bo'lmadi: ${content.reason}", recoverable = false),
        )

        else -> ReadOutcome.NotText(
            toolError("Faylni matn sifatida o'qib bo'lmadi.", recoverable = false),
        )
    }

    sealed interface Resolved {
        data class Found(val uri: String) : Resolved
        data class Failure(val error: ToolResult) : Resolved
    }

    sealed interface CreateTarget {
        data class Found(val parentUri: String, val fileName: String) : CreateTarget
        data class Failure(val error: ToolResult) : CreateTarget
    }

    sealed interface ReadOutcome {
        data class Text(val content: String, val truncated: Boolean, val totalBytes: Long) :
            ReadOutcome

        data class NotText(val error: ToolResult) : ReadOutcome
    }
}
