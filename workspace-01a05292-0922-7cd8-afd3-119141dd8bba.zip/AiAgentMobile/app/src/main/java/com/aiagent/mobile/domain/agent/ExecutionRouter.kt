package com.aiagent.mobile.domain.agent

/**
 * Vazifani PHONE yoki COLAB'da bajarishni hal qiluvchi komponent.
 *
 * **Faza 1 da bu faqat interfeys** — haqiqiy (LLM asosidagi) implementatsiya
 * `LlmExecutionRouter` nomi bilan Faza 6 da yoziladi. Maqsad: agent loop
 * boshidanoq routing'ni hisobga olgan holda qurilsin, keyin "yopishtirib" qo'yilmasin.
 *
 * Kutish: shubhali holatlarda `COLAB` qaytariladi (Colab — standart bajarish joyi).
 */
interface ExecutionRouter {
    suspend fun decide(userRequest: String, phoneSpecs: PhoneSpecs): ExecutionTarget
}

/**
 * Telefon resurslari — router qarori uchun kirish ma'lumoti.
 * Faza 6 da `ActivityManager.MemoryInfo` va `Runtime.availableProcessors()`
 * orqali bir marta olinadi va keshlanadi.
 */
data class PhoneSpecs(
    val ramMb: Long,
    val cpuCores: Int,
    val availableStorageMb: Long,
    val deviceModel: String,
)
