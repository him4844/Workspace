package com.aiagent.mobile.domain.usecase

/**
 * API kalitini ekranda ko'rsatish uchun yashirish — sof mantiq (test qilinadi).
 *
 * Spetsifikatsiya talabi: provider ro'yxatida kalitning TO'LIQ matni hech qachon
 * ko'rsatilmasin, faqat oxirgi 4 belgisi (`sk-...a91f` ko'rinishida).
 */
object ApiKeyMasker {

    /** Ko'rsatiladigan belgilar soni (oxirdan). */
    private const val VISIBLE_TAIL = 4

    /** Kalit boshlanishidan ko'rsatiladigan belgilar (turini tanish uchun, masalan "sk-"). */
    private const val VISIBLE_HEAD = 3

    fun mask(apiKey: String): String {
        if (apiKey.isBlank()) return ""
        if (apiKey.length <= VISIBLE_TAIL) return "••••"
        return apiKey.take(VISIBLE_HEAD) + "•••" + apiKey.takeLast(VISIBLE_TAIL)
    }
}
