package com.aiagent.mobile.domain.model

/**
 * Fayl turi — agent fayldan qanday foydalanishini belgilaydi (Faza 3).
 *
 * Foydalanuvchi talabi: "agent tanlangan papkadagi HAR QANDAY turdagi fayldan
 * foydalana olishi kerak". Shuning uchun har bir tur uchun aniq strategiya bor:
 * - TEXT    → matn to'liq o'qiladi (kerak bo'lsa kesiladi)
 * - IMAGE   → base64 ko'rinishida multimodal provider'ga yuboriladi
 * - PDF     → sahifalari rasmga aylantirilib yuboriladi (PdfRenderer)
 * - ARCHIVE → ichidagi fayllar ro'yxati + matnli yozuvlar
 * - BINARY  → aniq metadata (nomi, hajmi, turi) va tushunarli izoh
 */
enum class FileKind { TEXT, IMAGE, PDF, ARCHIVE, BINARY }

/**
 * MIME tur va fayl nomiga qarab turni aniqlash — sof mantiq (test qilinadi).
 *
 * MIME turi ishonchsiz bo'lishi mumkin (SAF ba'zan `application/octet-stream` yoki
 * `null` qaytaradi), shuning uchun kengaytma bo'yicha zaxira tekshiruv ham bor.
 */
object FileKindClassifier {

    fun classify(mimeType: String?, fileName: String): FileKind {
        val mime = mimeType?.lowercase().orEmpty()
        val name = fileName.lowercase()

        if (mime.startsWith("image/")) return FileKind.IMAGE
        if (mime == "application/pdf" || name.endsWith(".pdf")) return FileKind.PDF
        if (mime in ARCHIVE_MIME_TYPES || ARCHIVE_EXTENSIONS.any { name.endsWith(it) }) {
            return FileKind.ARCHIVE
        }
        if (mime.startsWith("text/")) return FileKind.TEXT
        if (mime in JSON_LIKE_MIME_TYPES) return FileKind.TEXT
        if (TEXT_EXTENSIONS.any { name.endsWith(it) }) return FileKind.TEXT

        return FileKind.BINARY
    }

    /** ZIP oilasidagi arxivlar — `java.util.zip` orqali o'qiladi. */
    private val ARCHIVE_MIME_TYPES = setOf(
        "application/zip",
        "application/x-zip",
        "application/x-zip-compressed",
        "application/java-archive",
    )

    private val ARCHIVE_EXTENSIONS = listOf(".zip", ".jar", ".apk", ".aar")

    private val JSON_LIKE_MIME_TYPES = setOf(
        "application/json",
        "application/xml",
        "application/javascript",
        "application/x-sh",
        "application/x-yaml",
        "application/toml",
    )

    /** MIME aniqlanmagan holat uchun kengaytma bo'yicha matn fayllari. */
    private val TEXT_EXTENSIONS = listOf(
        ".txt", ".md", ".markdown", ".json", ".json5", ".xml", ".yaml", ".yml", ".toml",
        ".ini", ".cfg", ".conf", ".properties", ".env", ".csv", ".tsv", ".log",
        ".kt", ".kts", ".java", ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx",
        ".gradle", ".sh", ".bash", ".zsh", ".bat", ".ps1", ".sql", ".html", ".htm",
        ".css", ".scss", ".less", ".c", ".h", ".cpp", ".hpp", ".cc", ".cs", ".go",
        ".rs", ".rb", ".php", ".swift", ".lua", ".r", ".dart", ".vue", ".svelte",
        ".dockerfile", ".gitignore", ".gitattributes", ".editorconfig", ".pro",
    )
}
