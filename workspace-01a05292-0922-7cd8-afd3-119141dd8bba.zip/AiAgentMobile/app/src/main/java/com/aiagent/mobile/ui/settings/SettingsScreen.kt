package com.aiagent.mobile.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.ProviderType
import com.aiagent.mobile.domain.usecase.ApiKeyMasker

/**
 * AI provider sozlamalari ekrani (Faza 3, 1-vazifa).
 *
 * UI/UX talablari (spetsifikatsiya, 11-band) va ularning javobi:
 * - Bo'sh holat: ikonka + tushuntirish + "Provider qo'shish" tugmasi.
 * - Yuklanish: `CircularProgressIndicator` (ro'yxat birinchi marta o'qilganda).
 * - Xato: snackbar orqali aniq xabar (shifrlash muvaffaqiyatsiz, test xatosi...).
 * - Buzuvchi amal (o'chirish): tasdiqlash dialogi.
 * - Teginish maydoni: barcha tugma/ikonka kamida 48dp.
 * - API kalit ro'yxatda faqat `sk-•••a91f` ko'rinishida — to'liq kalit hech qachon yo'q.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val form by viewModel.form.collectAsStateWithLifecycle()
    val colab by viewModel.colab.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var providerToDelete by remember { mutableStateOf<AiProvider?>(null) }
    var isColabGuideOpen by remember { mutableStateOf(false) }
    var isColabRequiredDialogOpen by remember { mutableStateOf(false) }

    // Snackbar matni resurslardan olinadi: `context.getString` chaqiruvi Compose
    // suspend kollektori ichida ham ishlaydi (stringResource esa faqat @Composable'da).
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        viewModel.messages.collect { message ->
            // Bir hodisa (`ColabUrlRequired`) snackbar emas, DIALOG ochadi —
            // uning matni `null` qaytadi.
            val text = message.displayText(context)
            if (text == null) {
                isColabRequiredDialogOpen = true
            } else {
                snackbarHostState.showSnackbar(text)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(
                        modifier = Modifier.size(48.dp),
                        onClick = onNavigateBack,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = stringResource(R.string.common_back),
                        )
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = viewModel::startNewProvider,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_add),
                    contentDescription = stringResource(R.string.settings_add),
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            when {
                state.isLoading -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                )

                else -> LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (state.providers.isEmpty()) {
                        item { EmptyProviders(onAdd = viewModel::startNewProvider) }
                    } else {
                        items(state.providers, key = AiProvider::id) { provider ->
                            ProviderCard(
                                provider = provider,
                                onActivate = { viewModel.activateProvider(provider) },
                                onEdit = { viewModel.startEditProvider(provider) },
                                onDelete = { providerToDelete = provider },
                            )
                        }
                    }
                    // Faza 5: Colab bo'limi ro'yxatning oxirida. Provider bo'lmasa ham
                    // ko'rinadi — ikkalasi bir-biriga bog'liq emas.
                    item {
                        ColabSettingsSection(
                            state = colab,
                            onUrlChange = viewModel::onColabUrlChange,
                            onSave = viewModel::saveColabUrl,
                            onCheck = viewModel::checkColabConnection,
                            onOpenGuide = { isColabGuideOpen = true },
                        )
                    }
                }
            }
        }
    }

    if (state.isFormOpen) {
        ProviderFormSheet(
            form = form,
            isTesting = state.isTesting,
            testResult = state.testResult,
            onDismiss = viewModel::closeForm,
            onNameChange = viewModel::onNameChange,
            onTypeChange = viewModel::onTypeChange,
            onApiBaseChange = viewModel::onApiBaseChange,
            onApiKeyChange = viewModel::onApiKeyChange,
            onModelChange = viewModel::onModelChange,
            onMaxTokensChange = viewModel::onMaxTokensChange,
            onContextLengthChange = viewModel::onContextLengthChange,
            onTemperatureChange = viewModel::onTemperatureChange,
            onMakeActiveChange = viewModel::onMakeActiveChange,
            onTest = viewModel::testConnection,
            onSave = viewModel::save,
        )
    }

    if (isColabGuideOpen) {
        ColabGuideSheet(onDismiss = { isColabGuideOpen = false })
    }

    if (isColabRequiredDialogOpen) {
        ColabRequiredDialog(
            onDismiss = { isColabRequiredDialogOpen = false },
            onOpenGuide = {
                isColabRequiredDialogOpen = false
                isColabGuideOpen = true
            },
        )
    }

    providerToDelete?.let { provider ->
        AlertDialog(
            onDismissRequest = { providerToDelete = null },
            title = { Text(stringResource(R.string.settings_delete_dialog_title)) },
            text = {
                Text(stringResource(R.string.settings_delete_dialog_body, provider.name))
            },
            confirmButton = {
                TextButton(
                    modifier = Modifier.height(48.dp),
                    onClick = {
                        viewModel.deleteProvider(provider)
                        providerToDelete = null
                    },
                ) { Text(stringResource(R.string.common_delete)) }
            },
            dismissButton = {
                TextButton(
                    modifier = Modifier.height(48.dp),
                    onClick = { providerToDelete = null },
                ) { Text(stringResource(R.string.common_cancel)) }
            },
        )
    }
}

@Composable
private fun EmptyProviders(onAdd: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_settings),
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.settings_empty_title),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_empty_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        Button(
            modifier = Modifier.height(48.dp),
            onClick = onAdd,
        ) {
            Icon(painter = painterResource(R.drawable.ic_add), contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.settings_add))
        }
    }
}

@Composable
private fun ProviderCard(
    provider: AiProvider,
    onActivate: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = provider.name,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                )
                AssistChip(
                    onClick = onActivate,
                    enabled = !provider.isDefault,
                    label = {
                        Text(
                            stringResource(
                                if (provider.isDefault) R.string.common_active
                                else R.string.common_inactive,
                            ),
                        )
                    },
                    leadingIcon = if (provider.isDefault) {
                        {
                            Icon(
                                painter = painterResource(R.drawable.ic_check),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    } else {
                        null
                    },
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = providerTypeName(provider.type),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = stringResource(R.string.settings_model_line, provider.model),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            // Xavfsizlik: faqat yashirilgan kalit. To'liq kalit ekranga chiqmaydi.
            Text(
                text = stringResource(
                    R.string.settings_key_line,
                    ApiKeyMasker.mask(provider.apiKey),
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(modifier = Modifier.height(48.dp), onClick = onEdit) {
                    Icon(
                        painter = painterResource(R.drawable.ic_edit),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.settings_edit))
                }
                TextButton(modifier = Modifier.height(48.dp), onClick = onDelete) {
                    Icon(
                        painter = painterResource(R.drawable.ic_delete),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.common_delete))
                }
            }
        }
    }
}

@Composable
internal fun providerTypeName(type: ProviderType): String = stringResource(
    when (type) {
        ProviderType.TOKENROUTER -> R.string.provider_type_tokenrouter
        ProviderType.DEEPSEEK -> R.string.provider_type_deepseek
        ProviderType.CUSTOM -> R.string.provider_type_custom
    },
)
