package com.aiagent.mobile.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import java.util.concurrent.TimeUnit
import javax.inject.Singleton
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

/**
 * Tarmoq qatlami uchun umumiy bog'lanishlar (Faza 3).
 *
 * OkHttpClient BITTA va singleton: ulanishlar havzasi (connection pool) va
 * dispatcher thread'lari barcha provider'lar orasida bo'lishiladi. Har bir
 * provider uchun esa `newBuilder()` orqali faqat interceptor farq qiladi.
 */
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        // LLM javobi sekin kelishi mumkin (uzun kod generatsiyasi) — shuning uchun
        // o'qish vaqti uzunroq. Timeout bo'lsa `AiError.Timeout` sifatida xabar qilinadi.
        .readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .addInterceptor(loggingInterceptor())
        .build()

    /**
     * Xavfsizlik: log darajasi ataylab `BASIC` (faqat metod, URL, kod, vaqt).
     * `HEADERS` yoki `BODY` darajasi `Authorization: Bearer <API KALIT>` sarlavhasini
     * va so'rov matnini logcat'ga yozib qo'yadi — bu kalit sizib chiqishi demak.
     */
    private fun loggingInterceptor(): HttpLoggingInterceptor =
        HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
            redactHeader("Authorization")
        }

    private const val CONNECT_TIMEOUT_SECONDS = 15L
    private const val WRITE_TIMEOUT_SECONDS = 60L
    private const val READ_TIMEOUT_SECONDS = 180L
}
