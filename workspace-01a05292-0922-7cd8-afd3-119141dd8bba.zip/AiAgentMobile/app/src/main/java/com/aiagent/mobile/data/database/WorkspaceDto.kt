package com.aiagent.mobile.data.database

import com.aiagent.mobile.domain.model.Workspace
import kotlinx.serialization.Serializable

/**
 * DataStore'ga yoziladigan workspace yozuvi (wire-format).
 *
 * Faza 1 dagi 1-qarorga ko'ra domen modellari `@Serializable` emas — saqlash formati
 * shu DTO orqali domen'dan ajratilgan. Keyin domen modeli o'zgarsa, bu DTO orqali
 * eski saqlangan ma'lumotni migratsiya qilish mumkin bo'ladi.
 */
@Serializable
data class WorkspaceDto(
    val id: String,
    val name: String,
    val uri: String,
    val lastOpenedAt: Long,
) {
    fun toDomain(): Workspace = Workspace(
        id = id,
        name = name,
        uri = uri,
        lastOpenedAt = lastOpenedAt,
    )

    companion object {
        fun fromDomain(workspace: Workspace) = WorkspaceDto(
            id = workspace.id,
            name = workspace.name,
            uri = workspace.uri,
            lastOpenedAt = workspace.lastOpenedAt,
        )
    }
}

/** Bitta kalit ostida saqlanadigan ro'yxat. */
@Serializable
data class WorkspaceListDto(val items: List<WorkspaceDto> = emptyList())
