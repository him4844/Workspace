package com.aiagent.mobile.data.database

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aiagent.mobile.domain.model.Workspace
import com.aiagent.mobile.domain.repository.WorkspaceRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.workspaceDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "workspaces",
)

/**
 * Workspace'lar DataStore Preferences'da, bitta JSON kalitida saqlanadi.
 *
 * QAROR: Proto DataStore emas, oddiy JSON tanlandi — yozuvlar soni kam (bir necha workspace),
 * shuning uchun proto sxemasining murakkabligi o'zini oqlamaydi. JSON buzilsa, ro'yxat
 * bo'sh deb hisoblanadi (ilova crash bo'lmaydi).
 */
@Singleton
class WorkspaceRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : WorkspaceRepository {

    private val json = Json { ignoreUnknownKeys = true }

    override fun observeWorkspaces(): Flow<List<Workspace>> =
        context.workspaceDataStore.data
            .catch { throwable ->
                // Fayl o'qilmaydigan holatda (buzilgan/kirish xatosi) bo'sh ro'yxat qaytaramiz.
                // Foydalanuvchi workspace'ni qayta tanlashi mumkin; ilova ishdan chiqmaydi.
                if (throwable is IOException) emit(emptyPreferences()) else throw throwable
            }
            .map { preferences -> decode(preferences[KEY_WORKSPACES]) }

    override suspend fun addWorkspace(workspace: Workspace) {
        mutate { current ->
            val index = current.indexOfFirst { it.uri == workspace.uri }
            if (index >= 0) {
                // Shu papka allaqachon saqlangan — duplikat yaratmaymiz, mavjudini yangilaymiz.
                current.toMutableList().also { list ->
                    list[index] = workspace.copy(id = list[index].id)
                }
            } else {
                current + workspace
            }
        }
    }

    override suspend fun removeWorkspace(id: String) {
        mutate { current -> current.filterNot { it.id == id } }
    }

    override suspend fun touchWorkspace(id: String) {
        mutate { current ->
            current.map { if (it.id == id) it.copy(lastOpenedAt = System.currentTimeMillis()) else it }
        }
    }

    override suspend fun findWorkspace(id: String): Workspace? =
        // Diqqat: kotlinx.coroutines.flow'da `firstOrNull(predicate)` YO'Q — avval Flow'dan
        // ro'yxatni olamiz (`first()`), keyin ro'yxat ustida predicate'li firstOrNull ishlaydi.
        observeWorkspaces().first().firstOrNull { workspace -> workspace.id == id }

    private suspend fun mutate(transform: (List<Workspace>) -> List<Workspace>) {
        context.workspaceDataStore.edit { preferences ->
            val current = decode(preferences[KEY_WORKSPACES])
            preferences[KEY_WORKSPACES] = encode(transform(current))
        }
    }

    private fun decode(raw: String?): List<Workspace> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            json.decodeFromString(WorkspaceListDto.serializer(), raw)
                .items
                .map(WorkspaceDto::toDomain)
                .sortedByDescending(Workspace::lastOpenedAt)
        }.getOrElse { emptyList() }
    }

    private fun encode(workspaces: List<Workspace>): String =
        json.encodeToString(
            WorkspaceListDto.serializer(),
            WorkspaceListDto(items = workspaces.map(WorkspaceDto::fromDomain)),
        )

    private companion object {
        val KEY_WORKSPACES = stringPreferencesKey("workspace_list_json")
    }
}
