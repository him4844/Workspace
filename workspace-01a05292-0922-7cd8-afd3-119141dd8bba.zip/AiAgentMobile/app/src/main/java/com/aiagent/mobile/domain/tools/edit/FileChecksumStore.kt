package com.aiagent.mobile.domain.tools.edit

import java.security.MessageDigest

/**
 * Fayl checksum'lari — "fayl AI o'qigandan keyin tashqaridan o'zgarganmi?" tekshiruvi
 * (Faza 4, 4-vazifa).
 *
 * Nima uchun kerak: agent faylni o'qiydi, patch tayyorlaydi, keyin yozadi. Agar
 * orada foydalanuvchi (yoki boshqa ilova) faylni o'zgartirgan bo'lsa, patch eski
 * matn ustiga qo'llanadi va natija buziladi. Shuning uchun `read_file` checksum
 * yozib qo'yadi, yozishdan oldin esa hozirgi checksum solishtiriladi — farq bo'lsa
 * CONFLICT qaytadi va agent faylni qayta o'qishga majbur bo'ladi.
 *
 * SHA-256 tanlandi: JVM'ning o'zida bor (yangi kutubxona yo'q), to'qnashuv ehtimoli
 * amalda nol. `domain` qatlami uchun ham toza — `java.security` Android'ga bog'liq emas.
 */
class FileChecksumStore {

    private val checksums = mutableMapOf<String, String>()

    /** Fayl o'qilganda chaqiriladi. */
    fun record(path: String, content: String) {
        checksums[normalize(path)] = checksumOf(content)
    }

    /** Fayl yozilgandan keyin yangi checksum yoziladi (keyingi tahrir uchun). */
    fun updateAfterWrite(path: String, newContent: String) = record(path, newContent)

    fun recorded(path: String): String? = checksums[normalize(path)]

    fun forget(path: String) {
        checksums.remove(normalize(path))
    }

    fun clear() = checksums.clear()

    fun checksumOf(content: String): String {
        val digest = MessageDigest.getInstance(ALGORITHM)
        val bytes = digest.digest(content.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { byte -> "%02x".format(byte) }
    }

    /**
     * Yo'lni yagona ko'rinishga keltirish: `./src/a.kt` va `src/a.kt` bitta kalit bo'lishi
     * kerak, aks holda conflict tekshiruvi ishlamay qoladi.
     */
    private fun normalize(path: String): String =
        path.replace('\\', '/').trim('/').split('/')
            .filter { it.isNotEmpty() && it != "." }
            .joinToString("/")

    private companion object {
        const val ALGORITHM = "SHA-256"
    }
}
