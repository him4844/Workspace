package com.aiagent.mobile.domain.usecase

/**
 * Token sonini taxmin qilish — sof mantiq (test qilinadi).
 *
 * Aniq tokenizator provider'ga bog'liq (BPE, SentencePiece...) va telefonda
 * og'ir. Shuning uchun oddiy va xavfsiz tarafdagi formula ishlatiladi:
 * ingliz lotin matnida ~4 belgi/token, kirill/o'zbek matnida belgi/token nisbati
 * kichikroq, shuning uchun 3.0 koeffitsienti tanlandi — bu kamroq belgini
 * sig'diradi va kontekst oynasini ochirib yubormaydi.
 */
object TokenEstimator {

    private const val CHARS_PER_TOKEN = 3.0

    /** Matn uzunligidan taxminiy token soni (yuqoriga yaxlitlanadi). */
    fun estimateTokens(text: String): Int =
        kotlin.math.ceil(text.length / CHARS_PER_TOKEN).toInt()

    /** Token byudjetiga sig'adigan belgilar soni. */
    fun charsForTokens(tokens: Int): Int = (tokens * CHARS_PER_TOKEN).toInt()

    /**
     * Matnni taxminan [maxTokens] token sig'adigan qismgacha kesadi.
     * Kesilgan bo'lsa, oxiriga aniq belgi qo'shiladi — model "matn tugadi" deb
     * adashmasligi kerak.
     */
    fun truncateToTokens(text: String, maxTokens: Int): TruncatedText {
        if (maxTokens <= 0) return TruncatedText("", true)
        val limit = charsForTokens(maxTokens)
        if (text.length <= limit) return TruncatedText(text, false)

        // So'z o'rtasidan kesmaslik uchun oxirgi bo'shliqgacha qaytamiz.
        val cutAt = text.lastIndexOf(' ', limit).takeIf { it > limit / 2 } ?: limit
        return TruncatedText(text.substring(0, cutAt), true)
    }

    data class TruncatedText(val text: String, val truncated: Boolean)
}
