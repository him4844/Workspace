package com.aiagent.mobile.di

import com.aiagent.mobile.data.ai.AiChatRepositoryImpl
import com.aiagent.mobile.data.colab.ColabExecutionEngine
import com.aiagent.mobile.data.database.SettingsRepositoryImpl
import com.aiagent.mobile.data.database.WorkspaceRepositoryImpl
import com.aiagent.mobile.data.filesystem.SafDocumentRepository
import com.aiagent.mobile.domain.agent.RemoteExecutionEngine
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.repository.SettingsRepository
import com.aiagent.mobile.domain.repository.WorkspaceRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Domen interfeyslarini data-layer implementatsiyalariga bog'laydi.
 * Faza 2: workspace + SAF. Faza 3: provider sozlamalari + AI chat.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindWorkspaceRepository(impl: WorkspaceRepositoryImpl): WorkspaceRepository

    @Binds
    @Singleton
    abstract fun bindDocumentRepository(impl: SafDocumentRepository): DocumentRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository

    @Binds
    @Singleton
    abstract fun bindAiChatRepository(impl: AiChatRepositoryImpl): AiChatRepository

    /**
     * Faza 1 da yaratilgan `RemoteExecutionEngine` interfeysining haqiqiy bog'lanishi.
     * Colab serveri bilan ishlash — `data/colab/ColabExecutionEngine`.
     */
    @Binds
    @Singleton
    abstract fun bindRemoteExecutionEngine(impl: ColabExecutionEngine): RemoteExecutionEngine
}
