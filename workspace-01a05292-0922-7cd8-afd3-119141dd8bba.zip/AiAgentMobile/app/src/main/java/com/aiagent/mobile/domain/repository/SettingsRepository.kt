package com.aiagent.mobile.domain.repository

import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AppSettings
import kotlinx.coroutines.flow.Flow

/**
 * Provider va ilova sozlamalarini saqlash (Faza 3).
 *
 * Xavfsizlik: `apiKey` diskka ochiq holda YOZILMAYDI — implementatsiya
 * (`data/database/SettingsRepositoryImpl`) uni Android Keystore kaliti bilan
 * AES/GCM orqali shifrlaydi. Domen qatlami esa kalitni ochiq ko'radi, chunki
 * uni HTTP sarlavhasiga qo'yish kerak.
 *
 * Implementatsiya: `data/database/SettingsRepositoryImpl`.
 */
interface SettingsRepository {

    val providers: Flow<List<AiProvider>>

    val settings: Flow<AppSettings>

    suspend fun saveProvider(provider: AiProvider)

    suspend fun deleteProvider(providerId: String)

    /** Birinchi saqlangan provider avtomatik faol bo'ladi (ro'yxat bo'sh bo'lmaganda). */
    suspend fun setActiveProvider(providerId: String)

    suspend fun updateSettings(settings: AppSettings)

    /** Joriy faol provider. Bittasi ham faol bo'lmasa — birinchi provider. */
    suspend fun activeProvider(): AiProvider?
}
