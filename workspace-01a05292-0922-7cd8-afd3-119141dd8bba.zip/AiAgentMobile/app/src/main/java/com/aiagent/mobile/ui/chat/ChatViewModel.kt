package com.aiagent.mobile.ui.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.model.IngestedFile
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.domain.agent.AgentController
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.repository.SettingsRepository
import com.aiagent.mobile.domain.repository.WorkspaceRepository
import com.aiagent.mobile.domain.usecase.FileContextBuilder
import com.aiagent.mobile.domain.usecase.HistoryWindow
import com.aiagent.mobile.domain.usecase.IngestAttachmentUseCase
import com.aiagent.mobile.domain.usecase.TokenEstimator
import com.aiagent.mobile.domain.tools.ToolResult
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Chat ekrani mantiqi (Faza 3, 4-6 vazifalar).
 *
 * Oqim: foydalanuvchi xabar yozadi -> biriktirilgan fayllar o'qiladi va kontekst
 * blokiga aylantiriladi -> tarix byudjetga sig'adigan qismgacha qisqartiriladi ->
 * OpenAI-mos `/chat/completions` chaqiriladi (streaming yo'q) -> javob ko'rsatiladi.
 *
 * Suhbat tarixi hozircha FAQAT xotirada (qayta ochilganda yo'qoladi) — doimiy
 * saqlash Faza 10 rejasida.
 */
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val chatRepository: AiChatRepository,
    private val ingestAttachment: IngestAttachmentUseCase,
    private val agentController: AgentController,
    private val workspaceRepository: WorkspaceRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    /**
     * Agent sikli bilan ko'prik (Faza 4).
     * Agent javobi chat tarixiga oddiy assistant xabari sifatida yoziladi —
     * foydalanuvchi uchun ikki xil suhbat yo'q, faqat bitta chat bor.
     *
     * **Tartib muhim:** `agentDelegate` AVVAL e'lon qilinadi, chunki Kotlin
     * xossa initsializatorlari e'lon tartibida bajariladi. Teskari tartibda
     * keyingi `= null` yozuvi delegatni o'chirib yuborardi.
     */
    private val agentDelegate = AgentChatDelegate(
        scope = viewModelScope,
        agent = agentController,
        workspaces = workspaceRepository,
        onFinalAnswer = ::onAgentAnswer,
        onError = ::onAgentError,
        onUndoResult = ::onUndoResult,
    )

    /** Agent paneli uchun holat (ChatScreen buni alohida kuzatadi). */
    val agentUi: StateFlow<AgentChatUi> = agentDelegate.ui

    /** O'qib bo'lingan fayllar (xotirada) — har xabarda qayta o'qimaymiz. */
    private val ingestedFiles = mutableListOf<IngestedFile>()

    /** Xato bo'lgan so'rov — "Qayta urinish" uchun saqlanadi. */
    private var failedRequest: PendingRequest? = null

    init {
        viewModelScope.launch {
            settingsRepository.providers.collect { providers ->
                val active = providers.firstOrNull { it.isDefault } ?: providers.firstOrNull()
                _uiState.update { it.copy(isLoadingProvider = false, activeProvider = active) }
            }
        }
        viewModelScope.launch {
            settingsRepository.settings.collect { settings ->
                _uiState.update { it.copy(settings = settings) }
            }
        }
    }

    /** Chat qaysi workspace ichida ochilganini aytish (agent tool'lari shunga bog'lanadi). */
    fun bindWorkspace(workspaceId: String) {
        agentDelegate.bindWorkspace(workspaceId)
    }

    /**
     * Fayl daraxtidan kelgan URI'larni o'qish (6-vazifa).
     * Har bir fayl turi bo'yicha alohida strategiya: `IngestAttachmentUseCase`.
     */
    fun attachFiles(uris: List<String>) {
        val newUris = uris.filter { uri -> ingestedFiles.none { it.uri == uri } }
        if (newUris.isEmpty()) return

        _uiState.update { it.copy(isPreparingFiles = true) }
        viewModelScope.launch {
            val limits = IngestAttachmentUseCase.Limits(
                maxTextBytes = _uiState.value.settings?.maxFileContextSizeBytes ?: DEFAULT_TEXT_BYTES,
            )
            newUris.forEach { uri ->
                val name = displayName(uri)
                val ingested = ingestAttachment.ingest(uri = uri, fileName = name, limits = limits)
                ingestedFiles += ingested
                _uiState.update { state ->
                    state.copy(
                        attachedFiles = state.attachedFiles + AttachedFileUi(
                            uri = uri,
                            fileName = ingested.fileName,
                            kind = ingested.kind,
                            sizeBytes = ingested.sizeBytes,
                            hasImages = ingested.images.isNotEmpty(),
                            note = ingested.note,
                        ),
                    )
                }
            }
            _uiState.update { it.copy(isPreparingFiles = false) }
        }
    }

    fun removeAttachment(uri: String) {
        ingestedFiles.removeAll { it.uri == uri }
        _uiState.update { state ->
            state.copy(attachedFiles = state.attachedFiles.filterNot { it.uri == uri })
        }
    }

    fun onInputChange(value: String) = _uiState.update { it.copy(input = value) }

    fun send() {
        val state = _uiState.value
        val text = state.input.trim()
        if (text.isEmpty() || state.isSending) return
        val provider = state.activeProvider ?: return

        val (messages, images, warnings) = buildRequest(text, provider)

        _uiState.update { current ->
            current.copy(
                input = "",
                isSending = true,
                error = null,
                contextWarnings = warnings,
                messages = current.messages + ChatUiMessage(
                    id = UUID.randomUUID().toString(),
                    role = MessageRole.USER,
                    content = text,
                    attachedFileNames = current.attachedFiles.map(AttachedFileUi::fileName),
                ),
            )
        }

        // Faza 4: agent rejimi yoqilgan va workspace mavjud bo'lsa, so'rov agent
        // sikliga ketadi (AI tool tanlaydi). Aks holda Faza 3 dagi oddiy chat ishlaydi.
        if (tryStartAgent(text, provider)) return

        failedRequest = PendingRequest(text = text, messages = messages, images = images)
        viewModelScope.launch { deliver(provider, messages, images) }
    }

    /** Agent siklini boshlashga urinish. `false` = oddiy chat yo'li davom etadi. */
    private fun tryStartAgent(text: String, provider: AiProvider): Boolean {
        val delegate = agentDelegate
        val state = agentUi.value
        if (!state.available || !state.isAgentMode) return false
        if (delegate.isBusy()) return false

        val attachmentBudget = (provider.contextLength * ATTACHMENT_BUDGET_RATIO).toInt()
        val context = FileContextBuilder.build(ingestedFiles, attachmentBudget)
        val history = _uiState.value.messages
            // Oxirida yangi yozilgan USER xabari ham bor — uni agent so'rovi qaytaradi.
            .dropLast(1)
            .toAgentHistory()

        val started = delegate.start(
            AgentLaunch(
                provider = provider,
                settings = _uiState.value.settings,
                userMessage = text,
                history = history,
                attachmentContext = context.text,
            ),
        )
        if (!started) return false
        // Agent sikli tugagach javob `onAgentAnswer` orqali keladi.
        failedRequest = null
        return true
    }

    private fun onAgentAnswer(answer: String) {
        _uiState.update { state ->
            state.copy(
                isSending = false,
                error = null,
                messages = state.messages.dropLastWhile(ChatUiMessage::isError) + ChatUiMessage(
                    id = UUID.randomUUID().toString(),
                    role = MessageRole.ASSISTANT,
                    content = answer,
                ),
            )
        }
        failedRequest = null
    }

    private fun onAgentError(error: AiError) {
        _uiState.update { state ->
            state.copy(
                isSending = false,
                error = error,
                messages = state.messages + ChatUiMessage(
                    id = UUID.randomUUID().toString(),
                    role = MessageRole.SYSTEM,
                    content = "",
                    isError = true,
                ),
            )
        }
    }

    // ------------------------------------------------- agent amallari (UI dan)

    fun toggleAgentMode() = agentDelegate.toggleAgentMode()

    fun stopAgent() {
        agentDelegate.stop()
        _uiState.update { it.copy(isSending = false) }
    }

    fun approveEdit() = agentDelegate.approveEdit()

    fun rejectEdit() = agentDelegate.rejectEdit()

    fun undoLastEdit() = agentDelegate.undoLastEdit()

    private fun onUndoResult(result: ToolResult) {
        val text = when (result) {
            is ToolResult.Success -> result.output
            is ToolResult.Error -> result.message
            is ToolResult.PermissionRequired -> result.description
        }
        _uiState.update { state ->
            state.copy(
                messages = state.messages + ChatUiMessage(
                    id = UUID.randomUUID().toString(),
                    role = MessageRole.SYSTEM,
                    content = text,
                    isError = result is ToolResult.Error,
                ),
            )
        }
    }

    /** Xato bo'lgan oxirgi so'rovni qayta yuborish. */
    fun retry() {
        val pending = failedRequest ?: return
        val provider = _uiState.value.activeProvider ?: return
        _uiState.update { it.copy(isSending = true, error = null) }
        viewModelScope.launch { deliver(provider, pending.messages, pending.images) }
    }

    private suspend fun deliver(
        provider: AiProvider,
        messages: List<AiRequestMessage>,
        images: List<IngestedImage>,
    ) {
        when (val result = chatRepository.complete(provider, messages, images)) {
            is AiResult.Success -> {
                val tokens = result.response.promptTokens?.let { prompt ->
                    result.response.completionTokens?.let { prompt + it }
                }
                _uiState.update { state ->
                    state.copy(
                        isSending = false,
                        // "Qayta urinish" muvaffaqiyatli bo'lsa, oxiridagi xato kartasi
                        // o'chiriladi — aks holda javob eski xato ostida paydo bo'ladi.
                        messages = state.messages.dropLastWhile(ChatUiMessage::isError) + ChatUiMessage(
                            id = UUID.randomUUID().toString(),
                            role = MessageRole.ASSISTANT,
                            content = result.response.content,
                            model = result.response.model,
                            totalTokens = tokens,
                        ),
                    )
                }
                failedRequest = null
            }

            is AiResult.Failure -> {
                if (result.error is AiError.VisionUnsupported && images.isNotEmpty()) {
                    // "Graceful" strategiya: rasmlarni olib tashlab, metadata bilan
                    // qayta yuboramiz va foydalanuvchiga ANIQ aytamiz.
                    _uiState.update { state ->
                        state.copy(
                            contextWarnings = state.contextWarnings + WARNING_VISION,
                        )
                    }
                    failedRequest = PendingRequest(
                        text = failedRequest?.text.orEmpty(),
                        messages = messages,
                        images = emptyList(),
                    )
                    deliver(provider, messages, emptyList())
                    return
                }
                _uiState.update { state ->
                    state.copy(
                        isSending = false,
                        error = result.error,
                        messages = state.messages + ChatUiMessage(
                            id = UUID.randomUUID().toString(),
                            role = MessageRole.SYSTEM,
                            content = "",
                            isError = true,
                        ),
                    )
                }
            }
        }
    }

    /** Xabar + fayl konteksti + tarixdan so'rov yig'ish. */
    private fun buildRequest(
        text: String,
        provider: AiProvider,
    ): Triple<List<AiRequestMessage>, List<IngestedImage>, List<Warning>> {
        val warnings = mutableListOf<Warning>()

        // Fayllar uchun byudjet: kontekstning 60% (qolgani tarix va javob uchun).
        val attachmentBudget = (provider.contextLength * ATTACHMENT_BUDGET_RATIO).toInt()
        val context = FileContextBuilder.build(ingestedFiles, attachmentBudget)
        if (context.warnings.isNotEmpty()) {
            warnings += Warning.TruncatedFiles(context.warnings)
        }

        val userContent = buildString {
            append(text)
            if (context.text.isNotBlank()) {
                append("\n\n[Kontekst: foydalanuvchi biriktirgan fayllar]\n")
                append(context.text)
            }
        }

        val history = _uiState.value.messages
            .filter { !it.isError }
            .map { AiRequestMessage(role = it.role, content = it.content) }

        val usedTokens = TokenEstimator.estimateTokens(userContent)
        val historyBudget = provider.contextLength - provider.maxTokens - usedTokens
        val windowedHistory = HistoryWindow.fit(history, historyBudget)
        if (windowedHistory.size < history.size) {
            warnings += Warning.HistoryTrimmed(history.size - windowedHistory.size)
        }

        return Triple(
            windowedHistory + AiRequestMessage(role = MessageRole.USER, content = userContent),
            context.images,
            warnings,
        )
    }

    /** SAF hujjat URI'sidan ko'rsatiladigan nom. */
    private fun displayName(uri: String): String {
        val decoded = if (uri.contains('%')) Uri.decode(uri) else uri
        val lastSegment = runCatching { Uri.parse(decoded).lastPathSegment }.getOrNull()
        return (lastSegment ?: decoded).substringAfterLast('/').ifBlank { "noma'lum fayl" }
    }

    private data class PendingRequest(
        val text: String,
        val messages: List<AiRequestMessage>,
        val images: List<IngestedImage>,
    )

    private companion object {
        const val ATTACHMENT_BUDGET_RATIO = 0.6f
        const val DEFAULT_TEXT_BYTES = 100_000
        val WARNING_VISION = Warning.VisionUnsupported
    }
}
