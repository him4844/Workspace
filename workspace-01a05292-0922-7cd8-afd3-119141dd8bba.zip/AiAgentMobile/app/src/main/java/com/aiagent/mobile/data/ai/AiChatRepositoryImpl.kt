package com.aiagent.mobile.data.ai

import com.aiagent.mobile.data.ai.dto.ChatCompletionRequest
import com.aiagent.mobile.data.ai.dto.ChatCompletionResponse
import com.aiagent.mobile.data.ai.dto.ChatMessageDto
import com.aiagent.mobile.data.ai.dto.ToolCallDto
import com.aiagent.mobile.data.ai.dto.ToolCallFunctionDto
import com.aiagent.mobile.data.ai.dto.ToolDto
import com.aiagent.mobile.data.ai.dto.ToolFunctionDto
import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.AiResponse
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.IngestedImage
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.domain.model.ToolCallRequest
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.tools.ParamType
import com.aiagent.mobile.domain.tools.ToolSpec
import com.aiagent.mobile.domain.usecase.ApiBaseNormalizer
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

/**
 * OpenAI-mos provider'lar bilan ishlash (Faza 3).
 *
 * Har bir provider'ning `apiBase` manzili har xil, shuning uchun Retrofit nusxasi
 * manzil bo'yicha keshlanadi — lekin OkHttpClient BITTA (ulanishlar havzasi va
 * timeout sozlamalari umumiy).
 *
 * Streaming yo'q (spetsifikatsiya talabi): `stream = false` va oddiy `suspend` chaqiruv.
 */
@Singleton
class AiChatRepositoryImpl @Inject constructor(
    private val httpClient: OkHttpClient,
) : AiChatRepository {

    private val json = Json {
        ignoreUnknownKeys = true
        // `null` maydonlarni yubormaslik: ba'zi serverlar `"max_tokens": null` ni xato deb biladi.
        explicitNulls = false
        // Standart qiymatlarni HAM yozish: aks holda `stream = false` simga umuman
        // chiqmaydi (kotlinx.serialization standart qiymatlarni tashlab ketadi) va
        // "streaming yo'q" qarori faqat kodda qolib, so'rovda ko'rinmaydi.
        encodeDefaults = true
    }

    private val services = ConcurrentHashMap<String, OpenAiChatApi>()

    override suspend fun complete(
        provider: AiProvider,
        messages: List<AiRequestMessage>,
        images: List<IngestedImage>,
        tools: List<ToolSpec>,
    ): AiResult = execute(
        provider = provider,
        messages = messages,
        images = images,
        tools = tools,
        maxTokens = provider.maxTokens,
    )

    override suspend fun testConnection(provider: AiProvider): AiResult = execute(
        provider = provider,
        messages = listOf(AiRequestMessage(role = MessageRole.USER, content = "ping")),
        images = emptyList(),
        // Test paytida tool yuborilmaydi — aks holda model `ping` ga tool chaqiruvi
        // bilan javob berishi mumkin va "ulanish ishlaydi" tekshiruvi noto'g'ri bo'ladi.
        tools = emptyList(),
        // Qisqa javob — test uchun bitta token ham yetarli, shuning uchun pul tejaldi.
        maxTokens = TEST_MAX_TOKENS,
    )

    private suspend fun execute(
        provider: AiProvider,
        messages: List<AiRequestMessage>,
        images: List<IngestedImage>,
        tools: List<ToolSpec>,
        maxTokens: Int,
    ): AiResult {
        val apiBase = ApiBaseNormalizer.normalize(provider.apiBase)
            ?: return AiResult.Failure(
                AiError.InvalidConfig("API manzil noto'g'ri: '${provider.apiBase}'"),
            )
        if (provider.apiKey.isBlank()) {
            return AiResult.Failure(AiError.InvalidConfig("API kalit kiritilmagan"))
        }
        if (provider.model.isBlank()) {
            return AiResult.Failure(AiError.InvalidConfig("Model nomi kiritilmagan"))
        }

        val request = ChatCompletionRequest(
            model = provider.model,
            messages = messages.map { it.toDto(images) },
            maxTokens = maxTokens.takeIf { it > 0 },
            temperature = provider.temperature,
            stream = false,
            // Tool yo'q bo'lsa `tools` maydoni umuman yuborilmaydi: ba'zi providerlar
            // bo'sh massivni ham xato deb hisoblaydi.
            tools = tools.takeIf { it.isNotEmpty() }?.map { spec -> spec.toDto() },
        )

        return try {
            val response = serviceFor(apiBase, provider.apiKey).chatCompletions(request)
            mapResponse(response)
        } catch (timeout: SocketTimeoutException) {
            AiResult.Failure(AiError.Timeout)
        } catch (ioException: IOException) {
            AiResult.Failure(mapIoException(ioException))
        } catch (exception: Exception) {
            AiResult.Failure(AiError.Unknown(exception.message ?: exception.javaClass.simpleName))
        }
    }

    private fun serviceFor(apiBase: String, apiKey: String): OpenAiChatApi =
        // Kesh kalitida API kalit ham bor: foydalanuvchi kalitni o'zgartirsa,
        // eski kalit bilan qurilgan interceptor ishlatilib qolmasligi kerak.
        services.getOrPut("$apiBase|$apiKey") {
            Retrofit.Builder()
                .baseUrl(apiBase)
                .client(
                    httpClient.newBuilder()
                        .addInterceptor { chain ->
                            val request = chain.request().newBuilder()
                                .header(HEADER_AUTHORIZATION, "Bearer $apiKey")
                                .header(HEADER_CONTENT_TYPE, CONTENT_TYPE_JSON)
                                .build()
                            chain.proceed(request)
                        }
                        .build(),
                )
                .addConverterFactory(json.asConverterFactory(CONTENT_TYPE_JSON.toMediaType()))
                .build()
                .create(OpenAiChatApi::class.java)
        }

    private fun mapResponse(response: Response<ChatCompletionResponse>): AiResult {
        if (!response.isSuccessful) {
            val detail = readErrorDetail(response)
            val error = when (response.code()) {
                401, 403 -> AiError.Unauthorized
                429 -> AiError.RateLimited
                400, 422 -> if (looksLikeVisionRejection(detail)) {
                    AiError.VisionUnsupported(detail)
                } else {
                    AiError.Server(response.code(), detail)
                }

                else -> AiError.Server(response.code(), detail)
            }
            return AiResult.Failure(error)
        }

        val body = response.body()
            ?: return AiResult.Failure(AiError.InvalidResponse("Javob tanasi bo'sh"))

        body.error?.let { serverError ->
            val detail = serverError.message ?: serverError.type ?: "server xatosi"
            return AiResult.Failure(
                if (looksLikeVisionRejection(detail)) AiError.VisionUnsupported(detail)
                else AiError.InvalidResponse(detail),
            )
        }

        val message = body.choices.firstOrNull()?.message
        val content = message?.content.orEmpty()
        val toolCalls = message?.toolCalls.orEmpty().mapNotNull { call -> call.toDomain() }

        // MUHIM (Faza 4): tool-calling'da model ko'pincha HECH QANDAY matn yozmaydi,
        // faqat tool_calls qaytaradi. Shuning uchun avval tool chaqiruvlari tekshiriladi —
        // aks holda oddiy agent so'rovi "bo'sh javob" deb xato hisoblanardi.
        if (content.isBlank() && toolCalls.isEmpty()) {
            return AiResult.Failure(
                AiError.InvalidResponse("Model bo'sh javob qaytardi (choices bo'sh yoki matn yo'q)"),
            )
        }

        return AiResult.Success(
            AiResponse(
                content = content,
                model = body.model,
                promptTokens = body.usage?.promptTokens,
                completionTokens = body.usage?.completionTokens,
                toolCalls = toolCalls,
            ),
        )
    }

    private fun readErrorDetail(response: Response<ChatCompletionResponse>): String? {
        val raw = runCatching { response.errorBody()?.string() }.getOrNull()
        if (raw.isNullOrBlank()) return null

        // Ko'p providerlar xatoni ham OpenAI sxemasida qaytaradi — xabarni ajratib olamiz.
        val parsed = runCatching {
            json.decodeFromString(ChatCompletionResponse.serializer(), raw)
        }.getOrNull()
        val message = parsed?.error?.message
        return message ?: raw.take(MAX_ERROR_DETAIL_CHARS)
    }

    private fun mapIoException(ioException: IOException): AiError = when (ioException) {
        // Ulana olmadi: DNS ishlamadi (tarmoq o'chiq) yoki manzil yopiq.
        is UnknownHostException -> AiError.NoNetwork
        is ConnectException -> AiError.NoNetwork
        else -> AiError.Unknown(ioException.message ?: ioException.javaClass.simpleName)
    }

    /**
     * Provider rasmlarni qabul qilmasligini 400 javobidagi matndan aniqlash.
     * Bu — "graceful" strategiyaning amaliy qismi: aniqlansa, UI aniq xabar
     * ko'rsatadi va so'rov rasmsiz qayta yuboriladi.
     */
    private fun looksLikeVisionRejection(detail: String?): Boolean {
        if (detail.isNullOrBlank()) return false
        val lowered = detail.lowercase()
        return VISION_REJECTION_HINTS.any { lowered.contains(it) }
    }

    /** Domen xabarini OpenAI DTO'ga aylantirish. Rasmlar bor bo'lsa — vision formati. */
    private fun AiRequestMessage.toDto(images: List<IngestedImage>): ChatMessageDto {
        // Tool natijasi: `role: "tool"` + `tool_call_id`. Content har doim oddiy matn.
        if (role == MessageRole.TOOL) {
            return ChatMessageDto(
                role = role.wireValue(),
                content = JsonPrimitive(content),
                toolCallId = toolCallId,
            )
        }

        // Assistant + tool chaqiruvi: OpenAI shu xabarni tool natijasidan OLDIN talab qiladi.
        if (role == MessageRole.ASSISTANT && toolCalls.isNotEmpty()) {
            return ChatMessageDto(
                role = role.wireValue(),
                // Matn bo'sh bo'lsa `content` yuborilmaydi (explicitNulls = false),
                // bu OpenAI sxemasiga mos — tool_calls li xabarda content shart emas.
                content = content.takeIf { it.isNotBlank() }?.let(::JsonPrimitive),
                toolCalls = toolCalls.map { call ->
                    ToolCallDto(
                        id = call.id,
                        type = "function",
                        function = ToolCallFunctionDto(
                            name = call.name,
                            arguments = json.encodeToString(
                                JsonObject.serializer(),
                                JsonObject(
                                    call.arguments.mapValues { (_, value) -> JsonPrimitive(value) },
                                ),
                            ),
                        ),
                    )
                },
            )
        }

        val attachImages = role == MessageRole.USER && images.isNotEmpty()
        val contentElement = if (!attachImages) {
            JsonPrimitive(content)
        } else {
            buildJsonArray {
                add(buildJsonObject { put("type", "text"); put("text", content) })
                images.forEach { image ->
                    add(
                        buildJsonObject {
                            put("type", "image_url")
                            put(
                                "image_url",
                                buildJsonObject {
                                    put(
                                        "url",
                                        "data:${image.mimeType};base64,${image.base64}",
                                    )
                                },
                            )
                        },
                    )
                }
            }
        }
        return ChatMessageDto(role = role.wireValue(), content = contentElement)
    }

    private fun MessageRole.wireValue(): String = when (this) {
        MessageRole.USER -> "user"
        MessageRole.ASSISTANT -> "assistant"
        MessageRole.SYSTEM -> "system"
        MessageRole.TOOL -> "tool"
    }

    /** Domen tool tavsifini OpenAI JSON schema'ga aylantirish. */
    private fun ToolSpec.toDto(): ToolDto {
        val properties = buildJsonObject {
            parameters.forEach { parameter ->
                put(
                    parameter.name,
                    buildJsonObject {
                        put("type", parameter.type.jsonType())
                        put("description", parameter.description)
                    },
                )
            }
        }
        val schema = buildJsonObject {
            put("type", "object")
            put("properties", properties)
            put(
                "required",
                buildJsonArray {
                    parameters.filter { it.required }.forEach { add(it.name) }
                },
            )
            put("additionalProperties", false)
        }
        return ToolDto(
            type = "function",
            function = ToolFunctionDto(
                name = name,
                description = description,
                parameters = schema,
            ),
        )
    }

    private fun ParamType.jsonType(): String = when (this) {
        ParamType.STRING -> "string"
        ParamType.INTEGER -> "integer"
        ParamType.BOOLEAN -> "boolean"
    }

    /**
     * Javobdagi tool chaqiruvini domen modeliga aylantirish.
     *
     * Argumentlar JSON MATN sifatida keladi; uni `Map<String, String>`ga aylantiramiz.
     * Buzilgan JSON uchun butun chaqiruv tashlab yuborilmaydi — bo'sh xarita bilan
     * qaytadi, tool esa "parametr berilmagan" deb aniq xato beradi (agent tuzatadi).
     */
    private fun ToolCallDto.toDomain(): ToolCallRequest? {
        val functionName = function?.name?.takeIf { it.isNotBlank() } ?: return null
        val rawArguments = function?.arguments.orEmpty()
        val parsed: Map<String, String> = if (rawArguments.isBlank()) {
            emptyMap()
        } else {
            runCatching {
                json.decodeFromString(JsonObject.serializer(), rawArguments)
                    .mapValues { (_, element) -> element.jsonContentAsString() }
            }.getOrElse { emptyMap() }
        }
        return ToolCallRequest(
            id = id ?: "call_${functionName}_${parsed.size}",
            name = functionName,
            arguments = parsed,
        )
    }

    /**
     * JSON qiymatini matnga aylantirish: satr qiymati tirnoqsiz, son/boolean/murakkab
     * qiymatlar esa o'z matn ko'rinishida qaytariladi (tool `toIntOrNull` bilan o'qiydi).
     */
    private fun kotlinx.serialization.json.JsonElement.jsonContentAsString(): String = when (this) {
        is JsonPrimitive -> if (isString) content else this.toString()
        else -> this.toString()
    }

    private companion object {
        const val HEADER_AUTHORIZATION = "Authorization"
        const val HEADER_CONTENT_TYPE = "Content-Type"
        const val CONTENT_TYPE_JSON = "application/json"
        const val MAX_ERROR_DETAIL_CHARS = 240
        const val TEST_MAX_TOKENS = 1
        val VISION_REJECTION_HINTS = listOf(
            "image_url",
            "image url",
            "multimodal",
            "vision",
            "does not support images",
            "image input",
        )
    }
}
