package com.aiagent.mobile.domain.tools.edit

import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.AgentTool
import com.aiagent.mobile.domain.tools.ParamType
import com.aiagent.mobile.domain.tools.ToolContext
import com.aiagent.mobile.domain.tools.ToolParameter
import com.aiagent.mobile.domain.tools.ToolPaths
import com.aiagent.mobile.domain.tools.edit.EditKind
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.optionalArg
import com.aiagent.mobile.domain.tools.requireArg
import com.aiagent.mobile.domain.tools.toToolMessage
import com.aiagent.mobile.domain.tools.toolError
import com.aiagent.mobile.domain.tools.toolSuccess

/**
 * Patch-based tahrirlash tool'lari: `apply_patch`, `replace_text`, `insert_text`
 * (Faza 4, 4-vazifa).
 *
 * Barcha uch tool ham:
 * 1. faylni o'qiydi;
 * 2. CONFLICT tekshiradi — fayl AI o'qigandan keyin tashqaridan o'zgargan bo'lsa,
 *    yozish to'xtatiladi va agentga aniq xabar qaytadi;
 * 3. yangi matnni hisoblaydi (`PatchEngine` yoki oddiy almashtirish);
 * 4. [EditCoordinator]ga taklif yuboradi (`ALWAYS_CONFIRM` da diff ekrani ochiladi).
 *
 * Nima uchun `write_file` dan afzal: butun faylni qayta yozishda model katta
 * faylning bir qismini yo'qotishi mumkin. Patch esa faqat kerakli joyni o'zgartiradi.
 */
class EditTools(
    private val documents: DocumentRepository,
    private val edits: EditCoordinator,
    private val checksums: FileChecksumStore,
) {

    val tools: List<AgentTool> = listOf(ApplyPatch(), ReplaceText(), InsertText())

    /** Unified diff formatidagi patch'ni qo'llash. */
    inner class ApplyPatch : AgentTool {
        override val name = "apply_patch"
        override val description =
            "Unified diff formatidagi patch'ni faylga qo'llaydi (@@ -1,4 +1,5 @@ ko'rinishida). " +
                "Bir nechta joyni birdan o'zgartirish uchun qulay. Kontekst qatorlari fayldagi " +
                "matnga ANIQ mos kelishi shart, aks holda conflict qaytadi."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Tahrirlanadigan fayl yo'li"),
            ToolParameter("patch", ParamType.STRING, "Unified diff matni"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val patch = args.requireArg("patch").getOrElse { return toolError(it.toToolMessage()) }

            val (original, uri) = readOrFail(context, path) ?: return conflictOrMissing(path)

            return when (val applied = PatchEngine.applyUnifiedDiff(original, patch, path)) {
                is PatchEngine.ApplyResult.Applied -> propose(
                    context = context,
                    path = path,
                    uri = uri,
                    original = original,
                    updated = applied.newContent,
                    description = "'$path' ga patch qo'llash " +
                        "(+${applied.addedLines}/-${applied.removedLines} qator)",
                )

                is PatchEngine.ApplyResult.PatchConflict ->
                    toolError("CONFLICT: ${applied.reason}", recoverable = true)

                is PatchEngine.ApplyResult.MalformedPatch ->
                    toolError("PATCH XATO: ${applied.reason}", recoverable = true)
            }
        }
    }

    /** Aniq matn bo'lagini almashtirish. */
    inner class ReplaceText : AgentTool {
        override val name = "replace_text"
        override val description =
            "Fayldagi aniq matn bo'lagini boshqasi bilan almashtiradi. " +
                "old_text faylda ANIQ uchramasa xato qaytadi (shuning uchun avval read_file qiling)."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Fayl yo'li"),
            ToolParameter("old_text", ParamType.STRING, "Almashtiriladigan aniq matn"),
            ToolParameter("new_text", ParamType.STRING, "Yangi matn"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val oldText = args.requireArg("old_text").getOrElse { return toolError(it.toToolMessage()) }
            // `new_text` ixtiyoriy: bo'sh matnga almashtirish (qatorni tozalash) ham amal.
            val newText = args.optionalArg("new_text")

            val (original, uri) = readOrFail(context, path) ?: return conflictOrMissing(path)

            val occurrences = countOccurrences(original, oldText)
            if (occurrences == 0) {
                return toolError(
                    "'old_text' faylda topilmadi. Matn oraliq bo'shliq yoki qator oxirlari bilan " +
                        "bir xil bo'lishi kerak — `read_file` bilan aniq nusxasini oling.",
                    recoverable = true,
                )
            }
            if (occurrences > 1) {
                return toolError(
                    "'old_text' faylda $occurrences marta uchraydi — noto'g'ri joyni o'zgartirib " +
                        "qo'ymaslik uchun to'xtatildi. Matnni atrofidagi qatorlar bilan birga " +
                        "yozing (yagona bo'lishi kerak).",
                    recoverable = true,
                )
            }

            val updated = original.replace(oldText, newText)
            return propose(
                context = context,
                path = path,
                uri = uri,
                original = original,
                updated = updated,
                description = "'$path' da matn almashtirish",
            )
        }

    }

    /** Ma'lum qator oldiga matn qo'shish. */
    inner class InsertText : AgentTool {
        override val name = "insert_text"
        override val description =
            "Berilgan qator raqami OLDIGA yangi matn qo'shadi (1 dan boshlanadi). " +
                "Fayl oxiriga qo'shish uchun oxirgi qatordan keyingi raqamni yozing."
        override val parameters = listOf(
            ToolParameter("path", ParamType.STRING, "Fayl yo'li"),
            ToolParameter(
                name = "line_number",
                type = ParamType.INTEGER,
                description = "Qaysi qator oldiga qo'shilsin (1 = fayl boshi)",
            ),
            ToolParameter("text", ParamType.STRING, "Qo'shiladigan matn"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val lineNumber = args["line_number"]?.trim()?.toIntOrNull()
                ?: return toolError("'line_number' butun son bo'lishi kerak (1 dan boshlanadi).")
            val text = args.requireArg("text").getOrElse { return toolError(it.toToolMessage()) }

            val (original, uri) = readOrFail(context, path) ?: return conflictOrMissing(path)

            val lines = original.lines().toMutableList()
            if (lineNumber < 1 || lineNumber > lines.size + 1) {
                return toolError(
                    "Qator raqari $lineNumber fayl chegarasidan tashqarida " +
                        "(faylda ${lines.size} qator bor).",
                    recoverable = true,
                )
            }

            lines.addAll(lineNumber - 1, text.lines())
            return propose(
                context = context,
                path = path,
                uri = uri,
                original = original,
                updated = lines.joinToString("\n"),
                description = "'$path' ga $lineNumber-qator oldiga matn qo'shish",
            )
        }
    }

    // ---------------------------------------------------------------- yordamchilar

    /** Faylni o'qish + conflict tekshiruvi. Mos kelsa (matn, uri) qaytadi. */
    private suspend fun readOrFail(
        context: ToolContext,
        path: String,
    ): Pair<String, String>? {
        val uri = (ToolPaths.resolveExisting(documents, context, path) as? ToolPaths.Resolved.Found)
            ?.uri ?: return null

        val text = (ToolPaths.readText(documents, context, uri) as? ToolPaths.ReadOutcome.Text)
            ?: return null

        // CONFLICT: `read_file` paytida yozilgan checksum hozirgi matnga mos kelmasa —
        // fayl tashqaridan o'zgargan, patch eski matn ustiga qo'llanmasin.
        val stored = checksums.recorded(path)
        if (stored != null && checksums.checksumOf(text.content) != stored) return null

        // Agent patch'ni ko'r-ko'rona yozmasligi uchun checksum yangilanadi.
        checksums.record(path, text.content)
        return text.content to uri
    }

    /** O'qib bo'lmaganda yoki conflict bo'lganda aniq xabar. */
    private fun conflictOrMissing(path: String): ToolResult {
        val stored = checksums.recorded(path)
        return if (stored != null) {
            toolError(
                "CONFLICT: '$path' fayli siz o'qiganingizdan keyin o'zgargan yoki uni matn " +
                    "sifatida o'qib bo'lmadi. `read_file` bilan qayta o'qing.",
                recoverable = true,
            )
        } else {
            toolError(
                "'$path' faylini o'qib bo'lmadi (mavjud emas yoki ikkilik fayl). " +
                    "Avval `read_file` bilan o'qing.",
                recoverable = true,
            )
        }
    }

    /** Yangi matnni tasdiq oqimiga yuborish. */
    private suspend fun propose(
        context: ToolContext,
        path: String,
        uri: String,
        original: String,
        updated: String,
        description: String,
    ): ToolResult {
        if (original == updated) {
            return toolError("O'zgartirish natijasi asl matn bilan bir xil — hech narsa qilinmadi.")
        }
        val (added, removed) = PatchEngine.summarize(original, updated)

        return edits.request(
            ProposedFileEdit(
                rootUri = context.rootUri,
                path = path,
                uri = uri,
                kind = EditKind.OVERWRITE,
                originalContent = original,
                newContent = updated,
                description = "$description (+$added/-$removed qator)",
            ),
            documents,
        ).also { result ->
            if (result is ToolResult.Success) checksums.updateAfterWrite(path, updated)
        }
    }

    private fun countOccurrences(source: String, needle: String): Int {
        if (needle.isEmpty()) return 0
        var count = 0
        var index = source.indexOf(needle)
        while (index >= 0) {
            count++
            index = source.indexOf(needle, index + needle.length)
        }
        return count
    }
}
