package com.aiagent.mobile.data.colab

import com.aiagent.mobile.data.colab.dto.ColabExecuteRequest
import com.aiagent.mobile.data.colab.dto.ColabExecuteResponse
import com.aiagent.mobile.data.colab.dto.ColabHealthResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/**
 * Colab FastAPI serverining endpoint'lari (Faza 5, 1-2 vazifalar).
 *
 * Yo'llar nisbiy (`health`, `execute`) — chunki `baseUrl` foydalanuvchi kiritgan
 * ngrok havolasi va har sessiyada o'zgaradi (Faza 3 dagi provider naqshi bilan bir xil).
 *
 * `Response<...>` qaytariladi: xato holatida HTTP kodini o'qib, uni foydalanuvchiga
 * tushunarli xabarga aylantiramiz ("havola eskirgan", "server xato qaytardi").
 */
interface ColabApi {

    /** Server ishlayaptimi + ish papkasi mavjudmi. */
    @GET("health")
    suspend fun health(): Response<ColabHealthResponse>

    /** Buyruqni bajaradi va FAQAT natijani qaytaradi. */
    @POST("execute")
    suspend fun execute(@Body request: ColabExecuteRequest): Response<ColabExecuteResponse>
}
