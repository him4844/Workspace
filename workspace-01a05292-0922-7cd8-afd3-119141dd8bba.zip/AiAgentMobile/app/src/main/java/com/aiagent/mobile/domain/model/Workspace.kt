package com.aiagent.mobile.domain.model

/**
 * Foydalanuvchi tanlagan ish papkasi (workspace).
 *
 * [uri] — SAF tree URI (`content://com.android.externalstorage.documents/tree/...`),
 * `takePersistableUriPermission()` orqali olingan ruxsatga tayanadi (Faza 2).
 * [lastOpenedAt] — epoch millis; ro'yxatda "oxirgi ochilgan vaqti" uchun ishlatiladi.
 */
data class Workspace(
    val id: String,
    val name: String,
    val uri: String,
    val lastOpenedAt: Long,
)
