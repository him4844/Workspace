package com.aiagent.mobile.domain.agent

import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AiRequestMessage
import com.aiagent.mobile.domain.model.AiResult
import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.domain.repository.AiChatRepository
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.ToolContext
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.ToolRegistry
import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.ProposedFileEdit
import java.util.UUID
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Agent boshqaruvchisi va sikli (Faza 4, 5-6 vazifalar).
 *
 * Sikl: so'rov → AI tool tanlaydi → tool bajariladi → natija AI'ga qaytariladi →
 * keyingi qadam. AI tool chaqirmasa — sikl tugaydi va javob foydalanuvchiga ko'rsatiladi.
 *
 * **QAROR — nima uchun `@Singleton` va o'z `CoroutineScope`i:**
 * `viewModelScope` ishlatilsa, foydalanuvchi chatdan chiqib ketishi bilan agent
 * o'ldiriladi (ViewModel yo'qoladi). Agent sikli 10 daqiqagacha davom etishi mumkin,
 * shuning uchun u singleton sifatida yashaydi va navigatsiyadan omon qoladi.
 * CHEKLOV: jarayon (process) o'ldirilsa sikl baribir yo'qoladi — haqiqiy fon rejimi
 * uchun foreground service kerak. Bu spetsifikatsiyada so'ralmagan va Faza 4
 * chegarasidan tashqarida, shuning uchun PROGRESS_LOG'da aniq qayd etildi.
 *
 * **MUHIM (spetsifikatsiya talabi):** bu fazada `ExecutionRouter` CHAQIRILMAYDI —
 * barcha tool'lar to'g'ridan-to'g'ri telefonda ishlaydi. Colab yo'nalishi Faza 5-6 da.
 */
class AgentController(
    private val chatRepository: AiChatRepository,
    private val documents: DocumentRepository,
    private val toolRegistry: ToolRegistry,
    private val editCoordinator: EditCoordinator,
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _state = MutableStateFlow(AgentState.IDLE)
    val state: StateFlow<AgentState> = _state.asStateFlow()

    private val _steps = MutableStateFlow<List<AgentStep>>(emptyList())
    val steps: StateFlow<List<AgentStep>> = _steps.asStateFlow()

    /** Agentning yakuniy javobi (tool chaqiruvisiz oxirgi xabar). */
    private val _finalAnswer = MutableStateFlow<String?>(null)
    val finalAnswer: StateFlow<String?> = _finalAnswer.asStateFlow()

    private val _error = MutableStateFlow<AiError?>(null)
    val error: StateFlow<AiError?> = _error.asStateFlow()

    /**
     * Tasdiq kutilayotgan fayl amali — diff ekrani shuni ko'rsatadi.
     * `StateFlow` bo'lgani uchun Compose o'zgarishni darhol ko'radi.
     */
    val pendingEdit: StateFlow<ProposedFileEdit?> = editCoordinator.pendingFlow

    fun isRunning(): Boolean = job?.isActive == true

    private var job: Job? = null
    private var approvalGate: CompletableDeferred<ToolResult>? = null

    /** Agent siklini boshlash. Allaqachon ishlayotgan bo'lsa, yangi so'rov e'tiborsiz qoladi. */
    fun start(request: AgentRunRequest) {
        if (job?.isActive == true) return

        _steps.value = emptyList()
        _finalAnswer.value = null
        _error.value = null
        job = scope.launch { runLoop(request) }
    }

    /** "Stop Agent" tugmasi (5-vazifa). */
    fun stop() {
        if (job?.isActive != true) return
        // Tasdiq kutilayotgan bo'lsa, avval darvozani yopamiz — aks holda sikl osilib qoladi.
        approvalGate?.complete(ToolResult.Error("Foydalanuvchi agentni to'xtatdi.", false))
        approvalGate = null
        job?.cancel()
        job = null
        _state.value = AgentState.CANCELLED
        addStep(AgentStepKind.LIMIT, "Agent to'xtatildi", "Foydalanuvchi 'Stop Agent' bosdi.")
    }

    /** Diff ekranida "Qabul qilish". */
    fun approvePendingEdit() {
        val gate = approvalGate ?: return
        scope.launch {
            val result = editCoordinator.accept(documents)
            _state.value = AgentState.RUNNING_TOOL
            gate.complete(result)
        }
    }

    /** Diff ekranida "Rad etish". */
    fun rejectPendingEdit() {
        val gate = approvalGate ?: return
        val result = editCoordinator.reject()
        _state.value = AgentState.RUNNING_TOOL
        gate.complete(result)
    }

    /** Oxirgi o'zgartirishni qaytarish (8-vazifa, `AUTO_APPLY` rejimi). */
    fun undoLastEdit(onDone: (ToolResult) -> Unit) {
        scope.launch { onDone(editCoordinator.undoLast(documents)) }
    }

    fun editHistory() = editCoordinator.history()

    // ---------------------------------------------------------------- sikl

    private suspend fun runLoop(request: AgentRunRequest) {
        editCoordinator.editMode = request.editMode
        val context = ToolContext(rootUri = request.rootUri, maxFileBytes = request.maxFileBytes)
        val limits = request.limits
        val startedAt = System.currentTimeMillis()

        val messages = mutableListOf<AiRequestMessage>()
        messages += AiRequestMessage(
            role = MessageRole.SYSTEM,
            content = AgentPrompt.system(
                workspaceName = request.workspaceName,
                toolNames = toolRegistry.tools.map { it.name },
                editModeName = request.editMode.name,
            ),
        )
        messages += request.history
        messages += AiRequestMessage(
            role = MessageRole.USER,
            content = buildUserContent(request),
        )

        var iteration = 0
        var toolCallCount = 0

        while (scope.isActive) {
            if (!checkLimits(limits, iteration, toolCallCount, startedAt)) return

            _state.value = AgentState.PLANNING
            addStep(
                kind = AgentStepKind.REQUEST,
                title = if (iteration == 0) "So'rov yuborildi" else "Keyingi qadam ($iteration)",
                detail = "${messages.size} ta xabar, ${toolRegistry.tools.size} ta tool taklif qilindi",
            )

            val result = chatRepository.complete(
                provider = request.provider,
                messages = messages,
                tools = toolRegistry.specs,
            )

            if (result is AiResult.Failure) {
                _error.value = result.error
                _state.value = AgentState.FAILED
                addStep(
                    kind = AgentStepKind.LIMIT,
                    title = "So'rov bajarilmadi",
                    detail = result.error.javaClass.simpleName,
                    isSuccess = false,
                )
                return
            }

            val response = (result as AiResult.Success).response

            // AI tool chaqirmadi — bu oddiy javob. Sikl tugaydi.
            if (!response.hasToolCalls) {
                _finalAnswer.value = response.content
                _state.value = AgentState.COMPLETED
                addStep(
                    kind = AgentStepKind.RESPONSE,
                    title = "Javob tayyor",
                    detail = response.content.take(STEP_DETAIL_CHARS),
                    isSuccess = true,
                )
                return
            }

            // OpenAI talabi: tool natijasidan oldin tool_calls li assistant xabari bo'lishi kerak.
            messages += AiRequestMessage(
                role = MessageRole.ASSISTANT,
                content = response.content,
                toolCalls = response.toolCalls,
            )

            for (call in response.toolCalls) {
                if (!scope.isActive) return
                toolCallCount++
                if (toolCallCount > limits.maxToolCalls) {
                    failByLimit("Tool chaqiruvi chegarasiga yetildi (${limits.maxToolCalls} ta).")
                    return
                }

                _state.value = AgentState.RUNNING_TOOL
                val argsSummary = call.arguments.entries.joinToString(", ") { (key, value) ->
                    "$key=${value.take(ARG_PREVIEW_CHARS)}"
                }
                addStep(AgentStepKind.TOOL_CALL, "Tool: ${call.name}", argsSummary)

                val toolResult = toolRegistry.invoke(call.name, call.arguments, context)

                val feedback = when (toolResult) {
                    // Tasdiq kutilmoqda — sikl shu yerda to'xtaydi va foydalanuvchini kutadi.
                    is ToolResult.PermissionRequired -> awaitApproval(toolResult)

                    is ToolResult.Success -> {
                        addStep(
                            AgentStepKind.TOOL_RESULT,
                            "Natija: ${call.name}",
                            toolResult.output.take(STEP_DETAIL_CHARS),
                            isSuccess = true,
                        )
                        toolResult
                    }

                    is ToolResult.Error -> {
                        addStep(
                            AgentStepKind.TOOL_RESULT,
                            "Xato: ${call.name}",
                            toolResult.message,
                            isSuccess = false,
                        )
                        if (!toolResult.recoverable) {
                            _state.value = AgentState.FAILED
                            _error.value = AiError.Unknown(toolResult.message)
                            return
                        }
                        toolResult
                    }
                }

                if (feedback == null) return // agent to'xtatildi

                messages += AiRequestMessage(
                    role = MessageRole.TOOL,
                    content = feedbackText(feedback),
                    toolCallId = call.id,
                )
            }
            iteration++
        }
    }

    /** Foydalanuvchi qarorini kutish. `null` = agent to'xtatildi. */
    private suspend fun awaitApproval(request: ToolResult.PermissionRequired): ToolResult? {
        // TARTIB MUHIM: darvoza (gate) HOLATDAN OLDIN o'rnatiladi. Aks holda UI
        // `WAITING_FOR_PERMISSION` ni ko'rib darhol tasdiqlasa, `approvalGate` hali
        // `null` bo'ladi va tasdiq jim yo'qoladi — agent abadiy kutib qoladi.
        val gate = CompletableDeferred<ToolResult>()
        approvalGate = gate

        _state.value = AgentState.WAITING_FOR_PERMISSION
        addStep(
            kind = AgentStepKind.AWAITING_APPROVAL,
            title = "Tasdiq kutilmoqda",
            detail = request.description,
        )

        return try {
            gate.await()
        } finally {
            approvalGate = null
        }
    }

    /** Tool natijasini AI o'qiy oladigan matnga aylantirish. */
    private fun feedbackText(result: ToolResult): String = when (result) {
        is ToolResult.Success -> result.output
        is ToolResult.Error -> "XATO: ${result.message}"
        is ToolResult.PermissionRequired ->
            "Foydalanuvchi tasdig'i kutilmoqda: ${result.description}"
    }

    private fun checkLimits(
        limits: AgentLimits,
        iteration: Int,
        toolCallCount: Int,
        startedAt: Long,
    ): Boolean {
        if (iteration >= limits.maxSteps) {
            failByLimit("Qadam chegarasiga yetildi (${limits.maxSteps} qadam).")
            return false
        }
        val elapsed = System.currentTimeMillis() - startedAt
        if (elapsed > limits.maxExecutionTimeMs) {
            failByLimit("Vaqt chegarasiga yetildi (${elapsed / MILLIS_IN_SECOND} soniya).")
            return false
        }
        return true
    }

    private fun failByLimit(reason: String) {
        _state.value = AgentState.FAILED
        addStep(AgentStepKind.LIMIT, "Agent to'xtatildi", reason, isSuccess = false)
    }

    private fun buildUserContent(request: AgentRunRequest): String = buildString {
        append(request.userMessage)
        if (request.attachmentContext.isNotBlank()) {
            append("\n\n[Kontekst: foydalanuvchi biriktirgan fayllar]\n")
            append(request.attachmentContext)
        }
    }

    private fun addStep(
        kind: AgentStepKind,
        title: String,
        detail: String? = null,
        isSuccess: Boolean? = null,
    ) {
        val step = AgentStep(
            id = UUID.randomUUID().toString(),
            kind = kind,
            title = title,
            detail = detail,
            isSuccess = isSuccess,
            timestamp = System.currentTimeMillis(),
        )
        // Cheksiz o'sishning oldini olamiz: faqat oxirgi MAX_STEPS_UI ta saqlanadi.
        _steps.value = (_steps.value + step).takeLast(MAX_STEPS_UI)
    }

    private companion object {
        const val STEP_DETAIL_CHARS = 300
        const val ARG_PREVIEW_CHARS = 60
        const val MAX_STEPS_UI = 200
        const val MILLIS_IN_SECOND = 1000
    }
}

/** Agent siklini boshlash uchun kerakli ma'lumotlar. */
data class AgentRunRequest(
    val provider: AiProvider,
    val rootUri: String,
    val workspaceName: String,
    val userMessage: String,
    val history: List<AiRequestMessage> = emptyList(),
    val attachmentContext: String = "",
    val editMode: EditMode = EditMode.ALWAYS_CONFIRM,
    val maxFileBytes: Int = 100_000,
    val limits: AgentLimits = AgentLimits(),
)
