package com.aiagent.mobile.ui.common

import com.aiagent.mobile.domain.usecase.ByteFormatter

/**
 * Foydalanuvchiga ko'rsatiladigan qiymatlarni formatlash.
 *
 * Faza 4 dan mantiq `domain/usecase/ByteFormatter`da yashaydi, chunki fayl tool'lari
 * ham shu formatdan foydalanadi va domen qatlami UI'ga bog'lanmasligi kerak.
 * Bu ob'ekt Faza 2-3 dagi UI chaqiruvlarini buzmaslik uchun qobiq sifatida qoldirildi.
 */
object Formatters {

    fun fileSize(bytes: Long): String = ByteFormatter.fileSize(bytes)
}
