package com.aiagent.mobile.ui.workspace

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.mobile.domain.model.Workspace
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.repository.WorkspaceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Workspace ekranining holati. */
data class WorkspaceUiState(
    val isLoading: Boolean = true,
    val workspaces: List<WorkspaceItem> = emptyList(),
)

/**
 * Ro'yxatdagi bitta workspace.
 * [hasAccess] = false bo'lsa, doimiy ruxsat yo'qolgan (foydalanuvchi bekor qilgan yoki
 * papka o'chirilgan) — UI aniq xabar va "qayta ulash / o'chirish" taklifini ko'rsatadi.
 */
data class WorkspaceItem(
    val workspace: Workspace,
    val hasAccess: Boolean,
)

@HiltViewModel
class WorkspaceViewModel @Inject constructor(
    private val workspaceRepository: WorkspaceRepository,
    private val documentRepository: DocumentRepository,
) : ViewModel() {

    /**
     * Ruxsat holati DataStore'da saqlanmaydi, har safar tekshiriladi. Shu trigger orqali
     * SAF dialogidan qaytgandan keyin holatni yangilaymiz.
     */
    private val refreshTrigger = MutableStateFlow(0)

    private val messages = Channel<String>(capacity = Channel.BUFFERED)
    val messageFlow: Flow<String> = messages.receiveAsFlow()

    val uiState: StateFlow<WorkspaceUiState> =
        combine(workspaceRepository.observeWorkspaces(), refreshTrigger) { workspaces, _ -> workspaces }
            .map { workspaces ->
                WorkspaceUiState(
                    isLoading = false,
                    workspaces = workspaces.map { workspace ->
                        WorkspaceItem(
                            workspace = workspace,
                            hasAccess = documentRepository.hasPersistablePermission(workspace.uri),
                        )
                    },
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
                initialValue = WorkspaceUiState(),
            )

    /** `ACTION_OPEN_DOCUMENT_TREE` natijasi. `null` = foydalanuvchi bekor qildi. */
    fun onFolderPicked(uri: Uri?) {
        if (uri == null) {
            sendMessage("Papka tanlash bekor qilindi")
            return
        }
        viewModelScope.launch {
            val uriString = uri.toString()
            val result = runCatching {
                // MAJBURIY: bu chaqiruvsiz ruxsat ilova qayta ochilganda yo'qoladi.
                documentRepository.takePersistablePermission(uriString)
                val name = documentRepository.treeDisplayName(uriString) ?: DEFAULT_NAME
                workspaceRepository.addWorkspace(
                    Workspace(
                        id = UUID.randomUUID().toString(),
                        name = name,
                        uri = uriString,
                        lastOpenedAt = System.currentTimeMillis(),
                    ),
                )
                name
            }
            result
                .onSuccess { sendMessage("Qo'shildi: $it") }
                .onFailure { error -> sendMessage("Papkaga ruxsat olinmadi: ${error.message ?: "noma'lum xato"}") }
            refreshTrigger.value += 1
        }
    }

    /** Workspace'ni ochish — "oxirgi ochilgan vaqti" yangilanadi. */
    fun onWorkspaceOpened(id: String) {
        viewModelScope.launch { workspaceRepository.touchWorkspace(id) }
    }

    /** Tasdiqlash dialogidan keyin chaqiriladi (halokatli amal — 8-qoida). */
    fun onDeleteConfirmed(id: String) {
        viewModelScope.launch {
            workspaceRepository.removeWorkspace(id)
            refreshTrigger.value += 1
            sendMessage("Workspace ro'yxatdan olib tashlandi")
        }
    }

    /** Ruxsati yo'qolgan workspace uchun yangi papka tanlash. */
    fun onRelinkRequested(id: String) {
        viewModelScope.launch {
            workspaceRepository.removeWorkspace(id)
            refreshTrigger.value += 1
            sendMessage("Eski yozuv o'chirildi — yangi papkani tanlang")
        }
    }

    private fun sendMessage(text: String) {
        messages.trySend(text)
    }

    private companion object {
        const val STOP_TIMEOUT_MS = 5_000L
        const val DEFAULT_NAME = "Tanlangan papka"
    }
}
