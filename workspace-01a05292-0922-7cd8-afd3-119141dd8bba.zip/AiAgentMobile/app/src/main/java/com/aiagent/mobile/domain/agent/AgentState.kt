package com.aiagent.mobile.domain.agent

/**
 * Agent holat mashinasi (Faza 4 dagi AgentController shu holatlar orasida o'tadi).
 *
 * - `WAITING_FOR_PERMISSION` — xavfli amal tasdiqlash kutilmoqda (Faza 7 CommandRisk)
 * - `WAITING_FOR_USER` — agent foydalanuvchi javobini kutmoqda (masalan conflict)
 * - `CANCELLED` — foydalanuvchi "Stop Agent" bosdi
 */
enum class AgentState {
    IDLE,
    PLANNING,
    RUNNING_TOOL,
    WAITING_FOR_PERMISSION,
    WAITING_FOR_USER,
    APPLYING_EDIT,
    TESTING,
    COMPLETED,
    FAILED,
    CANCELLED,
}
