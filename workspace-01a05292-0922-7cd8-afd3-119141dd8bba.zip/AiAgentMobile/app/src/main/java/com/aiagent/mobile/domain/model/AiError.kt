package com.aiagent.mobile.domain.model

/**
 * AI chaqiruvi xatosi — har bir tur foydalanuvchiga alohida, texnik jargonsiz
 * tushuntiriladi (Faza 3, 5-vazifa: tarmoq yo'q / 401 / 429 / timeout).
 *
 * Domen qatlami Android resurslarini bilmaydi: bu sealed interface faqat TURNI
 * bildiradi, matn esa UI'da string resurslardan olinadi. Shu tufayli xato
 * tasnifi emulyatorsiz test qilinadi.
 */
sealed interface AiError {

    /** Tarmoqqa ulanib bo'lmadi (Wi-Fi/mobil ma'lumot o'chiq, DNS ishlamadi). */
    data object NoNetwork : AiError

    /** Server ulanishni qabul qildi, lekin javob bermadi (kutish vaqti tugadi). */
    data object Timeout : AiError

    /** 401/403 — API kalit noto'g'ri yoki muddati o'tgan. */
    data object Unauthorized : AiError

    /** 429 — juda ko'p so'rov yoki kvota tugagan. */
    data object RateLimited : AiError

    /** 5xx yoki boshqa HTTP xatosi. */
    data class Server(val code: Int, val detail: String?) : AiError

    /** Javob kutilgan formatda emas (bo'sh choices, buzilgan JSON). */
    data class InvalidResponse(val detail: String?) : AiError

    /**
     * Provider rasmlarni qabul qilmaydi (multimodal emas).
     * Foydalanuvchi tanlagan strategiya ("graceful"): crash bo'lmaydi va rasm
     * jim tashlab yuborilmaydi — UI aniq xabar ko'rsatadi va so'rov rasmsiz
     * (faqat metadata bilan) qayta yuboriladi.
     */
    data class VisionUnsupported(val detail: String?) : AiError

    /** Provider sozlamasi noto'g'ri (masalan apiBase yaroqsiz). */
    data class InvalidConfig(val detail: String) : AiError

    data class Unknown(val detail: String?) : AiError
}

/** Qayta urinish ma'noga egami (UI "Qayta urinish" tugmasini shunga qarab ko'rsatadi). */
val AiError.isRetryable: Boolean
    get() = when (this) {
        AiError.NoNetwork, AiError.Timeout, AiError.RateLimited -> true
        is AiError.Server -> code in 500..599
        AiError.Unauthorized -> false
        is AiError.InvalidResponse,
        is AiError.InvalidConfig,
        is AiError.VisionUnsupported,
        is AiError.Unknown,
        -> false
    }
