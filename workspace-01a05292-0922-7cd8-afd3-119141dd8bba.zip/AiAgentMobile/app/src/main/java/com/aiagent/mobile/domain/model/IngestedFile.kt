package com.aiagent.mobile.domain.model

/**
 * Chatga biriktirilgan, AI'ga yuborishga tayyor fayl (Faza 3).
 *
 * [text] — matnli kontent (matn fayli, arxiv ro'yxati yoki ikkilik fayl tavsifi).
 * [images] — rasm fayli yoki PDF sahifalari (multimodal qism).
 * [note] — foydalanuvchiga va modelga aniq izoh (masalan "fayl 12 MB, faqat birinchi
 * 100 KB yuborildi"). Yashirin kesish bo'lmaydi — bu 3-qoidaga (soxta ko'rsatmaslik) zid.
 */
data class IngestedFile(
    val fileName: String,
    val uri: String,
    val kind: FileKind,
    val mimeType: String?,
    val sizeBytes: Long,
    val text: String?,
    val images: List<IngestedImage> = emptyList(),
    val truncated: Boolean = false,
    val note: String? = null,
)

/** AI'ga yuboriladigan bitta rasm (fayl yoki PDF sahifasi). */
data class IngestedImage(
    val mimeType: String,
    val base64: String,
    val label: String,
)
