package com.aiagent.mobile.domain.tools.search

import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.AgentTool
import com.aiagent.mobile.domain.tools.ParamType
import com.aiagent.mobile.domain.tools.ToolContext
import com.aiagent.mobile.domain.tools.ToolParameter
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.requireArg
import com.aiagent.mobile.domain.tools.toToolMessage
import com.aiagent.mobile.domain.tools.toolError
import com.aiagent.mobile.domain.tools.toolSuccess

/**
 * Qidiruv tool'lari: `search_files`, `search_text` (Faza 4, 3-vazifa).
 *
 * Spetsifikatsiya: "hozircha oddiy string qidiruv, index yo'q". Shuning uchun
 * har chaqiruvda papka daraxti aylanib chiqiladi — bu sekin, lekin sodda va
 * ishonchli. Room indeksi va token byudjeti Faza 9 da qo'shiladi (bu cheklov
 * PROGRESS_LOG'da qayd etilgan).
 *
 * Katta/kichik harf farqlanmaydi — agent "MainActivity" deb so'rasa ham,
 * "mainactivity" deb so'rasa ham bir xil natija oladi.
 */
class SearchTools(private val documents: DocumentRepository) {

    val tools: List<AgentTool> = listOf(SearchFiles(), SearchText())

    /** Fayl NOMI bo'yicha qidiruv. */
    inner class SearchFiles : AgentTool {
        override val name = "search_files"
        override val description =
            "Fayl nomlarini qidiradi (katta/kichik harf farqlanmaydi). " +
                "Masalan 'Activity' so'rovi MainActivity.kt ni topadi."
        override val parameters = listOf(
            ToolParameter("query", ParamType.STRING, "Qidiriladigan nom qismi"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val query = args.requireArg("query").getOrElse { return toolError(it.toToolMessage()) }

            val results = documents.searchFiles(context.rootUri, query, MAX_RESULTS)
            if (results.isEmpty()) {
                return toolSuccess("'$query' ga mos fayl nomi topilmadi.")
            }

            val listing = results.joinToString("\n") { node -> node.name }
            val suffix = if (results.size >= MAX_RESULTS) {
                "\n(natijalar $MAX_RESULTS ta bilan cheklandi)"
            } else {
                ""
            }
            return toolSuccess("${results.size} ta fayl topildi:\n$listing$suffix")
        }
    }

    /** Matn fayllari ichidan qidiruv — qator raqami bilan. */
    inner class SearchText : AgentTool {
        override val name = "search_text"
        override val description =
            "Matnli fayllar ichidan matn qidiradi va qator raqamlari bilan qaytaradi. " +
                "Ikkilik fayllar o'tkazib yuboriladi."
        override val parameters = listOf(
            ToolParameter("query", ParamType.STRING, "Qidiriladigan matn"),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val query = args.requireArg("query").getOrElse { return toolError(it.toToolMessage()) }

            val matches = documents.searchInFiles(
                rootUri = context.rootUri,
                query = query,
                maxFiles = MAX_FILES,
                maxMatchesPerFile = MAX_MATCHES_PER_FILE,
                maxFileBytes = context.maxFileBytes,
            )
            if (matches.isEmpty()) {
                return toolSuccess("'$query' matni hech qanday faylda topilmadi.")
            }

            val listing = matches.joinToString("\n") { match ->
                "${match.path}:${match.lineNumber}: ${match.lineText}"
            }
            return toolSuccess("${matches.size} ta moslik topildi:\n$listing")
        }
    }

    private companion object {
        const val MAX_RESULTS = 100
        const val MAX_FILES = 30
        const val MAX_MATCHES_PER_FILE = 5
    }
}
