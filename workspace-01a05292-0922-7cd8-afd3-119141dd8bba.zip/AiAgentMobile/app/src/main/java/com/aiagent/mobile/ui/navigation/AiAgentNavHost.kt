package com.aiagent.mobile.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aiagent.mobile.ui.chat.ChatScreen
import com.aiagent.mobile.ui.settings.SettingsScreen
import com.aiagent.mobile.ui.files.FileTreeScreen
import com.aiagent.mobile.ui.workspace.WorkspaceScreen

/**
 * Compose Navigation grafi.
 *
 * Faza 2 dan boshlang'ich ekran — [WorkspaceScreen] (Faza 0 dagi "Salom!" ekrani o'chirildi).
 * Oqim: Workspace -> Fayl daraxti -> Chat. Sozlamalar Workspace'dan ochiladi (Faza 3).
 */
@Composable
fun AiAgentNavHost() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.WORKSPACE,
    ) {
        composable(Routes.WORKSPACE) {
            WorkspaceScreen(
                onOpenWorkspace = { workspaceId ->
                    navController.navigate(Routes.fileTree(workspaceId))
                },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
            )
        }

        composable(
            route = Routes.FILE_TREE,
            arguments = listOf(
                navArgument(Routes.ARG_WORKSPACE_ID) { type = NavType.StringType },
            ),
        ) { entry ->
            val workspaceId = entry.arguments?.getString(Routes.ARG_WORKSPACE_ID).orEmpty()
            FileTreeScreen(
                onNavigateBack = { navController.popBackStack() },
                // Faza 4: agent tool'lari workspace ildizini bilishi shart.
                onGoToChat = { files ->
                    navController.navigate(Routes.chat(files, workspaceId))
                },
            )
        }

        composable(
            route = Routes.CHAT,
            arguments = listOf(
                navArgument(Routes.ARG_FILES) {
                    type = NavType.StringType
                    defaultValue = ""
                },
                navArgument(Routes.ARG_WORKSPACE_ID) {
                    type = NavType.StringType
                    defaultValue = ""
                },
            ),
        ) { backStackEntry ->
            ChatScreen(
                attachedFileUris = Routes.parseFiles(
                    backStackEntry.arguments?.getString(Routes.ARG_FILES),
                ),
                workspaceId = Routes.parseWorkspaceId(
                    backStackEntry.arguments?.getString(Routes.ARG_WORKSPACE_ID),
                ),
                onNavigateBack = { navController.popBackStack() },
                // Sozlamalar stack'ga qo'shilmaydi: chat ekraniga qaytganda
                // orqaga bosish fayl daraxtiga olib borishi kerak.
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onNavigateBack = { navController.popBackStack() })
        }
    }
}
