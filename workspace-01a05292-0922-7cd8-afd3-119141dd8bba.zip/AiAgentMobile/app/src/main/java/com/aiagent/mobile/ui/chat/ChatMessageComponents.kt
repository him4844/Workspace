package com.aiagent.mobile.ui.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.MessageRole
import com.aiagent.mobile.ui.common.toDisplayText
import com.aiagent.mobile.ui.theme.CodeTextStyle

/**
 * Chat xabarlari va ogohlantirish kartalari (Faza 3).
 *
 * `ChatScreen.kt` 400 qator chegarasidan oshib ketmasligi uchun alohida faylga
 * ajratildi (7-qoida). Kod bloklari monospace uslubida chiziladi — sintaksis
 * ranglash spetsifikatsiya bo'yicha shart emas.
 */

@Composable
internal fun MessageBubble(
    message: ChatUiMessage,
    error: AiError?,
    onRetry: () -> Unit,
) {
    if (message.isError) {
        Surface(
            color = MaterialTheme.colorScheme.errorContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row {
                    Icon(
                        painter = painterResource(R.drawable.ic_error_circle),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = error?.toDisplayText()
                            ?: stringResource(R.string.ai_error_unknown, "—"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
                TextButton(
                    modifier = Modifier.height(48.dp),
                    onClick = onRetry,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_refresh),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.chat_retry))
                }
            }
        }
        return
    }

    val isUser = message.role == MessageRole.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = if (isUser) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (message.attachedFileNames.isNotEmpty()) {
                    Text(
                        text = stringResource(
                            R.string.chat_attached_files,
                            message.attachedFileNames.size,
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    message.attachedFileNames.forEach { name ->
                        Text(
                            text = "• $name",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }

                parseCodeBlocks(message.content).forEach { segment ->
                    when (segment) {
                        is MessageSegment.Text -> Text(
                            text = segment.value,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (isUser) {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                        )

                        is MessageSegment.Code -> CodeBlock(segment)
                    }
                }

                message.totalTokens?.let { tokens ->
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.chat_tokens_info, tokens),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
internal fun CodeBlock(segment: MessageSegment.Code) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            if (segment.language.isNotBlank()) {
                Text(
                    text = segment.language,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
            }
            // Spetsifikatsiya talabi: kod monospace shriftda.
            Text(text = segment.value, style = CodeTextStyle)
        }
    }
}

@Composable
internal fun WarningCard(warning: Warning) {
    val text = when (warning) {
        is Warning.TruncatedFiles -> stringResource(
            R.string.chat_context_truncated_body,
            warning.details.joinToString("; "),
        )

        is Warning.HistoryTrimmed -> stringResource(
            R.string.chat_history_trimmed,
            warning.droppedMessages,
        )

        Warning.VisionUnsupported -> stringResource(R.string.ai_error_vision)
    }
    Surface(
        color = MaterialTheme.colorScheme.tertiaryContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            Icon(
                painter = painterResource(R.drawable.ic_warning),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
        }
    }
}

@Composable
internal fun ThinkingRow() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = stringResource(R.string.chat_thinking),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
