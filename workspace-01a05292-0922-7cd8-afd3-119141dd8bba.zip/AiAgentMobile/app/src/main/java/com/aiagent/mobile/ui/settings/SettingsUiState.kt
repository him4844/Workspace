package com.aiagent.mobile.ui.settings

import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider

/**
 * Sozlamalar ekrani UI modellari (Faza 3; Faza 5 da Colab qo'shildi).
 *
 * Nima uchun alohida fayl: `SettingsViewModel` 400 qator chegarasiga yetib qolgandi.
 * UI modellarini ajratish mantiqni o'qishni osonlashtiradi va chegaraga rioya qiladi.
 */
data class SettingsUiState(
    val isLoading: Boolean = true,
    val providers: List<AiProvider> = emptyList(),
    val isFormOpen: Boolean = false,
    val isTesting: Boolean = false,
    val testResult: TestOutcome? = null,
)

/** "Test qilish" natijasi — forma ichida ✅ yoki ❌ sifatida ko'rsatiladi. */
sealed interface TestOutcome {
    data object Success : TestOutcome
    data class Failed(val error: AiError) : TestOutcome
}

/** Ekranga chiqariladigan hodisalar (matn UI'da tanlanadi). */
sealed interface SettingsMessage {
    data class Saved(val name: String) : SettingsMessage
    data class Activated(val name: String) : SettingsMessage
    data class Deleted(val name: String) : SettingsMessage
    data class EncryptFailed(val detail: String) : SettingsMessage
    data object TestSuccess : SettingsMessage
    data class TestFailed(val error: AiError) : SettingsMessage

    /** Faza 5: Colab manzili saqlandi / tozalandi / talab qilinadi. */
    data object ColabSaved : SettingsMessage
    data object ColabCleared : SettingsMessage

    /** Colab amali chaqirildi, lekin URL kiritilmagan — qo'llanma ochilishi kerak. */
    data object ColabUrlRequired : SettingsMessage
}
