package com.aiagent.mobile.domain.model

/**
 * PDF faylining rasmga aylantirilgan sahifalari (Faza 3).
 *
 * Android'ning `PdfRenderer` API'si matn chiqarmaydi, lekin sahifani bitmap qilib
 * beradi — shuning uchun PDF multimodal provider'ga rasm sifatida yuboriladi.
 * Bu yangi kutubxona talab qilmaydigan yagona ishonchli yo'l.
 */
data class PdfPages(
    val pages: List<IngestedImage>,
    val totalPages: Int,
    val failedReason: String? = null,
)
