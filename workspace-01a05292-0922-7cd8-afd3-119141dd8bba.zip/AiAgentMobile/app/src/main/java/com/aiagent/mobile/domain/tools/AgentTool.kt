package com.aiagent.mobile.domain.tools

/**
 * Agent chaqira oladigan bitta tool (Faza 4, 1-vazifa).
 *
 * Dizayn qarori: tool'lar SOF KOTLIN — Android'ga bog'liq emas. Barcha fayl I/O
 * `DocumentRepository` interfeysi orqali qilinadi, shuning uchun har bir tool
 * emulyatorsiz, fake repository bilan JVM testida tekshiriladi
 * (`DomainPurityTest` bu chegarani himoya qiladi).
 *
 * Argumentlar `Map<String, String>` ko'rinishida: AI JSON yuboradi, controller
 * uni shu xaritaga aylantiradi. Barcha parametrlarimiz matn yoki son — murakkab
 * tuzilma kerak emas, shuning uchun maxsus parser yozilmadi.
 */
interface AgentTool {

    /** AI ko'radigan tool nomi (masalan `read_file`). */
    val name: String

    /** AI'ga tool nima qilishini tushuntiradigan qisqa izoh. */
    val description: String

    /** Parametr tavsifi — AI'ga JSON schema sifatida yuboriladi. */
    val parameters: List<ToolParameter>

    /** Tool'ni bajarish. [context] orqali workspace ildizi va rejim beriladi. */
    suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult
}

/** Bitta parametr tavsifi (JSON schema'ning soddalashtirilgan ko'rinishi). */
data class ToolParameter(
    val name: String,
    val type: ParamType,
    val description: String,
    val required: Boolean = true,
)

enum class ParamType { STRING, INTEGER, BOOLEAN }

/**
 * Tool bajarilishi uchun kerakli kontekst.
 *
 * [rootUri] — agent ishlaydigan workspace ildizining SAF URI'si. Barcha yo'llar
 * shu ildizga nisbatan (masalan `src/main.kt`). Bu agentni tanlangan papkadan
 * chiqib ketishining oldini oladi.
 */
data class ToolContext(
    val rootUri: String,
    val maxFileBytes: Int,
)

/** Majburiy parametrni olish — yo'q bo'lsa aniq xato. */
fun Map<String, String>.requireArg(name: String): Result<String> {
    val value = this[name]?.trim().orEmpty()
    return if (value.isEmpty()) {
        Result.failure(MissingArgumentException(name))
    } else {
        Result.success(value)
    }
}

/** Ixtiyoriy parametr. */
fun Map<String, String>.optionalArg(name: String, default: String = ""): String =
    this[name]?.trim()?.takeIf { it.isNotEmpty() } ?: default

class MissingArgumentException(val argName: String) :
    IllegalArgumentException("'$argName' parametri berilmagan")

/** `requireArg` xatosini bir xil matnga aylantirish (barcha tool'lar uchun). */
fun Throwable.toToolMessage(): String = when (this) {
    is MissingArgumentException -> "Kerakli parametr berilmagan: '$argName'"
    else -> message ?: javaClass.simpleName
}
