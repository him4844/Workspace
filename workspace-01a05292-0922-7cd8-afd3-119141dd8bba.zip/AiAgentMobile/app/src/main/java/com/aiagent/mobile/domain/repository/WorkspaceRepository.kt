package com.aiagent.mobile.domain.repository

import com.aiagent.mobile.domain.model.Workspace
import kotlinx.coroutines.flow.Flow

/**
 * Saqlangan workspace'lar bilan ishlash (Faza 2).
 *
 * Implementatsiya: `data/database/WorkspaceRepositoryImpl` (DataStore Preferences).
 * Interfeys domen qatlamida — shuning uchun ViewModel Android saqlash mexanizmini bilmaydi.
 */
interface WorkspaceRepository {

    /** Barcha saqlangan workspace'lar, oxirgi ochilgan vaqti bo'yicha kamayish tartibida. */
    fun observeWorkspaces(): Flow<List<Workspace>>

    /** Yangi workspace qo'shish. Agar shu URI allaqachon saqlangan bo'lsa — yangilaydi. */
    suspend fun addWorkspace(workspace: Workspace)

    /** Ro'yxatdan olib tashlash (fayllarga tegmaydi, faqat yozuvni o'chiradi). */
    suspend fun removeWorkspace(id: String)

    /** "Oxirgi ochilgan vaqti" ni yangilash — workspace ochilganda chaqiriladi. */
    suspend fun touchWorkspace(id: String)

    /** Bitta workspace'ni id bo'yicha topish (Faza 2: FileTreeScreen ochilganda kerak). */
    suspend fun findWorkspace(id: String): Workspace?
}
