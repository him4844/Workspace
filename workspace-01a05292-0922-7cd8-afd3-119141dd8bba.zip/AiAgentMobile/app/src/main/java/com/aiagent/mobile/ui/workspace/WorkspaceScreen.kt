package com.aiagent.mobile.ui.workspace

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiagent.mobile.R

/** Barcha interaktiv elementlar uchun minimal o'lcham (8-qoida: 48dp). */
private val MinTouchTarget = 48.dp

/**
 * Faza 2 — Workspace ekrani: papka tanlash, saqlangan workspace'lar ro'yxati,
 * ruxsati yo'qolgan yozuvlarni boshqarish.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceScreen(
    onOpenWorkspace: (workspaceId: String) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: WorkspaceViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var pendingDelete by remember { mutableStateOf<WorkspaceItem?>(null) }
    var pendingRelink by remember { mutableStateOf<WorkspaceItem?>(null) }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
        onResult = { uri -> viewModel.onFolderPicked(uri) },
    )

    // Foydalanuvchi amallariga darhol javob (8-qoida: feedback).
    LaunchedEffect(Unit) {
        viewModel.messageFlow.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.workspace_title)) },
                actions = {
                    // Faza 3: AI provider sozlamalari shu yerdan ochiladi.
                    IconButton(
                        modifier = Modifier.size(MinTouchTarget),
                        onClick = onOpenSettings,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_settings),
                            contentDescription = stringResource(R.string.workspace_open_settings),
                        )
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { folderPicker.launch(null) },
                icon = {
                    Icon(painterResource(R.drawable.ic_folder_add), contentDescription = null)
                },
                text = { Text(stringResource(R.string.workspace_pick_folder)) },
            )
        },
    ) { innerPadding ->
        when {
            state.isLoading -> LoadingContent(innerPadding)
            state.workspaces.isEmpty() -> EmptyContent(innerPadding) { folderPicker.launch(null) }
            else -> WorkspaceList(
                innerPadding = innerPadding,
                items = state.workspaces,
                onOpen = { item ->
                    if (item.hasAccess) {
                        viewModel.onWorkspaceOpened(item.workspace.id)
                        onOpenWorkspace(item.workspace.id)
                    } else {
                        pendingRelink = item
                    }
                },
                onDelete = { pendingDelete = it },
            )
        }
    }

    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            icon = { Icon(painterResource(R.drawable.ic_delete), contentDescription = null) },
            title = { Text(stringResource(R.string.workspace_delete_dialog_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.workspace_delete_dialog_body,
                        item.workspace.name,
                    ),
                )
            },
            confirmButton = {
                TextButton(
                    modifier = Modifier.height(MinTouchTarget),
                    onClick = {
                        viewModel.onDeleteConfirmed(item.workspace.id)
                        pendingDelete = null
                    },
                ) { Text(stringResource(R.string.workspace_delete)) }
            },
            dismissButton = {
                TextButton(
                    modifier = Modifier.height(MinTouchTarget),
                    onClick = { pendingDelete = null },
                ) { Text(stringResource(R.string.common_cancel)) }
            },
        )
    }

    pendingRelink?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingRelink = null },
            icon = { Icon(painterResource(R.drawable.ic_link_off), contentDescription = null) },
            title = { Text(stringResource(R.string.workspace_access_lost_title)) },
            text = { Text(stringResource(R.string.workspace_access_lost_body)) },
            confirmButton = {
                TextButton(
                    modifier = Modifier.height(MinTouchTarget),
                    onClick = {
                        pendingRelink = null
                        folderPicker.launch(null)
                    },
                ) { Text(stringResource(R.string.workspace_pick_folder)) }
            },
            dismissButton = {
                TextButton(
                    modifier = Modifier.height(MinTouchTarget),
                    onClick = {
                        viewModel.onRelinkRequested(item.workspace.id)
                        pendingRelink = null
                    },
                ) { Text(stringResource(R.string.workspace_delete)) }
            },
        )
    }
}

@Composable
private fun LoadingContent(innerPadding: PaddingValues) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.workspace_loading),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun EmptyContent(innerPadding: PaddingValues, onPick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                painter = painterResource(R.drawable.ic_folder_add),
                contentDescription = null,
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.workspace_empty_title),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.workspace_empty_body),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedButton(
                modifier = Modifier.height(MinTouchTarget),
                onClick = onPick,
            ) { Text(stringResource(R.string.workspace_pick_folder)) }
        }
    }
}

@Composable
private fun WorkspaceList(
    innerPadding: PaddingValues,
    items: List<WorkspaceItem>,
    onOpen: (WorkspaceItem) -> Unit,
    onDelete: (WorkspaceItem) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(items, key = { it.workspace.id }) { item ->
            WorkspaceCard(item = item, onOpen = { onOpen(item) }, onDelete = { onDelete(item) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkspaceCard(
    item: WorkspaceItem,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
) {
    val hasAccess = item.hasAccess
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onOpen,
        colors = CardDefaults.cardColors(
            containerColor = if (hasAccess) {
                MaterialTheme.colorScheme.surfaceVariant
            } else {
                MaterialTheme.colorScheme.errorContainer
            },
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                painter = painterResource(
                    if (hasAccess) R.drawable.ic_folder else R.drawable.ic_link_off,
                ),
                contentDescription = null,
                tint = if (hasAccess) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onErrorContainer
                },
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.workspace.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (hasAccess) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        MaterialTheme.colorScheme.onErrorContainer
                    },
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = if (hasAccess) {
                        relativeTime(item.workspace.lastOpenedAt)
                    } else {
                        stringResource(R.string.workspace_access_lost_short)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (hasAccess) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.onErrorContainer
                    },
                )
            }
            IconButton(
                modifier = Modifier.size(MinTouchTarget),
                onClick = onDelete,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_delete),
                    contentDescription = stringResource(R.string.workspace_delete),
                )
            }
        }
    }
}

@Composable
private fun relativeTime(millis: Long): String {
    val relative = DateUtils.getRelativeTimeSpanString(
        millis,
        System.currentTimeMillis(),
        DateUtils.MINUTE_IN_MILLIS,
    )
    return stringResource(R.string.workspace_last_opened, relative.toString())
}
