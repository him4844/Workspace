package com.aiagent.mobile.domain.repository

import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.model.PdfPages
import com.aiagent.mobile.domain.model.TextMatch

/**
 * Storage Access Framework (SAF) bilan ishlash abstraksiyasi (Faza 2; Faza 4 da
 * yozish/qidirish amallari bilan kengaytirildi).
 *
 * Nima uchun kerak: SAF "path" tushunchasini bilmaydi, faqat URI bilan ishlaydi.
 * Faza 4 dagi fayl tool'lari (`read_file`, `write_file`, `search_text`...) aynan
 * shu interfeys orqali ishlaydi — shuning uchun u domen qatlamida va tool'lar
 * emulyatorsiz test qilinadi.
 *
 * Implementatsiya: `data/filesystem/SafDocumentRepository`.
 */
interface DocumentRepository {

    /**
     * `ACTION_OPEN_DOCUMENT_TREE` natijasida olingan URI uchun doimiy ruxsat olish.
     * Bu chaqiruv bo'lmasa, ilova qayta ochilganda papkaga kirish yo'qoladi.
     */
    fun takePersistablePermission(uri: String)

    /**
     * Saqlangan URI uchun doimiy ruxsat hali amaldami?
     * (Foydalanuvchi tizim sozlamalaridan ruxsatni bekor qilishi yoki papkani
     * o'chirishi mumkin — bu holda aniq xabar ko'rsatish kerak.)
     */
    fun hasPersistablePermission(uri: String): Boolean

    /** Papka nomini olish (workspace ro'yxatida ko'rsatish uchun). I/O — shuning uchun suspend. */
    suspend fun treeDisplayName(uri: String): String?

    /** Bitta papkaning bevosita bolalarini o'qish (chuqur emas — faqat 1 daraja). */
    suspend fun listChildren(uri: String): List<FileNode>

    /**
     * Matn faylini o'qish. [maxBytes] dan katta fayl to'liq o'qilmaydi —
     * natija qisqartirilgan [FileContent.Text] bo'ladi (`truncated = true`).
     * Faza 3: foydalanuvchi tanlovi "to'liq yuklash + kesish", shuning uchun
     * katta matn fayli rad etilmaydi, balki kesiladi va bu aniq ko'rsatiladi.
     */
    suspend fun readTextFile(uri: String, maxBytes: Int): FileContent

    /** Rasmni base64 ko'rinishida o'qish (multimodal provider uchun). */
    suspend fun readImageBase64(uri: String, maxBytes: Int): FileContent

    /** ZIP oilasidagi arxiv yozuvlari ro'yxati. */
    suspend fun listArchiveEntries(uri: String, maxEntries: Int): FileContent

    /** Arxiv ichidagi matnli yozuvlarni o'qib, bitta matnga birlashtirish. */
    suspend fun readArchiveTextEntries(
        uri: String,
        maxEntries: Int,
        maxBytesPerEntry: Int,
    ): FileContent

    /** PDF sahifalarini rasmga aylantirish (Android `PdfRenderer`). */
    suspend fun renderPdfPages(uri: String, maxPages: Int, maxDimensionPx: Int): PdfPages

    /** Fayl hajmi (bayt). Aniqlab bo'lmasa -1. */
    suspend fun fileSize(uri: String): Long

    /** Faylning MIME turi. Aniqlab bo'lmaydigan bo'lsa `null`. */
    suspend fun mimeTypeOf(uri: String): String?

    // ---------------------------------------------------------------- Faza 4

    /**
     * Workspace ildiziga nisbatan yo'lni SAF URI'ga aylantirish.
     * `path` — `src/main.kt` ko'rinishidagi nisbiy yo'l; `.`, `..` va boshlanishdagi
     * `/` tozalanadi. **Agent tanlangan papkadan chiqib keta olmaydi**: `..` ildizdan
     * yuqoriga chiqishga urinmasligi uchun yo'l normallashtiriladi.
     * Mavjud bo'lmasa `null`.
     */
    suspend fun resolveChild(rootUri: String, path: String): String?

    /** Hujjat mavjudmi? */
    suspend fun exists(uri: String): Boolean

    /** Faylga matn yozish (mavjud faylni butunlay almashtiradi). */
    suspend fun writeFile(uri: String, content: String): Boolean

    /** Papka ichida yangi fayl yaratish. Yaratilgan faylning URI'si yoki `null`. */
    suspend fun createFile(parentUri: String, fileName: String, content: String): String?

    /** Papka yaratish. Yaratilgan papkaning URI'si yoki `null`. */
    suspend fun createDirectory(parentUri: String, name: String): String?

    /** Hujjatni o'chirish (fayl yoki bo'sh papka). */
    suspend fun deleteDocument(uri: String): Boolean

    /** Hujjatni boshqa papkaga ko'chirish (nomini ham o'zgartirishi mumkin). */
    suspend fun moveDocument(uri: String, targetParentUri: String, newName: String): String?

    /** Hujjatdan nusxa olish. Nusxaning URI'si yoki `null`. */
    suspend fun copyDocument(uri: String, targetParentUri: String, newName: String): String?

    /**
     * Fayl nomlarini rekursiv qidirish (Faza 4, 3-vazifa — oddiy qidiruv, indeks yo'q).
     * [query] — kichik/katta harfdan qat'i nazar qismli moslik.
     */
    suspend fun searchFiles(rootUri: String, query: String, maxResults: Int): List<FileNode>

    /**
     * Matnli fayllar ichidan qidirish. Qator raqami va matni bilan natija qaytaradi.
     * Ikkilik fayllar o'tkazib yuboriladi ([com.aiagent.mobile.domain.model.FileContent.Binary]).
     */
    suspend fun searchInFiles(
        rootUri: String,
        query: String,
        maxFiles: Int,
        maxMatchesPerFile: Int,
        maxFileBytes: Int,
    ): List<TextMatch>
}
