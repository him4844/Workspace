package com.aiagent.mobile.domain.tools

import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.edit.EditCoordinator
import com.aiagent.mobile.domain.tools.edit.EditTools
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import com.aiagent.mobile.domain.tools.files.MutatingFileTools
import com.aiagent.mobile.domain.tools.files.ReadOnlyFileTools
import com.aiagent.mobile.domain.tools.search.SearchTools

/**
 * Barcha agent tool'larini bitta joyda yig'ish (Faza 4, 1-4 vazifalar).
 *
 * Nima uchun klass (object emas): tool'lar `DocumentRepository` va `EditCoordinator`ga
 * bog'liq, ular esa Hilt orqali keladi. Shuning uchun reyestr DI'da `@Provides` bilan
 * yaratiladi (qarang: `di/UseCaseModule`).
 *
 * Jami 13 ta tool (spetsifikatsiya: 8 fayl + 2 qidiruv + 3 tahrir):
 * - o'qish (3): list_directory, read_file, get_file_info
 * - yozish (5): write_file, create_file, delete_file, move_file, copy_file
 * - qidiruv (2): search_files, search_text
 * - tahrir (3): apply_patch, replace_text, insert_text
 */
class ToolRegistry(
    documents: DocumentRepository,
    private val edits: EditCoordinator,
    checksums: FileChecksumStore,
) {

    private val byName: Map<String, AgentTool> = buildList {
        addAll(ReadOnlyFileTools(documents, checksums).tools)
        addAll(MutatingFileTools(documents, edits, checksums).tools)
        addAll(SearchTools(documents).tools)
        addAll(EditTools(documents, edits, checksums).tools)
    }.associateBy(AgentTool::name)

    /** AI'ga yuboriladigan tool ro'yxati. */
    val tools: List<AgentTool> = byName.values.toList()

    /** AI'ga yuboriladigan tool tavsiflari (JSON schema uchun). */
    val specs: List<ToolSpec> = tools.map(ToolSpec::from)

    fun find(name: String): AgentTool? = byName[name]

    /**
     * Tool'ni chaqirish. Noma'lum nom uchun aniq xato qaytadi — agent o'zini
     * tuzatishi mumkin (masalan `read_files` deb xato yozsa, ro'yxatni ko'rsatamiz).
     */
    suspend fun invoke(
        name: String,
        args: Map<String, String>,
        context: ToolContext,
    ): ToolResult {
        val tool = byName[name] ?: return toolError(
            "'$name' nomli tool yo'q. Mavjud tool'lar: ${byName.keys.sorted().joinToString(", ")}",
            recoverable = true,
        )
        return try {
            tool.execute(args, context)
        } catch (exception: Exception) {
            // Tool ichidagi kutilmagan xato butun agentni o'ldirmasligi kerak —
            // xato AI'ga qaytariladi va sikl davom etadi.
            toolError(
                "Tool bajarilishida kutilmagan xato: ${exception.message ?: exception.javaClass.simpleName}",
                recoverable = true,
            )
        }
    }

    /** Yozish tool'larini ajratish — UI'da "xavfli amal" belgisi uchun. */
    val mutatingToolNames: Set<String> = setOf(
        "write_file", "create_file", "delete_file", "move_file", "copy_file",
        "apply_patch", "replace_text", "insert_text",
    )
}

/** AI'ga yuboriladigan tool tavsifi (OpenAI function-calling sxemasiga aylantiriladi). */
data class ToolSpec(
    val name: String,
    val description: String,
    val parameters: List<ToolParameter>,
) {
    companion object {
        fun from(tool: AgentTool) = ToolSpec(
            name = tool.name,
            description = tool.description,
            parameters = tool.parameters,
        )
    }
}
