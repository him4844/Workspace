package com.aiagent.mobile.domain.tools

/**
 * Tool bajarilishi natijasi (Faza 4, 1-vazifa — spetsifikatsiyadagi aniq shakl).
 *
 * Nima uchun sealed class va uchta tur:
 * - [Success] — natija matn sifatida AI'ga qaytariladi (keyingi qadam shunga qarab davom etadi).
 * - [Error] — xato AI'ga qaytariladi; `recoverable = true` bo'lsa agent boshqa yo'lni
 *   sinab ko'rishi mumkin, `false` bo'lsa sikl to'xtatiladi (masalan ruxsat yo'q).
 * - [PermissionRequired] — xavfli/tasdiqlashni talab qiladigan amal. Agent
 *   `WAITING_FOR_PERMISSION` holatiga o'tadi va foydalanuvchi qarorini kutadi
 *   (`ALWAYS_CONFIRM` rejimidagi barcha fayl o'zgartirishlari shu yo'ldan o'tadi).
 */
sealed class ToolResult {
    data class Success(val output: String) : ToolResult()
    data class Error(val message: String, val recoverable: Boolean) : ToolResult()
    data class PermissionRequired(val description: String) : ToolResult()
}

/** Qisqa yordamchilar — tool kodini ixcham saqlash uchun. */
fun toolSuccess(output: String): ToolResult = ToolResult.Success(output)

fun toolError(message: String, recoverable: Boolean = true): ToolResult =
    ToolResult.Error(message, recoverable)
