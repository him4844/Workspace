package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.FileNode

/**
 * Ierarxik fayl daraxtini LazyColumn uchun tekis (flat) ro'yxatga aylantirish.
 *
 * Bu sof mantiq — Android'siz test qilinadi (`FileTreeFlattenerTest`).
 * LazyColumn ierarxiyani to'g'ridan-to'g'ri ko'rsata olmaydi, shuning uchun
 * ochilgan papkalarning bolalari ro'yxatga chuqurlik ([FileRow.depth]) bilan qo'shiladi.
 *
 * Muhim: bolalar **sekin (lazy)** yuklanadi. Ochilgan papka hali yuklanmagan bo'lsa,
 * u ro'yxatga kiritilmaydi — UI o'z holatida "yuklanmoqda" indikatorini ko'rsatadi.
 */
object FileTreeFlattener {

    /**
     * @param rootChildren ildiz papkaning bolalari
     * @param childrenByUri har bir ochilgan papka URI'si -> uning bolalari
     * @param expandedUris hozir ochiq (yoyilgan) papkalar URI'lari
     */
    fun flatten(
        rootChildren: List<FileNode>,
        childrenByUri: Map<String, List<FileNode>>,
        expandedUris: Set<String>,
    ): List<FileRow> {
        val rows = mutableListOf<FileRow>()
        appendRows(
            nodes = sortForDisplay(rootChildren),
            depth = 0,
            expandedUris = expandedUris,
            childrenByUri = childrenByUri,
            out = rows,
        )
        return rows
    }

    /** Papkalar birinchi, keyin fayllar; har biri nomi bo'yicha (katta-kichik harf muhim emas). */
    fun sortForDisplay(nodes: List<FileNode>): List<FileNode> =
        nodes.sortedWith(
            compareByDescending<FileNode> { it.isDirectory }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.name },
        )

    private fun appendRows(
        nodes: List<FileNode>,
        depth: Int,
        expandedUris: Set<String>,
        childrenByUri: Map<String, List<FileNode>>,
        out: MutableList<FileRow>,
    ) {
        nodes.forEach { node ->
            val isExpanded = node.isDirectory && node.uri in expandedUris
            out += FileRow(node = node, depth = depth, isExpanded = isExpanded)

            if (isExpanded) {
                val children = childrenByUri[node.uri] ?: return@forEach
                appendRows(
                    nodes = sortForDisplay(children),
                    depth = depth + 1,
                    expandedUris = expandedUris,
                    childrenByUri = childrenByUri,
                    out = out,
                )
            }
        }
    }
}

/** LazyColumn'ning bitta qatori: tugun + uning chuqurligi (chapdan chekinish uchun). */
data class FileRow(
    val node: FileNode,
    val depth: Int,
    val isExpanded: Boolean,
)
