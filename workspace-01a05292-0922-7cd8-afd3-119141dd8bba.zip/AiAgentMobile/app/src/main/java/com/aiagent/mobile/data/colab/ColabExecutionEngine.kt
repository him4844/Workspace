package com.aiagent.mobile.data.colab

import com.aiagent.mobile.data.colab.dto.ColabExecuteRequest
import com.aiagent.mobile.domain.agent.ColabStatus
import com.aiagent.mobile.domain.agent.RemoteExecutionEngine
import com.aiagent.mobile.domain.agent.RemoteTask
import com.aiagent.mobile.domain.agent.RemoteTaskResult
import com.aiagent.mobile.domain.repository.SettingsRepository
import com.aiagent.mobile.domain.usecase.ColabUrlNormalizer
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType

/**
 * Colab serveri bilan ishlash (Faza 5, 2-vazifa).
 *
 * Faza 1 dagi `RemoteExecutionEngine` interfeysining haqiqiy implementatsiyasi.
 *
 * **QAROR — ikkita timeout:** `/health` tez javob berishi kerak (aks holda Sozlamalar
 * ekrani "tekshirilmoqda" holatida osilib qoladi), `/execute` esa og'ir build'ni kutadi
 * (bir necha daqiqa). Shuning uchun bitta `OkHttpClient`dan ikki xil muddatli
 * mijoz hosil qilinadi.
 *
 * **QAROR — manzil bo'yicha kesh:** foydalanuvchi ngrok havolasini har sessiyada
 * almashtiradi. Retrofit nusxasi manzil bo'yicha keshlanadi, lekin `OkHttpClient`
 * umumiy (ulanishlar havzasi bo'lishiladi) — Faza 3 dagi provider naqshi bilan bir xil.
 */
@Singleton
class ColabExecutionEngine @Inject constructor(
    private val httpClient: OkHttpClient,
    private val settingsRepository: SettingsRepository,
) : RemoteExecutionEngine {

    private val healthApis = ConcurrentHashMap<String, ColabApi>()
    private val executeApis = ConcurrentHashMap<String, ColabApi>()

    private val json = Json {
        ignoreUnknownKeys = true
        // Server maydon yubormasa, DTO standart qiymati ishlatilsin (qulash bo'lmasligi uchun).
        coerceInputValues = true
        // MUHIM: `encodeDefaults` bo'lmasa, kotlinx.serialization STANDART qiymatli
        // maydonlarni umuman yubormaydi. `timeoutSeconds = 300` standart bo'lgani uchun
        // `timeout_seconds` simga chiqmasdi va foydalanuvchi bergan boshqa muddat
        // serverga JIM yetib bormasdi. (Faza 3 da `stream` bilan aynan shu xato bo'lgan.)
        encodeDefaults = true
    }

    override suspend fun isAvailable(): Boolean = checkStatus().isConnected

    override suspend fun checkStatus(): ColabStatus {
        val url = currentUrl() ?: return ColabStatus.NotConfigured
        val api = healthApis.getOrPut(url) { retrofitFor(url, HEALTH_READ_TIMEOUT_SECONDS) }

        return try {
            val response = api.health()
            when {
                response.isSuccessful -> {
                    val body = response.body()
                    ColabStatus.Connected(workspaceExists = body?.workspaceExists ?: true)
                }

                // Ngrok o'lik tunnel uchun aynan shu kodlarni qaytaradi. Bu "server
                // xatosi" emas — havola eskirgani, shuning uchun foydalanuvchiga
                // boshqa (va aniq) yo'l ko'rsatma beriladi.
                response.code() in STALE_TUNNEL_CODES ->
                    ColabStatus.Unreachable("HTTP ${response.code()} — tunnel yopiq")

                else -> ColabStatus.ServerError(response.code())
            }
        } catch (timeout: SocketTimeoutException) {
            ColabStatus.Unreachable(timeout.message ?: "vaqt tugadi")
        } catch (ioException: IOException) {
            // Eng ko'p uchraydigan holat: Colab sessiyasi tugagan, havola eskirgan.
            ColabStatus.Unreachable(ioException.message ?: ioException.javaClass.simpleName)
        } catch (exception: Exception) {
            ColabStatus.Unreachable(exception.message ?: exception.javaClass.simpleName)
        }
    }

    override suspend fun executeTask(task: RemoteTask): RemoteTaskResult {
        val url = currentUrl()
            ?: return RemoteTaskResult(
                success = false,
                output = "",
                // Foydalanuvchi buni ko'rganda nima qilishini bilishi kerak — shunchaki
                // "xato" emas, aniq yo'l ko'rsatma.
                errorMessage = "Colab URL kiritilmagan. Sozlamalar → Colab URL maydoniga " +
                    "havolani joylashtiring.",
            )

        val api = executeApis.getOrPut(url) { retrofitFor(url, EXECUTE_READ_TIMEOUT_SECONDS) }
        val request = ColabExecuteRequest(
            id = task.id,
            command = task.command,
            workdir = task.workdir,
            timeoutSeconds = (task.timeoutMs / MILLIS_IN_SECOND).toInt().coerceAtLeast(1),
        )

        return try {
            val response = api.execute(request)
            if (response.isSuccessful) {
                val body = response.body()
                    ?: return RemoteTaskResult(
                        success = false,
                        output = "",
                        errorMessage = "Colab bo'sh javob qaytardi (HTTP ${response.code()}).",
                    )
                RemoteTaskResult(
                    success = body.success,
                    output = body.output,
                    errorMessage = body.errorMessage,
                )
            } else {
                RemoteTaskResult(
                    success = false,
                    output = "",
                    errorMessage = "Colab serveri xato qaytardi (HTTP ${response.code()}). " +
                        "Havola eskirgan bo'lishi mumkin — Colab'da 'Run all' ni qayta bosing.",
                )
            }
        } catch (timeout: SocketTimeoutException) {
            RemoteTaskResult(
                success = false,
                output = "",
                errorMessage = "Colab javob bermadi (vaqt tugadi). Build juda og'ir bo'lishi " +
                    "mumkin yoki havola eskirgan.",
            )
        } catch (ioException: IOException) {
            RemoteTaskResult(
                success = false,
                output = "",
                errorMessage = "Colab bilan aloqa uzildi: " +
                    "${ioException.message ?: ioException.javaClass.simpleName}. " +
                    "Havola eskirgan bo'lsa, yangisini kiriting.",
            )
        } catch (exception: Exception) {
            RemoteTaskResult(
                success = false,
                output = "",
                errorMessage = "Kutilmagan xato: " +
                    "${exception.message ?: exception.javaClass.simpleName}",
            )
        }
    }

    /** Sozlamalardagi joriy Colab manzili (tozalangan). Kiritilmagan bo'lsa `null`. */
    private suspend fun currentUrl(): String? {
        val settings = settingsRepository.settings.first()
        return ColabUrlNormalizer.normalize(settings.colabUrl)
    }

    private fun retrofitFor(baseUrl: String, readTimeoutSeconds: Long): ColabApi =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(
                httpClient.newBuilder()
                    .readTimeout(readTimeoutSeconds, TimeUnit.SECONDS)
                    .build(),
            )
            .addConverterFactory(json.asConverterFactory(CONTENT_TYPE.toMediaType()))
            .build()
            .create(ColabApi::class.java)

    private companion object {
        /** Ngrok o'lik/eskirgan tunnel uchun qaytaradigan kodlar. */
        val STALE_TUNNEL_CODES = setOf(404, 502, 503, 504)

        const val HEALTH_READ_TIMEOUT_SECONDS = 15L
        const val EXECUTE_READ_TIMEOUT_SECONDS = 1_200L
        const val MILLIS_IN_SECOND = 1_000L
        const val CONTENT_TYPE = "application/json"
    }
}
