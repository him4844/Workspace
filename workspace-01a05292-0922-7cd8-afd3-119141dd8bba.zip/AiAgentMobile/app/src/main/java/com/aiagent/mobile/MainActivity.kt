package com.aiagent.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.aiagent.mobile.ui.navigation.AiAgentNavHost
import com.aiagent.mobile.ui.theme.AiAgentTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Yagona Activity (single-activity arxitektura).
 * Barcha ekranlar Compose Navigation orqali [AiAgentNavHost] ichida almashadi.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AiAgentTheme {
                AiAgentNavHost()
            }
        }
    }
}
