package com.aiagent.mobile.domain.usecase

import com.aiagent.mobile.domain.model.IngestedFile
import com.aiagent.mobile.domain.model.IngestedImage

/**
 * Biriktirilgan fayllardan AI'ga yuboriladigan kontekst blokini qurish — sof mantiq.
 *
 * Foydalanuvchi tanlagan strategiya: "to'liq yuklash + kesish". Shuning uchun
 * byudjetga sig'magan qism kesiladi, LEKIN bu hech qachon yashirin bo'lmaydi:
 * har bir kesish haqida [Result.warnings] orqali aniq izoh qaytariladi va u
 * ham modelga, ham foydalanuvchiga ko'rsatiladi.
 */
object FileContextBuilder {

    data class Result(
        val text: String,
        val images: List<IngestedImage>,
        val warnings: List<String>,
    )

    /**
     * @param files chatga biriktirilgan fayllar
     * @param availableTokens fayllar uchun ajratilgan token byudjeti
     */
    fun build(files: List<IngestedFile>, availableTokens: Int): Result {
        if (files.isEmpty()) return Result(text = "", images = emptyList(), warnings = emptyList())

        // Byudjet fayllar orasida teng bo'linadi, lekin har biriga kamida
        // MIN_TOKENS_PER_FILE qoldiriladi — aks holda ko'p fayl biriktirilganda
        // har biri foydasiz darajada qisqarib qoladi.
        val perFileTokens = (availableTokens / files.size).coerceAtLeast(MIN_TOKENS_PER_FILE)

        val builder = StringBuilder()
        val warnings = mutableListOf<String>()
        val images = mutableListOf<IngestedImage>()

        files.forEach { file ->
            builder.append("\n\n--- Biriktirilgan fayl: ${file.fileName} ")
            builder.append("(${describeSize(file.sizeBytes)}, tur: ${file.kind.name}) ---\n")

            file.note?.let { note ->
                builder.append("[Izoh: $note]\n")
                warnings += "${file.fileName}: $note"
            }

            val text = file.text
            if (!text.isNullOrEmpty()) {
                val truncated = TokenEstimator.truncateToTokens(text, perFileTokens)
                builder.append(truncated.text)
                if (truncated.truncated || file.truncated) {
                    val message = "kontekst cheklovi tufayli faqat birinchi " +
                        "~${perFileTokens}token qismi yuborildi"
                    if (file.note == null) warnings += "${file.fileName}: $message"
                }
            }

            if (file.images.isNotEmpty()) {
                images += file.images
                builder.append(
                    "[Bu fayl rasm sifatida biriktirildi: ${file.images.size} ta rasm. " +
                        "Rasm provayder qo'llab-quvvatlamasa, u o'rniga yuqoridagi metadata ishlatiladi.]",
                )
            }
        }

        return Result(
            text = builder.toString().trim(),
            images = images,
            warnings = warnings,
        )
    }

    private fun describeSize(bytes: Long): String = when {
        bytes <= 0 -> "hajm noma'lum"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "${bytes / (1024 * 1024)} MB"
    }

    private const val MIN_TOKENS_PER_FILE = 500
}
