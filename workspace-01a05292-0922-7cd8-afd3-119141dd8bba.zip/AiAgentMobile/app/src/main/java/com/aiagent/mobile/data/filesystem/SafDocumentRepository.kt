package com.aiagent.mobile.data.filesystem

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import com.aiagent.mobile.domain.model.FileContent
import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.model.PdfPages
import com.aiagent.mobile.domain.model.TextMatch
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.usecase.FileContentClassifier
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SAF (Storage Access Framework) orqali fayl tizimiga kirish.
 *
 * Hech qanday `READ_EXTERNAL_STORAGE` / `MANAGE_EXTERNAL_STORAGE` ruxsati so'ralmaydi:
 * foydalanuvchi papkani o'zi tanlaydi va biz faqat shu papkaga (va uning ichidagilarga)
 * `takePersistableUriPermission` orqali doimiy ruxsat olamiz.
 *
 * Faza 3: matn bilan birga rasm (base64), PDF (sahifa rasmlari) va arxiv (ro'yxat +
 * matnli yozuvlar) o'qish qo'shildi — agent har qanday turdagi fayldan foydalanishi kerak.
 */
@Singleton
class SafDocumentRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) : DocumentRepository {

    private val resolver get() = context.contentResolver
    private val archives by lazy { ArchiveReader(resolver) }
    private val pdfs by lazy { PdfPageRenderer(resolver) }
    private val writer by lazy { SafDocumentWriter(context) }
    private val searcher by lazy { SafSearcher(context, writer) }

    override fun takePersistablePermission(uri: String) {
        val parsed = uri.toUri()
        val readWrite = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            resolver.takePersistableUriPermission(parsed, readWrite)
        } catch (securityException: SecurityException) {
            // Ba'zi DocumentsProvider'lar faqat o'qish ruxsatini beradi (masalan "Yuklab olishlar"
            // ustidan tanlangan ba'zi manbalar). Bunday holda kamida o'qishni saqlab qolamiz.
            resolver.takePersistableUriPermission(parsed, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    override fun hasPersistablePermission(uri: String): Boolean {
        val parsed = uri.toUri()
        return resolver.persistedUriPermissions.any { permission ->
            permission.uri == parsed && permission.isReadPermission
        }
    }

    override suspend fun treeDisplayName(uri: String): String? = withContext(Dispatchers.IO) {
        DocumentFile.fromTreeUri(context, uri.toUri())?.name
    }

    override suspend fun listChildren(uri: String): List<FileNode> = withContext(Dispatchers.IO) {
        val directory = DocumentFile.fromTreeUri(context, uri.toUri())
            ?: return@withContext emptyList()
        if (!directory.exists()) return@withContext emptyList()

        directory.listFiles().map { documentFile ->
            FileNode(
                name = documentFile.name ?: UNTITLED_NAME,
                uri = documentFile.uri.toString(),
                isDirectory = documentFile.isDirectory,
                sizeBytes = documentFile.length(),
                mimeType = documentFile.type,
            )
        }
    }

    override suspend fun readTextFile(uri: String, maxBytes: Int): FileContent =
        withContext(Dispatchers.IO) {
            val parsed = uri.toUri()
            val mimeType = runCatching { resolver.getType(parsed) }.getOrNull()

            val raw = try {
                // Chegaragacha o'qiymiz (maxBytes+1 emas): Faza 3 strategiyasi
                // "to'liq yuklash + kesish", shuning uchun katta fayl rad etilmaydi.
                readAtMost(parsed, maxBytes)
            } catch (ioException: IOException) {
                return@withContext FileContent.Failed(
                    reason = "Faylni o'qib bo'lmadi: " +
                        "${ioException.message ?: "kiritish-chiqarish xatosi"}",
                )
            }

            if (raw == null) {
                return@withContext FileContent.Failed(reason = "Fayl ochilmadi yoki ruxsat yo'q")
            }

            // Haqiqiy hajm alohida so'raladi: kesilganini aniq aytish uchun kerak.
            val realSize = querySize(parsed) ?: raw.size.toLong()

            FileContentClassifier.classify(
                raw = raw,
                reportedSizeBytes = maxOf(realSize, raw.size.toLong()),
                maxBytes = maxBytes,
                mimeType = mimeType,
            )
        }

    override suspend fun readImageBase64(uri: String, maxBytes: Int): FileContent =
        withContext(Dispatchers.IO) {
            val parsed = uri.toUri()
            val mimeType = resolver.getType(parsed) ?: IMAGE_FALLBACK_MIME

            // maxBytes+1 o'qiladi: chegaradan oshgani aniqlansa, rasm rad etiladi
            // (rasmni kesish ma'nosiz — modelga buzilgan rasm kerak emas).
            val raw = try {
                readAtMost(parsed, maxBytes + 1)
            } catch (ioException: IOException) {
                return@withContext FileContent.Failed(
                    reason = "Rasmni o'qib bo'lmadi: " +
                        "${ioException.message ?: "kiritish-chiqarish xatosi"}",
                )
            } ?: return@withContext FileContent.Failed(reason = "Rasm ochilmadi yoki ruxsat yo'q")

            if (raw.size > maxBytes) {
                val realSize = querySize(parsed) ?: raw.size.toLong()
                return@withContext FileContent.TooLarge(
                    sizeBytes = realSize,
                    maxBytes = maxBytes.toLong(),
                )
            }

            FileContent.Image(
                mimeType = mimeType,
                base64 = Base64.encodeToString(raw, Base64.NO_WRAP),
                sizeBytes = raw.size.toLong(),
            )
        }

    override suspend fun listArchiveEntries(uri: String, maxEntries: Int): FileContent =
        withContext(Dispatchers.IO) { archives.listEntries(uri.toUri(), maxEntries) }

    override suspend fun readArchiveTextEntries(
        uri: String,
        maxEntries: Int,
        maxBytesPerEntry: Int,
    ): FileContent = withContext(Dispatchers.IO) {
        archives.readTextEntries(uri.toUri(), maxEntries, maxBytesPerEntry)
    }

    override suspend fun renderPdfPages(
        uri: String,
        maxPages: Int,
        maxDimensionPx: Int,
    ): PdfPages = withContext(Dispatchers.IO) {
        pdfs.render(uri.toUri(), maxPages, maxDimensionPx)
    }

    override suspend fun fileSize(uri: String): Long = withContext(Dispatchers.IO) {
        querySize(uri.toUri()) ?: -1L
    }

    override suspend fun mimeTypeOf(uri: String): String? = withContext(Dispatchers.IO) {
        runCatching { resolver.getType(uri.toUri()) }.getOrNull()
    }

    /**
     * Fayl hajmini `DocumentsContract` so'rovi orqali olish.
     * `DocumentFile.fromSingleUri` daraxt ichidagi fayllar uchun ishlamaydi
     * (Faza 2 da kuzatilgan), shuning uchun to'g'ridan-to'g'ri cursor ishlatiladi.
     */
    private fun querySize(uri: Uri): Long? {
        val cursor = runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
        }.getOrNull() ?: return null
        return cursor.use {
            val index = it.getColumnIndex(OpenableColumns.SIZE)
            if (index < 0 || !it.moveToFirst()) return@use null
            if (it.isNull(index)) null else it.getLong(index)
        }
    }

    /**
     * Oqimdan ko'pi bilan [limit] bayt o'qiydi.
     *
     * Diqqat: `InputStream.readNBytes(int)` Java 9+ metodi va Android'da faqat API 33 dan bor.
     * Bizning minSdk 30, shuning uchun qo'lda sikl ishlatiladi.
     */
    private fun readAtMost(uri: Uri, limit: Int): ByteArray? {
        val input = runCatching { resolver.openInputStream(uri) }.getOrNull() ?: return null
        return input.use { stream ->
            val accumulator = ByteArrayOutputStream()
            val buffer = ByteArray(READ_BUFFER_BYTES)
            var total = 0
            while (total < limit) {
                val read = stream.read(buffer, 0, minOf(buffer.size, limit - total))
                if (read <= 0) break
                accumulator.write(buffer, 0, read)
                total += read
            }
            accumulator.toByteArray()
        }
    }

    // ------------------------------------------------------------ Faza 4
    // Yozish va qidirish amallari `SafDocumentWriter`/`SafSearcher`ga topshirilgan:
    // bu fayl 400 qator chegarasidan oshmasligi kerak (7-qoida).

    override suspend fun resolveChild(rootUri: String, path: String): String? =
        withContext(Dispatchers.IO) { writer.resolve(rootUri, path) }

    override suspend fun exists(uri: String): Boolean =
        withContext(Dispatchers.IO) { writer.exists(uri) }

    override suspend fun writeFile(uri: String, content: String): Boolean =
        withContext(Dispatchers.IO) { writer.writeFile(uri, content) }

    override suspend fun createFile(
        parentUri: String,
        fileName: String,
        content: String,
    ): String? = withContext(Dispatchers.IO) { writer.createFile(parentUri, fileName, content) }

    override suspend fun createDirectory(parentUri: String, name: String): String? =
        withContext(Dispatchers.IO) { writer.createDirectory(parentUri, name) }

    override suspend fun deleteDocument(uri: String): Boolean =
        withContext(Dispatchers.IO) { writer.deleteDocument(uri) }

    override suspend fun moveDocument(
        uri: String,
        targetParentUri: String,
        newName: String,
    ): String? = withContext(Dispatchers.IO) {
        writer.moveDocument(uri, targetParentUri, newName)
    }

    override suspend fun copyDocument(
        uri: String,
        targetParentUri: String,
        newName: String,
    ): String? = withContext(Dispatchers.IO) {
        writer.copyDocument(uri, targetParentUri, newName)
    }

    override suspend fun searchFiles(
        rootUri: String,
        query: String,
        maxResults: Int,
    ): List<FileNode> = withContext(Dispatchers.IO) {
        searcher.searchFiles(rootUri, query, maxResults)
    }

    override suspend fun searchInFiles(
        rootUri: String,
        query: String,
        maxFiles: Int,
        maxMatchesPerFile: Int,
        maxFileBytes: Int,
    ): List<TextMatch> = withContext(Dispatchers.IO) {
        searcher.searchInFiles(rootUri, query, maxFiles, maxMatchesPerFile, maxFileBytes)
    }

    private companion object {
        const val READ_BUFFER_BYTES = 8 * 1024
        const val UNTITLED_NAME = "noma'lum"
        const val IMAGE_FALLBACK_MIME = "image/png"
    }
}
