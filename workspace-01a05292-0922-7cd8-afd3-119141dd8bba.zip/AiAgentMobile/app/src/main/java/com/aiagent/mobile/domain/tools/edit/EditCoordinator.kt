package com.aiagent.mobile.domain.tools.edit

import com.aiagent.mobile.domain.model.EditMode
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.toolError
import com.aiagent.mobile.domain.tools.toolSuccess
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Fayl o'zgartirishlarini boshqarish (Faza 4, 5-8 vazifalar).
 *
 * Ikki rejim (Faza 1 dagi `AppSettings.editMode`):
 * - `ALWAYS_CONFIRM` (XAVFSIZ STANDART) — hech bir fayl foydalanuvchi tasdiqlamasdan
 *   o'zgarmaydi. Amal [pending] ga qo'yiladi va [ToolResult.PermissionRequired]
 *   qaytadi; agent `WAITING_FOR_PERMISSION` holatida kutadi. Diff ekranida
 *   "Qabul qilish" → [accept], "Rad etish" → [reject].
 * - `AUTO_APPLY` — amal darhol bajariladi, lekin har biri [EditHistory]ga yoziladi
 *   (oxirgi [MAX_HISTORY]) va [undoLast] bilan qaytariladi.
 *
 * Bu klass SOF KOTLIN: fayl I/O `DocumentRepository` orqali, shuning uchun
 * fake repository bilan JVM testida tekshiriladi.
 */
class EditCoordinator {

    var editMode: EditMode = EditMode.ALWAYS_CONFIRM

    private val _pending = MutableStateFlow<ProposedFileEdit?>(null)

    /**
     * `ALWAYS_CONFIRM` rejimida foydalanuvchi qarorini kutayotgan amal.
     *
     * Nima uchun `StateFlow`: diff ekrani Compose'da chiziladi. Oddiy `var` bo'lsa,
     * Compose uning o'zgarganini bilmaydi va ekran tasodifan (boshqa holat o'zgarishi
     * tufayli qayta chizilganda) paydo bo'ladi. `StateFlow` buni kafolatlaydi.
     */
    val pendingFlow: StateFlow<ProposedFileEdit?> = _pending.asStateFlow()

    /** Hozirgi kutilayotgan amal (`null` bo'lsa kutilmayapti). */
    val pending: ProposedFileEdit? get() = _pending.value

    private val historyEntries = ArrayDeque<EditHistoryEntry>()

    fun history(): List<EditHistoryEntry> = historyEntries.toList()

    /**
     * Amalni bajarishga yuborish. `ALWAYS_CONFIRM` da bajarilmaydi — faqat navbatga qo'yiladi.
     */
    suspend fun request(
        edit: ProposedFileEdit,
        documents: DocumentRepository,
    ): ToolResult {
        // Halokatli amallar HAR DOIM tasdiqdan o'tadi — `AUTO_APPLY` rejimida ham.
        // Spetsifikatsiyaning UI/UX qoidasi: "fayl o'chirish ... har doim tasdiqlash
        // dialogi orqali o'tadi". Foydalanuvchi avtomatik rejimni tanlagan bo'lsa ham,
        // qaytarib bo'lmaydigan amalni jim bajarish xavfsiz-standart tamoyiliga zid.
        if (editMode == EditMode.ALWAYS_CONFIRM || edit.kind == EditKind.DELETE) {
            _pending.value = edit
            return ToolResult.PermissionRequired(edit.description)
        }
        return perform(edit, documents, recordHistory = true)
    }

    /** Foydalanuvchi diff ekranida "Qabul qilish" bosdi. */
    suspend fun accept(documents: DocumentRepository): ToolResult {
        val edit = pending ?: return toolError("Tasdiqlashni kutayotgan amal yo'q", recoverable = false)
        _pending.value = null
        return perform(edit, documents, recordHistory = true)
    }

    /** Foydalanuvchi "Rad etish" bosdi — agent boshqa yechim sinab ko'rishi mumkin. */
    fun reject(): ToolResult {
        _pending.value = null
        return toolError("Foydalanuvchi o'zgartirishni rad etdi.", recoverable = true)
    }

    /** Oxirgi amalni qaytarish (Faza 4, 8-vazifa). */
    suspend fun undoLast(documents: DocumentRepository): ToolResult {
        val entry = historyEntries.removeLastOrNull()
            ?: return toolError("Qaytariladigan o'zgartirish yo'q.", recoverable = true)

        return when (entry.kind) {
            EditKind.OVERWRITE -> {
                val content = entry.previousContent
                    ?: return toolError("Eski matn saqlanmagan — qaytarib bo'lmadi.", false)
                if (documents.writeFile(entry.uri, content)) {
                    toolSuccess("'${entry.path}' oldingi holatiga qaytarildi.")
                } else {
                    toolError("Faylga yozib bo'lmadi: ${entry.path}", recoverable = false)
                }
            }

            EditKind.CREATE -> {
                val created = entry.createdUri
                    ?: return toolError("Yaratilgan fayl manzili saqlanmagan.", false)
                if (documents.deleteDocument(created)) {
                    toolSuccess("Yaratilgan '${entry.path}' o'chirildi.")
                } else {
                    toolError("Faylni o'chirib bo'lmadi: ${entry.path}", recoverable = false)
                }
            }

            EditKind.DELETE -> {
                val content = entry.previousContent
                    ?: return toolError("O'chirilgan fayl matni saqlanmagan.", false)
                val parent = parentUriOf(entry.uri)
                    ?: return toolError("Asl papkani aniqlab bo'lmadi.", false)
                val restored = documents.createFile(parent, fileNameOf(entry.path), content)
                if (restored != null) {
                    toolSuccess("'${entry.path}' qayta tiklandi.")
                } else {
                    toolError("Faylni qayta yaratib bo'lmadi: ${entry.path}", recoverable = false)
                }
            }

            EditKind.MOVE -> {
                val source = entry.sourceUri
                    ?: return toolError("Asl manzil saqlanmagan.", false)
                val parent = parentUriOf(source)
                    ?: return toolError("Asl papkani aniqlab bo'lmadi.", false)
                val moved = documents.moveDocument(entry.uri, parent, fileNameOf(entry.path))
                if (moved != null) {
                    toolSuccess("'${entry.path}' eski joyiga qaytarildi.")
                } else {
                    toolError("Faylni qayta ko'chirib bo'lmadi.", recoverable = false)
                }
            }

            EditKind.COPY -> {
                val created = entry.createdUri
                    ?: return toolError("Nusxa manzili saqlanmagan.", false)
                if (documents.deleteDocument(created)) {
                    toolSuccess("Nusxa o'chirildi.")
                } else {
                    toolError("Nusxani o'chirib bo'lmadi.", recoverable = false)
                }
            }
        }
    }

    /** Amalni haqiqatan bajarish va tarixga yozish. */
    private suspend fun perform(
        edit: ProposedFileEdit,
        documents: DocumentRepository,
        recordHistory: Boolean,
    ): ToolResult = when (edit.kind) {
        EditKind.OVERWRITE -> {
            val content = edit.newContent ?: return toolError("Yoziladigan matn yo'q.", false)
            if (documents.writeFile(edit.uri, content)) {
                if (recordHistory) {
                    push(
                        EditHistoryEntry(
                            path = edit.path,
                            uri = edit.uri,
                            kind = EditKind.OVERWRITE,
                            previousContent = edit.originalContent,
                            createdUri = null,
                            description = edit.description,
                            timestamp = System.currentTimeMillis(),
                        ),
                    )
                }
                toolSuccess("'${edit.path}' yangilandi (${content.length} belgi).")
            } else {
                toolError("Faylga yozib bo'lmadi: ${edit.path}", recoverable = false)
            }
        }

        EditKind.CREATE -> {
            val content = edit.newContent ?: ""
            // DIQQAT: CREATE uchun `edit.uri` ALLAQACHON ota papka URI'si
            // (`MutatingFileTools.CreateFile` shunday to'ldiradi). Shuning uchun bu yerda
            // `parentUriOf` ISHLATILMAYDI — aks holda fayl ota papkaning ichiga emas,
            // bobosiga yaratiladi. Bu xato Faza 4 testlarida aniqlandi va tuzatildi.
            val parent = edit.uri
            val created = documents.createFile(parent, fileNameOf(edit.path), content)
            if (created != null) {
                if (recordHistory) {
                    push(
                        EditHistoryEntry(
                            path = edit.path,
                            uri = created,
                            kind = EditKind.CREATE,
                            previousContent = null,
                            createdUri = created,
                            description = edit.description,
                            timestamp = System.currentTimeMillis(),
                        ),
                    )
                }
                toolSuccess("'${edit.path}' yaratildi.")
            } else {
                toolError(
                    "Faylni yaratib bo'lmadi: ${edit.path} (allaqachon mavjud bo'lishi mumkin)",
                    recoverable = true,
                )
            }
        }

        EditKind.DELETE -> {
            if (recordHistory) {
                push(
                    EditHistoryEntry(
                        path = edit.path,
                        uri = edit.uri,
                        kind = EditKind.DELETE,
                        previousContent = edit.originalContent,
                        createdUri = null,
                        description = edit.description,
                        timestamp = System.currentTimeMillis(),
                    ),
                )
            }
            if (documents.deleteDocument(edit.uri)) {
                toolSuccess("'${edit.path}' o'chirildi.")
            } else {
                toolError("Faylni o'chirib bo'lmadi: ${edit.path}", recoverable = false)
            }
        }

        EditKind.MOVE -> {
            val target = edit.targetPath
                ?: return toolError("Ko'chirish uchun yangi yo'l berilmagan.", true)
            val targetParent = parentUriOf(edit.uri)?.let { resolveParentFor(documents, edit.rootUri, target) }
                ?: return toolError("Maqsad papkani aniqlab bo'lmadi: $target", true)
            val moved = documents.moveDocument(edit.uri, targetParent, fileNameOf(target))
            if (moved != null) {
                if (recordHistory) {
                    push(
                        EditHistoryEntry(
                            path = target,
                            uri = moved,
                            kind = EditKind.MOVE,
                            previousContent = null,
                            createdUri = moved,
                            sourceUri = edit.uri,
                            description = edit.description,
                            timestamp = System.currentTimeMillis(),
                        ),
                    )
                }
                toolSuccess("'${edit.path}' -> '$target' ko'chirildi.")
            } else {
                toolError("Faylni ko'chirib bo'lmadi: ${edit.path}", recoverable = false)
            }
        }

        EditKind.COPY -> {
            val target = edit.targetPath
                ?: return toolError("Nusxa uchun yangi yo'l berilmagan.", true)
            val targetParent = resolveParentFor(documents, edit.rootUri, target)
                ?: return toolError("Maqsad papkani aniqlab bo'lmadi: $target", true)
            val copy = documents.copyDocument(edit.uri, targetParent, fileNameOf(target))
            if (copy != null) {
                if (recordHistory) {
                    push(
                        EditHistoryEntry(
                            path = target,
                            uri = copy,
                            kind = EditKind.COPY,
                            previousContent = null,
                            createdUri = copy,
                            description = edit.description,
                            timestamp = System.currentTimeMillis(),
                        ),
                    )
                }
                toolSuccess("'${edit.path}' nusxasi '$target' ga olindi.")
            } else {
                toolError("Nusxa olib bo'lmadi: ${edit.path}", recoverable = false)
            }
        }
    }

    /** Maqsad yo'lining ota papkasini topish (yo'q papkalar avtomatik yaratilmaydi). */
    private suspend fun resolveParentFor(
        documents: DocumentRepository,
        rootUri: String,
        targetPath: String,
    ): String? {
        val parentPath = targetPath.replace('\\', '/').substringBeforeLast('/', "")
        return if (parentPath.isEmpty()) {
            rootUri
        } else {
            documents.resolveChild(rootUri, parentPath)
        }
    }

    private fun push(entry: EditHistoryEntry) {
        historyEntries.addLast(entry)
        // Chegara: faqat oxirgi MAX_HISTORY ta saqlanadi (xotira nazorati).
        while (historyEntries.size > MAX_HISTORY) historyEntries.removeFirst()
    }

    private fun parentUriOf(uri: String): String? {
        val withoutScheme = uri.substringBeforeLast('/')
        return withoutScheme.takeIf { it.contains("://") }
    }

    private fun fileNameOf(path: String): String =
        path.replace('\\', '/').trim('/').substringAfterLast('/')

    private companion object {
        /** Faza 4, 8-vazifa: "oxirgi 10 ta". */
        const val MAX_HISTORY = 10
    }
}
