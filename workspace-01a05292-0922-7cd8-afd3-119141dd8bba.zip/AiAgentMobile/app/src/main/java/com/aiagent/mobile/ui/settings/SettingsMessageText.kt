package com.aiagent.mobile.ui.settings

import android.content.Context
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.model.AiError

/**
 * Snackbar matnlari (Faza 3).
 *
 * Nima uchun `Context.getString` va `stringResource` emas: snackbar xabarlari
 * `LaunchedEffect` ichidagi suspend kollektordan chiqariladi, u yerda
 * `@Composable` funksiyalarni chaqirib bo'lmaydi. Matnlar baribir bitta
 * manbadan — `strings.xml` dan olinadi, shuning uchun tarjima ikkilanmaydi.
 */
internal fun SettingsMessage.displayText(context: Context): String? = when (this) {
    is SettingsMessage.Saved -> context.getString(R.string.settings_saved, name)
    is SettingsMessage.Activated -> context.getString(R.string.settings_activated, name)
    is SettingsMessage.Deleted -> context.getString(R.string.settings_deleted, name)
    is SettingsMessage.EncryptFailed ->
        context.getString(R.string.provider_encrypt_failed) + " — " + detail

    SettingsMessage.TestSuccess -> context.getString(R.string.provider_test_success)
    is SettingsMessage.TestFailed ->
        context.getString(R.string.provider_test_failed) + " — " + error.snippet(context)

    SettingsMessage.ColabSaved -> context.getString(R.string.colab_saved)
    SettingsMessage.ColabCleared -> context.getString(R.string.colab_cleared)

    // Bu hodisa snackbar emas, DIALOG ochadi — shuning uchun matni yo'q.
    SettingsMessage.ColabUrlRequired -> null
}

/**
 * Xato sababining qisqa ko'rinishi. To'liq, foydalogi uchun mo'ljallangan xabar
 * chat ekranida `AiError.toDisplayText()` orqali ko'rsatiladi.
 */
private fun AiError.snippet(context: Context): String = when (this) {
    AiError.NoNetwork -> context.getString(R.string.ai_error_no_network)
    AiError.Timeout -> context.getString(R.string.ai_error_timeout)
    AiError.Unauthorized -> context.getString(R.string.ai_error_unauthorized)
    AiError.RateLimited -> context.getString(R.string.ai_error_rate_limited)
    is AiError.Server -> context.getString(R.string.ai_error_server, code, detail ?: "—")
    is AiError.InvalidResponse -> context.getString(R.string.ai_error_invalid_response, detail ?: "—")
    is AiError.InvalidConfig -> context.getString(R.string.ai_error_invalid_config, detail)
    is AiError.VisionUnsupported -> context.getString(R.string.ai_error_vision)
    is AiError.Unknown -> context.getString(R.string.ai_error_unknown, detail ?: "—")
}
