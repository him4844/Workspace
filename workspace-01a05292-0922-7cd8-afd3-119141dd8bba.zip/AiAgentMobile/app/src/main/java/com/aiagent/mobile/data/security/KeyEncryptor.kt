package com.aiagent.mobile.data.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * API kalitini shifrlash (Faza 3, 1-vazifa).
 *
 * QAROR (spetsifikatsiyadan og'ish, PROGRESS_LOG.md ga yoziladi):
 * Spetsifikatsiya `EncryptedSharedPreferences` ni ko'rsatadi, lekin
 * `androidx.security:security-crypto` kutubxonasi rasman DEPRECATED va
 * Google uni yangilamaydi. Shuning uchun platformaning o'zi — **Android Keystore**
 * (AES/GCM) ishlatildi: kalit apparat/TEE darajasida saqlanadi, ilova uni
 * hech qachon ko'ra olmaydi va diskgа faqat shifrlangan matn tushadi.
 *
 * Saqlash formati: `enc:v1:<base64(iv + ciphertext)>`.
 * Prefiks ikki maqsadga xizmat qiladi:
 *  - versiyani bildiradi (kelajakda algoritm o'zgarsa, eski yozuvlarni migratsiya qilish mumkin);
 *  - prefikssiz qiymat ochiq matn deb hisoblanadi — ya'ni avval oddiy DataStore'da
 *    saqlangan kalitlar ilova yangilanganda avtomatik o'qiladi (keyin qayta yoziladi).
 *
 * Har bir shifrlashda YANGI tasodifiy IV ishlatiladi (GCM uchun majburiy:
 * bir xil IV + kalit takrorlansa xavfsizlik buziladi).
 */
@Singleton
class KeyEncryptor @Inject constructor() {

    private val key: SecretKey by lazy { getOrCreateKey() }

    /** Ochiq matnni shifrlab, saqlashga yaroqli qatorga aylantiradi. */
    fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(cipher.iv.size + cipherText.size)
            cipher.iv.copyInto(combined, 0)
            cipherText.copyInto(combined, cipher.iv.size)
            return PREFIX + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (exception: Exception) {
            // Jim qolib ochiq matn saqlash — xavfsizlikni yashirin pasaytirish bo'lardi.
            // Shuning uchun xato yuqoriga uzatiladi va UI aniq xabar ko'rsatadi.
            throw KeyEncryptorException(
                "API kalitini shifrlab bo'lmadi: ${exception.message ?: exception.javaClass.simpleName}",
                exception,
            )
        }
    }

    /**
     * Saqlangan qiymatni ochadi. Prefikssiz qiymat (eski/ochiq saqlangan) ochiq matn
     * deb qaytariladi — ilova crash bo'lmaydi.
     */
    fun decrypt(stored: String): String {
        if (stored.isEmpty()) return ""
        if (!stored.startsWith(PREFIX)) return stored

        return try {
            val combined = Base64.decode(stored.removePrefix(PREFIX), Base64.NO_WRAP)
            if (combined.size <= GCM_IV_BYTES) return stored
            val iv = combined.copyOfRange(0, GCM_IV_BYTES)
            val cipherText = combined.copyOfRange(GCM_IV_BYTES, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (exception: Exception) {
            // Kalit boshqa qurilmadan ko'chirilgan yoki Keystore tozalangan bo'lishi mumkin.
            // Buzilgan kalitni "ochiq matn" sifatida yubormaymiz — bo'sh qaytaramiz,
            // shunda UI "API kalit talab qilinadi" deb aniq aytadi.
            ""
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE,
        )
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(KEY_SIZE_BITS)
                // Foydalanuvchi autentifikatsiyasi talab qilinmaydi: agent fon rejimida
                // (Faza 4) ham ishlaydi va ilova har ochilganda biometrik so'ramaydi.
                .setUserAuthenticationRequired(false)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "aiagent_api_key_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val PREFIX = "enc:v1:"
        const val KEY_SIZE_BITS = 256
        const val GCM_IV_BYTES = 12
        const val GCM_TAG_BITS = 128
    }
}

/** Keystore nosozligi — UI buni tushunarli xabar bilan ko'rsatadi. */
class KeyEncryptorException(message: String, cause: Throwable?) : RuntimeException(message, cause)
