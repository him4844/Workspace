package com.aiagent.mobile.data.colab.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Colab FastAPI serveri bilan almashiladigan transport modellari (Faza 5).
 *
 * Maydon nomlari notebook'dagi Python modellariga **bire-mos** kelishi shart:
 * `errorMessage` (camelCase) va `timeout_seconds` / `workspace_exists` (snake_case)
 * aralash holda — chunki FastAPI Pydantic maydon nomini o'zgartirmasdan yuboradi.
 * Shuning uchun snake_case maydonlar `@SerialName` bilan belgilangan.
 *
 * **Faqat natija printsipi (spetsifikatsiya 3-vazifasi):** bu DTO'larda fayl,
 * binary yoki artifakt maydoni YO'Q. Kerak bo'lsa [ColabExecuteResponse.output]
 * ichida Drive havolasi matn sifatida keladi.
 */

/** `POST /execute` so'rovi. */
@Serializable
data class ColabExecuteRequest(
    val id: String = "",
    val command: String,
    val workdir: String,
    @SerialName("timeout_seconds")
    val timeoutSeconds: Int = 300,
)

/** `POST /execute` javobi — faqat uch maydon. */
@Serializable
data class ColabExecuteResponse(
    val success: Boolean,
    val output: String = "",
    val errorMessage: String? = null,
)

/** `GET /health` javobi. */
@Serializable
data class ColabHealthResponse(
    val status: String = "",
    val workdir: String = "",
    @SerialName("workspace_exists")
    val workspaceExists: Boolean = false,
)
