package com.aiagent.mobile.domain.agent

/**
 * Vazifa qayerda bajarilishini bildiradi.
 *
 * Bu enum butun agent arxitekturasining markaziy nuqtasi: har bir tool chaqiruvi
 * PHONE (SAF/Termux, Faza 4/7) yoki COLAB (FastAPI + ngrok, Faza 5) yo'lidan boradi.
 */
enum class ExecutionTarget { PHONE, COLAB }
