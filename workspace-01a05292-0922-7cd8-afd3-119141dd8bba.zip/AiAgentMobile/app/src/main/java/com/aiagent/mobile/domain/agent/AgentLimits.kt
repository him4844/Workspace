package com.aiagent.mobile.domain.agent

/**
 * Agentning resurs chegaralari — cheksiz sikl va nazoratsiz sarfning oldini oladi.
 *
 * Bu chegaralar Faza 4 dagi AgentController tomonidan har qadamda tekshiriladi va
 * buzilganda agent `FAILED` holatiga o'tadi. UI'da (Faza 10) "Ilg'or sozlamalar"
 * ostida o'zgartirish imkoni bo'ladi, standart qiymatlar esa xavfsiz tomonda.
 */
data class AgentLimits(
    val maxSteps: Int = 30,
    val maxToolCalls: Int = 50,
    val maxExecutionTimeMs: Long = 10 * 60 * 1000,
    val maxCommandOutputBytes: Long = 1_000_000,
)
