package com.aiagent.mobile.domain.tools.edit

import com.github.difflib.DiffUtils
import com.github.difflib.UnifiedDiffUtils
import com.github.difflib.patch.Patch

/**
 * Patch qo'llash va diff hisoblash (Faza 4, 4 va 7-vazifalar).
 *
 * Kutubxona: `io.github.java-diff-utils` (spetsifikatsiya shuni ko'rsatadi).
 * U sof JVM kutubxonasi — Android'ga bog'liq emas, shuning uchun `domain` qatlamida
 * qoldi va `DomainPurityTest` buzilmadi. Foydasi: patch mantiqi emulyatorsiz test qilinadi.
 *
 * Ikki vazifa:
 * - [applyUnifiedDiff] — AI yuborgan unified diff'ni fayl matniga qo'llash.
 *   Mos kelmagan qator bo'lsa **PatchConflict** qaytadi (jim buzish emas) —
 *   bu 4-vazifadagi "checksum/conflict" talabining ikkinchi qatlami.
 * - [diffLines] — diff ekrani uchun qatorlarni tur (qo'shildi/o'chirildi/o'zgarmadi)
 *   va raqamlar bilan tayyorlaydi.
 */
object PatchEngine {

    /** Diff natijasi: yangi matn yoki aniq conflict sababi. */
    sealed interface ApplyResult {
        data class Applied(val newContent: String, val addedLines: Int, val removedLines: Int) :
            ApplyResult

        data class PatchConflict(val reason: String) : ApplyResult
        data class MalformedPatch(val reason: String) : ApplyResult
    }

    /**
     * Unified diff'ni [originalContent] ga qo'llash.
     *
     * [path] — patch sarlavhasidagi fayl nomi (`--- a/src/x.kt`). AI ba'zan fayl nomini
     * noto'g'ri yozadi, shuning uchun solishtirish yumshoq: nom mos kelmasa ham
     * patch qo'llanadi (muhimi — qatorlar mos kelishi), lekin bu holat qayd etiladi.
     */
    fun applyUnifiedDiff(originalContent: String, patchText: String, path: String): ApplyResult {
        // Faqat BOSHI va OXIRIdagi bo'sh qatorlar olib tashlanadi. Ichki bo'sh qator
        // unified diff'da "bo'sh kontekst qatori" ma'nosini beradi va uni tashlab yuborish
        // patch'ni buzadi (hunk qatorlar soni mos kelmay, conflict chiqadi).
        val patchLines = patchText.lines().dropWhile(String::isBlank).dropLastWhile(String::isBlank)
        if (patchLines.isEmpty()) return ApplyResult.MalformedPatch("Patch bo'sh")

        val patch: Patch<String> = try {
            UnifiedDiffUtils.parseUnifiedDiff(
                // `parseUnifiedDiff` bo'sh qatorlarni kontekst deb o'qishi mumkin,
                // shuning uchun fayl nomlari bo'lmasa ham hunk'larni topadi.
                ensureHeaders(patchLines, path),
            )
        } catch (exception: Exception) {
            return ApplyResult.MalformedPatch(
                "Patch formati noto'g'ri: ${exception.message ?: "kutilmagan xato"}",
            )
        }

        if (patch.deltas.isEmpty()) {
            return ApplyResult.MalformedPatch("Patch'da o'zgartirish yo'q (hunk topilmadi)")
        }

        val original = originalContent.lines()
        val patched = try {
            DiffUtils.patch(original, patch)
        } catch (exception: Exception) {
            // Eng muhim holat: fayl AI o'qiganidan keyin o'zgargan yoki AI eski
            // kontekstni yozgan. Jim yozish o'rniga aniq conflict qaytaramiz.
            return ApplyResult.PatchConflict(
                "Patch faylga mos kelmadi: ${exception.message ?: "qatorlar topilmadi"}. " +
                    "Fayl o'qib chiqilgandan keyin o'zgargan bo'lishi mumkin — " +
                    "avval `read_file` bilan qayta o'qing.",
            )
        }

        val newContent = patched.joinToString("\n")
        return ApplyResult.Applied(
            newContent = newContent,
            addedLines = patch.deltas.sumOf { delta -> delta.target.lines.size },
            removedLines = patch.deltas.sumOf { delta -> delta.source.lines.size },
        )
    }

    /**
     * Patch'da `---`/`+++` sarlavhalari bo'lmasa qo'shish — ba'zi modellar ularni
     * tashlab yuboradi, `parseUnifiedDiff` esa sarlavhasiz hunk'larni o'qimaydi.
     */
    private fun ensureHeaders(lines: List<String>, path: String): List<String> {
        if (lines.any { it.startsWith("---") }) return lines
        val firstHunk = lines.indexOfFirst { it.startsWith("@@") }
        if (firstHunk < 0) return lines
        return listOf("--- a/$path", "+++ b/$path") + lines.subList(firstHunk, lines.size)
    }

    // ---------------------------------------------------------------- diff ekrani

    /** Diff'ning bitta qatori (UI shu ro'yxatni chizadi). */
    data class DiffLine(
        val type: DiffLineType,
        val oldNumber: Int?,
        val newNumber: Int?,
        val text: String,
    )

    enum class DiffLineType { UNCHANGED, ADDED, REMOVED }

    /**
     * Ikki matn orasidagi farqni qatorlar ro'yxatiga aylantirish.
     * Kontekst qatorlari ham saqlanadi — foydalanuvchi o'zgarish atrofini ko'rishi kerak.
     */
    fun diffLines(original: String, updated: String, contextLines: Int = 3): List<DiffLine> {
        val originalLines = original.lines()
        val updatedLines = updated.lines()
        val patch = DiffUtils.diff(originalLines, updatedLines)

        val changedOld = mutableSetOf<Int>()
        val changedNew = mutableSetOf<Int>()
        patch.deltas.forEach { delta ->
            val oldStart = delta.source.position
            repeat(delta.source.lines.size) { changedOld += oldStart + it }
            val newStart = delta.target.position
            repeat(delta.target.lines.size) { changedNew += newStart + it }
        }

        val result = mutableListOf<DiffLine>()
        val maxOld = originalLines.size
        val maxNew = updatedLines.size

        // Har bir qatorni uning turiga qarab chiqaramiz: DiffUtils delta'lari
        // "eski qatorlar -> yangi qatorlar" juftligini beradi, shuning uchun
        // avval o'chirilganlar, keyin qo'shilganlar ko'rsatiladi (odatiy diff tartibi).
        var oldIndex = 0
        var newIndex = 0
        val deltas = patch.deltas

        while (oldIndex < maxOld || newIndex < maxNew) {
            val delta = deltas.firstOrNull { it.source.position == oldIndex }

            if (delta != null) {
                delta.source.lines.forEachIndexed { offset, text ->
                    result += DiffLine(DiffLineType.REMOVED, oldIndex + offset + 1, null, text)
                }
                delta.target.lines.forEachIndexed { offset, text ->
                    result += DiffLine(DiffLineType.ADDED, null, newIndex + offset + 1, text)
                }
                oldIndex += delta.source.lines.size
                newIndex += delta.target.lines.size
                continue
            }

            if (oldIndex < maxOld && newIndex < maxNew) {
                val keep = shouldKeep(
                    index = oldIndex,
                    changedOld = changedOld,
                    changedNew = changedNew,
                    contextLines = contextLines,
                    totalOld = maxOld,
                )
                if (keep) {
                    result += DiffLine(
                        DiffLineType.UNCHANGED,
                        oldIndex + 1,
                        newIndex + 1,
                        originalLines[oldIndex],
                    )
                }
                oldIndex++
                newIndex++
            } else if (oldIndex < maxOld) {
                oldIndex++
            } else {
                newIndex++
            }
        }
        return result
    }

    /** Kontekst qatorini ko'rsatish kerakmi (o'zgarishga yaqin bo'lsa — ha). */
    private fun shouldKeep(
        index: Int,
        changedOld: Set<Int>,
        changedNew: Set<Int>,
        contextLines: Int,
        totalOld: Int,
    ): Boolean {
        for (offset in -contextLines..contextLines) {
            val neighbour = index + offset
            if (neighbour in 0 until totalOld && neighbour in changedOld) return true
            if (neighbour in changedNew) return true
        }
        return false
    }

    /** Qisqa statistika — agent javobida va UI'da ko'rsatiladi. */
    fun summarize(original: String, updated: String): Pair<Int, Int> {
        val patch = DiffUtils.diff(original.lines(), updated.lines())
        var added = 0
        var removed = 0
        patch.deltas.forEach { delta ->
            added += delta.target.lines.size
            removed += delta.source.lines.size
        }
        return added to removed
    }
}
