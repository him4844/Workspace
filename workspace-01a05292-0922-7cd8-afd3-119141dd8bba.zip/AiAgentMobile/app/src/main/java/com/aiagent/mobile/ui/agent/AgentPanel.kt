package com.aiagent.mobile.ui.agent

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aiagent.mobile.R
import com.aiagent.mobile.domain.agent.AgentState
import com.aiagent.mobile.domain.agent.AgentStep
import com.aiagent.mobile.domain.agent.AgentStepKind

/**
 * Agent ish jarayoni paneli (Faza 4, 5-vazifa).
 *
 * Nima uchun kerak: agent bir nechta tool chaqiradi va bu vaqt oladi. Foydalanuvchi
 * "nima bo'layapti" ni ko'rmasa, ilova muzlab qolgandek tuyuladi. Shuning uchun
 * har bir qadam ko'rsatiladi va "Stop Agent" tugmasi har doim ochiq.
 */
@Composable
fun AgentPanel(
    agentState: AgentState,
    steps: List<AgentStep>,
    onStop: () -> Unit,
) {
    val listState = rememberLazyListState()
    LaunchedEffect(steps.size) {
        if (steps.isNotEmpty()) listState.animateScrollToItem(steps.lastIndex)
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (agentState == AgentState.PLANNING || agentState == AgentState.RUNNING_TOOL) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        painter = painterResource(stateIcon(agentState)),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stringResource(stateText(agentState)),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                if (agentState == AgentState.PLANNING ||
                    agentState == AgentState.RUNNING_TOOL ||
                    agentState == AgentState.WAITING_FOR_PERMISSION
                ) {
                    OutlinedButton(
                        modifier = Modifier.height(48.dp),
                        onClick = onStop,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_close),
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.agent_stop))
                    }
                }
            }

            if (steps.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(steps, key = AgentStep::id) { step -> StepRow(step) }
                }
            }
        }
    }
}

@Composable
private fun StepRow(step: AgentStep) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(
            painter = painterResource(stepIcon(step)),
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = when (step.isSuccess) {
                true -> MaterialTheme.colorScheme.primary
                false -> MaterialTheme.colorScheme.error
                null -> MaterialTheme.colorScheme.onSurfaceVariant
            },
        )
        Spacer(Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = step.title, style = MaterialTheme.typography.bodyMedium)
            if (!step.detail.isNullOrBlank()) {
                Text(
                    text = step.detail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 4,
                )
            }
        }
    }
}

private fun stateIcon(state: AgentState): Int = when (state) {
    AgentState.COMPLETED -> R.drawable.ic_check_circle
    AgentState.FAILED, AgentState.CANCELLED -> R.drawable.ic_error_circle
    AgentState.WAITING_FOR_PERMISSION -> R.drawable.ic_warning
    else -> R.drawable.ic_refresh
}

private fun stepIcon(step: AgentStep): Int = when {
    step.kind == AgentStepKind.TOOL_RESULT && step.isSuccess == false -> R.drawable.ic_error_circle
    step.kind == AgentStepKind.AWAITING_APPROVAL -> R.drawable.ic_warning
    step.kind == AgentStepKind.LIMIT -> R.drawable.ic_warning
    step.isSuccess == true -> R.drawable.ic_check
    else -> R.drawable.ic_file_text
}

private fun stateText(state: AgentState): Int = when (state) {
    AgentState.IDLE -> R.string.agent_state_idle
    AgentState.PLANNING -> R.string.agent_state_planning
    AgentState.RUNNING_TOOL -> R.string.agent_state_running_tool
    AgentState.WAITING_FOR_PERMISSION -> R.string.agent_state_waiting_permission
    AgentState.WAITING_FOR_USER -> R.string.agent_state_waiting_user
    AgentState.APPLYING_EDIT -> R.string.agent_state_applying
    AgentState.TESTING -> R.string.agent_state_testing
    AgentState.COMPLETED -> R.string.agent_state_completed
    AgentState.FAILED -> R.string.agent_state_failed
    AgentState.CANCELLED -> R.string.agent_state_cancelled
}
