package com.aiagent.mobile.domain.tools.files

import com.aiagent.mobile.domain.model.FileNode
import com.aiagent.mobile.domain.repository.DocumentRepository
import com.aiagent.mobile.domain.tools.AgentTool
import com.aiagent.mobile.domain.tools.ParamType
import com.aiagent.mobile.domain.tools.ToolContext
import com.aiagent.mobile.domain.tools.ToolParameter
import com.aiagent.mobile.domain.tools.ToolPaths
import com.aiagent.mobile.domain.tools.ToolResult
import com.aiagent.mobile.domain.tools.optionalArg
import com.aiagent.mobile.domain.tools.requireArg
import com.aiagent.mobile.domain.tools.toToolMessage
import com.aiagent.mobile.domain.tools.toolError
import com.aiagent.mobile.domain.tools.toolSuccess
import com.aiagent.mobile.domain.tools.edit.FileChecksumStore
import com.aiagent.mobile.domain.usecase.ByteFormatter

/**
 * O'qish tool'lari: `list_directory`, `read_file`, `get_file_info` (Faza 4, 2-vazifa).
 *
 * Bular faylni O'ZGARTIRMAYDI, shuning uchun tasdiq so'ramaydi — agent ularni
 * erkin chaqira oladi. `read_file` esa checksum yozib qo'yadi: keyingi tahrirda
 * fayl tashqaridan o'zgargan bo'lsa, conflict aniqlanadi (4-vazifa).
 */
class ReadOnlyFileTools(
    private val documents: DocumentRepository,
    private val checksums: FileChecksumStore,
) {

    val tools: List<AgentTool> = listOf(ListDirectory(), ReadFile(), GetFileInfo())

    /** Papka mazmuni. `path` bo'sh bo'lsa workspace ildizi ko'rsatiladi. */
    inner class ListDirectory : AgentTool {
        override val name = "list_directory"
        override val description =
            "Papkadagi fayl va papkalarni ko'rsatadi. path bo'sh qoldirilsa workspace ildizi ochiladi."
        override val parameters = listOf(
            ToolParameter(
                name = "path",
                type = ParamType.STRING,
                description = "Papka yo'li (workspace ildiziga nisbatan). Ildiz uchun bo'sh qoldiring.",
                required = false,
            ),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.optionalArg("path")
            val uri = if (path.isEmpty()) {
                context.rootUri
            } else {
                when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                    is ToolPaths.Resolved.Found -> resolved.uri
                    is ToolPaths.Resolved.Failure -> return resolved.error
                }
            }

            val children = documents.listChildren(uri)
            if (children.isEmpty()) {
                return toolSuccess("'$path' papkasi bo'sh.")
            }

            val listing = children
                .sortedWith(compareByDescending<FileNode> { it.isDirectory }.thenBy { it.name.lowercase() })
                .joinToString("\n") { node ->
                    if (node.isDirectory) {
                        "[papka] ${node.name}/"
                    } else {
                        "[fayl]  ${node.name} (${ByteFormatter.fileSize(node.sizeBytes)})"
                    }
                }
            val folders = children.count { it.isDirectory }
            return toolSuccess(
                "Jami ${children.size} ta yozuv ($folders papka, ${children.size - folders} fayl):\n$listing",
            )
        }
    }

    /** Fayl matnini o'qish + checksum yozish. */
    inner class ReadFile : AgentTool {
        override val name = "read_file"
        override val description =
            "Matn faylini o'qiydi va mazmunini qaytaradi. Tahrirdan oldin shu tool bilan o'qing — " +
                "keyin fayl tashqaridan o'zgarsa, conflict aniqlanadi."
        override val parameters = listOf(
            ToolParameter(
                name = "path",
                type = ParamType.STRING,
                description = "Fayl yo'li (workspace ildiziga nisbatan), masalan src/Main.kt",
            ),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val uri = when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                is ToolPaths.Resolved.Found -> resolved.uri
                is ToolPaths.Resolved.Failure -> return resolved.error
            }

            return when (val outcome = ToolPaths.readText(documents, context, uri)) {
                is ToolPaths.ReadOutcome.Text -> {
                    // Conflict nazorati: checksum shu yerda yoziladi.
                    checksums.record(path, outcome.content)

                    val header = buildString {
                        append("Fayl: $path (${outcome.content.length} belgi)")
                        if (outcome.truncated) {
                            append(" — DIQQAT: fayl ${outcome.totalBytes} bayt, ")
                            append("faqat birinchi qismi qaytarildi")
                        }
                    }
                    toolSuccess("$header\n\n${outcome.content}")
                }

                is ToolPaths.ReadOutcome.NotText -> outcome.error
            }
        }
    }

    /** Fayl haqida qisqa ma'lumot (hajm, tur, checksum). */
    inner class GetFileInfo : AgentTool {
        override val name = "get_file_info"
        override val description =
            "Fayl haqida ma'lumot: nomi, hajmi, MIME turi va joriy checksum. " +
                "Fayl mavjudligini tekshirish uchun ham ishlatiladi."
        override val parameters = listOf(
            ToolParameter(
                name = "path",
                type = ParamType.STRING,
                description = "Fayl yoki papka yo'li",
            ),
        )

        override suspend fun execute(args: Map<String, String>, context: ToolContext): ToolResult {
            val path = args.requireArg("path").getOrElse { return toolError(it.toToolMessage()) }
            val uri = when (val resolved = ToolPaths.resolveExisting(documents, context, path)) {
                is ToolPaths.Resolved.Found -> resolved.uri
                is ToolPaths.Resolved.Failure -> return resolved.error
            }

            val size = documents.fileSize(uri)
            val mime = documents.mimeTypeOf(uri)
            val stored = checksums.recorded(path)

            val summary = buildString {
                appendLine("Yo'l: $path")
                appendLine("Hajm: ${if (size >= 0) ByteFormatter.fileSize(size) else "noma'lum"}")
                appendLine("Turi: ${mime ?: "aniqlanmadi"}")
                appendLine(
                    "Oxirgi o'qilgan checksum: " + (stored?.take(CHECKSUM_PREVIEW) ?: "yo'q (hali o'qilmagan)"),
                )
            }
            return toolSuccess(summary.trim())
        }
    }

    private companion object {
        const val CHECKSUM_PREVIEW = 12
    }
}
