package com.aiagent.mobile.ui.chat

/**
 * Javob matnidagi ``` kod bloklarini ajratish — sof mantiq (test qilinadi).
 *
 * Spetsifikatsiya talabi: kod bloklari monospace shriftda ko'rinishi kerak,
 * sintaksis ranglash shart emas. Shuning uchun to'liq Markdown parser emas,
 * faqat kod bloklarini ajratadigan oddiy va bashoratli funksiya yozildi.
 */
sealed interface MessageSegment {
    data class Text(val value: String) : MessageSegment
    data class Code(val value: String, val language: String) : MessageSegment
}

private const val FENCE = "```"

fun parseCodeBlocks(source: String): List<MessageSegment> {
    val segments = mutableListOf<MessageSegment>()
    var rest = source

    while (true) {
        val start = rest.indexOf(FENCE)
        if (start < 0) {
            if (rest.isNotBlank()) segments += MessageSegment.Text(rest)
            return segments
        }

        val before = rest.substring(0, start)
        if (before.isNotBlank()) segments += MessageSegment.Text(before)

        val afterFence = rest.substring(start + FENCE.length)
        val lineBreak = afterFence.indexOf('\n')
        if (lineBreak < 0) {
            // Yopilmagan blok: qolgan qismni kod deb hisoblaymiz (foydalanuvchi
            // ko'rib turgan matn yo'qolib qolmasligi kerak).
            segments += MessageSegment.Code(afterFence.trim(), language = "")
            return segments
        }

        val language = afterFence.substring(0, lineBreak).trim()
        val body = afterFence.substring(lineBreak + 1)
        val end = body.indexOf(FENCE)
        if (end < 0) {
            segments += MessageSegment.Code(body.trimEnd(), language)
            return segments
        }

        segments += MessageSegment.Code(body.substring(0, end).trimEnd(), language)
        rest = body.substring(end + FENCE.length)
    }
}
