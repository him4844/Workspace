package com.aiagent.mobile.ui.chat

import com.aiagent.mobile.domain.model.AiError
import com.aiagent.mobile.domain.model.AiProvider
import com.aiagent.mobile.domain.model.AppSettings
import com.aiagent.mobile.domain.model.FileKind
import com.aiagent.mobile.domain.model.MessageRole

/**
 * Chat ekrani UI holati (Faza 3 + Faza 4).
 *
 * Nima uchun alohida fayl: `ChatViewModel` 400 qator chegarasiga yetib qolgandi,
 * UI modellarini ajratish mantiqni o'qishni osonlashtiradi va chegaraga rioya qiladi.
 */
data class ChatUiState(
    val isLoadingProvider: Boolean = true,
    val activeProvider: AiProvider? = null,
    val settings: AppSettings? = null,
    val messages: List<ChatUiMessage> = emptyList(),
    val attachedFiles: List<AttachedFileUi> = emptyList(),
    val input: String = "",
    val isSending: Boolean = false,
    val isPreparingFiles: Boolean = false,
    val error: AiError? = null,
    val contextWarnings: List<Warning> = emptyList(),
)

data class ChatUiMessage(
    val id: String,
    val role: MessageRole,
    val content: String,
    val attachedFileNames: List<String> = emptyList(),
    val model: String? = null,
    val totalTokens: Int? = null,
    val isError: Boolean = false,
)

data class AttachedFileUi(
    val uri: String,
    val fileName: String,
    val kind: FileKind,
    val sizeBytes: Long,
    val hasImages: Boolean,
    val note: String?,
)

/** Foydalanuvchiga aniq ko'rsatiladigan ogohlantirishlar (yashirin kesish bo'lmaydi). */
sealed interface Warning {
    data class TruncatedFiles(val details: List<String>) : Warning
    data class HistoryTrimmed(val droppedMessages: Int) : Warning
    data object VisionUnsupported : Warning
}
