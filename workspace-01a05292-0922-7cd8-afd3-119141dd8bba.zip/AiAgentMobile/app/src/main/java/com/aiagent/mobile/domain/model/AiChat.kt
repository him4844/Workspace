package com.aiagent.mobile.domain.model

/**
 * AI provider'ga yuboriladigan so'rov va undan qaytadigan javob.
 *
 * OpenAI-mos `/chat/completions` shakli domen modeliga aylantirilgan:
 * transport DTO'lari (`data/ai/dto`) hech qachon domen tashqarisiga chiqmaydi.
 *
 * Faza 4: tool-calling qo'shildi. Endi javobda matn bilan birga [AiResponse.toolCalls]
 * bo'lishi mumkin, va natijani qaytarish uchun [MessageRole.TOOL] rolli xabar yuboriladi.
 */
data class AiRequestMessage(
    val role: MessageRole,
    val content: String,
    /**
     * `role = TOOL` bo'lganda MAJBURIY: bu javob qaysi tool chaqiruviga tegishli ekanini
     * bildiradi. OpenAI sxemasi shu identifikator orqali tool natijasini chaqiruv bilan
     * bog'laydi; u bo'lmasa ko'p provider 400 qaytaradi.
     */
    val toolCallId: String? = null,
    /**
     * `role = ASSISTANT` va tool chaqiruvi bo'lgan holat uchun.
     *
     * Nima uchun kerak: OpenAI sxemasi `role: "tool"` xabaridan OLDIN shu chaqiruvlarni
     * o'z ichiga olgan `assistant` xabarini talab qiladi. Aks holda provider
     * "messages with role 'tool' must be a response to a preceding message with
     * 'tool_calls'" deb 400 qaytaradi. Shuning uchun agent sikli har bir tool
     * chaqiruvini tarixda saqlaydi.
     */
    val toolCalls: List<ToolCallRequest> = emptyList(),
)

/** AI so'ragan bitta tool chaqiruvi. */
data class ToolCallRequest(
    val id: String,
    val name: String,
    /**
     * Argumentlar allaqachon tahlil qilingan holda: JSON matnini `Map`ga aylantirish
     * data qatlamida qilinadi (`AiChatRepositoryImpl`), shuning uchun domen qatlami
     * JSON kutubxonasini bilmaydi.
     */
    val arguments: Map<String, String>,
)

/** Provider javobining domen ko'rinishi. */
data class AiResponse(
    val content: String,
    val model: String?,
    val promptTokens: Int?,
    val completionTokens: Int?,
    /** Bo'sh bo'lmasa — agent tool chaqirmoqchi, oddiy javob emas. */
    val toolCalls: List<ToolCallRequest> = emptyList(),
) {
    val hasToolCalls: Boolean get() = toolCalls.isNotEmpty()
}

/**
 * Chaqiruv natijasi. Exception o'rniga natija qaytariladi — chunki xato turi
 * UI'da foydalogi uchun aniq matnga aylantiriladi va ViewModel try/catch'ga
 * botishi shart emas.
 */
sealed interface AiResult {
    data class Success(val response: AiResponse) : AiResult
    data class Failure(val error: AiError) : AiResult
}
