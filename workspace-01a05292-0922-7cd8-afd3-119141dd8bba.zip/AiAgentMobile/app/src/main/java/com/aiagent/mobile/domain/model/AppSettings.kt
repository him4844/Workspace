package com.aiagent.mobile.domain.model

/**
 * Ilova sozlamalari (Faza 2-3 da DataStore orqali saqlanadi).
 *
 * Xavfsiz-standart printsipi: [editMode] standart holda `ALWAYS_CONFIRM` —
 * ya'ni hech bir fayl foydalanuvchi tasdiqlamasdan o'zgarmaydi.
 * [executionPreference] standart holda `COLAB_PRIMARY` — og'ir ishlar Colab'da,
 * Colab mavjud bo'lmasa telefonga o'tiladi (Faza 6 fallback).
 */
data class AppSettings(
    val activeProviderId: String?,
    val editMode: EditMode,
    val isDarkTheme: Boolean? = null,
    val maxFileContextSizeBytes: Int = 100_000,
    val executionPreference: ExecutionPreference = ExecutionPreference.COLAB_PRIMARY,
    /**
     * Colab serverining tashqi (ngrok) manzili — foydalanuvchi qo'lda kiritadi (Faza 5).
     *
     * Bo'sh satr = Colab hali sozlanmagan. Bu xato emas, shuning uchun UI'da
     * "xatolik" emas, "Qanday ulash mumkin" qo'llanmasi ko'rsatiladi.
     */
    val colabUrl: String = "",
)

/**
 * Fayl o'zgartirish rejimi.
 * `ALWAYS_CONFIRM` — har o'zgartirish diff orqali tasdiqlanadi (xavfsiz standart).
 * `AUTO_APPLY` — agent o'zi yozadi, lekin oxirgi 10 ta o'zgartirish uchun Undo saqlanadi (Faza 4).
 */
enum class EditMode { ALWAYS_CONFIRM, AUTO_APPLY }

/**
 * Bajarish joyi afzalligi. Bu — foydalanuvchi tanlovi; yakuniy qarorni
 * Faza 6 da `ExecutionRouter` beradi, lekin `PHONE_ONLY` holatida Colab
 * yo'nalishi umuman chaqirilmaydi.
 */
enum class ExecutionPreference { COLAB_PRIMARY, PHONE_ONLY }
