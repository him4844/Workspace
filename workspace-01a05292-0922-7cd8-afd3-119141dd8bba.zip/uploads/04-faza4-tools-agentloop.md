# 04 — FAZA 4: Tool system va lokal agent loop (faqat telefon)

**Bu faylni FAZA 3 muvaffaqiyatli tugagach yuboring.**

---

## AGENT UCHUN DOIMIY QOIDALAR (bu qism har bir faza faylida takrorlanadi — buzish taqiqlanadi)

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yozib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 4 — Tool system va lokal agent loop (faqat telefon)

**Maqsad:** Oddiy chatni haqiqiy agentga aylantirish — lekin hali faqat telefon fayllari ustida ishlaydi, Colab yo'q.

**Vazifalar:**
1. Tool schema va `ToolResult` sealed class:
```kotlin
sealed class ToolResult {
    data class Success(val output: String) : ToolResult()
    data class Error(val message: String, val recoverable: Boolean) : ToolResult()
    data class PermissionRequired(val description: String) : ToolResult()
}
```
2. File tools implementatsiyasi: `list_directory`, `read_file`, `write_file`, `create_file`, `delete_file`, `move_file`, `copy_file`, `get_file_info` — barchasi SAF orqali, telefon xotirasida ishlaydi.
3. Search tools (oddiy versiya): `search_files`, `search_text` — hozircha oddiy string qidiruv, index yo'q.
4. `apply_patch`, `replace_text`, `insert_text` — patch-based editing, checksum tekshiruvi bilan (fayl AI o'qigandan keyin tashqaridan o'zgargan bo'lsa, conflict ko'rsatiladi).
5. Agent Controller: `AgentState` transitions, `AgentLimits` qo'llanilishi, "Stop Agent" tugmasi.
6. Agent Loop: so'rov → tool tanlash → bajarish → natija AI'ga qaytarish → keyingi qadam.
7. Diff ekrani: `java-diff-utils` orqali, qo'shilgan/o'chirilgan qatorlar rangli ko'rsatilishi, "Qabul qilish"/"Rad etish".
8. `AUTO_APPLY` rejimida Edit History buffer (oxirgi 10 ta), Undo imkoniyati.

**MUHIM:** Bu fazada `ExecutionRouter` hali chaqirilmaydi — barcha tool'lar to'g'ridan-to'g'ri telefonda ishlaydi. Colab yo'nalishi Faza 5 va 6 da qo'shiladi.

**TEKSHIRUV TALABI:**
- Oddiy so'rov ("Python nima?") uchun agent hech qanday tool chaqirmasligi kerak — faqat javob berishi kerak.
- Fayl bilan bog'liq so'rov ("shu papkadagi fayllarni ko'rsat") uchun agent `list_directory` tool'ini chaqirishi va natijani to'g'ri ko'rsatishi kerak.
- Bitta faylni tahrirlash so'ralganda, Diff ekrani to'g'ri qatorlarni ko'rsatishi va "Qabul qilish" bosilganda haqiqatan faylga yozilishi SHART (buni fayl mazmunini o'qib tasdiqla).
- `./gradlew build` xatosiz o'tishi SHART.
