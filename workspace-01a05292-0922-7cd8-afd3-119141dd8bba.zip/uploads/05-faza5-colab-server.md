# 05 — FAZA 5: Colab backend — server va ulanish

**Bu faylni FAZA 4 muvaffaqiyatli tugagach yuboring.**

---

## AGENT UCHUN DOIMIY QOIDALAR (bu qism har bir faza faylida takrorlanadi — buzish taqiqlanadi)

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yozib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 5 — Colab backend: server va ulanish

**Maqsad:** Google Colab tomonida ishlaydigan serverni yaratish va Android ilovasidan unga ulanishni ta'minlash. Bu fazada faqat ULANISH quriladi — routing mantig'i Faza 6 da.

**Vazifalar:**

1. **Colab notebook shabloni** (alohida `.ipynb` fayl yoki hujjatlashtirilgan kod bloklari sifatida, loyihaning `/colab/` papkasida saqlansin):
   - Google Drive mount qilish (`drive.mount('/content/drive')`) — bu birinchi ishga tushirishda foydalanuvchidan Google hisobi orqali OAuth ruxsatini so'raydi (Colab'ning o'z standart oynasi orqali); notebook izohida bu qadam foydalanuvchiga oldindan tushuntiriladi.
   - Loyiha papkasi Drive'da: `/content/drive/MyDrive/AiAgentWorkspace/`
   - Oddiy FastAPI server, quyidagi endpoint'lar bilan:
     - `POST /execute` — buyruq bajarish (masalan `./gradlew assembleDebug`), faqat natija (stdout/stderr, exit code) qaytaradi
     - `GET /health` — server ishlab turganini tekshirish
   - `pyngrok` orqali tashqi URL generatsiya qilish. Notebookning eng boshiga, alohida va aniq ajratilgan katakchaga (birinchi "Setup" bo'limi sifatida) quyidagilar yoziladi:
     - Ngrok authtoken kiritish uchun maydon (`NGROK_AUTH_TOKEN = "..."`) — izohda foydalanuvchiga aniq ko'rsatma: "ngrok.com saytida bepul ro'yxatdan o'ting → Dashboard → 'Your Authtoken' bo'limidan tokenni nusxalab shu yerga joylashtiring"
     - Token kiritilmagan yoki bo'sh holatda ishga tushirilsa, notebook tushunarli xato chiqarib to'xtaydi (Python exception stack trace emas, oddiy `print()` orqali: "❌ Ngrok authtoken kiritilmagan. Yuqoridagi katakchaga tokeningizni kiriting.")
   - Server ishga tushgach, ngrok URL notebook chiqishida katta va ажratilgan holda ko'rsatiladi (masalan `print(f"\n{'='*50}\n✅ SERVER TAYYOR\nUshbu havolani nusxalab, ilovadagi Sozlamalar → Colab URL maydoniga joylashtiring:\n{public_url}\n{'='*50}")`), shunda foydalanuvchi uni chalg'itmasdan topa oladi.

2. **Android tomonida `data/colab/` implementatsiyasi:**
   - `RemoteExecutionEngine` interfeysining haqiqiy implementatsiyasi (`ColabExecutionEngine`) — Faza 1'da yaratilgan interfeys asosida
   - Retrofit orqali Colab serveriga so'rov yuborish
   - Settings ekraniga "Colab URL" maydoni qo'shish (foydalanuvchi ngrok havolasini qo'lda kiritadi)
   - `isAvailable()` — `/health` endpoint orqali ulanishni tekshirish, Settings ekranida "✅ Ulangan" / "❌ Ulanmagan" holatini ko'rsatish
   - **Ulanish qismi UX'i (bu ko'p qadamli tashqi jarayon, shuning uchun alohida e'tibor talab qiladi):**
     - "Colab URL" maydoni yonida kichik "?" yoki "Qanday ulash mumkin" havolasi — bosilganda qisqa, 4 qadamli qo'llanma ko'rsatiladi (bottom sheet yoki dialog): "1) Colab notebook'ni oching va 'Run all' bosing → 2) Google Drive ruxsatini tasdiqlang → 3) Chiqqan havolani nusxalang → 4) Shu yerga joylashtiring". Notebook faylining o'zini ochish uchun havola ham shu yerda bo'lishi mumkin.
     - URL kiritilmagan holatda, Colab talab qiladigan har qanday amal (masalan "Build qil" so'rovi) chaqirilganda, oddiy xatolik o'rniga foydalanuvchini to'g'ridan-to'g'ri shu qo'llanmaga yo'naltiruvchi tugma ko'rsatiladi.
     - Ulanish uzilib qolgan holat (masalan session tugagan, eski URL ishlamay qolgan) aniq: "❌ Ulanmagan — havola eskirgan bo'lishi mumkin, Colab'da qayta 'Run all' bosib, yangi havolani kiriting" kabi sabab bilan tushuntiriladi, shunchaki "xatolik" deb qoldirilmaydi.

3. **Faqat natija qaytarish printsipi:** `RemoteTaskResult` faqat `success`, `output` (matn — log/xato xabari), va `errorMessage` maydonlarini o'z ichiga oladi. Oraliq fayllar, build artifaktlari yoki boshqa katta ma'lumotlar Android'ga QAYTARILMAYDI — agar foydalanuvchiga fayl kerak bo'lsa (masalan tayyor APK), alohida "natijani yuklab olish havolasi" (Drive link) qaytariladi, fayl o'zi emas.

**TEKSHIRUV TALABI:**
- Colab notebook ishga tushirilganda, ngrok URL generatsiya qilinishi va shu URL orqali `/health` so'roviga javob qaytishi kerak (buni real Colab hisobida sinab ko'rish tavsiya etiladi, lekin kamida kod xatosiz yozilgan va mantiqiy to'g'ri bo'lishi SHART).
- Android tomonida Settings ekranida Colab URL kiritilib, "Ulanishni tekshirish" bosilganda to'g'ri holat ko'rsatilishi kerak.
- `./gradlew build` xatosiz o'tishi SHART.
