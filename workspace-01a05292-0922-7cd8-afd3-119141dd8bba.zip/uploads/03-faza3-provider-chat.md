# 03 — FAZA 3: Provider sozlamalari va oddiy chat

**Bu faylni FAZA 2 muvaffaqiyatli tugagach yuboring.**

---

## AGENT UCHUN DOIMIY QOIDALAR (bu qism har bir faza faylida takrorlanadi — buzish taqiqlanadi)

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yozib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 3 — Provider sozlamalari va oddiy chat (tool calling'siz)

**Maqsad:** AI bilan oddiy matnli suhbat — hali agent emas, faqat chat.

**Vazifalar:**
1. `SettingsScreen` — provider qo'shish/tahrirlash/o'chirish/faollashtirish (`AiProvider` modeli asosida). API kalit `EncryptedSharedPreferences` orqali saqlanadi. Bu — foydalanuvchi API kalitni kiritadigan asosiy joy, shuning uchun UX'i alohida diqqat talab qiladi:
   - "Yangi provider qo'shish" formasi: Nomi, Turi (dropdown — TokenRouter/DeepSeek/Custom, tanlanganda `apiBase` mos qiymat bilan avtomatik to'ldiriladi), API kalit maydoni (standart holda yashirin, ko'z ikonkasi bilan ko'rsatish/yashirish), Model nomi, Max tokens, Temperature (slider, joriy qiymat ko'rinib turadi), Context length.
   - API kalit maydoni bo'sh holda saqlashga urinilganda, darhol (forma yuborilishidan oldin) "API kalit talab qilinadi" xabari chiqadi — serverdan xato qaytgunicha kutilmaydi.
   - Kalit muvaffaqiyatli saqlangach, aniq vizual tasdiqlash (masalan qisqa "✅ Saqlandi" holati yoki avtomatik ro'yxatga qaytish + snackbar).
   - Provider ro'yxatida har bir karta: nomi, turi, faol/nofaol holati aniq ko'rinadi; API kalitning o'zi hech qachon ochiq matnda ro'yxatda ko'rsatilmaydi (faqat oxirgi 4 belgisi, masalan `sk-...a91f`).
2. "Test qilish" tugmasi — provider'ga qisqa so'rov yuborib ✅/❌ ko'rsatadi, so'rov davomida albatta yuklanish indikatori ko'rsatiladi (tugma bosilgach hech narsa o'zgarmasdan turib qolmaydi).
3. Retrofit orqali `/chat/completions` (OpenAI-compatible) chaqiruvi, streaming'siz, oddiy request-response.
4. `ChatScreen` — xabar yuborish, javob olish, kod bloklarini monospace formatda ko'rsatish (oddiy syntax highlighting shart emas, keyinroq qo'shiladi).
5. Xatolik holatlari: tarmoq yo'q, 401, 429, timeout — har biriga alohida, tushunarli xabar.
6. Fayl tanlab chatga biriktirish (Faza 2'dagi FileTreeScreen bilan bog'lash) — tanlangan fayl matni foydalanuvchi xabariga context sifatida qo'shiladi.

**TEKSHIRUV TALABI:**
- Haqiqiy API kalit bilan test qilinganda, provider javob qaytarishi kerak (buni tasdiqlashning imkoni bo'lmasa, kamida mock/test serverga so'rov ketishini logdan tasdiqla).
- 401 xatosi kelganda foydalanuvchiga tushunarli xabar chiqishi kerak, ilova crash bo'lmasligi kerak.
- `./gradlew build` xatosiz o'tishi SHART.
