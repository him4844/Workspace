# 01 — FAZA 1: Domain modellari va Colab arxitektura interfeysi

**Bu faylni FAZA 0 muvaffaqiyatli tugagach, ikkinchi xabar sifatida to'liq nusxalab yuboring.**

---

## AGENT UCHUN DOIMIY QOIDALAR (bu qism har bir faza faylida takrorlanadi — buzish taqiqlanadi)

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yozib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 1 — Domain modellari va Colab arxitektura interfeysi

**Maqsad:** Barcha asosiy data classlarni yaratish, jumladan Colab bilan ishlash uchun abstraktsiya qatlamini boshidanoq qo'shish (keyinroq to'ldiriladi, lekin interfeys hoziroq mavjud bo'lishi kerak).

**Vazifalar:**

1. `domain/model/` ichida quyidagi data classlarni yarat (aniq shu maydonlar bilan):

```kotlin
data class AiProvider(
    val id: String,
    val name: String,
    val type: ProviderType,
    val apiBase: String,
    val apiKey: String,
    val model: String,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.2f,
    val contextLength: Int = 128000,
    val isDefault: Boolean = false
)
enum class ProviderType { TOKENROUTER, DEEPSEEK, CUSTOM }

data class Workspace(
    val id: String,
    val name: String,
    val uri: String,
    val lastOpenedAt: Long
)

data class FileNode(
    val name: String,
    val uri: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val mimeType: String?,
    val children: List<FileNode> = emptyList()
)

data class ChatMessage(
    val id: String,
    val role: MessageRole,
    val content: String,
    val attachedFiles: List<String> = emptyList(),
    val proposedEdits: List<ProposedEdit> = emptyList(),
    val timestamp: Long
)
enum class MessageRole { USER, ASSISTANT, SYSTEM }

data class ProposedEdit(
    val filePath: String,
    val originalContent: String,
    val newContent: String,
    val status: EditStatus
)
enum class EditStatus { PENDING, ACCEPTED, REJECTED, APPLIED }

data class AppSettings(
    val activeProviderId: String?,
    val editMode: EditMode,
    val isDarkTheme: Boolean? = null,
    val maxFileContextSizeBytes: Int = 100_000,
    val executionPreference: ExecutionPreference = ExecutionPreference.COLAB_PRIMARY
)
enum class EditMode { ALWAYS_CONFIRM, AUTO_APPLY }
enum class ExecutionPreference { COLAB_PRIMARY, PHONE_ONLY }
```

2. **Colab arxitektura interfeysi** — hozircha faqat interfeys, implementatsiya keyingi fazada:

```kotlin
// domain/agent/ExecutionTarget.kt
enum class ExecutionTarget { PHONE, COLAB }

// domain/agent/ExecutionRouter.kt
interface ExecutionRouter {
    suspend fun decide(userRequest: String, phoneSpecs: PhoneSpecs): ExecutionTarget
}

data class PhoneSpecs(
    val ramMb: Long,
    val cpuCores: Int,
    val availableStorageMb: Long,
    val deviceModel: String
)

// domain/agent/RemoteExecutionEngine.kt — Colab tomonidagi ishlarni bajaradigan interfeys
interface RemoteExecutionEngine {
    suspend fun isAvailable(): Boolean
    suspend fun executeTask(task: RemoteTask): RemoteTaskResult
}

data class RemoteTask(
    val id: String,
    val command: String,          // masalan: "./gradlew assembleDebug"
    val workdir: String,
    val timeoutMs: Long = 300_000
)

data class RemoteTaskResult(
    val success: Boolean,
    val output: String,           // FAQAT natija — oraliq fayllar qaytarilmaydi
    val errorMessage: String? = null
)
```

3. `domain/agent/` ichida agent uchun asosiy holat modellari (implementatsiyasiz, faqat data class/enum):

```kotlin
enum class AgentState {
    IDLE, PLANNING, RUNNING_TOOL, WAITING_FOR_PERMISSION,
    WAITING_FOR_USER, APPLYING_EDIT, TESTING, COMPLETED, FAILED, CANCELLED
}

data class AgentLimits(
    val maxSteps: Int = 30,
    val maxToolCalls: Int = 50,
    val maxExecutionTimeMs: Long = 10 * 60 * 1000,
    val maxCommandOutputBytes: Long = 1_000_000
)
```

**MUHIM:** Bu fazada `ExecutionRouter` va `RemoteExecutionEngine` ning HAQIQIY implementatsiyasini yozma — faqat interfeys va data classlar. Haqiqiy Colab ulanishi Faza 5 da qo'shiladi. Bu yerda maqsad — arxitekturaning boshidanoq shu narsani hisobga olib qurilishi, keyin "yopishtirib qo'yilmasligi".

**TEKSHIRUV TALABI:** Barcha model va interfeys fayllari compile bo'lishi kerak (implementatsiya yo'qligi uchun xato bermasligi kerak — interfeyslar hali hech joyda ishlatilmagan). `./gradlew build` xatosiz o'tishi SHART.
