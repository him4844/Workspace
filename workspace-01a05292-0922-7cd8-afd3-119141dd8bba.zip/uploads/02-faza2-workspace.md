# 02 — FAZA 2: Workspace va fayl tizimi (SAF)

**Bu faylni FAZA 1 muvaffaqiyatli tugagach yuboring.**

---

## AGENT UCHUN DOIMIY QOIDALAR (bu qism har bir faza faylida takrorlanadi — buzish taqiqlanadi)

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yozib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 2 — Workspace va fayl tizimi (SAF)

**Maqsad:** Foydalanuvchi telefon papkasini tanlashi, fayl daraxtini ko'rishi.

**Vazifalar:**
1. `WorkspaceScreen`: bo'sh holatda "Papka tanlash" tugmasi, `ACTION_OPEN_DOCUMENT_TREE` orqali tanlash, `takePersistableUriPermission()` chaqirilishi SHART.
2. Tanlangan workspace DataStore'ga saqlanadi (`Workspace` model orqali).
3. Oldin saqlangan workspace'lar ro'yxati — card ko'rinishida, nomi + oxirgi ochilgan vaqti + o'chirish imkoniyati.
4. Agar saqlangan URI ruxsati yo'qolgan bo'lsa — aniq xabar va ro'yxatdan olib tashlash taklifi.
5. `FileTreeScreen`: `DocumentFile.fromTreeUri()` orqali ildizni olish, LazyColumn bilan ierarxik ko'rinish (expand/collapse), fayl hajmi va ikonkasi bilan.
6. Matn fayllari uchun oddiy preview (bottom sheet, monospace).
7. Fayl tanlash checkbox'i + "Tanlangan fayllar bilan chatga o'tish" FAB (hozircha faqat navigatsiya, chat keyingi fazada).

**TEKSHIRUV TALABI:**
- Papka tanlangach, ilova qayta ochilganda ruxsat saqlanib qolishi SHART (buni real qurilmada/emulyatorda tekshir: ilovani to'liq yop, qayta och, workspace hali ko'rinishi kerak).
- Fayl daraxti kamida 2 daraja chuqurlikdagi papkalarni to'g'ri ko'rsatishi kerak.
- `./gradlew build` xatosiz o'tishi SHART.
