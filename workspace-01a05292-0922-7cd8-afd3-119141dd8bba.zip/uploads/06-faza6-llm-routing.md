# 06 — FAZA 6: LLM asosidagi routing (Phone vs Colab)

**Bu faylni FAZA 5 muvaffaqiyatli tugagach yuboring.**

---

## AGENT UCHUN DOIMIY QOIDALAR (bu qism har bir faza faylida takrorlanadi — buzish taqiqlanadi)

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yozib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 6 — LLM asosidagi routing (Phone vs Colab)

**Maqsad:** Og'ir hisoblash vazifalarini (build, test, render va h.k.) LLM chaqiruvi orqali telefon yoki Colab'da bajarishni hal qilish.

**MUHIM CHEGARA — bu fazani boshlashdan oldin albatta o'qing:**
Telefondagi SAF workspace va Colab'dagi Google Drive papkasi — bu **ikki alohida, bog'lanmagan fayl tizimi**. Shu sababli:
- **Fayl o'qish/yozish amallari** (`read_file`, `write_file`, `create_file`, `delete_file`, `apply_patch` va Faza 4'dagi boshqa barcha SAF-asosidagi tool'lar) uchun LLM router **HECH QACHON** ishlatilmaydi va manba avtomatik tanlanmaydi. Buning o'rniga:
  - Chat/Workspace ekranida foydalanuvchi aniq tanlaydi: "Bu ish telefon fayllarida" yoki "Bu ish Colab/Drive fayllarida" (masalan kichik toggle yoki tanlov, workspace darajasida yoki suhbat darajasida — UI/UX qoidalariga mos, aniq va tushunarli qilib joylashtiring).
  - Agent hech qachon o'zi taxmin qilib, fayl amalini boshqa fayl tizimiga yubormaydi — bu foydalanuvchining fayllarini noto'g'ri joyda o'zgartirish xavfini oldini oladi.
  - Agar Colab manba tanlangan bo'lsa, fayl amallari `ColabExecutionEngine` orqali (masalan `cat`, `ls`, shell orqali) Drive workspace papkasida bajariladi; agar telefon tanlangan bo'lsa, Faza 4'dagi mavjud SAF yo'li ishlatiladi.
- **LLM asosidagi router faqat quyidagilar uchun ishlaydi:** build/compile buyruqlari, test ishga tushirish, render, va boshqa aniq "hisoblash vazifasi" bo'lgan, muayyan bitta fayl tizimiga bog'liq bo'lmagan buyruqlar (bular asosan Faza 7-8'da to'liq ishga tushadi, lekin router mexanizmi shu fazada quriladi).

**Vazifalar:**

1. `ExecutionRouter` interfeysining haqiqiy implementatsiyasi (`LlmExecutionRouter`) — **faqat hisoblash turidagi vazifalar uchun chaqiriladi, fayl o'qish/yozish tool'lari uchun emas** (yuqoridagi chegaraga qarang):
   - Har bir mos vazifadan oldin, quyidagi promptni faol AI provider'ga yuboradi:

```
Siz AI kodlash agentining "yo'naltiruvchi" (router) qismisiz. Vazifangiz —
foydalanuvchi so'rovini va telefon spetsifikatsiyasini tahlil qilib,
bajarish joyini aniqlash.

DIQQAT: Bu router faqat hisoblash vazifalari (build, test, render va
shunga o'xshash) uchun ishlatiladi. Fayl o'qish/yozish bu yerga kirmaydi.

ASOSIY QOIDA: Colab — standart bajarish joyi. Faqat quyidagi hollarda
telefonga o'ting:
- Colab orqali bajarib bo'lmaydigan ish (masalan, mahalliy qurilma
  sozlamalarini o'zgartirish, Termux-ga xos amallar)
- Vazifa juda yengil va telefon resurslari (RAM, CPU) yetarli, VA Colab'ga
  ulanish narxi ishning o'zidan qimmatga tushadigan holat

Kirish ma'lumotlari:
- Foydalanuvchi so'rovi: "{user_message}"
- Telefon spetsifikatsiyasi: RAM={ram}, CPU={cpu_cores} yadro,
  qurilma modeli={device_model}

Qoidalar:
1. Faqat bitta so'z bilan javob bering: "COLAB" yoki "PHONE"
2. Shubhali yoki noaniq holatlarda har doim "COLAB" tanlang
3. Hech qanday izoh yoki qo'shimcha matn yozmang

Javob:
```

   - Javobni parse qilish (`"COLAB"` yoki `"PHONE"` so'zini tekshirish, boshqa matn kelsa default `COLAB`)
2. `PhoneSpecs` — Android API orqali RAM, CPU yadrolari sonini bir marta ilova ishga tushganda olish (`ActivityManager.MemoryInfo`, `Runtime.availableProcessors()`), keshda saqlash.
3. **Fayl manbai tanlovi UI'si:** Workspace yoki Chat ekraniga foydalanuvchi uchun aniq, ko'rinadigan tanlov qo'shing (masalan segmented control: "📱 Telefon" / "☁️ Colab"). Bu tanlov joriy suhbat/vazifa uchun qaysi fayl tizimi ishlatilishini belgilaydi. Tanlov qilinmagan holatda, standart qiymat — telefon (chunki bu xavfsizroq va Colab ulanishini talab qilmaydi).
3b. **Loyihani ko'chirish (Phone ↔ Colab sync):** Foydalanuvchi joriy loyihani ikki yo'nalishda ham ko'chira olishi kerak — bu fayl manbai tanlovidan alohida, aniq bir marotabalik amal:
   - **"Telefondan Colab'ga yuborish"** — telefondagi SAF workspace'dagi barcha fayllar o'qilib, Colab serveriga (`/execute` orqali yoki alohida `/upload` endpoint orqali) yuboriladi va Drive workspace papkasiga yoziladi. Katta loyihalarda bu vaqt olishi mumkin — progress indikator (necha fayldan nechasi yuborilgani) ko'rsatilishi SHART.
   - **"Colab'dan telefonga olish"** — Drive workspace papkasidagi fayllar o'qilib, telefondagi SAF workspace'ga yoziladi. Bu amal fayllarni ustidan yozishi mumkinligi uchun, boshlashdan oldin aniq ogohlantirish va tasdiqlash dialogi ko'rsatiladi ("Telefondagi N ta fayl Colab versiyasi bilan almashtiriladi. Davom etilsinmi?").
   - Ikkala amal ham Settings yoki Workspace ekranida aniq, alohida tugmalar sifatida joylashtiriladi (masalan "🔄 Sinxronlash" bo'limi ostida ikkita tugma: "→ Colab'ga yuborish" / "← Colab'dan olish").
   - Amal davomida va tugagach aniq natija ko'rsatiladi: nechta fayl muvaffaqiyatli ko'chirilgani, xato bo'lgan fayllar (agar bo'lsa) ro'yxati bilan.
   - Bu amal **mavjud fayl manbai tanlovini o'zgartirmaydi** — masalan "Colab'ga yuborish" bosilgach, joriy ish hali ham foydalanuvchi tanlagan manbada davom etadi, avtomatik almashtirilmaydi.
4. Agent Controller'ga integratsiya: hisoblash turidagi vazifalar uchun `ExecutionRouter.decide()` chaqiriladi; fayl tool'lari uchun esa 3-banddagi foydalanuvchi tanloviga qaraladi — ikkalasi alohida mexanizm sifatida ishlaydi va aralashtirilmaydi.
5. **Fallback mantiq (faqat LLM router uchun):** agar router `COLAB` desa, lekin `isAvailable()` false qaytarsa (Colab ulanmagan/URL noto'g'ri) — agent avtomatik telefonga o'tishi va buni Agent Activity Log'da aniq ko'rsatishi kerak ("Colab mavjud emas, telefonda bajarilmoqda"). Agar foydalanuvchi fayl manbai sifatida Colab'ni tanlagan bo'lsa-yu, Colab ulanmagan bo'lsa — bu holda avtomatik telefonga O'TILMAYDI (chunki bu foydalanuvchining aniq tanlovi edi), buning o'rniga aniq xabar ko'rsatiladi: "Colab ulanmagan — Sozlamalardan ulanishni tekshiring, yoki fayl manbaini Telefon'ga o'zgartiring".
6. Agent Task UI paneliga "Bajarilish joyi: Colab" / "Bajarilish joyi: Telefon" indikatori qo'shish, har bir hisoblash vazifasi yonida (fayl amallari uchun esa foydalanuvchining tanlagan manbai doimiy ko'rinadi, masalan ekran yuqorisida kichik belgi bilan).

**TEKSHIRUV TALABI:**
- Og'ir hisoblash so'rovi (masalan "loyihani build qil") berilganda, router "COLAB" javobini qaytarishi va agentning Colab yo'nalishidan foydalanishi kerak (Colab ulanmagan bo'lsa — telefon fallback ishlashi va bu foydalanuvchiga ko'rsatilishi kerak).
- Fayl o'qish/yozish so'ralganda, LLM router HECH QACHON chaqirilmasligi va foydalanuvchi tanlagan manba (telefon yoki Colab) ishlatilishi SHART — buni kodni o'qib tasdiqla.
- Foydalanuvchi Colab'ni fayl manbai sifatida tanlagan, lekin Colab ulanmagan holatda, avtomatik telefonga o'tilmasligi va aniq xabar chiqishi SHART.
- "Telefondan Colab'ga yuborish" va "Colab'dan telefonga olish" amallari ikkalasi ham ishlashi, progress ko'rsatilishi, va "Colab'dan olish" amali tasdiqlash dialogisiz boshlanmasligi SHART.
- `./gradlew build` xatosiz o'tishi SHART.
