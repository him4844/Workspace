# Android AI Coding Agent — Fazalarga bo'lingan qurish spetsifikatsiyasi

**Qanday ishlatish:** Har bir "FAZA" ni alohida xabar sifatida, ketma-ket, agentga yuboring. Har fazadan oldin agent PROGRESS_LOG.md faylini o'qishi SHART (Faza 0'dan keyin bu fayl mavjud bo'ladi). Har faza oxirida agent shu faylni yangilashi SHART. Keyingi fazani yubormasdan oldin, agentning shu fazadagi "TEKSHIRUV NATIJASI" bo'limini o'qib, muvaffaqiyatli tugallanganini tasdiqlang.

---

## AGENT UCHUN DOIMIY QOIDALAR (har bir faza xabariga qo'shib yuboriladi)

Bu qoidalar barcha fazalarda amal qiladi. Ularni buzish taqiqlanadi:

1. **Kontekst uzluksizligi:** Har faza boshida, hech narsa yozishdan oldin, `PROGRESS_LOG.md` faylini to'liq o'qi. U yerda oldingi fazalarda nima qilinganini, qanday qaror qabul qilinganini, va qaysi fayllar yaratilganini yoz ib qo'yilgan. Agar bu fayl mavjud bo'lmasa (faqat Faza 0'da), uni shu fazada yarat.
2. **Har faza oxirida majburiy yozish:** Faza tugagach, `PROGRESS_LOG.md` ga quyidagilarni qo'sh (eskisini o'chirmasdan, faqat qo'shib bor):
   - Faza raqami va sanasi
   - Yaratilgan/o'zgartirilgan fayllar ro'yxati (to'liq yo'l bilan)
   - Qabul qilingan muhim texnik qarorlar (masalan: "Retrofit URL manzili X sabab bilan Y qilib belgilandi")
   - Ma'lum bo'lgan cheklovlar yoki keyingi fazaga qoldirilgan narsalar
   - TEKSHIRUV NATIJASI (pastga qarang)
3. **Hech narsani soxta qilib ko'rsatma:** `// TODO: implement` yoki `return "success"` kabi soxta kod yozib, buni "bajarildi" deb hisoblash QATIYAN TAQIQLANADI. Agar biror narsa Android platformasi cheklovi sababli to'liq bajarilmasa — buni ANIQ yoz (qaysi faylda, nima sababdan), placeholder UI qoldirish mumkin, lekin buni hech qachon "tayyor" deb belgilama.
4. **Har faza oxirida MAJBURIY tekshiruv:** Faza kodini yozib bo'lgach, quyidagilarni bajar:
   - Loyihani compile qil (`./gradlew build` yoki mos buyruq). Xato bo'lsa — shu fazada tuzat, keyingi fazaga o'tma.
   - Shu fazada yaratilgan har bir yangi ekran/funksiya uchun qisqa qo'lda tekshirish ro'yxatini o'zing bajarganday tasavvur qil va natijani yoz (masalan: "WorkspaceScreen ochilganda bo'sh holat ko'rinadimi — HA/YO'Q").
   - Agar avvalgi fazada yozilgan kodni shu faza buzgan bo'lsa (masalan yangi model maydoni qo'shilib, eski kod compile bo'lmay qolsa) — buni albatta tuzat, sukut saqlama.
   - Javobing oxirida aniq "TEKSHIRUV NATIJASI:" degan bo'lim yoz — nima ishladi, nima ishlamadi, nima keyingi fazaga qoldirildi.
5. **Faza chegarasidan chiqma:** Faqat shu faza uchun so'ralgan narsani qil. Keyingi fazalarga tegishli narsalarni oldindan yozib qo'yish — kontekstni behuda sarflaydi va keyingi fazada ziddiyat yaratadi.
6. **Savol berish huquqi:** Agar spetsifikatsiyada noaniqlik bo'lsa, eng oddiy va ishonchli variantni tanla, buni PROGRESS_LOG.md ga "QARORLAR" sifatida yoz va davom et. Faqat hal qiluvchi arxitektura tanlovi bo'lsa (masalan butunlay boshqa kutubxona), to'xtab so'ra.
7. **Fayl hajmi:** Bitta faylni 400 qatordan oshirma — agar funksiya katta bo'lsa, mantiqiy qismlarga bo'l (masalan alohida UseCase classlar).
8. **UI/UX standartlari — MAJBURIY, har bir ekran uchun:** Ilova "yaxshi ishlaydi" darajasida emas, "yaxshi ishlatishga yoqimli" darajasida bo'lishi SHART. Har bir yangi ekran yoki komponent yaratilganda, quyidagi ro'yxat albatta tekshiriladi va TEKSHIRUV NATIJASI'da har biriga alohida javob beriladi (bor/yo'q):
   - **Bo'sh holat (empty state):** Har bir ro'yxat/ekran, ma'lumot bo'lmaganda, tushunarli tasvir + matn + (agar tegishli bo'lsa) harakat tugmasi bilan ko'rsatiladi — hech qachon oddiy bo'sh oq ekran qoldirilmaydi.
   - **Yuklanish holati (loading state):** Har bir tarmoq/fayl operatsiyasi paytida skeleton loader yoki progress indikator ko'rsatiladi — hech qachon ekran "muzlab qolganday" ko'rinmaydi.
   - **Xatolik holati (error state):** Har bir xatolik foydalanuvchiga tushunarli tilda, texnik jargon'siz tushuntiriladi, va imkon qadar "Qayta urinish" harakati beriladi.
   - **Tasdiqlash va halokatli amallar:** Fayl o'chirish, workspace o'chirish, rollback kabi qaytarib bo'lmaydigan amallar har doim tasdiqlash dialogi orqali o'tadi.
   - **Teginish nishonlari (touch targets):** Barcha tugma/interaktiv elementlar kamida 48dp balandlik/kenglikda bo'ladi — kichik, bosish qiyin elementlar taqiqlanadi.
   - **Fikr-mulohaza (feedback):** Har bir foydalanuvchi amali (tugma bosish, fayl saqlash, nusxalash) darhol vizual javob beradi (masalan qisqa animatsiya, snackbar, holat o'zgarishi) — "bosdimmi-bosmadimmi" degan noaniqlik bo'lmaydi.
   - **Izchillik (consistency):** Rang, shrift, bo'shliq (spacing), ikonka uslubi butun ilova bo'ylab bir xil bo'ladi — Material 3 dizayn tizimidan chetga chiqilmaydi, o'z ixtiyoricha uslub aralashtirilmaydi.
   - **Kognitiv yuk:** Bir ekranda haddan tashqari ko'p tugma/opsiya ko'rsatilmaydi — murakkab sozlamalar (masalan Agent Limits) "Ilg'or sozlamalar" ostiga yashiriladi, oddiy foydalanuvchi uchun asosiy oqim toza va sodda qoladi.
   - **Xavfsiz-standart qiymatlar:** Har bir sozlama, birinchi marta ochilganda, eng xavfsiz va tushunarli qiymatga ega bo'ladi (masalan tahrirlash rejimi default holda `ALWAYS_CONFIRM`, `FULL_AUTO` emas).
   - **Klaviatura va matn kiritish:** API kalit kabi maydonlarda mos klaviatura turi, ko'rsatish/yashirish (👁) tugmasi, va noto'g'ri kiritilganda darhol (submit qilishdan oldin) validatsiya xabari beriladi.
   - **Orqaga qaytish va navigatsiya:** Har bir ekranda tizim "orqaga" tugmasi mantiqiy joyga olib boradi, foydalanuvchi hech qachon "qayerdaligini" yo'qotmaydi (masalan sarlavhalar, breadcrumb yoki aniq ekran nomi orqali).
   Agar biror ekranda yuqoridagilardan biri qo'llanilmasa (masalan "tasdiqlash dialogi" oddiy ma'lumot ekraniga tegishli emas), bu "qo'llanilmaydi" deb belgilanadi, lekin sukut saqlanib o'tkazib yuborilmaydi.

---

## FAZA 0 — Loyiha skeleti va PROGRESS_LOG tizimi

**Maqsad:** Bo'sh, lekin compile bo'ladigan Android loyihasini yaratish + progress kuzatuv tizimini o'rnatish.

**Vazifalar:**
1. Yangi Android loyiha yarat:
   - Package: `com.aiagent.mobile`
   - Min SDK 26, Target SDK eng so'nggi barqaror
   - Gradle Kotlin DSL, Jetpack Compose, Hilt
   - Bitta modul (`app`)
2. Quyidagi bo'sh papka strukturasini yarat (fayllar ichida hozircha faqat package deklaratsiyasi bo'lishi mumkin):
   ```
   domain/model/, domain/repository/, domain/usecase/
   domain/agent/, domain/tools/, domain/context/
   data/ai/, data/filesystem/, data/terminal/, data/git/, data/index/, data/database/, data/security/, data/colab/
   ui/workspace/, ui/files/, ui/chat/, ui/agent/, ui/diff/, ui/terminal/, ui/settings/, ui/history/
   ```
   (`data/colab/` — bu keyingi fazalarda Colab integratsiyasi uchun, hozircha bo'sh papka.)
3. Loyiha ildizida `PROGRESS_LOG.md` faylini yarat, quyidagi shablon bilan:
   ```markdown
   # PROGRESS LOG — Android AI Coding Agent

   Bu fayl loyihaning barcha fazalardagi tarixini saqlaydi. HAR FAZADAN OLDIN BUNI TO'LIQ O'QI.

   ## Umumiy arxitektura qarorlari
   (bu yerga o'zgarmas, butun loyihaga tegishli qarorlar yoziladi)

   ## Fazalar tarixi
   ---
   ```
4. Bo'sh `MainActivity` + minimal Compose Navigation skeleti (hozircha faqat "Hello" ekrani) yarat — shunchaki compile va ishga tushishini tasdiqlash uchun.
5. `build.gradle.kts` ga Faza 1-3 uchun kerak bo'ladigan asosiy dependencylarni qo'sh (Compose BOM, Navigation, Hilt, DataStore, Retrofit, OkHttp).

**TEKSHIRUV TALABI:** Loyiha xatosiz compile bo'lishi va emulator/qurilmada ochilib, "Hello" ekranini ko'rsatishi SHART. Shundan keyingina Faza 1 ga o'tiladi.

---

## FAZA 1 — Domain modellari va Colab arxitektura interfeysi

**Maqsad:** Barcha asosiy data classlarni yaratish, jumladan Colab bilan ishlash uchun abstraktsiya qatlamini boshidanoq qo'shish (keyinroq to'ldiriladi, lekin interfeys hoziroq mavjud bo'lishi kerak).

**Vazifalar:**

1. `domain/model/` ichida quyidagi data classlarni yarat (aniq shu maydonlar bilan):

```kotlin
data class AiProvider(
    val id: String,
    val name: String,
    val type: ProviderType,
    val apiBase: String,
    val apiKey: String,
    val model: String,
    val maxTokens: Int = 4096,
    val temperature: Float = 0.2f,
    val contextLength: Int = 128000,
    val isDefault: Boolean = false
)
enum class ProviderType { TOKENROUTER, DEEPSEEK, CUSTOM }

data class Workspace(
    val id: String,
    val name: String,
    val uri: String,
    val lastOpenedAt: Long
)

data class FileNode(
    val name: String,
    val uri: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val mimeType: String?,
    val children: List<FileNode> = emptyList()
)

data class ChatMessage(
    val id: String,
    val role: MessageRole,
    val content: String,
    val attachedFiles: List<String> = emptyList(),
    val proposedEdits: List<ProposedEdit> = emptyList(),
    val timestamp: Long
)
enum class MessageRole { USER, ASSISTANT, SYSTEM }

data class ProposedEdit(
    val filePath: String,
    val originalContent: String,
    val newContent: String,
    val status: EditStatus
)
enum class EditStatus { PENDING, ACCEPTED, REJECTED, APPLIED }

data class AppSettings(
    val activeProviderId: String?,
    val editMode: EditMode,
    val isDarkTheme: Boolean? = null,
    val maxFileContextSizeBytes: Int = 100_000,
    val executionPreference: ExecutionPreference = ExecutionPreference.COLAB_PRIMARY
)
enum class EditMode { ALWAYS_CONFIRM, AUTO_APPLY }
enum class ExecutionPreference { COLAB_PRIMARY, PHONE_ONLY }
```

2. **Colab arxitektura interfeysi** — hozircha faqat interfeys, implementatsiya keyingi fazada:

```kotlin
// domain/agent/ExecutionTarget.kt
enum class ExecutionTarget { PHONE, COLAB }

// domain/agent/ExecutionRouter.kt
interface ExecutionRouter {
    suspend fun decide(userRequest: String, phoneSpecs: PhoneSpecs): ExecutionTarget
}

data class PhoneSpecs(
    val ramMb: Long,
    val cpuCores: Int,
    val availableStorageMb: Long,
    val deviceModel: String
)

// domain/agent/RemoteExecutionEngine.kt — Colab tomonidagi ishlarni bajaradigan interfeys
interface RemoteExecutionEngine {
    suspend fun isAvailable(): Boolean
    suspend fun executeTask(task: RemoteTask): RemoteTaskResult
}

data class RemoteTask(
    val id: String,
    val command: String,          // masalan: "./gradlew assembleDebug"
    val workdir: String,
    val timeoutMs: Long = 300_000
)

data class RemoteTaskResult(
    val success: Boolean,
    val output: String,           // FAQAT natija — oraliq fayllar qaytarilmaydi
    val errorMessage: String? = null
)
```

3. `domain/agent/` ichida agent uchun asosiy holat modellari (implementatsiyasiz, faqat data class/enum):

```kotlin
enum class AgentState {
    IDLE, PLANNING, RUNNING_TOOL, WAITING_FOR_PERMISSION,
    WAITING_FOR_USER, APPLYING_EDIT, TESTING, COMPLETED, FAILED, CANCELLED
}

data class AgentLimits(
    val maxSteps: Int = 30,
    val maxToolCalls: Int = 50,
    val maxExecutionTimeMs: Long = 10 * 60 * 1000,
    val maxCommandOutputBytes: Long = 1_000_000
)
```

**MUHIM:** Bu fazada `ExecutionRouter` va `RemoteExecutionEngine` ning HAQIQIY implementatsiyasini yozma — faqat interfeys va data classlar. Haqiqiy Colab ulanishi Faza 5 da qo'shiladi. Bu yerda maqsad — arxitekturaning boshidanoq shu narsani hisobga olib qurilishi, keyin "yopishtirib qo'yilmasligi".

**TEKSHIRUV TALABI:** Barcha model va interfeys fayllari compile bo'lishi kerak (implementatsiya yo'qligi uchun xato bermasligi kerak — interfeyslar hali hech joyda ishlatilmagan). `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 2 — Workspace va fayl tizimi (SAF)

**Maqsad:** Foydalanuvchi telefon papkasini tanlashi, fayl daraxtini ko'rishi.

**Vazifalar:**
1. `WorkspaceScreen`: bo'sh holatda "Papka tanlash" tugmasi, `ACTION_OPEN_DOCUMENT_TREE` orqali tanlash, `takePersistableUriPermission()` chaqirilishi SHART.
2. Tanlangan workspace DataStore'ga saqlanadi (`Workspace` model orqali).
3. Oldin saqlangan workspace'lar ro'yxati — card ko'rinishida, nomi + oxirgi ochilgan vaqti + o'chirish imkoniyati.
4. Agar saqlangan URI ruxsati yo'qolgan bo'lsa — aniq xabar va ro'yxatdan olib tashlash taklifi.
5. `FileTreeScreen`: `DocumentFile.fromTreeUri()` orqali ildizni olish, LazyColumn bilan ierarxik ko'rinish (expand/collapse), fayl hajmi va ikonkasi bilan.
6. Matn fayllari uchun oddiy preview (bottom sheet, monospace).
7. Fayl tanlash checkbox'i + "Tanlangan fayllar bilan chatga o'tish" FAB (hozircha faqat navigatsiya, chat keyingi fazada).

**TEKSHIRUV TALABI:**
- Papka tanlangach, ilova qayta ochilganda ruxsat saqlanib qolishi SHART (buni real qurilmada/emulyatorda tekshir: ilovani to'liq yop, qayta och, workspace hali ko'rinishi kerak).
- Fayl daraxti kamida 2 daraja chuqurlikdagi papkalarni to'g'ri ko'rsatishi kerak.
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 3 — Provider sozlamalari va oddiy chat (tool calling'siz)

**Maqsad:** AI bilan oddiy matnli suhbat — hali agent emas, faqat chat.

**Vazifalar:**
1. `SettingsScreen` — provider qo'shish/tahrirlash/o'chirish/faollashtirish (`AiProvider` modeli asosida). API kalit `EncryptedSharedPreferences` orqali saqlanadi. Bu — foydalanuvchi API kalitni kiritadigan asosiy joy, shuning uchun UX'i alohida diqqat talab qiladi:
   - "Yangi provider qo'shish" formasi: Nomi, Turi (dropdown — TokenRouter/DeepSeek/Custom, tanlanganda `apiBase` mos qiymat bilan avtomatik to'ldiriladi), API kalit maydoni (standart holda yashirin, ko'z ikonkasi bilan ko'rsatish/yashirish), Model nomi, Max tokens, Temperature (slider, joriy qiymat ko'rinib turadi), Context length.
   - API kalit maydoni bo'sh holda saqlashga urinilganda, darhol (forma yuborilishidan oldin) "API kalit talab qilinadi" xabari chiqadi — serverdan xato qaytgunicha kutilmaydi.
   - Kalit muvaffaqiyatli saqlangach, aniq vizual tasdiqlash (masalan qisqa "✅ Saqlandi" holati yoki avtomatik ro'yxatga qaytish + snackbar).
   - Provider ro'yxatida har bir karta: nomi, turi, faol/nofaol holati aniq ko'rinadi; API kalitning o'zi hech qachon ochiq matnda ro'yxatda ko'rsatilmaydi (faqat oxirgi 4 belgisi, masalan `sk-...a91f`).
2. "Test qilish" tugmasi — provider'ga qisqa so'rov yuborib ✅/❌ ko'rsatadi, so'rov davomida albatta yuklanish indikatori ko'rsatiladi (tugma bosilgach hech narsa o'zgarmasdan turib qolmaydi).
3. Retrofit orqali `/chat/completions` (OpenAI-compatible) chaqiruvi, streaming'siz, oddiy request-response.
4. `ChatScreen` — xabar yuborish, javob olish, kod bloklarini monospace formatda ko'rsatish (oddiy syntax highlighting shart emas, keyinroq qo'shiladi).
5. Xatolik holatlari: tarmoq yo'q, 401, 429, timeout — har biriga alohida, tushunarli xabar.
6. Fayl tanlab chatga biriktirish (Faza 2'dagi FileTreeScreen bilan bog'lash) — tanlangan fayl matni foydalanuvchi xabariga context sifatida qo'shiladi.

**TEKSHIRUV TALABI:**
- Haqiqiy API kalit bilan test qilinganda, provider javob qaytarishi kerak (buni tasdiqlashning imkoni bo'lmasa, kamida mock/test serverga so'rov ketishini logdan tasdiqla).
- 401 xatosi kelganda foydalanuvchiga tushunarli xabar chiqishi kerak, ilova crash bo'lmasligi kerak.
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 4 — Tool system va lokal agent loop (faqat telefon)

**Maqsad:** Oddiy chatni haqiqiy agentga aylantirish — lekin hali faqat telefon fayllari ustida ishlaydi, Colab yo'q.

**Vazifalar:**
1. Tool schema va `ToolResult` sealed class:
```kotlin
sealed class ToolResult {
    data class Success(val output: String) : ToolResult()
    data class Error(val message: String, val recoverable: Boolean) : ToolResult()
    data class PermissionRequired(val description: String) : ToolResult()
}
```
2. File tools implementatsiyasi: `list_directory`, `read_file`, `write_file`, `create_file`, `delete_file`, `move_file`, `copy_file`, `get_file_info` — barchasi SAF orqali, telefon xotirasida ishlaydi.
3. Search tools (oddiy versiya): `search_files`, `search_text` — hozircha oddiy string qidiruv, index yo'q.
4. `apply_patch`, `replace_text`, `insert_text` — patch-based editing, checksum tekshiruvi bilan (fayl AI o'qigandan keyin tashqaridan o'zgargan bo'lsa, conflict ko'rsatiladi).
5. Agent Controller: `AgentState` transitions, `AgentLimits` qo'llanilishi, "Stop Agent" tugmasi.
6. Agent Loop: so'rov → tool tanlash → bajarish → natija AI'ga qaytarish → keyingi qadam, `Faza 4` uchun bosqichlar `domain/agent/`da yoziladi (11.4-bo'lim mantiqiy ketma-ketligi).
7. Diff ekrani: `java-diff-utils` orqali, qo'shilgan/o'chirilgan qatorlar rangli ko'rsatilishi, "Qabul qilish"/"Rad etish".
8. `AUTO_APPLY` rejimida Edit History buffer (oxirgi 10 ta), Undo imkoniyati.

**MUHIM:** Bu fazada `ExecutionRouter` hali chaqirilmaydi — barcha tool'lar to'g'ridan-to'g'ri telefonda ishlaydi. Colab yo'nalishi Faza 5 va 6 da qo'shiladi.

**TEKSHIRUV TALABI:**
- Oddiy so'rov ("Python nima?") uchun agent hech qanday tool chaqirmasligi kerak — faqat javob berishi kerak.
- Fayl bilan bog'liq so'rov ("shu papkadagi fayllarni ko'rsat") uchun agent `list_directory` tool'ini chaqirishi va natijani to'g'ri ko'rsatishi kerak.
- Bitta faylni tahrirlash so'ralganda, Diff ekrani to'g'ri qatorlarni ko'rsatishi va "Qabul qilish" bosilganda haqiqatan faylga yozilishi SHART (buni fayl mazmunini o'qib tasdiqla).
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 5 — Colab backend: server va ulanish

**Maqsad:** Google Colab tomonida ishlaydigan serverni yaratish va Android ilovasidan unga ulanishni ta'minlash. Bu fazada faqat ULANISH qurilady — routing mantig'i Faza 6 da.

**Vazifalar:**

1. **Colab notebook shabloni** (alohida `.ipynb` fayl yoki hujjatlashtirilgan kod bloklari sifatida, loyihaning `/colab/` papkasida saqlansin):
   - Google Drive mount qilish (`drive.mount('/content/drive')`)
   - Loyiha papkasi Drive'da: `/content/drive/MyDrive/AiAgentWorkspace/`
   - Oddiy FastAPI server, quyidagi endpoint'lar bilan:
     - `POST /execute` — buyruq bajarish (masalan `./gradlew assembleDebug`), faqat natija (stdout/stderr, exit code) qaytaradi
     - `GET /health` — server ishlab turganini tekshirish
   - `pyngrok` yoki shunga o'xshash orqali tashqi URL generatsiya qilish, uni notebook chiqishida aniq ko'rsatish

2. **Android tomonida `data/colab/` implementatsiyasi:**
   - `RemoteExecutionEngine` interfeysining haqiqiy implementatsiyasi (`ColabExecutionEngine`) — Faza 1'da yaratilgan interfeys asosida
   - Retrofit orqali Colab serveriga so'rov yuborish
   - Settings ekraniga "Colab URL" maydoni qo'shish (foydalanuvchi ngrok havolasini qo'lda kiritadi)
   - `isAvailable()` — `/health` endpoint orqali ulanishni tekshirish, Settings ekranida "✅ Ulangan" / "❌ Ulanmagan" holatini ko'rsatish

3. **Faqat natija qaytarish printsipi:** `RemoteTaskResult` faqat `success`, `output` (matn — log/xato xabari), va `errorMessage` maydonlarini o'z ichiga oladi. Oraliq fayllar, build artifaktlari yoki boshqa katta ma'lumotlar Android'ga QAYTARILMAYDI — agar foydalanuvchiga fayl kerak bo'lsa (masalan tayyor APK), alohida "natijani yuklab olish havolasi" (Drive link) qaytariladi, fayl o'zi emas.

**TEKSHIRUV TALABI:**
- Colab notebook ishga tushirilganda, ngrok URL generatsiya qilinishi va shu URL orqali `/health` so'roviga javob qaytishi kerak (buni real Colab hisobida sinab ko'rish tavsiya etiladi, lekin kamida kod xatosiz yozilgan va mantiqiy to'g'ri bo'lishi SHART).
- Android tomonida Settings ekranida Colab URL kiritilib, "Ulanishni tekshirish" bosilganda to'g'ri holat ko'rsatilishi kerak.
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 6 — LLM asosidagi routing (Phone vs Colab)

**Maqsad:** Agentning o'zi, LLM chaqiruvi orqali, har bir vazifani telefonda yoki Colab'da bajarishni hal qilishi.

**Vazifalar:**

1. `ExecutionRouter` interfeysining haqiqiy implementatsiyasi (`LlmExecutionRouter`):
   - Har bir agent vazifasidan oldin, quyidagi promptni faol AI provider'ga yuboradi:

```
Siz AI kodlash agentining "yo'naltiruvchi" (router) qismisiz. Vazifangiz —
foydalanuvchi so'rovini va telefon spetsifikatsiyasini tahlil qilib,
bajarish joyini aniqlash.

ASOSIY QOIDA: Colab — standart bajarish joyi. Faqat quyidagi hollarda
telefonga o'ting:
- Colab orqali bajarib bo'lmaydigan ish (masalan, telefonning o'z fayl
  tizimiga to'g'ridan-to'g'ri kirish, mahalliy qurilma sozlamalarini
  o'zgartirish, Termux-ga xos amallar)
- Vazifa juda yengil va telefon resurslari (RAM, CPU) yetarli, VA Colab'ga
  ulanish/fayl yuborish narxi ishning o'zidan qimmatga tushadigan holat
  (masalan bitta qatorli matn o'zgartirish)

Kirish ma'lumotlari:
- Foydalanuvchi so'rovi: "{user_message}"
- Telefon spetsifikatsiyasi: RAM={ram}, CPU={cpu_cores} yadro,
  qurilma modeli={device_model}

Qoidalar:
1. Faqat bitta so'z bilan javob bering: "COLAB" yoki "PHONE"
2. Shubhali yoki noaniq holatlarda har doim "COLAB" tanlang
3. "PHONE" faqat quyidagi holatlarda: (a) vazifa faqat telefonda
   bajarilishi texnik jihatdan mumkin, yoki (b) vazifa shunchalik
   yengilki, Colab'ga murojaat qilish ortiqcha
4. Hech qanday izoh yoki qo'shimcha matn yozmang

Javob:
```

   - Javobni parse qilish (`"COLAB"` yoki `"PHONE"` so'zini tekshirish, boshqa matn kelsa default `COLAB`)
2. `PhoneSpecs` — Android API orqali RAM, CPU yadrolari sonini bir marta ilova ishga tushganda olish (`ActivityManager.MemoryInfo`, `Runtime.availableProcessors()`), keshda saqlash.
3. Agent Controller'ga integratsiya: har bir tool chaqiruvidan oldin (yoki har agent step boshida) `ExecutionRouter.decide()` chaqiriladi, natijaga qarab tool `PHONE` yo'lidan (Faza 4'dagi mavjud implementatsiya) yoki `COLAB` yo'lidan (Faza 5'dagi `ColabExecutionEngine`) bajariladi.
4. **Fallback mantiq:** agar router `COLAB` desa, lekin `isAvailable()` false qaytarsa (Colab ulanmagan/URL noto'g'ri) — agent avtomatik telefonga o'tishi va buni Agent Activity Log'da aniq ko'rsatishi kerak ("Colab mavjud emas, telefonda bajarilmoqda").
5. Agent Task UI paneliga "Bajarilish joyi: Colab" / "Bajarilish joyi: Telefon" indikatori qo'shish, har bir tool chaqiruvi yonida.

**TEKSHIRUV TALABI:**
- Og'ir so'rov (masalan "loyihani build qil") berilganda, router "COLAB" javobini qaytarishi va agentning Colab yo'nalishidan foydalanishi kerak (Colab ulanmagan bo'lsa — telefon fallback ishlashi va bu foydalanuvchiga ko'rsatilishi kerak).
- Yengil so'rov (masalan "shu faylni ochib ber") uchun routerning qarori loglansin va mantiqiy bo'lsin.
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 7 — Terminal, Git va xavfsizlik

**Maqsad:** Termux integratsiyasi (fallback sifatida, Colab mavjud bo'lmaganda) + git + xavfsizlik choralari.

**Vazifalar:**
1. Termux orqali `run_command` tool — faqat Colab mavjud bo'lmaganda yoki router "PHONE" desa ishlatiladi (Faza 6'dagi routing bilan bog'lansin).
2. Command Security: `CommandRisk` (SAFE/MODERATE/DANGEROUS) klassifikatsiyasi, DANGEROUS buyruqlar uchun har doim confirmation (Colab'da ham, telefonda ham).
3. Git integration: Termux orqali (`git status`, `diff`, `log`, `commit`, va h.k.) — Git mavjud bo'lmagan loyihalarda talab qilinmaydi.
4. Checkpoint system: Git bo'lmagan hollarda lokal backup (o'zgartirilgan fayllar, original hash/kontent, timestamp), rollback imkoniyati.
5. Secret Protection: `.env`, `*.pem`, `*.key`, `keystore`, va h.k. fayllar AI contextiga avtomatik yuborilmasligi, SecretScanner orqali redact qilinishi.

**TEKSHIRUV TALABI:**
- `rm -rf` kabi xavfli buyruq so'ralganda, confirmation dialogisiz bajarilmasligi SHART (buni qo'lda sinab tasdiqla).
- `.env` fayli mavjud loyihada, AI context so'ralganda bu fayl tarkibi context'ga qo'shilmasligi kerak.
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 8 — Build/test feedback loop va avtomatik tuzatish

**Maqsad:** Agent build/test xatolarini o'zi tahlil qilib tuzatishi (Faza 6'dagi routing orqali — bu ish odatda Colab'da bajariladi).

**Vazifalar:**
1. Terminal Output → AI Feedback Loop: build/test natijasi (xususan xatolar) avtomatik AI'ga qaytariladi, tahlil qilinadi.
2. Automatic Test/Fix Loop: muvaffaqiyatsiz bo'lsa, `maxFixAttempts = 5` gacha avtomatik tuzatishga urinish, har urinish UI'da ko'rsatiladi ("Attempt 2/5").
3. 5 urinishdan keyin: "Agent could not resolve the problem automatically" + "View Error"/"Continue Manually".
4. Patch-based editing takomillashtirilishi: patch muvaffaqiyatsiz bo'lsa, fayl qayta o'qiladi, kontekst qayta hisoblanadi, AI'dan yangi patch so'raladi (max 3 marta).

**TEKSHIRUV TALABI:**
- Qasddan xato kiritilgan kichik loyihada (masalan import yo'q), agentga "build qilib xatoni tuzat" deyilganda, u xatoni topib, tuzatib, qayta build qilib, muvaffaqiyatga erishishi kerak — bu real senariy sifatida sinaladi.
- 5 urinishdan keyin ham hal bo'lmasa, foydalanuvchiga aniq xabar chiqishi SHART.
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 9 — Codebase index va smart context

**Maqsad:** Katta loyihalarda barcha fayllarni context'ga yubormaslik.

**Vazifalar:**
1. Codebase Indexer: Room database orqali fayl/symbol/class/function darajasida indekslash.
2. `find_symbol`, `find_references` tool'lari.
3. Smart File Context: kichik fayl to'liq, katta faylda faqat relevant qismlar (search → login → relevant file → relevant symbol ketma-ketligi bilan).
4. Context Manager: token budget boshqaruvi (system prompt/conversation/relevant code/tool results/reserve foizlari), context to'lganda eski suhbatni summary qilish.

**TEKSHIRUV TALABI:**
- 50+ fayldan iborat test loyihasida, "login funksiyasidagi xatoni tuzat" so'ralganda, agent BUTUN loyihani emas, faqat tegishli fayl(lar)ni context'ga olishi kerak (buni Agent Activity Log orqali tasdiqla).
- `./gradlew build` xatosiz o'tishi SHART.

---

## FAZA 10 — UX yakunlash va yakuniy sinov

**Maqsad:** Barcha qismlarni birlashtirib, to'liq ishlaydigan v1 sifatida yakunlash.

**Vazifalar:**
1. Planning Mode: murakkab tasklar uchun plan generatsiyasi va UI'da ko'rsatish.
2. Multi-file editing UI: Accept All / Reject All / Review Each.
3. Agent Task UI paneli: Stop/Pause/Resume/View Changes/Rollback — to'liq ishlaydigan holatda.
4. Streaming: AI javob va tool progress real-time ko'rsatilishi.
5. Cost/Token control UI: "Context: 48k/128k" ko'rsatkichi.
6. Barcha xato/loading/bo'sh holatlar, navigatsiya, tema (Material 3, Dark/Light/System) silliqlanishi.
7. **Yakuniy end-to-end sinov** (bu FAZA 10 ning eng muhim qismi):
   - Test senariysi: "Login ishlamayapti. Xatoni topib tuzat va test qil."
   - Agent: qidiradi → o'qiydi → plan tuzadi → checkpoint yaratadi → Colab/telefon routing qaror qiladi → o'zgartiradi → build/test qiladi → xato bo'lsa tuzatadi (max 5 marta) → natijani ko'rsatadi.
   - Bu butun oqim uzilishsiz ishlashi SHART — agar biror qadamda uzilish bo'lsa, bu FAZA 10 muvaffaqiyatsiz hisoblanadi va tuzatilmaguncha loyiha "tayyor" deb belgilanmaydi.

**TEKSHIRUV TALABI:**
- Yuqoridagi to'liq test senariysi kamida bitta real (yoki real'ga yaqin) loyihada oxirigacha ishlashi SHART.
- PROGRESS_LOG.md faylida barcha 10 ta fazaning xulosasi va "Ma'lum cheklovlar" bo'limi to'liq yozilgan bo'lishi kerak.
- `./gradlew build` xatosiz o'tishi SHART.

---

## Qo'shimcha eslatmalar (promptga nima yetishmayotgan edi)

Bu spetsifikatsiyani avvalgi (bitta yaxlit) versiyadan farqli qiladigan asosiy qo'shimchalar:

1. **PROGRESS_LOG.md** — bu eng muhim qo'shimcha. Avvalgi urinishda context yo'qolishi asosiy muammo bo'lgan; bu fayl har fazada o'qilib-yozilib, agentning "xotira" vazifasini bajaradi.
2. **Har faza uchun aniq TEKSHIRUV TALABI** — oldingi versiyada faqat oxirida umumiy "qabul mezonlari" bor edi. Endi har bosqichda tekshirish bor, xato keyingi fazaga o'tib ketmaydi.
3. **Colab boshidanoq arxitekturaga kiritilgan** (Faza 1) — lekin haqiqiy ulanish Faza 5-6 da, shu bilan keyinchalik "yopishtirib qo'yish" muammosi oldini olinadi.
4. **Fazalar kichikroq va mustaqil** — har biri alohida compile bo'ladigan, tekshiriladigan bosqich, LSP/RAG/multi-agent kabi "kelajak uchun tayyorgarlik" qismlari butunlay olib tashlangan (bular v1 uchun shart emas va murakkablikni oshiradi; agar kerak bo'lsa, alohida Faza 11+ sifatida keyin qo'shiladi).
5. **Ziddiyatlar oldindan hal qilingan** — Git haqidagi ziddiyat (avval "kerak emas" keyin "kerak") olib tashlandi, endi Faza 7 da bir marta, aniq shart bilan yoziladi.

Agar loyiha davomida yangi funksiya qo'shish kerak bo'lsa, uni alohida "Faza 11", "Faza 12" va h.k. sifatida, xuddi shu formatda (Maqsad → Vazifalar → TEKSHIRUV TALABI) yozib qo'shish tavsiya etiladi — asosiy 10 fazani o'zgartirmang.
